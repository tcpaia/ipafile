//
//  TSSAppData.m
//  TSSProject
//
//  Created by TSS on 15/12/11.
//  Copyright © 2015年 AIA. All rights reserved.
//

#import "TSSAppData.h"
#import "Singleton.h"
#import "SystemTss.h"

@implementation TSSAppData

SYNTHESIZE_SINGLETON_FOR_CLASS(TSSAppData)

@synthesize agentCode;
@synthesize agentPassword;
@synthesize deviceToken;
@synthesize touchOFF;

-(NSString*)randomId
{
    long long int timestamp = (long long int)([[NSDate date] timeIntervalSince1970]*1000);
    return FORMAT(@"%@-%lld", [TSSAppData getInstance].agentCode,timestamp);
}

- (instancetype)init {
    self = [super init];
    if (self) {
        //self.sslCertFile = @"uat_jfw_imo_sgp";
    }
    return self;
}

@end
