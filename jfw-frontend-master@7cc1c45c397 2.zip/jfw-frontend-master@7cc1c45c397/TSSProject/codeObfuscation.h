#ifndef Demo_codeObfuscation_h
#define Demo_codeObfuscation_h
//confuse string at Thu Apr 23 12:04:07 +08 2020
#define sslCertFile BbbuWVSKphtDzetO
#define agentPassword ERstohLYsxxSAtTi
#define masterKey EYEuavEMRmgDcPmu
#define deviceToken gpfGXdXDmVtRQSFz
#define agentJfwRole nwgEqxOlqREvIEWI
#define leaderCode LzerghnXgQKTIOfE
#define leaderName PDgPeRoGwZiTkiDg
#define addOrChangeFollowupandNote RDpKIKetepyWEOjT
#define iFollowUpBean CjYbydlDVmyjdDIr
#define aCustomerBean SkmfPboQSnXoqdVM
#define nominatedPardterArray IATTFkQGoRrUTbbh
#define hiddenCalendar MbbZVsciDSHixWmx
#define followUpAndNoteBean IneCmcbJTPbJkNpu
#define FSCCode JMWETdpHHQXDoqzY
#define FSCName XKjiMgpGdltYjVZW
#define icNo UXZCoZVhlFtoFZwX
#define rnfCode owcpqKbuTVPvhgMJ
#define qualifications ViqmEOgXuKYnVIXu
#define contactNo XKascaUZYeLWcnlG
#define timeBomb vfQOwmWsJgdCowKu
#define channel AuqEREfXSnIzycls
#define contractCd WwviHbuQLaIGydbN
#define appVersion SoTtdnePHjkIWqbT
#define FSCPhoto MKnYlzipehTxvgKw
#define lastPasswordCreationTime AMSXtwsEbRRUgaXH
#define lastLoginTime siOHRmNXGmJeAnHr
#define token2fa pjmbHeByrhrshkDI
#define licensesString pvBQnqJcwGfOIcFV
#define servertimestampString vdINCkrfMTGSYXPZ
#define licenses idzPbbKsInmbowcX
#define isBankOrBrokerUser SRTDYKIAVAvXDnqu
#define activationType ApdAPPqPEUTxlbWE
#define activationFscObj KQPLXVoPgplJwcLb
#define isSubmitForm ZERFfdhplwNtvMnO
#define didActivated NewPKbFQFwjJrTzf
#define iWebView ysqpiFkrCGkvghRE
#define openingStatus qdPwZIGbnOTlAVYX
#define closingStatus VGRxRejXZZSVQYkX
#define generalStatus dFksoUQucnAwcedQ
#define downLoadAppointmentEvent IfFiVWQGYoIrGxzZ
#endif
