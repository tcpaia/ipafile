//
//  NominatedCadidateBean.h
//  TSSProject
//
//  Created by WFF on 22/10/2017.
//  Copyright © 2017 AIA. All rights reserved.
//

#import "Bean.h"

#define NOMINATED_CADIDATE_TABLE_NAME   @"NominatedCadidate"
@interface NominatedCadidateBean : Bean

@property (nonatomic, retain) NSString *nominatedCode;
@property (nonatomic, retain) NSString *nominatedName;
@property (nonatomic, retain) NSString *nominatedAgencyCode;
@property (nonatomic, retain) NSString *nominatedDistrictCode;

- (NSString *) descriptionForShow;

@end
