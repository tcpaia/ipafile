//
//  LanguageBean.m
//  TSSProject
//
//  Created by TSS on 16/5/25.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import "LanguageBean.h"

@implementation LanguageBean

@end
