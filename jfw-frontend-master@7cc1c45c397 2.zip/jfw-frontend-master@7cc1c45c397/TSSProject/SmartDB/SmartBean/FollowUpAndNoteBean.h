//
//  FollowUpAndNoteBean.h
//  TSSProject
//
//  Created by TSS on 16/7/7.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Bean.h"

#define	FOLLOWUP_TABLE_NAME @"FollowUp"

@interface FollowUpAndNoteBean : Bean

@property (nonatomic, retain) NSString *customerId;
@property (nonatomic, retain) NSString *eventDescription;
@property (nonatomic, retain) NSString *eventTitle;
@property (nonatomic, retain) NSString *type;
@property (nonatomic, retain) NSString *notifyTime;
@property (nonatomic, retain) NSString *location;
@property (nonatomic, retain) NSString *style;
@property (nonatomic, retain) NSNumber *meettingDate;
@property (nonatomic, retain) NSNumber *startDate;
@property (nonatomic, retain) NSNumber *endDate;
@property (nonatomic, retain) NSString *other;
@property (nonatomic, retain) NSString *calendarId;
@property (nonatomic, retain) NSString *calendarStyle;
@end
