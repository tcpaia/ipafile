//
//  CustomerInfoBean.m
//  TSSProject
//
//  Created by TSS on 16/5/4.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import "CustomerInfoBean.h"
#import "CustomerInfoDao.h"
@interface CustomerInfoBean ()

@end

@implementation CustomerInfoBean

- (void)save
{
    [[CustomerInfoDao getInstance] saveOrUpdate:self];
}

@end
