//
//  NominatedPartnerBean.h
//  TSSProject
//
//  Created by WFF on 17/11/2017.
//  Copyright © 2017 AIA. All rights reserved.
//

#import "CustomerInfoBean.h"

#define NOMINATED_PARTNER_TABLE_NAME @"NominatedPartner"

@interface NominatedPartnerBean : CustomerInfoBean

@property (nonatomic, retain) NSString *partnerCode;
@property (nonatomic, retain) NSString *partnerName;

@end
