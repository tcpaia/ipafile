//
//  TrackerResultNewFscBean.h
//  TSSProject
//
//  Created by WFF on 2018/2/26.
//  Copyright © 2018 AIA. All rights reserved.
//

#import "Bean.h"

#define TRACKER_RESULT_NEW_FSC_TABLE_NAME @"TrackerResultNewFsc"

@interface TrackerResultNewFscBean : Bean

@property (nonatomic, retain) NSString *requestAgentCode;
@property (nonatomic, retain) NSString *requestAgentName;

@property (nonatomic, retain) NSString *agentCode;
@property (nonatomic, retain) NSString *agentName;
@property (nonatomic, retain) NSString *customerName;

@property (nonatomic, retain) NSString *category1;  //opening
@property (nonatomic, retain) NSString *dateLong1;

@property (nonatomic, retain) NSString *category2;  //closing
@property (nonatomic, retain) NSString *dateLong2;

- (NSString *) dateLong1Str;
- (NSString *) dateLong2Str;

@end
