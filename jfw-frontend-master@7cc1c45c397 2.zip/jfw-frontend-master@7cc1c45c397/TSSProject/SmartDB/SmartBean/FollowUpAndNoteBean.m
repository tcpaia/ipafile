//
//  FollowUpAndNoteBean.m
//  TSSProject
//
//  Created by TSS on 16/7/7.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import "FollowUpAndNoteBean.h"
#import "FollowUpAndNoteDao.h"

@implementation FollowUpAndNoteBean

- (void)save
{
    [[FollowUpAndNoteDao getInstance] saveOrUpdate:self];
}

@end
