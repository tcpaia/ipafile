//
//  NominatedCadidateBean.m
//  TSSProject
//
//  Created by WFF on 22/10/2017.
//  Copyright © 2017 AIA. All rights reserved.
//

#import "NominatedCadidateBean.h"
#import "NominatedCadidateDao.h"
#import "TSSValidationUtil.h"

@implementation NominatedCadidateBean

- (NSString *) descriptionForShow
{
    return [NSString stringWithFormat:@"%@ (%@)",[TSSValidationUtil convertNilToEmptyString:self.nominatedName], [TSSValidationUtil convertNilToEmptyString:self.nominatedCode]];
}

- (NSString *) description
{
    return [NSMutableString stringWithFormat: @"nominatedCode = %@, nominatedName = %@, nominatedAgencyCode = %@, nominatedDistrictCode = %@", self.nominatedCode, self.nominatedName, self.nominatedAgencyCode, self.nominatedDistrictCode];
}

- (void)save
{
    [[NominatedCadidateDao getInstance] saveOrUpdate:self];
}

- (void)delete
{
    [[NominatedCadidateDao getInstance] deleteWithID:self.idKey];
}
@end
