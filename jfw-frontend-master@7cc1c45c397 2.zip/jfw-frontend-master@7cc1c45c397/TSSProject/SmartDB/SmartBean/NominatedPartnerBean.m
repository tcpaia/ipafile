//
//  NominatedPartnerBean.m
//  TSSProject
//
//  Created by WFF on 17/11/2017.
//  Copyright © 2017 AIA. All rights reserved.
//

#import "NominatedPartnerBean.h"
#import "NominatedPartnerDao.h"
@implementation NominatedPartnerBean

- (void) save
{
    [[NominatedPartnerDao getInstance] saveOrUpdate:self];
}
@end
