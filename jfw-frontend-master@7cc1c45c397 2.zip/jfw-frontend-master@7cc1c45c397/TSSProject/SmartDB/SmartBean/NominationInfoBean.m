//
//  NominationInfoBean.m
//  TSSProject
//
//  Created by WFF on 22/10/2017.
//  Copyright © 2017 AIA. All rights reserved.
//

#import "NominationInfoBean.h"
#import "NominationInfoDao.h"

#import "NSDate+Ex.h"

@implementation NominationInfoBean

- (NSString *) description
{
    return [NSMutableString stringWithFormat: @"oid = %@, sponsorLeaderCode = %@, fscCode = %@, fscName = %@, assessorCode = %@, assessorName = %@, assessorStartDate = %@, assessorEndDate = %@, lastUpdateDateTimeLong = %@, deleteStatus = %@, uploadStatus = %@", self.oid, self.sponsorLeaderCode, self.fscCode, self.fscName, self.assessorCode, self.assessorName, self.assessorStartDate, self.assessorEndDate, self.lastUpdateDateTimeLong, self.deleteStatus, self.uploadStatus];
}

- (void)save
{
    [[NominationInfoDao getInstance] saveOrUpdate:self];
}

- (void)delete
{
    [[NominationInfoDao getInstance] deleteWithID:self.idKey];
}

- (NSString *) fscInfoStr
{
    return [NSString stringWithFormat: @"%@ (%@)", self.fscCode, self.fscName];
}

- (NSString *) assessorInfoStr
{
    return [NSString stringWithFormat: @"%@ (%@)", self.assessorCode, self.assessorName];
}

- (NSString *) assessorDateStr
{
    NSDate *startDate = [NSDate convertNumberToDateNoDateFormat: self.assessorStartDate];
    NSDate *endDate = [NSDate convertNumberToDateNoDateFormat: self.assessorEndDate];
    return [NSString stringWithFormat: @"%@ to %@ ", [startDate parseStringFormatDateTime:kNSDateFormatter16], [endDate parseStringFormatDateTime:kNSDateFormatter16]];
}

- (BOOL) isNominatedHistory
{
    NSTimeInterval now = [[NSDate date] timeIntervalSince1970];
    
    if (now - self.assessorStartDate.longLongValue > 0) {
        if ((now - self.assessorEndDate.longLongValue >= kSecondOfOneDay)) {
            return YES;
        }
    }
    return NO;
}
@end
