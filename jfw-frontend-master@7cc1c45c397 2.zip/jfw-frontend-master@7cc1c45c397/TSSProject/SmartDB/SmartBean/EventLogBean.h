//
//  EventLogBean.h
//  TSSProject
//
//  Created by TSS on 16/5/13.
//  Copyright © 2016年 AIA. All rights reserved.
//
#import "Bean.h"
#define	Event_Log_TABLE_NAME @"EventLog"

#define SMART_LOGIN @"smartLogin"
#define SMART_ADD_CUSTOMER @"addCustomer"

@interface EventLogBean : Bean

@property (nonatomic, retain) NSString *agentcode;
@property (nonatomic, retain) NSString *eventtype;
@property (nonatomic, retain) NSString *devicetype;
@property (nonatomic, retain) NSString *deviceosversion;
@property (nonatomic, retain) NSString *smartversion;

- (void)save;

@end