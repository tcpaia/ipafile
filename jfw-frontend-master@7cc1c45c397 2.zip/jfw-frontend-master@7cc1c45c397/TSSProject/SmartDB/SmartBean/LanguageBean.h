//
//  LanguageBean.h
//  TSSProject
//
//  Created by TSS on 16/5/25.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Bean.h"

@interface LanguageBean : Bean

@property (nonatomic, retain) NSString *LanguageCode;
@property (nonatomic, retain) NSString *LanguageStringID;
@property (nonatomic, retain) NSString *LanguageText;

@end
