//
//  AgentProfileBean.h
//  TSSProject
//
//  Created by TSS on 16/4/7.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import "Bean.h"
#define	AGENT_PROFILE_TABLE_NAME @"AgentProfile"

@interface AgentProfileBean : Bean

@property (nonatomic, retain) NSString *agentcode;
@property (nonatomic, retain) NSString *agencycode;
@property (nonatomic, retain) NSString *agentname;
@property (nonatomic, retain) NSString *agenttype;
@property (nonatomic, retain) NSString *agentlevelcode;
@property (nonatomic, retain) NSString *agentstatus;
@property (nonatomic, retain) NSString *agentcompanycode;
@property (nonatomic, retain) NSString *agentphoto;
@property (nonatomic, retain) NSString *agentlastlogintime;
@property (nonatomic, retain) NSString *isfirstlogin;
@property (nonatomic, retain) NSString *agentleadercode;
@property (nonatomic, retain) NSString *agentleadername;
@property (nonatomic, retain) NSString *branchcode;
@property (nonatomic, retain) NSString *agenttimebomb;
@property (nonatomic, retain) NSString *agentmasterkey;
@property (nonatomic, retain) NSString *jfwrole;
@property (nonatomic, retain) NSString *photoStatus;
@property (nonatomic, copy) NSString *setupManagerCode;
@property (nonatomic, copy) NSString *setupManagerName;
- (void)save;
@end
