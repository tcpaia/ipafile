//
//  AgentProfileBean.m
//  TSSProject
//
//  Created by TSS on 16/4/7.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import "AgentProfileBean.h"
#import "AgentProfileDao.h"

@implementation AgentProfileBean


- (void)save
{
    [[AgentProfileDao getInstance] saveOrUpdate:self];
}

@end
