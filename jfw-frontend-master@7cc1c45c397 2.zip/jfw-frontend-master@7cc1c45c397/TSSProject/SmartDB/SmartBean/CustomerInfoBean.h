//
//  CustomerInfoBean.h
//  TSSProject
//
//  Created by TSS on 16/5/4.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import "Bean.h"
#define	CUSTOMER_INFO_TABLE_NAME @"CustomerInfo"
@interface CustomerInfoBean : Bean

@property (nonatomic, retain) NSString *address;
@property (nonatomic, retain) NSString *age;
@property (nonatomic, retain) NSString *agentcode;
@property (nonatomic, retain) NSString *branch;
@property (nonatomic, retain) NSString *childrennum;
@property (nonatomic, retain) NSString *city;
@property (nonatomic, retain) NSString *companyname;
@property (nonatomic, retain) NSString *contacttype;
@property (nonatomic, retain) NSString *createby;
@property (nonatomic, retain) NSString *createddatetime;
@property (nonatomic, retain) NSString *createddatetimelong;
@property (nonatomic, retain) NSString *customerType;
@property (nonatomic, retain) NSString *dob;
@property (nonatomic, retain) NSString *email;
@property (nonatomic, retain) NSString *fullname;
@property (nonatomic, retain) NSString *gender;
@property (nonatomic, retain) NSString *internalId;
@property (nonatomic, retain) NSString *lastupdatedatetime;
@property (nonatomic, retain) NSString *lastupdatedatetimelong;
@property (nonatomic, retain) NSString *mobile;
@property (nonatomic, retain) NSString *maritalstatus;
@property (nonatomic, retain) NSString *occupationcode;
@property (nonatomic, retain) NSString *oid;
@property (nonatomic, retain) NSString *serialVersionUID;
@property (nonatomic, retain) NSString *smoker;
@property (nonatomic, retain) NSData *headerdata;
@property (nonatomic, retain) NSString *fromWhere;
@property (nonatomic, retain) NSString *uploadStatus;
@property (nonatomic, retain) NSString *latitude;
@property (nonatomic, retain) NSString *longitude;
@property (nonatomic, retain) NSString *distance;
@property (nonatomic, retain) NSString *internalRole;
@property (nonatomic, retain) NSString *status;
@property (nonatomic, retain) NSString *notes;
@property (nonatomic, retain) NSString *firstname;
@property (nonatomic, retain) NSString *lastname;
@property (nonatomic, retain) NSString *customerUuid;

- (void)save;

@end

