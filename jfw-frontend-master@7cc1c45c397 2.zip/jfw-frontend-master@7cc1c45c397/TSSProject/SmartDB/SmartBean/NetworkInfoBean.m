//
//  NetworkInfoBean.m
//  TSSProject
//
//  Created by WFF on 09/08/2017.
//  Copyright © 2017 AIA. All rights reserved.
//

#import "NetworkInfoBean.h"

@implementation NetworkInfoBean

- (NSString *) description
{
    return [NSMutableString stringWithFormat: @"buildVesion = %@, serverURL = %@, loginPageURL = %@, webServicesURL = %@, newsFeedURL = %@, nameSpace = %@", self.buildVesion, self.serverURL, self.loginPageURL, self.webServicesURL, self.newsFeedURL, self.nameSpace];
}
@end
