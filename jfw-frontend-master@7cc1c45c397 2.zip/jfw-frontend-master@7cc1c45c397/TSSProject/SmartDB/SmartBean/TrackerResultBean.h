//
//  TrackerResultBean.h
//  TSSProject
//
//  Created by WFF on 03/12/2017.
//  Copyright © 2017 AIA. All rights reserved.
//

#import "Bean.h"

#define TRACKER_RESULT_TABLE_NAME @"TrackerResult"

@interface TrackerResultBean : Bean

@property (nonatomic, retain) NSString *fscCode;
@property (nonatomic, retain) NSString *fscName;
@property (nonatomic, retain) NSString *month;
@property (nonatomic, retain) NSString *year;
@property (nonatomic, retain) NSNumber *trackerCount;

@end
