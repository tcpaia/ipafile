//
//  NominationInfoBean.h
//  TSSProject
//
//  Created by WFF on 22/10/2017.
//  Copyright © 2017 AIA. All rights reserved.
//

#import "Bean.h"

#define NOMINATIONINFO_TABLE_NAME   @"NominationInfo"
@interface NominationInfoBean : Bean

@property (nonatomic, retain) NSString *nominationInfoID;
@property (nonatomic, retain) NSString *oid;
@property (nonatomic, retain) NSString *sponsorLeaderCode;

@property (nonatomic, retain) NSString *fscCode;
@property (nonatomic, retain) NSString *fscName;
@property (nonatomic, retain) NSString *assessorCode;
@property (nonatomic, retain) NSString *assessorName;

@property (nonatomic, retain) NSNumber *assessorStartDate;
@property (nonatomic, retain) NSNumber *assessorEndDate;

@property (nonatomic, retain) NSString *createDateTimeLong;
@property (nonatomic, retain) NSString *lastUpdateDateTimeLong;
@property (nonatomic, retain) NSString *deleteStatus;
@property (nonatomic, retain) NSString *uploadStatus;

- (NSString *) fscInfoStr;
- (NSString *) assessorInfoStr;
- (NSString *) assessorDateStr;
- (BOOL) isNominatedHistory;

- (void)delete;
- (void)save;
@end
