//
//  TrackerResultNewFscBean.m
//  TSSProject
//
//  Created by WFF on 2018/2/26.
//  Copyright © 2018 AIA. All rights reserved.
//

#import "TrackerResultNewFscBean.h"
#import "SystemTss.h"

#import "NSDate+Ex.h"

@implementation TrackerResultNewFscBean

- (NSString *) dateLong1Str
{
    return [self buildDateShowStrByDateLong: self.dateLong1];
}

- (NSString *) dateLong2Str
{
    return [self buildDateShowStrByDateLong: self.dateLong2];
}

- (NSString *) buildDateShowStrByDateLong: (NSString*) dateLong
{
    if (dateLong == nil || dateLong.length < 1) {
        return @"-";
    } else if ([dateLong isEqualToString: IMO_SMART_NO]) {
        return @"-";
    } else {
        NSNumber *tempNumber = [NSNumber numberWithLongLong:[dateLong longLongValue]/1000];
        NSDate *startDate = [NSDate convertNumberToDateNoDateFormat: tempNumber];
        return [startDate parseStringFormatDateTime:kNSDateFormatter22];
    }
}
@end
