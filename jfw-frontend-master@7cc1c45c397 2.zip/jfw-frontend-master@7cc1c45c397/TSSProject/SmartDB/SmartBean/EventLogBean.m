//
//  EventLogBean.m
//  TSSProject
//
//  Created by TSS on 16/5/13.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import "EventLogBean.h"
#import "EventLogDao.h"
@interface EventLogBean ()

@end
@implementation EventLogBean

- (void)save
{
    [[EventLogDao getInstance] saveOrUpdate:self];
}

@end