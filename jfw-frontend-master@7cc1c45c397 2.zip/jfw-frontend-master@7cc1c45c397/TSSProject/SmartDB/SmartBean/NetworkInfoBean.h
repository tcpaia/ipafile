//
//  NetworkInfoBean.h
//  TSSProject
//
//  Created by WFF on 09/08/2017.
//  Copyright © 2017 AIA. All rights reserved.
//

#import "Bean.h"

#define NETWORK_INFO_TABLE_NAME     @"NetworkInfo"

@interface NetworkInfoBean : Bean

@property (nonatomic, retain) NSString *buildVesion;
@property (nonatomic, retain) NSString *serverURL;
@property (nonatomic, retain) NSString *loginPageURL;
@property (nonatomic, retain) NSString *webServicesURL;
@property (nonatomic, retain) NSString *newsFeedURL;
@property (nonatomic, retain) NSString *nameSpace;

@end
