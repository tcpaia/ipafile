//
//  TrackerResultBean.m
//  TSSProject
//
//  Created by WFF on 03/12/2017.
//  Copyright © 2017 AIA. All rights reserved.
//

#import "TrackerResultBean.h"

@implementation TrackerResultBean

@end
