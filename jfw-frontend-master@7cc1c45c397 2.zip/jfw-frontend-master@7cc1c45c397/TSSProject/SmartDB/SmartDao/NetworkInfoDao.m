//
//  NetworkInfoDao.m
//  TSSProject
//
//  Created by WFF on 09/08/2017.
//  Copyright © 2017 AIA. All rights reserved.
//

#import "NetworkInfoDao.h"
#import "Singleton.h"
#import "TSSValidationUtil.h"

#import "NetworkInfoBean.h"

@implementation NetworkInfoDao

SYNTHESIZE_SINGLETON_FOR_CLASS(NetworkInfoDao);

- (id) init
{
    //TEST_BEAN_COLUMN_DETAILS;
    
    NSMutableArray *tableColumes = [self readValuesFromTablePlist:NETWORK_INFO_TABLE_NAME];
    self = [super init:NETWORK_INFO_TABLE_NAME primaryColumnName:BEAN_ID columnDetails:tableColumes];
    
    if (self) {
        self.setBeanValueBlock = ^(FMResultSet *result)
        {
            
            NetworkInfoBean *o = [NetworkInfoBean new];
            return o;
        };
        self.getBeanValueBlock = ^(Bean *bean) {
            
            return [NSMutableDictionary dictionary];
        };
    }
    
    return self;
}

- (NSMutableDictionary *) getBeanValue:(Bean *) bean
{
    NSMutableDictionary *ht = [NSMutableDictionary dictionaryWithCapacity:[self.columnDetails count]];
    
    NetworkInfoBean *o = (NetworkInfoBean *) bean;
    
    NSMutableArray *temp = [NSMutableArray arrayWithArray:[o allPropertyNames]];
    
    for (int i=0; i<temp.count; i++)
    {
        [self htSetObject:ht forBean:o selName:[temp objectAtIndex:i]];
    }
    
    [ht setObject:[TSSValidationUtil convertNilToNull:o.idKey] forKey:BEAN_ID];
    [ht setObject:[TSSValidationUtil convertNilToNull:o.updatedate] forKey:UPDATE_COLUMN_NAME];
    [ht setObject:[TSSValidationUtil convertNilToNull:o.createdate] forKey:CREATE_COLUMN_NAME];
    
    return ht;
}

-(void)htSetObject:(NSMutableDictionary*) ht forBean:(NetworkInfoBean*)bean selName:(NSString*)name;
{
    [ht setObject:[TSSValidationUtil convertNilToNull:[bean doGetMethord:name]] forKey:name];
}

- (void) setBeanValue:(NSMutableDictionary *) ht forBean: (Bean *) bean
{
    NetworkInfoBean *o = (NetworkInfoBean *) bean;
    
    o.idKey = [TSSValidationUtil convertNullToNil:[ht objectForKey:BEAN_ID]];
    o.updatedate = [TSSValidationUtil convertNullToNil:[ht objectForKey:UPDATE_COLUMN_NAME]];
    o.createdate = [TSSValidationUtil convertNullToNil:[ht objectForKey:CREATE_COLUMN_NAME]];
    
    [o assginToPropertyWithDictionary:ht];
}

- (id) createBean
{
    return [[NetworkInfoBean alloc] init];
}

- (NetworkInfoBean*) selectNetworkInfoBeanByBuildVesion: (NSString*)buildVesion
{
    NSString *where = FORMAT(@"WHERE buildVesion = ?");
    NSArray *parameters = [NSArray arrayWithObjects: buildVesion,nil];
    NSMutableArray *result = [[NetworkInfoDao getInstance] selectAllWhere:where parameters:parameters];
    if (result != nil && result.count>0) {
        NetworkInfoBean *networkInfo = [result objectAtIndex:0];
        return networkInfo;
    }
    return nil;
}
@end
