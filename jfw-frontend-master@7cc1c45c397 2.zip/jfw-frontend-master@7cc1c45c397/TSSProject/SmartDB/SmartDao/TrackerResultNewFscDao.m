//
//  TrackerResultNewFscDao.m
//  TSSProject
//
//  Created by WFF on 2018/2/26.
//  Copyright © 2018 AIA. All rights reserved.
//

#import "TrackerResultNewFscDao.h"
#import "Singleton.h"

#import "SystemTss.h"
#import "TSSFileManager.h"
#import "TSSValidationUtil.h"

#import "TrackerResultNewFscBean.h"

@implementation TrackerResultNewFscDao

SYNTHESIZE_SINGLETON_FOR_CLASS(TrackerResultNewFscDao);

- (id) init
{
    NSMutableArray *tableColumes = [self readValuesFromTablePlist: TRACKER_RESULT_NEW_FSC_TABLE_NAME];
    self = [super init:TRACKER_RESULT_NEW_FSC_TABLE_NAME primaryColumnName:BEAN_ID columnDetails:tableColumes];
    
    if (self)
    {
        self.setBeanValueBlock = ^(FMResultSet *result) {
            TrackerResultNewFscBean *o = [TrackerResultNewFscBean new];
            return o;
        };
        self.getBeanValueBlock = ^(Bean *bean) {
            return [NSMutableDictionary dictionary];
        };
    }
    return self;
}

- (void) initWithDB
{
    @try {
        [self openDB];
    } @catch (NSException *e) {
        
    }
}

- (NSMutableDictionary *) getBeanValue:(Bean *) bean
{
    NSMutableDictionary *ht = [NSMutableDictionary dictionaryWithCapacity:[self.columnDetails count]];
    TrackerResultNewFscBean *o = (TrackerResultNewFscBean *) bean;
    
    NSMutableArray *temp = [NSMutableArray arrayWithArray:[o allPropertyNames]];
    for (int i=0; i<temp.count; i++)
    {
        [self htSetObject:ht forBean:o selName:[temp objectAtIndex:i]];
    }
    
    NSMutableArray *temp2 = [NSMutableArray arrayWithArray:[o allSuperPropertyNames]];
    for (int i=0; i<temp2.count; i++)
    {
        [self htSetObject:ht forBean:o selName:[temp2 objectAtIndex:i]];
    }
    
    [ht setObject:[TSSValidationUtil convertNilToNull:o.idKey] forKey:BEAN_ID];
    [ht setObject:[TSSValidationUtil convertNilToNull:o.updatedate] forKey:UPDATE_COLUMN_NAME];
    [ht setObject:[TSSValidationUtil convertNilToNull:o.createdate] forKey:CREATE_COLUMN_NAME];
    
    return ht;
}

-(void) htSetObject:(NSMutableDictionary*) ht forBean:(TrackerResultNewFscBean*)bean selName:(NSString*)name;
{
    [ht setObject:[TSSValidationUtil convertNilToNull:[bean doGetMethord:name]] forKey:name];
}

- (void) setBeanValue:(NSMutableDictionary *) ht forBean: (Bean *) bean
{
    TrackerResultNewFscBean *o = (TrackerResultNewFscBean *) bean;
    
    o.idKey = [TSSValidationUtil convertNullToNil:[ht objectForKey:BEAN_ID]];
    o.updatedate = [TSSValidationUtil convertNullToNil:[ht objectForKey:UPDATE_COLUMN_NAME]];
    o.createdate = [TSSValidationUtil convertNullToNil:[ht objectForKey:CREATE_COLUMN_NAME]];
    
    [o assginToPropertyWithDictionary:ht];
}

- (id) createBean
{
    return [[TrackerResultNewFscBean alloc] init];
}

- (NSMutableArray *) selectTrackerForNewFscByTrackerSearch: (TrackerNewFscSearchModel *) searchModel
{
    //select t.beanid, t.agentCode, t.customerName, t.category1, t.dateLong1, t.category2, t.dateLong2, c.fullname as agentName from TrackerResultNewFsc as t left join (select internalid, fullname from CustomerInfo where customertype = '0' and internalid is not null ) as c on t.fscCode = c.internalid where 1=1
    
    
//    NSMutableString *sql = [NSMutableString stringWithFormat: @"select t.beanid, t.requestAgentCode, t.requestAgentName, t.agentCode, c.fullname as agentName, "];
    NSMutableString *sql = [NSMutableString stringWithFormat: @"select t.beanid, t.requestAgentCode, t.requestAgentName, "];
    
    if (searchModel.showRequestFSCCode) {
        [sql appendFormat: @"t.requestAgentCode as agentCode, t.requestAgentName as agentName, "];
    } else {
        [sql appendFormat: @"t.agentCode, c.fullname as agentName, "];
    }
    
    [sql appendFormat: @"t.customerName, t.category1, t.dateLong1, t.category2, t.dateLong2 "];
    [sql appendFormat: @"from TrackerResultNewFsc as t left join "];
    [sql appendFormat: @"(select internalid, fullname from CustomerInfo where customertype = '0' and internalid is not null ) "];
    [sql appendFormat: @"as c on t.agentCode = c.internalid where 1=1 "];
    
    if (searchModel != nil) {
        if ([TSSValidationUtil isNilOrEmptyString: searchModel.fscNameOrCodeOrCustomer] == NO) {
            
            if (searchModel.showRequestFSCCode) {
                [sql appendFormat: @"and (t.requestAgentCode like '%%%@%%' or t.requestAgentName like '%%%@%%' or t.customerName like '%%%@%%') ", searchModel.fscNameOrCodeOrCustomer, searchModel.fscNameOrCodeOrCustomer, searchModel.fscNameOrCodeOrCustomer];
            } else {
                [sql appendFormat: @"and (t.agentCode like '%%%@%%' or c.fullname like '%%%@%%' or t.customerName like '%%%@%%') ", searchModel.fscNameOrCodeOrCustomer, searchModel.fscNameOrCodeOrCustomer, searchModel.fscNameOrCodeOrCustomer];
            }
        }
    }
    NSMutableArray *result = [self selectbysql:sql parameters:nil andConvertResutToBeanFlag: YES];

    return result;
}
@end
