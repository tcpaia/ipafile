//
//  EventLogDao.h
//  TSSProject
//
//  Created by TSS on 16/5/13.
//  Copyright © 2016年 AIA. All rights reserved.
//
#import "EventLogBean.h"
#import "AbstractDao.h"

@interface EventLogDao : AbstractDao

+ (EventLogDao *) getInstance;

- (void) initWithDB;

- (NSMutableArray*)getBeansWithCount:(int)aNumber;

-(void)eventSaveByType:(NSString*)aType;

@end