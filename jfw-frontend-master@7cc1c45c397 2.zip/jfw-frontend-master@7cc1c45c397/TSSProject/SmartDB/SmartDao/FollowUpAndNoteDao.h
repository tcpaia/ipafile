//
//  FollowUpAndNoteDao.h
//  TSSProject
//
//  Created by TSS on 16/7/7.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AbstractDao.h"
#import "FollowUpAndNoteBean.h"

@interface FollowUpAndNoteDao : AbstractDao

+ (FollowUpAndNoteDao *) getInstance;

- (NSMutableArray *)getBeanWithCustomerId:(NSString*)aCustomerId;

- (void) initWithDB;


@end
