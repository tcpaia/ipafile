//
//  FollowUpAndNoteDao.m
//  TSSProject
//
//  Created by TSS on 16/7/7.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import "FollowUpAndNoteDao.h"
#import "TSSValidationUtil.h"
#import "Singleton.h"
#import "FollowUpAndNoteBean.h"

@implementation FollowUpAndNoteDao

SYNTHESIZE_SINGLETON_FOR_CLASS(FollowUpAndNoteDao);

- (id) init
{
    NSMutableArray *tableColumes = [self readValuesFromTablePlist:FOLLOWUP_TABLE_NAME];
    self = [super init:FOLLOWUP_TABLE_NAME primaryColumnName:BEAN_ID columnDetails:tableColumes];
    
    if (self) {
        self.setBeanValueBlock = ^(FMResultSet *result)
        {
            
            FollowUpAndNoteBean *o = [FollowUpAndNoteBean new];
            return o;
        };
        self.getBeanValueBlock = ^(Bean *bean) {
            
            return [NSMutableDictionary dictionary];
        };
    }
    
    return self;
}

- (void) initWithDB
{
    @try
    {
        [self openDB];
    }
    @catch (NSException *e)
    {
        //[e printStackTrace];
    }
}

- (NSMutableArray *)getBeanWithCustomerId:(NSString*)aCustomerId
{
    NSString *where = FORMAT(@"WHERE customerId = ?");
    NSArray *parameters = [NSArray arrayWithObjects:aCustomerId,nil];
    NSMutableArray *t =[[FollowUpAndNoteDao getInstance] selectAllWhere:where parameters:parameters];
    if (t.count>0)
    {
        //FollowUpAndNoteBean *custm = [t objectAtIndex:0];
        return t;
    }
    else
    {
        return nil;
    }
}


- (NSMutableDictionary *) getBeanValue:(Bean *) bean
{
    NSMutableDictionary *ht = [NSMutableDictionary dictionaryWithCapacity:[self.columnDetails count]];
    
    FollowUpAndNoteBean *o = (FollowUpAndNoteBean *) bean;
    
    NSMutableArray *temp = [NSMutableArray arrayWithArray:[o allPropertyNames]];
    
    for (int i=0; i<temp.count; i++)
    {
        [self htSetObject:ht forBean:o selName:[temp objectAtIndex:i]];
    }
    
    [ht setObject:[TSSValidationUtil convertNilToNull:o.idKey] forKey:BEAN_ID];
    [ht setObject:[TSSValidationUtil convertNilToNull:o.updatedate] forKey:UPDATE_COLUMN_NAME];
    [ht setObject:[TSSValidationUtil convertNilToNull:o.createdate] forKey:CREATE_COLUMN_NAME];
    
    return ht;
}

-(void)htSetObject:(NSMutableDictionary*) ht forBean:(FollowUpAndNoteBean*)bean selName:(NSString*)name;
{
    [ht setObject:[TSSValidationUtil convertNilToNull:[bean doGetMethord:name]] forKey:name];
}

- (void) setBeanValue:(NSMutableDictionary *) ht forBean: (Bean *) bean
{
    FollowUpAndNoteBean *o = (FollowUpAndNoteBean *) bean;
    
    o.idKey = [TSSValidationUtil convertNullToNil:[ht objectForKey:BEAN_ID]];
    o.updatedate = [TSSValidationUtil convertNullToNil:[ht objectForKey:UPDATE_COLUMN_NAME]];
    o.createdate = [TSSValidationUtil convertNullToNil:[ht objectForKey:CREATE_COLUMN_NAME]];
    
    [o assginToPropertyWithDictionary:ht];
}

- (id) createBean
{
    return [[FollowUpAndNoteBean alloc] init];
}

@end
