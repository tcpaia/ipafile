//
//  NominatedPartnerDao.h
//  TSSProject
//
//  Created by WFF on 17/11/2017.
//  Copyright © 2017 AIA. All rights reserved.
//

#import "AbstractDao.h"
#import "NominatedPartnerBean.h"

@interface NominatedPartnerDao : AbstractDao

+ (NominatedPartnerDao *) getInstance;

- (void) initWithDB;

- (NominatedPartnerBean *) getBeanWithCustomerOid:(NSString*)oid;

- (NominatedPartnerBean *) getBeanWithInternalId: (NSString*) internalId;
@end
