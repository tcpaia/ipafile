//
//  NominatedCadidateDao.h
//  TSSProject
//
//  Created by WFF on 22/10/2017.
//  Copyright © 2017 AIA. All rights reserved.
//

#import "AbstractDao.h"
#import "NominatedCadidateBean.h"

@interface NominatedCadidateDao : AbstractDao

+ (NominatedCadidateDao *) getInstance;
- (void) initWithDB;

- (NSMutableArray *) getAllNominatedCadidates;
- (NominatedCadidateBean *) getBeanWithNominatedCode: (NSString *) assessorCode;
@end
