//
//  TrackerResultDao.m
//  TSSProject
//
//  Created by WFF on 03/12/2017.
//  Copyright © 2017 AIA. All rights reserved.
//

#import "TrackerResultDao.h"
#import "Singleton.h"

#import "SystemTss.h"
#import "TSSFileManager.h"
#import "TSSValidationUtil.h"

#import "TrackerResultBean.h"
#import "TrackerResultModel.h"
#import "TrackerUIHelper.h"
#import "TrackerExcelConstants.h"
#import "NSDate+Ex.h"

@implementation TrackerResultDao

SYNTHESIZE_SINGLETON_FOR_CLASS(TrackerResultDao);

- (id) init
{
    NSMutableArray *tableColumes = [self readValuesFromTablePlist: TRACKER_RESULT_TABLE_NAME];
    self = [super init:TRACKER_RESULT_TABLE_NAME primaryColumnName:BEAN_ID columnDetails:tableColumes];
    
    if (self)
    {
        self.setBeanValueBlock = ^(FMResultSet *result) {
            TrackerResultBean *o = [TrackerResultBean new];
            return o;
        };
        self.getBeanValueBlock = ^(Bean *bean) {
            return [NSMutableDictionary dictionary];
        };
    }
    return self;
}

- (void) initWithDB
{
    @try {
        [self openDB];
    } @catch (NSException *e) {
        
    }
}

- (NSMutableDictionary *) getBeanValue:(Bean *) bean
{
    NSMutableDictionary *ht = [NSMutableDictionary dictionaryWithCapacity:[self.columnDetails count]];
    TrackerResultBean *o = (TrackerResultBean *) bean;
    
    NSMutableArray *temp = [NSMutableArray arrayWithArray:[o allPropertyNames]];
    for (int i=0; i<temp.count; i++)
    {
        [self htSetObject:ht forBean:o selName:[temp objectAtIndex:i]];
    }
    
    NSMutableArray *temp2 = [NSMutableArray arrayWithArray:[o allSuperPropertyNames]];
    for (int i=0; i<temp2.count; i++)
    {
        [self htSetObject:ht forBean:o selName:[temp2 objectAtIndex:i]];
    }
    
    [ht setObject:[TSSValidationUtil convertNilToNull:o.idKey] forKey:BEAN_ID];
    [ht setObject:[TSSValidationUtil convertNilToNull:o.updatedate] forKey:UPDATE_COLUMN_NAME];
    [ht setObject:[TSSValidationUtil convertNilToNull:o.createdate] forKey:CREATE_COLUMN_NAME];
    
    return ht;
}

-(void) htSetObject:(NSMutableDictionary*) ht forBean:(TrackerResultBean*)bean selName:(NSString*)name;
{
    [ht setObject:[TSSValidationUtil convertNilToNull:[bean doGetMethord:name]] forKey:name];
}

- (void) setBeanValue:(NSMutableDictionary *) ht forBean: (Bean *) bean
{
    TrackerResultBean *o = (TrackerResultBean *) bean;
    
    o.idKey = [TSSValidationUtil convertNullToNil:[ht objectForKey:BEAN_ID]];
    o.updatedate = [TSSValidationUtil convertNullToNil:[ht objectForKey:UPDATE_COLUMN_NAME]];
    o.createdate = [TSSValidationUtil convertNullToNil:[ht objectForKey:CREATE_COLUMN_NAME]];
    
    [o assginToPropertyWithDictionary:ht];
}

- (id) createBean
{
    return [[TrackerResultBean alloc] init];
}

- (NSMutableArray *) selectTrackerCountByAgentCode:(NSString *) agentCode andTrackerSearch: (TrackerSearchModel *) searchModel
{
    NSMutableString *sql = [NSMutableString stringWithFormat: @"select "];
    
    if ([searchModel.agentJfwRole isEqualToString: Leader]) {
        [sql appendFormat: @"c.fullname as advisorName, t.fscCode as advisorCode, "];
    } else if ([searchModel.agentJfwRole isEqualToString: Agent]) {
        [sql appendFormat: @"c.agentname as advisorName, t.fscCode as advisorCode, "];
    }
    
    NSUInteger columnCount = searchModel.columnCount;
    
    NSUInteger preYear = searchModel.currentYear - 1;
    
    //如果没有搜索，或者搜索的条件中没有填写月份，则查询今年的12个月
    if (searchModel.inputSearch == NO || (searchModel.inputSearch == YES && [TSSValidationUtil isNilOrEmptyString: searchModel.beginMonth])) {
        if ([searchModel.trackerType isEqualToString: TRACKER_FOR_YEARLY]) {
            [sql appendFormat: @"sum(case when t.year = %ld then t.trackerCount else 0 END) as sumYear1, ", (long)preYear];
            [sql appendFormat: @"sum(case when t.year = %ld then t.trackerCount else 0 END) as sumYear2 ", (long)searchModel.currentYear];
        } else if ([searchModel.trackerType isEqualToString: TRACKER_FOR_MONTHLY]){
            for (NSUInteger i = 0; i < columnCount; i++) {
//                [sql appendFormat: @"sum(case when t.year = %ld and t.month = %ld then t.trackerCount else 0 END)  as sumMonth%ld ",searchModel.currentYear, i + 1, i + 1];
                [sql appendFormat: @"sum(case when t.year * 100 + t.month = %ld then t.trackerCount else 0 END)  as sumMonth%ld ", (long)(searchModel.currentYear *100 + i + 1), (long)(i + 1)];
                if (i < columnCount - 1) {
                    [sql appendFormat: @","];
                }
                [sql appendFormat: @" "];
            }
        }
    } else {
        //如果搜索条件中含有时间，则要区分是否出现跨年
        NSUInteger beginMonth = [searchModel.beginYear integerValue] * 100 + [searchModel.beginMonth integerValue];
        NSUInteger endMonth = [searchModel.endYear integerValue] *100 + [searchModel.endMonth integerValue];
        
        BOOL sameYear = ([searchModel.beginYear integerValue] - [searchModel.endYear integerValue]) == 0 ? YES : NO;
        if ([searchModel.trackerType isEqualToString: TRACKER_FOR_YEARLY]) {
            if (sameYear) {
                [sql appendFormat: @"sum(case when t.year = %ld then t.trackerCount else 0 END) as sumYear1 ", (long)[searchModel.beginYear integerValue]];
            } else {
                [sql appendFormat: @"sum(case when t.year = %ld then t.trackerCount else 0 END) as sumYear1, ", (long) [searchModel.beginYear integerValue]];
                [sql appendFormat: @"sum(case when t.year = %ld then t.trackerCount else 0 END) as sumYear2 ",  (long)[searchModel.endYear integerValue]];
            }
        } else if ([searchModel.trackerType isEqualToString: TRACKER_FOR_MONTHLY]){
            NSUInteger tempCount = 0;
            NSUInteger tempMonth = beginMonth;
            for (NSUInteger i = 0; i < columnCount; i++) {

                [sql appendFormat: @"sum(case when t.year * 100 + t.month = %ld then t.trackerCount else 0 END) as sumMonth%ld ",  (long)tempMonth,  (long)(tempCount + 1)];
                if (tempCount < columnCount - 1) {
                    [sql appendFormat: @","];
                }
                [sql appendFormat: @" "];
                if (tempCount == columnCount - 1) {
                    break;
                }
                
                if (endMonth == tempMonth) {
                    break;
                }
                
                if (tempMonth == ([searchModel.beginYear integerValue] * 100 + 12)) {
                    tempMonth = [searchModel.endYear integerValue] * 100 + 1;
                } else {
                    tempMonth ++;
                }
                tempCount ++;
            }
        }
    }
    
    [sql appendFormat: @"from TrackerResult as t "];
    
    if ([searchModel.agentJfwRole isEqualToString: Leader]) {
        [sql appendFormat: @"left join (select internalid, fullname from CustomerInfo where customertype = '0' and internalid is not null ) as c "];
        [sql appendFormat: @"on t.fscCode = c.internalid "];
    } else if ([searchModel.agentJfwRole isEqualToString: Agent]) {
        [sql appendFormat: @"left join AgentProfile as c "];
        [sql appendFormat: @"on t.fscCode = c.agentcode "];
    }
    
    [sql appendFormat: @"where 1=1 "];
    
    //如果没有搜索时间
    if (searchModel.inputSearch == NO || (searchModel.inputSearch == YES && [TSSValidationUtil isNilOrEmptyString: searchModel.beginMonth])) {
        if ([searchModel.trackerType isEqualToString: TRACKER_FOR_YEARLY]) {
            [sql appendFormat: @"and ( (t.year *100+t.month) >= %ld and (t.year*100+ t.month <= %ld) ) ", (long)(preYear * 100 + 1),  (long)(searchModel.currentYear * 100 + 12)];
        } else if ([searchModel.trackerType isEqualToString: TRACKER_FOR_MONTHLY]) {
            [sql appendFormat: @"and ( (t.year *100+t.month) >= %ld and (t.year*100+ t.month <= %ld) ) ",  (long)(searchModel.currentYear * 100 + 1),  (long)(searchModel.currentYear * 100 + 12)];
        }
    } else {
        //如果有搜索时间
        [sql appendFormat: @"and ( (t.year *100+t.month) >= %ld and (t.year*100+ t.month <= %ld) ) ",  (long)([searchModel.beginYear integerValue] * 100 + [searchModel.beginMonth integerValue]),  (long)([searchModel.endYear integerValue] *100 + [searchModel.endMonth integerValue])];
    }

    if (searchModel.inputSearch == YES) {
        if ([TSSValidationUtil isNilOrEmptyString:searchModel.fscNameOrCode] == NO) {
            if ([searchModel.agentJfwRole isEqualToString: Leader]) {
                [sql appendFormat: @"and (c.fullname like '%%%@%%' or t.fscCode like '%%%@%%') ", searchModel.fscNameOrCode, searchModel.fscNameOrCode];
            } else if ([searchModel.agentJfwRole isEqualToString: Agent]) {
                [sql appendFormat: @"and (c.agentname like '%%%@%%' or t.fscCode like '%%%@%%') ", searchModel.fscNameOrCode, searchModel.fscNameOrCode];
            }
        }
    }
    
    if ([searchModel.agentJfwRole isEqualToString: Leader]) {
        [sql appendFormat: @"group by t.fscCode, c.fullname "];
        [sql appendFormat: @"order by c.fullname asc"];
    } else if ([searchModel.agentJfwRole isEqualToString: Agent]) {
        [sql appendFormat: @"group by t.fscCode, c.agentname "];
        [sql appendFormat: @"order by c.agentname asc"];
    }

    
    NSMutableArray *queryResult = [self selectbysql:sql parameters:nil andConvertResutToBeanFlag: NO];
    NSMutableArray * result = nil;
    
    if(queryResult != nil && queryResult.count > 0) {
        result = [NSMutableArray array];
        TrackerResultModel *model = nil;
        int i = 0;
        NSString *fscName = nil;
        for (NSDictionary *subDict in queryResult) {
            model = [[TrackerResultModel alloc] init];
            
            model.fscCode = [subDict objectForKey:@"advisorCode"];
            fscName = [subDict objectForKey:@"advisorName"];
            fscName = [TSSValidationUtil convertNullToNil: fscName];
            if ([TSSValidationUtil isNilOrEmptyString: fscName]) {
                fscName = @"";
            }
            model.fscName = fscName;
            if ([searchModel.trackerType isEqualToString: TRACKER_FOR_YEARLY]) {
                model.sumYearArray = [NSMutableArray array];
                for (i = 0; i < columnCount; i ++) {
                    [model.sumYearArray addObject: [subDict objectForKey: [NSString stringWithFormat: @"sumYear%d", i+1]]];
                }
            } else if ([searchModel.trackerType isEqualToString: TRACKER_FOR_MONTHLY]) {
                model.sumMonthArray = [NSMutableArray array];
                NSString *monthValue;
                for (i = 0; i < columnCount; i ++) {
                    monthValue = [subDict objectForKey: [NSString stringWithFormat: @"sumMonth%d", i+1]];
                    [model.sumMonthArray addObject: monthValue];
                    int n = [monthValue integerValue];
                    model.sumValue += n;
                }
            }
            
            [result addObject: model];
        }
    }
    return result;
}
@end
