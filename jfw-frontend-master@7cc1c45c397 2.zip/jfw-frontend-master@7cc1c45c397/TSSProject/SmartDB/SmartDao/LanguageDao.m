//
//  LanguageDao.m
//  TSSProject
//
//  Created by TSS on 16/5/23.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import "LanguageDao.h"
#import "DBQueue.h"
#import "Singleton.h"
#import "LanguageBean.h"
#import "TSSValidationUtil.h"

@implementation LanguageDao

SYNTHESIZE_SINGLETON_FOR_CLASS(LanguageDao);

- (NSString*) getStrByKeyCode:(NSString*)key code:(NSString*)code
{
    NSString *where = FORMAT(@"WHERE LanguageStringID = ? AND LanguageCode = ?");

    //NSString *where = FORMAT(@"WHERE LanguageStringID = '%@' AND LanguageCode = '%@'", key,code);
    NSArray *parameters = [NSArray arrayWithObjects:key,code,nil];
    NSMutableArray *t =[[LanguageDao getInstance] selectAllWhere:where parameters:parameters];
    if (t.count>0) {
        
        LanguageBean *temp = [t objectAtIndex:0];
        return temp.LanguageText;
    }
    else
    {
        return nil;
    }
}

-(void)htSetObject:(NSMutableDictionary*) ht forBean:(LanguageBean*)bean selName:(NSString*)name;
{
    [ht setObject:[TSSValidationUtil convertNilToNull:[bean doGetMethord:name]] forKey:name];
}

- (void) setBeanValue:(NSMutableDictionary *) ht forBean: (Bean *) bean
{
    LanguageBean *o = (LanguageBean *) bean;
    
    [o assginToPropertyWithDictionary:ht];
}

- (id) createBean
{
    return [[LanguageBean alloc] init];
}


@end
