//
//  CustomerInfoDao.m
//  TSSProject
//
//  Created by TSS on 16/5/4.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import "CustomerInfoDao.h"
#import "CustomerInfoBean.h"
#import "Singleton.h"
#import "TSSValidationUtil.h"
#import "SystemTss.h"
#import "TSSFileManager.h"
@implementation CustomerInfoDao

SYNTHESIZE_SINGLETON_FOR_CLASS(CustomerInfoDao);

- (id) init
{
    //TEST_BEAN_COLUMN_DETAILS;
    NSMutableArray *tableColumes = [self readValuesFromTablePlist:CUSTOMER_INFO_TABLE_NAME];
    self = [super init:CUSTOMER_INFO_TABLE_NAME primaryColumnName:BEAN_ID columnDetails:tableColumes];
    
    if (self) {
        self.setBeanValueBlock = ^(FMResultSet *result)
        {
            CustomerInfoBean *o = [CustomerInfoBean new];
            return o;
        };
        self.getBeanValueBlock = ^(Bean *bean) {
            
            return [NSMutableDictionary dictionary];
        };
    }
    return self;
}

- (void) initWithDB
{
    @try
    {
        [self openDB];
    }
    @catch (NSException *e)
    {
        //[e printStackTrace];
    }
}

- (NSMutableDictionary *) getBeanValue:(Bean *) bean
{
    NSMutableDictionary *ht = [NSMutableDictionary dictionaryWithCapacity:[self.columnDetails count]];
    CustomerInfoBean *o = (CustomerInfoBean *) bean;
    NSMutableArray *temp = [NSMutableArray arrayWithArray:[o allPropertyNames]];
    
    for (int i=0; i<temp.count; i++)
    {
        [self htSetObject:ht forBean:o selName:[temp objectAtIndex:i]];
    }
    
    [ht setObject:[TSSValidationUtil convertNilToNull:o.idKey] forKey:BEAN_ID];
    [ht setObject:[TSSValidationUtil convertNilToNull:o.updatedate] forKey:UPDATE_COLUMN_NAME];
    [ht setObject:[TSSValidationUtil convertNilToNull:o.createdate] forKey:CREATE_COLUMN_NAME];
    
    return ht;
}

-(void)htSetObject:(NSMutableDictionary*) ht forBean:(CustomerInfoBean*)bean selName:(NSString*)name;
{
    [ht setObject:[TSSValidationUtil convertNilToNull:[bean doGetMethord:name]] forKey:name];
}

- (void) setBeanValue:(NSMutableDictionary *) ht forBean: (Bean *) bean
{
    CustomerInfoBean *o = (CustomerInfoBean *) bean;
    
    o.idKey = [TSSValidationUtil convertNullToNil:[ht objectForKey:BEAN_ID]];
    o.updatedate = [TSSValidationUtil convertNullToNil:[ht objectForKey:UPDATE_COLUMN_NAME]];
    o.createdate = [TSSValidationUtil convertNullToNil:[ht objectForKey:CREATE_COLUMN_NAME]];
    
    [o assginToPropertyWithDictionary:ht];
}

- (id) createBean
{
    return [[CustomerInfoBean alloc] init];
}

- (CustomerInfoBean*)getBeanWithCustomerUUId:(NSString*)aId
{
//    NSString *where = FORMAT(@"WHERE customerUuid = ? AND status!='D'");
    NSString *where = FORMAT(@"WHERE customerUuid = ? ");
    NSArray *parameters = [NSArray arrayWithObjects:aId,nil];
    NSMutableArray *t =[[CustomerInfoDao getInstance] selectAllWhere:where parameters:parameters];
    if (t.count>0)
    {
        CustomerInfoBean *custm = [t objectAtIndex:0];
        return custm;
    }
    return nil;
}

- (CustomerInfoBean*)getBeanWithCustomerUUIdWithoutDelete:(NSString*)aId
{
    NSString *where = FORMAT(@"WHERE customerUuid = ? AND status!='D'");
    NSArray *parameters = [NSArray arrayWithObjects:aId,nil];
    NSMutableArray *t =[[CustomerInfoDao getInstance] selectAllWhere:where parameters:parameters];
    if (t.count>0)
    {
        CustomerInfoBean *custm = [t objectAtIndex:0];
        return custm;
    }
    return nil;
}

- (NSMutableArray*)getBeansWithName:(NSString*)aName
{
    NSString *where = FORMAT(@"WHERE fullname LIKE '%%%@%%' AND status!='D' ",aName);
    //NSArray *parameters = [NSArray arrayWithObjects:aName,nil];
    NSMutableArray *t =[[CustomerInfoDao getInstance] selectAllWhere:where parameters:nil];
    if (t.count>0)
    {
        return t;
    }
    return nil;
}

- (NSMutableArray *)getBeanWithCustometType:(NSString *)aCustomerType
{
    NSString *where = FORMAT(@"WHERE customerType = ? AND status!='D' ORDER BY fullname COLLATE NOCASE ASC");
    NSArray *parameters = [NSArray arrayWithObjects:aCustomerType,nil];
    NSMutableArray *t =[self selectAllWhere:where parameters:parameters];
    return t;
}

- (NSMutableArray*)getBeansWithCount:(int)aNumber
{
//    NSString *where = FORMAT(@"WHERE status!='D' ORDER BY fullname COLLATE NOCASE ASC LIMIT ?");
    NSString *where = FORMAT(@"WHERE 1=1 ORDER BY lastupdatedatetimelong desc LIMIT ?");
    NSArray *parameters = [NSArray arrayWithObjects:@(aNumber),nil];
    NSMutableArray *t = [self selectAllWhere:where parameters:parameters];
    return t;
}
#pragma --- end ---

#pragma  change

- (CustomerInfoBean*)getBeanWithCustomerOid:(NSString*)oid
{
    NSString *where = FORMAT(@"WHERE oid = ?");
    NSArray *parameters = [NSArray arrayWithObjects:oid,nil];
    NSMutableArray *t =[[CustomerInfoDao getInstance] selectAllWhere:where parameters:parameters];
    if (t.count>0)
    {
        return [t objectAtIndex:0];
    }
    return nil;
}
#pragma -- end --

- (NSMutableArray *)getBeansNoWithRoleType:(NSString *)aRoleType
{
    NSString *where = FORMAT(@"WHERE internalRole != ? AND status!='D' AND customerType ='0'");
    NSArray *parameters = [NSArray arrayWithObjects:aRoleType,nil];
    NSMutableArray *t =[self selectAllWhere:where parameters:parameters];
    return t;
}

- (NSMutableArray *)getCustomerBeanWithUploadStatus:(NSString *)uploadStatus
{
    NSString *where = FORMAT(@"WHERE uploadStatus = ?");
    NSArray *parameters = [NSArray arrayWithObjects:uploadStatus,nil];
    NSMutableArray *t =[self selectAllWhere:where parameters:parameters];
    return t;
}

- (NSMutableArray*)getAllBeansOrderByDESC
{
    NSString *where = FORMAT(@"WHERE status!='D' ORDER BY fullname COLLATE NOCASE ASC");
    NSMutableArray *t = [self selectAllWhere:where parameters:nil];
    if (t.count>0)
    {
        return t;
    }
    return nil;
}

- (NSMutableArray *) getAllBeansOrderByDescForViewByLeaderInternalID: (NSString *) internalID
{
    NSMutableString *sql = [NSMutableString stringWithFormat: @"WHERE status!='D' "];
    [sql appendFormat: @"and internalId not in (select internalId from CustomerInfo where internalrole = ? and internalid != ?) "];
    [sql appendFormat: @"ORDER BY fullname COLLATE NOCASE ASC"];
    NSMutableArray *parameters = [NSMutableArray arrayWithObjects: Leader, internalID, nil];
    NSMutableArray *result = [self selectAllWhere: sql parameters: parameters];
    if (result != nil && result.count > 0)
    {
        return result;
    }
    return nil;
}

- (CustomerInfoBean*)getBeanWithInternalId:(NSString*)aId
{
    NSString *where = FORMAT(@"WHERE internalId = ?");
    NSArray *parameters = [NSArray arrayWithObjects:aId,nil];
    NSMutableArray *t =[[CustomerInfoDao getInstance] selectAllWhere:where parameters:parameters];
    if (t.count>0)
    {
        return [t objectAtIndex:0];
    }
    return nil;
}

- (NSUInteger) selectAllCountForBeansOrderByDESC
{
    NSString *countSubSql = FORMAT(@" count(*) ");
    NSString *whereSql = FORMAT(@" WHERE status!='D' ");
    return [self selectCountForCountSubSql: countSubSql andWhere:whereSql andParameters: nil];
}

- (NSUInteger) selectCountForBeansNoWithRoleType:(NSString *)aRoleType
{
    NSString *countSubSql = FORMAT(@" count(*) ");
    NSString *whereSql = FORMAT(@" WHERE internalRole != ? AND status!='D' AND customerType =='0' ");
    NSArray *parameters = [NSArray arrayWithObjects:aRoleType,nil];
    return [self selectCountForCountSubSql: countSubSql andWhere:whereSql andParameters: parameters];
}

- (NSUInteger) selectCountWithCustometType:(NSString *)aCustomerType andInternalID: (NSString *) internalID
{
    NSString *countSubSql = FORMAT(@" count(*) ");
    NSString *whereSql = FORMAT(@" WHERE customerType =? and internalId = ? AND status!='D' ");
    NSArray *parameters = [NSArray arrayWithObjects: aCustomerType, internalID, nil];
    return [self selectCountForCountSubSql: countSubSql andWhere:whereSql andParameters: parameters];
}
#pragma -- end --

@end
