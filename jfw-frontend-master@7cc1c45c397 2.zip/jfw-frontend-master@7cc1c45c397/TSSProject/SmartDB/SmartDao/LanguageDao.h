//
//  LanguageDao.h
//  TSSProject
//
//  Created by TSS on 16/5/23.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AbstractDao.h"
#define EN_LANGUAGE @"en"
#define CN_LANGUAGE @"zh_CN"

@class LanguageBean;

@interface LanguageDao : AbstractDao

+ (LanguageDao *) getInstance;

- (NSString*) getStrByKeyCode:(NSString*)key code:(NSString*)code;

@end
