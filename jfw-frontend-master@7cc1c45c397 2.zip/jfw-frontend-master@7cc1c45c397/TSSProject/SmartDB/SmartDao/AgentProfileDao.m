//
//  AgentProfileDao.m
//  TSSProject
//
//  Created by TSS on 16/4/7.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import "AgentProfileDao.h"
#import "AgentProfileBean.h"
#import "Singleton.h"
#import "TSSValidationUtil.h"
#import "SystemTss.h"
#import "TSSFileManager.h"

@implementation AgentProfileDao


SYNTHESIZE_SINGLETON_FOR_CLASS(AgentProfileDao);

- (id) init
{
    //TEST_BEAN_COLUMN_DETAILS;
    
    NSMutableArray *tableColumes = [self readValuesFromTablePlist:AGENT_PROFILE_TABLE_NAME];
    self = [super init:AGENT_PROFILE_TABLE_NAME primaryColumnName:BEAN_ID columnDetails:tableColumes];
    
    if (self) {
        self.setBeanValueBlock = ^(FMResultSet *result)
        {
            
            AgentProfileBean *o = [AgentProfileBean new];
            return o;
        };
        self.getBeanValueBlock = ^(Bean *bean) {
            
            return [NSMutableDictionary dictionary];
        };
    }
    
    return self;
}



- (void) initWithDB
{
    @try
    {
        [self openDB];
    }
    @catch (NSException *e)
    {
        //[e printStackTrace];
    }
}


- (NSMutableDictionary *) getBeanValue:(Bean *) bean
{
    NSMutableDictionary *ht = [NSMutableDictionary dictionaryWithCapacity:[self.columnDetails count]];
    
    AgentProfileBean *o = (AgentProfileBean *) bean;
    
    NSMutableArray *temp = [NSMutableArray arrayWithArray:[o allPropertyNames]];
    
    for (int i=0; i<temp.count; i++)
    {
        [self htSetObject:ht forBean:o selName:[temp objectAtIndex:i]];
    }
    
    [ht setObject:[TSSValidationUtil convertNilToNull:o.idKey] forKey:BEAN_ID];
    [ht setObject:[TSSValidationUtil convertNilToNull:o.updatedate] forKey:UPDATE_COLUMN_NAME];
    [ht setObject:[TSSValidationUtil convertNilToNull:o.createdate] forKey:CREATE_COLUMN_NAME];
    
    return ht;
}

-(void)htSetObject:(NSMutableDictionary*) ht forBean:(AgentProfileBean*)bean selName:(NSString*)name;
{
    [ht setObject:[TSSValidationUtil convertNilToNull:[bean doGetMethord:name]] forKey:name];
}

- (void) setBeanValue:(NSMutableDictionary *) ht forBean: (Bean *) bean
{
    AgentProfileBean *o = (AgentProfileBean *) bean;
    
    o.idKey = [TSSValidationUtil convertNullToNil:[ht objectForKey:BEAN_ID]];
    o.updatedate = [TSSValidationUtil convertNullToNil:[ht objectForKey:UPDATE_COLUMN_NAME]];
    o.createdate = [TSSValidationUtil convertNullToNil:[ht objectForKey:CREATE_COLUMN_NAME]];
    
    [o assginToPropertyWithDictionary:ht];
}

- (id) createBean
{
    return [[AgentProfileBean alloc] init];
}

-(AgentProfileBean*)getBeanWithCode:(NSString*)code
{
    NSString *where = FORMAT(@"WHERE agentcode = ?");
    NSArray *parameters = [NSArray arrayWithObjects:code,nil];
    NSMutableArray *t =[[AgentProfileDao getInstance] selectAllWhere:where parameters:parameters];
    if (t.count>0) {
        AgentProfileBean *agent = [t objectAtIndex:0];
        return agent;
    }
    else
    {
        return nil;
    }
}

- (NSUInteger) selectCountForBeanWithCode: (NSString*)code
{
    NSString *countSubSql = FORMAT(@" count(*) ");
    NSString *whereSql = FORMAT(@" WHERE agentcode = ? ");
    NSArray *parameters = [NSArray arrayWithObjects:code,nil];
    return [self selectCountForCountSubSql: countSubSql andWhere:whereSql andParameters: parameters];
}
@end
