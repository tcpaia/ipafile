//
//  TrackerResultNewFscDao.h
//  TSSProject
//
//  Created by WFF on 2018/2/26.
//  Copyright © 2018 AIA. All rights reserved.
//

#import "AbstractDao.h"
#import "TrackerNewFscSearchModel.h"

@interface TrackerResultNewFscDao : AbstractDao

+ (TrackerResultNewFscDao *) getInstance;

- (void) initWithDB;

- (NSMutableArray *) selectTrackerForNewFscByTrackerSearch: (TrackerNewFscSearchModel *) searchModel;

@end
