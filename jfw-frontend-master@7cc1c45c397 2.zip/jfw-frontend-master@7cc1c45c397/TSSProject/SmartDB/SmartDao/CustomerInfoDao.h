//
//  CustomerInfoDao.h
//  TSSProject
//
//  Created by TSS on 16/5/4.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CustomerInfoBean.h"
#import "AbstractDao.h"

@interface CustomerInfoDao : AbstractDao

+ (CustomerInfoDao *) getInstance;

- (void) initWithDB;

- (CustomerInfoBean*)getBeanWithCustomerOid:(NSString*)oid;

- (CustomerInfoBean*)getBeanWithInternalId:(NSString*)aId;

- (NSMutableArray *)getBeanWithCustometType:(NSString *)aCustomerType;

- (NSMutableArray*)getBeansWithCount:(int)aNumber;

- (NSMutableArray*)getBeansWithName:(NSString*)aName;


- (NSMutableArray *)getCustomerBeanWithUploadStatus:(NSString *)uploadStatus;

- (NSMutableArray *)getBeansNoWithRoleType:(NSString *)aRoleType;

- (NSMutableArray*)getAllBeansOrderByDESC;

- (NSMutableArray *) getAllBeansOrderByDescForViewByLeaderInternalID: (NSString *) internalID;

- (CustomerInfoBean*)getBeanWithCustomerUUId:(NSString*)aId;

- (CustomerInfoBean*)getBeanWithCustomerUUIdWithoutDelete:(NSString*)aId;

- (NSUInteger) selectAllCountForBeansOrderByDESC;

- (NSUInteger) selectCountForBeansNoWithRoleType:(NSString *)aRoleType;

- (NSUInteger) selectCountWithCustometType:(NSString *)aCustomerType andInternalID: (NSString *) internalID;
@end
