//
//  AgentProfileDao.h
//  TSSProject
//
//  Created by TSS on 16/4/7.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AbstractDao.h"

@class AgentProfileBean;
@interface AgentProfileDao : AbstractDao

+ (AgentProfileDao *) getInstance;

- (void) initWithDB;

-(AgentProfileBean*)getBeanWithCode:(NSString*)code;

- (NSUInteger) selectCountForBeanWithCode: (NSString*)code;
@end
