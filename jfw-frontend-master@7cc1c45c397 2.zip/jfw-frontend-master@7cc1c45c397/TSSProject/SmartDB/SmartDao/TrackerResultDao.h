//
//  TrackerResultDao.h
//  TSSProject
//
//  Created by WFF on 03/12/2017.
//  Copyright © 2017 AIA. All rights reserved.
//

#import "AbstractDao.h"
#import "TrackerSearchModel.h"

@interface TrackerResultDao : AbstractDao

+ (TrackerResultDao *) getInstance;

- (void) initWithDB;

- (NSMutableArray *) selectTrackerCountByAgentCode:(NSString *) agentCode andTrackerSearch: (TrackerSearchModel *) searchModel;

@end
