//
//  NominationInfoDao.h
//  TSSProject
//
//  Created by WFF on 22/10/2017.
//  Copyright © 2017 AIA. All rights reserved.
//

#import "AbstractDao.h"
#import "NominationInfoBean.h"

@interface NominationInfoDao : AbstractDao

+ (NominationInfoDao *) getInstance;

- (void) initWithDB;

- (NominationInfoBean *) getBeanWithNominationInfoID: (NSString *) nominationInfoID;

- (NominationInfoBean*)getBeansDESCWithCount:(int) count;

- (NSMutableArray *) getBeansWithoutDeletedAndHideDESC;

- (NSMutableArray *) getBeansWithoutDeletedAndHideDESCBySearchText: (NSString *) searchText;

- (NSMutableArray *) getBeansForAgentWithoutDeletedAndHideDESCBySearchText: (NSString *) searchText;

- (NSMutableArray *) getBeansWithUploadStatus:(NSString *)uploadStatus;

- (NSMutableArray *) getOverlapBeansByFSCCode: (NSString *)fscCode andStartDateNum:(NSNumber *) startNumber andEndDateNum:(NSNumber *) endNumber andOid: (NSString *)oid;

@end
