//
//  EventLogDao.m
//  TSSProject
//
//  Created by TSS on 16/5/13.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import "EventLogDao.h"
#import "EventLogBean.h"
#import "Singleton.h"
#import "TSSValidationUtil.h"
#import "SystemTss.h"
#import "TSSFileManager.h"
#import "TSSAppData.h"
#import "TSSHardWareUtil.h"
#import "TSSAppSetting.h"

@implementation EventLogDao

SYNTHESIZE_SINGLETON_FOR_CLASS(EventLogDao);

- (id) init
{
    NSMutableArray *tableColumes = [self readValuesFromTablePlist:Event_Log_TABLE_NAME];
    self = [super init:Event_Log_TABLE_NAME primaryColumnName:BEAN_ID columnDetails:tableColumes];
    
    if (self) {
        self.setBeanValueBlock = ^(FMResultSet *result)
        {
            
            EventLogBean *o = [EventLogBean new];
            return o;
        };
        self.getBeanValueBlock = ^(Bean *bean) {
            
            return [NSMutableDictionary dictionary];
        };
    }
    
    return self;
}



- (void) initWithDB
{
    @try
    {
        [self openDB];
    }
    @catch (NSException *e)
    {
        //[e printStackTrace];
    }
}


- (NSMutableDictionary *) getBeanValue:(Bean *) bean
{
    NSMutableDictionary *ht = [NSMutableDictionary dictionaryWithCapacity:[self.columnDetails count]];
    
    EventLogBean *o = (EventLogBean *) bean;
    
    NSMutableArray *temp = [NSMutableArray arrayWithArray:[o allPropertyNames]];
    
    for (int i=0; i<temp.count; i++)
    {
        [self htSetObject:ht forBean:o selName:[temp objectAtIndex:i]];
    }
    
    [ht setObject:[TSSValidationUtil convertNilToNull:o.idKey] forKey:BEAN_ID];
    [ht setObject:[TSSValidationUtil convertNilToNull:o.updatedate] forKey:UPDATE_COLUMN_NAME];
    [ht setObject:[TSSValidationUtil convertNilToNull:o.createdate] forKey:CREATE_COLUMN_NAME];
    
    return ht;
}

-(void)htSetObject:(NSMutableDictionary*) ht forBean:(EventLogBean*)bean selName:(NSString*)name;
{
    [ht setObject:[TSSValidationUtil convertNilToNull:[bean doGetMethord:name]] forKey:name];
}

- (void) setBeanValue:(NSMutableDictionary *) ht forBean: (Bean *) bean
{
    EventLogBean *o = (EventLogBean *) bean;
    
    o.idKey = [TSSValidationUtil convertNullToNil:[ht objectForKey:BEAN_ID]];
    o.updatedate = [TSSValidationUtil convertNullToNil:[ht objectForKey:UPDATE_COLUMN_NAME]];
    o.createdate = [TSSValidationUtil convertNullToNil:[ht objectForKey:CREATE_COLUMN_NAME]];
    
    [o assginToPropertyWithDictionary:ht];
}

- (id) createBean
{
    return [[EventLogBean alloc] init];
}


- (NSMutableArray*)getBeansWithCount:(int)aNumber
{
    NSString *where = FORMAT(@"ORDER BY updatedate ASC LIMIT %d", aNumber);
    NSMutableArray *t = [self selectAllWhere:where parameters:nil];
    return t;
}

-(void)eventSaveByType:(NSString*)aType
{
    EventLogBean *temp = [[EventLogBean alloc] init];
    temp.eventtype = aType;
    temp.agentcode = [TSSAppData getInstance].agentCode;
    temp.devicetype = [TSSHardWareUtil platformString];
    temp.deviceosversion = [TSSHardWareUtil deviceSystemVersion];
    temp.smartversion = FORMAT(@"%@.%@",[TSSAppSetting getInstance].majorVersion,[TSSAppSetting getInstance].minVersion);
    [temp save];
    //temp.agentcode = [tss];
}
@end
