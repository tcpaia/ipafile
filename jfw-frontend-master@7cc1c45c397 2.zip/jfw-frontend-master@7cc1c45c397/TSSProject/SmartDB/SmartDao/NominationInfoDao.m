//
//  NominationInfoDao.m
//  TSSProject
//
//  Created by WFF on 22/10/2017.
//  Copyright © 2017 AIA. All rights reserved.
//

#import "NominationInfoDao.h"
#import "NominationInfoBean.h"
#import "Singleton.h"
#import "TSSValidationUtil.h"
#import "SystemTss.h"
#import "TSSFileManager.h"

@implementation NominationInfoDao
SYNTHESIZE_SINGLETON_FOR_CLASS(NominationInfoDao);

- (id) init
{
    //TEST_BEAN_COLUMN_DETAILS;
    NSMutableArray *tableColumes = [self readValuesFromTablePlist: NOMINATIONINFO_TABLE_NAME];
    self = [super init:NOMINATIONINFO_TABLE_NAME primaryColumnName:BEAN_ID columnDetails:tableColumes];
    
    if (self) {
        self.setBeanValueBlock = ^(FMResultSet *result)
        {
            NominationInfoBean *o = [NominationInfoBean new];
            return o;
        };
        self.getBeanValueBlock = ^(Bean *bean) {
            return [NSMutableDictionary dictionary];
        };
    }
    return self;
}

- (void) initWithDB
{
    @try
    {
        [self openDB];
    }
    @catch (NSException *e)
    {
        //[e printStackTrace];
    }
}

- (NSMutableDictionary *) getBeanValue:(Bean *) bean
{
    NSMutableDictionary *ht = [NSMutableDictionary dictionaryWithCapacity:[self.columnDetails count]];
    
    NominationInfoBean *o = (NominationInfoBean *) bean;
    
    NSMutableArray *temp = [NSMutableArray arrayWithArray:[o allPropertyNames]];
    
    for (int i=0; i<temp.count; i++)
    {
        [self htSetObject:ht forBean:o selName:[temp objectAtIndex:i]];
    }
    
    [ht setObject:[TSSValidationUtil convertNilToNull:o.idKey] forKey:BEAN_ID];
    [ht setObject:[TSSValidationUtil convertNilToNull:o.updatedate] forKey:UPDATE_COLUMN_NAME];
    [ht setObject:[TSSValidationUtil convertNilToNull:o.createdate] forKey:CREATE_COLUMN_NAME];
    
    return ht;
}

-(void)htSetObject:(NSMutableDictionary*) ht forBean:(NominationInfoBean*)bean selName:(NSString*)name;
{
    [ht setObject:[TSSValidationUtil convertNilToNull:[bean doGetMethord:name]] forKey:name];
}

- (void) setBeanValue:(NSMutableDictionary *) ht forBean: (Bean *) bean
{
    NominationInfoBean *o = (NominationInfoBean *) bean;
    
    o.idKey = [TSSValidationUtil convertNullToNil:[ht objectForKey:BEAN_ID]];
    o.updatedate = [TSSValidationUtil convertNullToNil:[ht objectForKey:UPDATE_COLUMN_NAME]];
    o.createdate = [TSSValidationUtil convertNullToNil:[ht objectForKey:CREATE_COLUMN_NAME]];
    
    [o assginToPropertyWithDictionary:ht];
}

- (id) createBean
{
    return [[NominationInfoBean alloc] init];
}

- (NominationInfoBean *) getBeanWithNominationInfoID: (NSString *) nominationInfoID
{
    NSString *where = FORMAT(@"WHERE nominationInfoID = ? ");
    NSArray *parameters = [NSArray arrayWithObjects:nominationInfoID,nil];
    NSMutableArray *result =[self selectAllWhere:where parameters:parameters];
    if (result != nil && result.count > 0) {
        return [result objectAtIndex:0];
    }
    return nil;
}

- (NominationInfoBean *)getBeansDESCWithCount:(int) count
{
    NSString *where = FORMAT(@"ORDER BY assessorStartDate DESC LIMIT ?");
    NSArray *parameters = [NSArray arrayWithObjects:@(count),nil];
    NSMutableArray * result = [self selectAllWhere:where parameters:parameters];
    if (result != nil && result.count > 0) {
        return [result objectAtIndex:0];
    }
    return nil;
}

- (NSMutableArray *) getBeansWithoutDeletedAndHideDESC
{
    NSString *where = FORMAT(@"WHERE deleteStatus != ? and deleteStatus != ? ORDER BY assessorStartDate DESC, assessorEndDate DESC");
    NSArray *parameters = [NSArray arrayWithObjects: NOMINATION_STATUS_REMOVE, NOMINATION_STATUS_HIDE, nil];
    NSMutableArray *t = [self selectAllWhere: where parameters: parameters];
    return t;
}

- (NSMutableArray *) getBeansWithoutDeletedAndHideDESCBySearchText: (NSString *) searchText
{
    NSMutableString *querySql = [NSMutableString stringWithFormat: @"WHERE deleteStatus != ? and deleteStatus != ? "];

    if ([TSSValidationUtil isNilOrEmptyString: searchText] == NO) {
        [querySql appendFormat: @"and (fscCode LIKE '%%%@%%' or fscName LIKE '%%%@%%' or assessorCode LIKE '%%%@%%' or assessorName LIKE '%%%@%%') ", searchText, searchText, searchText, searchText];
    }
    [querySql appendFormat: @"ORDER BY assessorStartDate DESC , assessorEndDate DESC"];
    NSArray *parameters = [NSArray arrayWithObjects: NOMINATION_STATUS_REMOVE, NOMINATION_STATUS_HIDE, nil];
    NSMutableArray *t = [self selectAllWhere: querySql parameters: parameters];
    return t;
}

- (NSMutableArray *) getBeansForAgentWithoutDeletedAndHideDESCBySearchText: (NSString *) searchText
{
    NSMutableString *querySql = [NSMutableString stringWithFormat: @"WHERE deleteStatus != ? and deleteStatus != ? "];
    
    if ([TSSValidationUtil isNilOrEmptyString: searchText] == NO) {
        [querySql appendFormat: @"and (assessorCode LIKE '%%%@%%' or assessorName LIKE '%%%@%%') ", searchText, searchText];
    }
    [querySql appendFormat: @"ORDER BY assessorStartDate DESC , assessorEndDate DESC"];
    NSArray *parameters = [NSArray arrayWithObjects: NOMINATION_STATUS_REMOVE, NOMINATION_STATUS_HIDE, nil];
    NSMutableArray *t = [self selectAllWhere: querySql parameters: parameters];
    return t;
}

- (NSMutableArray *) getBeansWithUploadStatus:(NSString *)uploadStatus
{
    NSString *where = FORMAT(@"WHERE uploadStatus = ?");
    NSArray *parameters = [NSArray arrayWithObjects:uploadStatus,nil];
    return [self selectAllWhere:where parameters:parameters];
}

- (NSMutableArray *) getOverlapBeansByFSCCode: (NSString *)fscCode andStartDateNum:(NSNumber *) startNumber andEndDateNum:(NSNumber *) endNumber andOid: (NSString *)oid
{
    NSMutableString *querySql = [NSMutableString stringWithFormat: @"where deleteStatus = ? and fscCode = ? "];
    [querySql appendFormat: @"and ((assessorStartDate <= ? and assessorEndDate>= ?) "];
    [querySql appendFormat: @"or (assessorStartDate <= ? and assessorEndDate>= ?) "];
    [querySql appendFormat: @"or (assessorStartDate <= ? and assessorEndDate>= ?) "];
    [querySql appendFormat: @"or (assessorStartDate >= ? and assessorEndDate<= ?)) "];

    NSMutableArray *parameters = [NSMutableArray arrayWithObjects: NOMINATION_STATUS_PENDING, fscCode, startNumber, startNumber, endNumber, endNumber, startNumber, endNumber, startNumber, endNumber, nil];
    //如果是修改，要排除当前这一条
    if ([TSSValidationUtil isNilOrEmptyString: oid] == NO) {
        [querySql appendFormat: @"and oid != ? "];
        [parameters addObject: oid];
    }
    [querySql appendFormat: @"ORDER BY assessorStartDate DESC , assessorEndDate DESC"];
    return [self selectAllWhere:querySql parameters:parameters];
}

@end
