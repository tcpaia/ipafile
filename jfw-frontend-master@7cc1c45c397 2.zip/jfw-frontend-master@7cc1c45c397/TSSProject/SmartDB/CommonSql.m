//
//  CommonSql.m
//  TSSProject
//
//  Created by aiait on 2018/9/3.
//  Copyright © 2018年 AIA. All rights reserved.
//

#import "CommonSql.h"

@implementation CommonSql

static CommonSql *__commonSqlClass;
+(CommonSql *)sharedcommonSql
{
    static dispatch_once_t oneToken;
    
    dispatch_once(&oneToken, ^{
        
        __commonSqlClass = [[CommonSql alloc]init];
        
    });
    
    return __commonSqlClass;
}


-(NSArray *)setNetworkInfoSqlString{
    
    NSString * sql1 = @"delete from NetworkInfo;";
    NSString * sql2 = @"insert into NetworkInfo (beanid, buildVesion, serverURL, loginPageURL, webServicesURL, newsFeedURL, nameSpace) values ('1','UAT_SGP','https://iposuat.aia.com.sg/imosmart/RestfulService/callAction/','https://iposuat.aia.com.sg/ipos/AgentActivationIL?CMD=TOKEN','https://iposuat.aia.com.sg/ipos/ServerWS','http://10.72.5.223:8180/imosmart/RestfulService/callAction/','http://ws.ipos.tfs/');";
    NSString * sql3 = @"insert into NetworkInfo (beanid, buildVesion, serverURL, loginPageURL, webServicesURL, newsFeedURL, nameSpace) values ('2','SIT_SGP','http://sinagsljbs01.aia.biz:8280/imosmart/RestfulService/callAction/','http://sinagsljbs01.aia.biz:8180/ipos/AgentActivationIL?CMD=TOKEN','http://sinagsljbs01.aia.biz:8180/ipos/ServerWS','http://10.72.5.223:8180/imosmart/RestfulService/callAction/','http://ws.ipos.tfs/');";
    NSString * sql4 = @"insert into NetworkInfo (beanid, buildVesion, serverURL, loginPageURL, webServicesURL, newsFeedURL, nameSpace) values ('3','DEMO_GROUP','http://54.169.209.137/imosmart1/RestfulService/callAction/','','','http://10.72.5.223:8180/imosmart/RestfulService/callAction/','http://ws.ipos.tfs/');";
    NSString * sql5 = @"insert into NetworkInfo (beanid, buildVesion, serverURL, loginPageURL, webServicesURL, newsFeedURL, nameSpace) values ('4','SIT_COE','http://10.72.5.40:8080/imosmart/RestfulService/callAction/','','','http://10.72.5.223:8180/imosmart/RestfulService/callAction/','http://ws.ipos.tfs/');";
    NSString * sql6 = @"insert into NetworkInfo (beanid, buildVesion, serverURL, loginPageURL, webServicesURL, newsFeedURL, nameSpace) values ('5','PRO_SGP','https://mypageapp.aia.com.sg/imosmart/RestfulService/callAction/','https://ipos.aia.com.sg/ipos/AgentActivationIL?CMD=TOKEN','https://ipos.aia.com.sg/ipos/ServerWS','http://10.72.5.223:8180/imosmart/RestfulService/callAction/','http://ws.ipos.tfs/');";
    
    NSArray * arr = @[@"",sql1,sql2,sql3,sql4,sql5,sql6,@""];
    return arr;
}

-(NSArray *)sqlArray{
    
    NSArray * arr = [[NSArray alloc]init];
    arr = [self setNetworkInfoSqlString];
    return arr;
}

@end
