//
//  main.m
//  TSSProject
//
//  Created by TSS on 15/12/1.
//  Copyright © 2015年 AIA. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#include <sys/sysctl.h>
#import "HashValue.h"
#import "TSSAppSetting.h"
#import "EncrypationObject.h"

static bool AmIBeingDebugged(void)
// Returns true if the current process is being debugged (either
// running under the debugger or has a debugger attached post facto).
{
    int                 junk;
    int                 mib[4];
    struct kinfo_proc   info;
    size_t              size;
    
    // Initialize the flags so that, if sysctl fails for some bizarre
    // reason, we get a predictable result.
    
    info.kp_proc.p_flag = 0;
    
    // Initialize mib, which tells sysctl the info we want, in this case
    // we're looking for information about a specific process ID.
    
    mib[0] = CTL_KERN;
    mib[1] = KERN_PROC;
    mib[2] = KERN_PROC_PID;
    mib[3] = getpid();
    
    // Call sysctl.
    
    size = sizeof(info);
    junk = sysctl(mib, sizeof(mib) / sizeof(*mib), &info, &size, NULL, 0);
    assert(junk == 0);
    
    // We're being debugged if the P_TRACED flag is set.
    
    return ( (info.kp_proc.p_flag & P_TRACED) != 0 );
}

int main(int argc, char * argv[]) {
#if defined(HONGKONGPRODUCTION) || defined(MALAYSIAPRODUCTION) || defined(CHINAPRODUCTION)
#ifndef DEBUG
    BOOL isDebugging = AmIBeingDebugged();
    DLog(@"AmIBeingDebugged = %d",isDebugging);
    if (isDebugging) {
#ifndef DEBUG
        return -1;
#endif
    }
    FILE *file = fopen(argv[0], "rb");
    // Read entire contents of executable file; calculate a hash value
    // ...
    if (file == NULL) {
        fclose(file);
        return -1;
    }
    //    NSInteger count = 0;
    //    fseek(file, 0, SEEK_END);
    //    count = ftell(file);
    //    NSLog(@"fileSize = %ld",count);
    //    fseek(file, 0, SEEK_SET);
    unsigned char buffer[32*1024];
    fread(buffer, sizeof(unsigned char), sizeof(buffer), file);
    NSData *hashData = [NSData dataWithBytes:buffer length:sizeof(buffer)];
    DLog(@"mutData.length = %ld,byte = %ld",(long)hashData.length,(long)sizeof(hashData.bytes));
    hashData = [HashValue sha256HashWithData:hashData];
    hashData = [HashValue sha256HashWithData:hashData];
    hashData = [HashValue sha256HashWithData:hashData];
    NSString *hashString = [hashData base64Encoding];
    fclose(file);
    NSError *error = nil;
    NSDictionary *info = [[NSBundle mainBundle] infoDictionary];
    if ([info objectForKey: @"SignerIdentity"] != nil) {
        return -1;
    }
    NSString *pathApp = [[NSBundle mainBundle] executablePath];
    NSDictionary *dictFileAttributeApp = [[NSFileManager defaultManager] attributesOfItemAtPath:pathApp error:&error];
    if (error) {
        DLog(@"error == %@",error);
        return -1;
    }
    NSDate *modifiedDateApp = [dictFileAttributeApp fileModificationDate];
    
    NSString *pathPkgInfo = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"PkgInfo"];
    NSDictionary *dictFileAttributePkgInfo = [[NSFileManager defaultManager] attributesOfItemAtPath:pathPkgInfo error:&error];
    if (error) {
        DLog(@"error == %@",error);
        return -1;
    }
    NSDate *modifiedDatePkgInfo = [dictFileAttributePkgInfo fileModificationDate];
    DLog(@"modifiedDateApp == %@, modifiedDatePkgInfo = %@",modifiedDateApp,modifiedDatePkgInfo);
    DLog(@"modifiedDateApp == %@, modifiedDatePkgInfo = %@",modifiedDateApp,modifiedDatePkgInfo);
    if(fabs([modifiedDateApp timeIntervalSinceReferenceDate] - [modifiedDatePkgInfo timeIntervalSinceReferenceDate]) > 600) {
#ifndef DEBUG
        return -1;
#endif
    }
    
    NSDictionary *dictFileAttributeSettings = [[NSFileManager defaultManager] attributesOfItemAtPath:[TSSAppSetting getInstance].settingsPath error:&error];
    if (error) {
        DLog(@"error == %@",error);
        return -1;
    }
    NSDate *modifiedDateSettings = [dictFileAttributeSettings fileModificationDate];
    DLog(@"modifiedDatePkgInfo == %@, modifiedDateSettings = %@",modifiedDatePkgInfo,modifiedDateSettings);
    DLog(@"modifiedDatePkgInfo == %@, modifiedDateSettings = %@",modifiedDatePkgInfo,modifiedDateSettings);
    if(fabs([modifiedDateSettings timeIntervalSinceReferenceDate] - [modifiedDatePkgInfo timeIntervalSinceReferenceDate]) > 600) {
#ifndef DEBUG
        return -1;
#endif
    }
    DLog(@"hashString == %@, SumKey = %@",hashString,[TSSAppSetting getInstance].sumKey);
    DLog(@"hashString == %@, SumKey = %@",hashString,[TSSAppSetting getInstance].sumKey);
    if (!hashString || ![TSSAppSetting getInstance].sumKey || ![hashString isEqualToString:[TSSAppSetting getInstance].sumKey]) {
        return -1;
    }
    
#endif
#endif
    
#if defined(ROLEPLAYSIT)
    DLog(@"is 64 Bit System == %d, fileName = %@", [TFUtil isSystem64BitSupport], [TFUtil formatPlatformFileName:@"t11-en.db3"]);
    AppTargetType targetType = kAppTargetTypeHongKongProduction;
    NSString *bundleId = [AIAPreLoadScriptUtil getBundleIdByAppTargetType:targetType];
    
    NSString *preScriptDatabaseFileName = [TFUtil appFileNameWithFileType:kAppFileTypePreLoadScriptDatabase targetType:targetType encrypted:NO];
    NSString *preScriptDatabasePassword = [TFUtil getEncryptionKeyWithString:bundleId type:EncryptionKeyTypePreLoadScript];
    NSString *preScriptDatabaseFilePath = [[NSBundle mainBundle] pathForResource:preScriptDatabaseFileName ofType:nil];
    [AIAPreLoadScriptUtil encryptPreScriptDatabaseAtPath:preScriptDatabaseFilePath withPassword:preScriptDatabasePassword];
    
    NSString *appSettingsFileName = [TFUtil appFileNameWithFileType:kAppFileTypeSettingsPlist targetType:targetType encrypted:NO];
    NSString *appSettingsPassword = [TFUtil getEncryptionKeyWithString:bundleId type:EncryptionKeyTypeAppSettings];
    NSString *appSettingsFilePath = [[NSBundle mainBundle] pathForResource:appSettingsFileName ofType:nil];
    [AIAPreLoadScriptUtil encryptAppSettingsAtPath:appSettingsFilePath withPassword:appSettingsPassword];
#endif
    

    @autoreleasepool {
        return UIApplicationMain(argc, argv, @"AIAAppEventsController", NSStringFromClass([AppDelegate class]));
    }
}
