//
//  AIAAppEventsController.m
//  RolePlayer
//
//  Created by Ming Zhang on 1/18/16.
//  Copyright © 2016 AIA. All rights reserved.
//

#import "AIAAppEventsController.h"
#include <unistd.h>
#include <sys/types.h>
#include <sys/sysctl.h>
#include <string.h>
#include <dlfcn.h>
#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#import "AppDelegate.h"
#import "TSSAppSetting.h"

#pragma mark - Reset IdleTimer
#define kNotificationShouldResetAppIdleTimer @"NotificationShouldResetAppIdleTimer"

#define kTimeOutMinute (20)
#define kTimeOutMaxSeconds (1200)

@interface AIAAppEventsController () {
    NSTimer *idleTimer;
}

@end;

@implementation AIAAppEventsController

- (instancetype)init{
    if(self = [super init]){
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleApplicationDidEnterBackgroundNotification:) name:UIApplicationDidEnterBackgroundNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleApplicationWillEnterForegroundNotification:) name:UIApplicationWillEnterForegroundNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(resetIdleTimer) name:kNotificationShouldResetAppIdleTimer object:nil];
        [self startIdleTimer];
    }
    return self;
}


- (void)sendEvent:(UIEvent *)event {
    //NSLog(@"sendEvent");
    [super sendEvent:event];
    // Only want to reset the timer on a Began touch or an Ended touch, to reduce the number of timer resets.
    NSSet *allTouches = [event allTouches];
    if ([allTouches count] > 0) {
        // allTouches count only ever seems to be 1, so anyObject works here.
        UITouchPhase phase = ((UITouch *)[allTouches anyObject]).phase;
        if (phase == UITouchPhaseEnded){
            [self resetIdleTimer];
        }
    }
}

- (void)resetIdleTimer {
//    DLog(@"resetIdleTimer");
    [self invalidateIdleTimer];
    [self startIdleTimer];
}

- (void)idleTimerExceeded {
    [self invalidateIdleTimer];
    
    [(AppDelegate *)self.delegate showTimeoutAlert];
}

- (void)handleApplicationDidEnterBackgroundNotification:(NSNotification *)notification {
    [self invalidateIdleTimer];
}

- (void)handleApplicationWillEnterForegroundNotification:(NSNotification *) notif {
    [self resetIdleTimer];
}

- (void)startIdleTimer {
    idleTimer = [NSTimer scheduledTimerWithTimeInterval:60*[TSSAppSetting getInstance].timeoutMinute target:self selector:@selector(idleTimerExceeded) userInfo:nil repeats:NO];
    [[NSRunLoop mainRunLoop] addTimer:idleTimer forMode:NSRunLoopCommonModes];
}

- (void)invalidateIdleTimer {
    if (idleTimer) {
        [idleTimer invalidate];
        idleTimer = nil;
    }
}

@end
