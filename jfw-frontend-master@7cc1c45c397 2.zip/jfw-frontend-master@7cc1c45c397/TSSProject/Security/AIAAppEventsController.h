//
//  AIAAppEventsController.h
//  RolePlayer
//
//  Created by Ming Zhang on 1/18/16.
//  Copyright © 2016 AIA. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AIAAppEventsController : UIApplication

@end
