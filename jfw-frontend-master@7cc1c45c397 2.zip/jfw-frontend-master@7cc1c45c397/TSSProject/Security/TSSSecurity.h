//
//  TSSSecurity.h
//  TSSProject
//
//  Created by TSS on 16/4/6.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import <Foundation/Foundation.h>
#include <sys/types.h>
#include <sys/sysctl.h>
#import <sys/stat.h>
#include <string.h>
#import <mach-o/loader.h>
#import <mach-o/dyld.h>
#import <mach-o/arch.h>
#import <CommonCrypto/CommonDigest.h>

#define TIMEBOMB_PASS @"Pass"
#define TIMEBOMB_ALERT @"TimebombAlert"
#define TIMEBOMB1_EXPIRE @"Timebomb1"
#define TIMEBOMB2_EXPIRE @"Timebomb2"
#define AGENT_LASTTIME_EMPTY @"ActivationTimeEmpty"

@interface TSSSecurity : NSObject

+ (NSString *)headerNoteName;
+ (NSString *)encryptionKey;
+ (NSString *)separator1;
+ (NSString *)separator2;
+ (bool)jailbroken;
+ (bool)jailbrokenOC;
+ (NSString *) decryptMasterKeyFile:(NSString *) agentCode withPassword:(NSString *) password;
+ (NSString *) md5DecryptMasterKeyFile:(NSString *) agentCode withPassword:(NSString *) password;

+ (void) encryptMasterKeyWithPassword:(NSString *) agentCode withPassword:(NSString *) password;
+ (void) md5EncryptMasterKeyWithPassword:(NSString *) agentCode withPassword:(NSString *) password;

+ (bool *) checkMasterKeyFile:(NSString *) agentCode;
+ (BOOL *) md5CheckMasterKeyFile:(NSString *) agentCode;
+ (NSString *) md5:(NSString *)text;
+ (NSString *) sha256:(NSString *)text;
+ (NSString*) checkNoTimebomb:(NSString*) lastActivationTime;
+ (BOOL)isSystemBackDated:(NSDate *)lastLoginTime;

+ (void) writeTestTimeStr: (NSString *)timeLogStr toTestFileName: (NSString *)testFileName andTimeInterval: (NSTimeInterval)timeInterval;
+ (void) writeResponseData: (NSData *)returnData toTestFileName: (NSString *)testFileName andTimeInterval: (NSTimeInterval)timeInterval;
+ (NSString *)enCodeDataBase64:(NSString *)base64String;
+ (NSString *)deCodeDataBase64:(NSString *)base64String;
@end
