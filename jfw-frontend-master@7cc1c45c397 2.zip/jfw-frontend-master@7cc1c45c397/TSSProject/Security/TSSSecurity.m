//
//  TSSSecurity.m
//  TSSProject
//
//  Created by TSS on 16/4/6.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import "TSSSecurity.h"
#import "TSSValidationUtil.h"
#import "TSSAppData.h"
#import "SystemTss.h"
#import "TSSAppData.h"
#import "TSSFileManager.h"
#import "HashValue.h"
#import "NSData+AES256.h"
#import "PDKeyChain.h"
#import "TSSAppSetting.h"
#import "NSDate+Ex.h"

@implementation TSSSecurity

+ (NSString *)headerNoteName {
    return @"key";
}

+ (NSString *)encryptionKey {
    NSInteger repeatCount = 10;
    NSInteger digitalCount = 32;
    NSMutableString *mutKey = [NSMutableString string];
    for (NSInteger i = 0; i < repeatCount; i++) {
        [mutKey appendString:[TSSValidationUtil convertNilToEmptyString:[TSSAppData getInstance].agentCode]];
    }
    mutKey = [NSMutableString stringWithString:[mutKey substringToIndex:MIN(mutKey.length, digitalCount)]];
    for (NSInteger i = mutKey.length; i < digitalCount; i++) {
        [mutKey appendString:@"0"];
    }
    DLog(@"mutKey === %@",mutKey);
    return mutKey;
}

+ (NSString *)separator1 {
    return @":";
}

+ (NSString *)separator2 {
    return @"#####";
}

+ (bool)jailbrokenOC{
    
#if !(TARGET_IPHONE_SIMULATOR)
    
    if ([[NSFileManager defaultManager] fileExistsAtPath:@"/Applications/Cydia.app"])
    {
        return YES;
    }
    else if ([[NSFileManager defaultManager] fileExistsAtPath:@"/Library/MobileSubstrate/MobileSubstrate.dylib"])
    {
        return YES;
    }
    else if ([[NSFileManager defaultManager] fileExistsAtPath:@"/bin/bash"])
    {
        return YES;
    }
    else if ([[NSFileManager defaultManager] fileExistsAtPath:@"/usr/sbin/sshd"])
    {
        return YES;
    }
    else if ([[NSFileManager defaultManager] fileExistsAtPath:@"/etc/apt"])
    {
        return YES;
    }
    else if ([[NSFileManager defaultManager] fileExistsAtPath:@"/var/lib/xcon"])
    {
        return YES;
    }
    
    
    NSError *error;
    NSString *testWriteText = @"Jailbreak test";
    NSString *testWritePath = @"/private/jailbreaktest.txt";
    
    NSData *testWriteTextData = [testWriteText dataUsingEncoding:NSUTF8StringEncoding];
    NSFileHandle *fileHandle = [NSFileHandle fileHandleForWritingAtPath:testWritePath];
    [fileHandle writeData:testWriteTextData];
    [fileHandle closeFile];
    if (error == nil)
    {
        [[NSFileManager defaultManager] removeItemAtPath:testWritePath error:nil];
        return YES;
    }
    else
    {
        [[NSFileManager defaultManager] removeItemAtPath:testWritePath error:nil];
    }
    
    if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"cydia://package/com.example.package"]])
    {
        return YES;
    }
    
#endif
    
    return NO;
}

+ (bool)jailbroken {
    
#if !(TARGET_IPHONE_SIMULATOR)
    
    //Directory permissions checking
    NSArray *nameArray = @[@"/Applications/Cydia.app",
                           @"/Library/MobileSubstrate/MobileSubstrate.dylib",
                           @"/var/lib/cydia",
                           @"/var/cache/apt",
                           @"/var/lib/apt",
                           @"/etc/apt",
                           @"/bin/bash",
                           @"/bin/sh",
                           @"/usr/sbin/sshd",
                           @"/usr/libexec/ssh-keysign",
                           @"/etc/ssh/sshd_config",
                           @"/var/lib/xcon"
                           ];
    
    struct stat s;
    for (NSString *fileName in nameArray) {
        const char *charFileName = [fileName UTF8String];
        //        if (stat(charFileName, &s) != -1) { //replace stat to be lstat for pen test issue
        if (lstat(charFileName, &s) != -1) {
            return YES;
        }
    }
    
    //Directory permissions checking
    NSArray *dicrectoryArray = @[@"/Applications",
                                 @"/Library/Ringtones",
                                 @"/Library/Wallpaper",
                                 @"/usr/include",
                                 @"/usr/libexec",
                                 @"/usr/share"
                                 ];
    
    struct stat d;
    for (NSString *dName in dicrectoryArray) {
        const char *charDName = [dName UTF8String];
        
        lstat(charDName, &d);
        
        if (d.st_mode & S_IFLNK) {
            return YES;
        }
    }
    
    
    NSMutableArray *mutArray = [NSMutableArray arrayWithArray:nameArray];
    [mutArray addObjectsFromArray:dicrectoryArray];
    [mutArray removeObject:@"/Applications"];
    [mutArray removeObject:@"/Library/Ringtones"];
    [mutArray removeObject:@"/usr/share"];
    NSInteger index = 0;
    for (NSString *fName in mutArray) {
        //        [[TFSLog getInstance] logString:[NSString stringWithFormat:@"%s(Line: %d)To detect Jailbroken: FILENAME = %@", __func__, __LINE__, fName] type:TFSLOGINFO];
        FILE *output = fopen([fName UTF8String], "r");
        DLog(@"index = [%ld], fileName = %@", index++, fName);
        if (output) {
            DLog(@"isJailbroken: %@", fName);
            return YES;
        }
        fclose(output);
    }
    
    //Process forking
//    if (fork() != -1) {
//        return YES;
//    }
    
    //dyld checking
    uint32_t count = _dyld_image_count();
    for(uint32_t i = 0; i < count; i++){
        const char *dyld = _dyld_get_image_name(i);
        int slength = strlen(dyld);
        
        int j;
        for(j = slength - 1; j>= 0; --j){
            if(dyld[j] == '/') break;
        }
        
        NSString *dyldString = [NSString stringWithUTF8String:dyld];
        if ([dyldString hasSuffix:@"/Library/MobileSubstrate/MobileSubstrate.dylib"] ||
            [dyldString hasSuffix:@"/Library/MobileSubstrate/DynamicLibraries/xCon.dylib"]) {
            return YES;
        }
        
    }
    
    return NO;
    
    
#endif
    
    return NO;
}

+(void)encryptMasterKeyWithPassword:(NSString *) agentCode withPassword:(NSString *) password
{
    NSString * documentFolderPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    
    NSString * agentFolder = FORMAT(@"%@/%@",documentFolderPath,[TSSSecurity sha256:agentCode]);
    [TSSFileManager createFolder:agentFolder];
    NSString * masterKeyFile = FORMAT(@"%@/%@.mkf",agentFolder,[TSSSecurity sha256:agentCode]);

    DLog(@"encryptMasterKeyWithPassword masterKayFile:%@", masterKeyFile);
    BOOL existed = [TSSFileManager fileExits:masterKeyFile];

    if(existed)
    {
        DLog(@"Deleting exiting masterkey file: %@", masterKeyFile);
        [TSSFileManager deleteFile:masterKeyFile];
    } else {
        DLog(@"Not exiting masterkey file: %@", masterKeyFile);
    }

    // Create an empty text file.
    [[NSFileManager defaultManager] createFileAtPath:masterKeyFile contents:nil attributes:[NSDictionary dictionaryWithObject:NSFileProtectionComplete forKey: NSFileProtectionKey]];

    // Open a handle to it.
    NSFileHandle* pfile = [NSFileHandle fileHandleForWritingAtPath:masterKeyFile];

    NSData * hashPassword = [HashValue sha256HashWithString:password];
    [pfile writeData:[[[NSString stringWithString:FORMAT(@"%@\n%@",[TSSAppData getInstance].agentCode,[TSSAppData getInstance].masterKey)] dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKeyData:hashPassword]];
    [pfile closeFile];
     /*NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
    
     NSString *tSwitch = [user objectForKey:TOUCHID_SWITCH];
    if (![tSwitch isEqualToString:TOUCHID_UNABLE]) {
        [user setObject:[TSSAppData getInstance].agentCode forKey:TOUCHID_AGENT];
        [user setObject:[TSSAppData getInstance].agentPassword forKey:TOUCHID_PASS];
    }*/
    
}

+ (void) md5EncryptMasterKeyWithPassword:(NSString *) agentCode withPassword:(NSString *) password
{
    
    NSString * documentFolderPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    
    NSString * agentFolder = FORMAT(@"%@/%@",documentFolderPath,[TSSSecurity md5:agentCode]);
    [TSSFileManager createFolder:agentFolder];
    NSString * masterKeyFile = FORMAT(@"%@/%@.mkf",agentFolder,[TSSSecurity md5:agentCode]);
    
    DLog(@"encryptMasterKeyWithPassword masterKayFile:%@", masterKeyFile);
    BOOL existed = [TSSFileManager fileExits:masterKeyFile];
    
    if(existed)
    {
        DLog(@"Deleting exiting masterkey file: %@", masterKeyFile);
        [TSSFileManager deleteFile:masterKeyFile];
    } else {
        DLog(@"Not exiting masterkey file: %@", masterKeyFile);
    }
    
    // Create an empty text file.
    [[NSFileManager defaultManager] createFileAtPath:masterKeyFile contents:nil attributes:[NSDictionary dictionaryWithObject:NSFileProtectionComplete forKey: NSFileProtectionKey]];
    
    // Open a handle to it.
    NSFileHandle* pfile = [NSFileHandle fileHandleForWritingAtPath:masterKeyFile];
    
    NSData * hashPassword = [HashValue sha256HashWithString:password];
    [pfile writeData:[[[NSString stringWithString:FORMAT(@"%@\n%@",[TSSAppData getInstance].agentCode,[TSSAppData getInstance].masterKey)] dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKeyData:hashPassword]];
    [pfile closeFile];
    /*NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
     
     NSString *tSwitch = [user objectForKey:TOUCHID_SWITCH];
     if (![tSwitch isEqualToString:TOUCHID_UNABLE]) {
     [user setObject:[TSSAppData getInstance].agentCode forKey:TOUCHID_AGENT];
     [user setObject:[TSSAppData getInstance].agentPassword forKey:TOUCHID_PASS];
     }*/
    
}

+ (BOOL *) checkMasterKeyFile:(NSString *) agentCode
{
    NSString * documentFolderPath = [TSSFileManager applicationDocumentsDirectory];
    NSString * agentFolder = FORMAT(@"%@/%@", documentFolderPath, [TSSSecurity sha256:agentCode]);
    NSString * masterKeyFile = FORMAT(@"%@/%@.mkf",agentFolder,[TSSSecurity sha256:agentCode]);

    DLog(@"checkMasterKeyFile:%@", masterKeyFile);
    if(![TSSFileManager fileExits:masterKeyFile])
    {
        DLog(@"checkMasterKeyFile Not Exists: %@", masterKeyFile);
        return NO;
    } else {
        DLog(@"checkMasterKeyFile Exists: %@", masterKeyFile);
        return YES;
    }

}

+ (BOOL *) md5CheckMasterKeyFile:(NSString *) agentCode
{
    NSString * documentFolderPath = [TSSFileManager applicationDocumentsDirectory];
    NSString * agentFolder = FORMAT(@"%@/%@", documentFolderPath, [TSSSecurity md5:agentCode]);
    NSString * masterKeyFile = FORMAT(@"%@/%@.mkf",agentFolder,[TSSSecurity md5:agentCode]);
    
    DLog(@"checkMasterKeyFile:%@", masterKeyFile);
    if(![TSSFileManager fileExits:masterKeyFile])
    {
        DLog(@"checkMasterKeyFile Not Exists: %@", masterKeyFile);
        return NO;
    } else {
        DLog(@"checkMasterKeyFile Exists: %@", masterKeyFile);
        return YES;
    }
    
}

+ (NSString *) decryptMasterKeyFile:(NSString *) agentCode withPassword:(NSString *) password
{
    NSString * documentFolderPath = [TSSFileManager applicationDocumentsDirectory];
    NSString * agentFolder = FORMAT(@"%@/%@", documentFolderPath, [TSSSecurity sha256:agentCode]);
    NSString * masterKeyFile = FORMAT(@"%@/%@.mkf",agentFolder,[TSSSecurity sha256:agentCode]);
    NSString * masterKey = nil;
    
    if(![TSSFileManager fileExits:masterKeyFile])
    {
        return @"";
    }
    
    NSData *myData = [NSData dataWithContentsOfFile:masterKeyFile];
    
    if (myData)
    {
        myData = [myData AES256DecryptWithKeyData:[HashValue sha256HashWithString:password]];
        
        NSString* content = [[NSString alloc] initWithData:myData encoding:NSUTF8StringEncoding];
        
        if (!(content == nil || content.length == 0))
        {
            NSArray *tokens = [content componentsSeparatedByString:@"\n"];
            
            if([[tokens objectAtIndex:0] isEqualToString:agentCode])
            {
                masterKey = [tokens objectAtIndex:1];
            }
            else {
                masterKey = @"";
            }
        }
        else {
            masterKey = @"";
        }
        
        //        NSLog(@"decrypt masterkey file %@", content);
        
    }
    DLog(@"master key = %@",masterKey);
    return masterKey;
}

+ (NSString *) md5DecryptMasterKeyFile:(NSString *) agentCode withPassword:(NSString *) password
{
    NSString * documentFolderPath = [TSSFileManager applicationDocumentsDirectory];
    NSString * agentFolder = FORMAT(@"%@/%@", documentFolderPath, [TSSSecurity md5:agentCode]);
    NSString * masterKeyFile = FORMAT(@"%@/%@.mkf",agentFolder,[TSSSecurity md5:agentCode]);
    NSString * masterKey = nil;
    
    if(![TSSFileManager fileExits:masterKeyFile])
    {
        return @"";
    }
    
    NSData *myData = [NSData dataWithContentsOfFile:masterKeyFile];
    
    if (myData)
    {
        myData = [myData AES256DecryptWithKeyData:[HashValue sha256HashWithString:password]];
        
        NSString* content = [[NSString alloc] initWithData:myData encoding:NSUTF8StringEncoding];
        
        if (!(content == nil || content.length == 0))
        {
            NSArray *tokens = [content componentsSeparatedByString:@"\n"];
            
            if([[tokens objectAtIndex:0] isEqualToString:agentCode])
            {
                masterKey = [tokens objectAtIndex:1];
            }
            else {
                masterKey = @"";
            }
        }
        else {
            masterKey = @"";
        }
        
        //        NSLog(@"decrypt masterkey file %@", content);
        
    }
    DLog(@"master key = %@",masterKey);
    return masterKey;
}

/*
#pragma mark write masterKey to keychain
+(void)encryptMasterKeyFromKeychainWithPassword:(NSString *) agentCode withPassword:(NSString *) password;
{
    
    NSString * documentFolderPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    
    NSString * agentFolder = FORMAT(@"%@/%@",documentFolderPath,[TSSAppData getInstance].agentCode);
    [TSSFileManager createFolder:agentFolder];
    NSString * masterKeyFile = FORMAT(@"%@/%@.mkf",agentFolder,[TSSAppData getInstance].agentCode);
    
    NSLog(@"encryptMasterKeyWithPassword masterKayFile:%@", masterKeyFile);
    BOOL existed = ![TSSValidationUtil isNilOrEmptyString:[PDKeyChain keyChainLoad:kMaterKeyFileKey]];
    
    if(existed)
    {
        NSLog(@"Deleting exiting masterkey file: %@", masterKeyFile);
    } else {
        NSLog(@"Not exiting masterkey file: %@", masterKeyFile);
    }
    [PDKeyChain  keyChainSaveKey:kMaterKeyFileKey withkeyChainValue:masterKeyFile];
}

#pragma get masterkey from keychain
+ (NSString *) decryptMasterKeyFileFromKeychainWithAgentCode:(NSString *) agentCode withPassword:(NSString *) password
{
    NSString * documentFolderPath = [TSSFileManager applicationDocumentsDirectory];
    NSString * agentFolder = FORMAT(@"%@/%@", documentFolderPath, agentCode);
    NSString * masterKeyFile = FORMAT(@"%@/%@.mkf",agentFolder,agentCode);
    NSString * masterKey = nil;
    
    if([TSSValidationUtil isNilOrEmptyString:[PDKeyChain keyChainLoad:kMaterKeyFileKey]])
    {
        return @"";
    }
    
    NSData *myData = [NSData dataWithContentsOfFile:masterKeyFile];
    
    if (myData)
    {
        myData = [myData AES256DecryptWithKeyData:[HashValue sha256HashWithString:password]];
        
        NSString* content = [[NSString alloc] initWithData:myData encoding:NSUTF8StringEncoding];
        
        if (!(content == nil || content.length == 0))
        {
            NSArray *tokens = [content componentsSeparatedByString:@"\n"];
            
            if([[tokens objectAtIndex:0] isEqualToString:agentCode])
            {
                masterKey = [tokens objectAtIndex:1];
            }
            else {
                masterKey = @"";
            }
        }
        else {
            masterKey = @"";
        }
        
        //        NSLog(@"decrypt masterkey file %@", content);
        
    }
    NSLog(@"master key = %@",masterKey);
    return masterKey;
}
*/

+ (NSString *) md5:(NSString *)text {
    const char *cStr = [text UTF8String];
    unsigned char digest[CC_MD5_DIGEST_LENGTH];
    CC_MD5( cStr, strlen(cStr), digest ); // This is the md5 call
    
    NSMutableString *output = [NSMutableString stringWithCapacity:CC_MD5_DIGEST_LENGTH * 2];
    
    for(int i = 0; i < CC_MD5_DIGEST_LENGTH; i++)
    {
        [output appendFormat:@"%02x", digest[i]];
    }
    
    return  output;
}

+ (NSString *) sha256:(NSString *)text {
    const char *cStr = [text UTF8String];
    unsigned char digest[CC_SHA256_DIGEST_LENGTH];   
    CC_SHA256(cStr, strlen(cStr), digest);
    
    NSMutableString *output = [NSMutableString stringWithCapacity:CC_SHA256_DIGEST_LENGTH * 2];
    
    for(int i = 0; i < CC_SHA256_DIGEST_LENGTH; i++) {
        [output appendFormat:@"%02x", digest[i]];
    }

    return  output;
}

+ (NSString*) checkNoTimebomb:(NSString*) lastActivationTime
{
    if([TSSValidationUtil isNilOrNull:lastActivationTime] || lastActivationTime.length <= 0) {
        return AGENT_LASTTIME_EMPTY;
    }
    long long llnowinSeconds = [[NSDate date] timeIntervalSince1970];
    long long lllastLogintimeinSeconds = [lastActivationTime longLongValue] / 1000.0;
    long long timebomb1inSeconds = (long long)[[TSSAppSetting getInstance].timebomb1 longLongValue] * 24 * 60 * 60;
    //long long timebomb1inSeconds = (long long)[[TSSAppSetting getInstance].timebomb1 longLongValue];
    long long timebomb2inSeconds = (long long)[[TSSAppSetting getInstance].timebomb2 longLongValue] * 24 * 60 * 60;
    //long long timebomb2inSeconds = (long long)[[TSSAppSetting getInstance].timebomb2 longLongValue];
    long long timebomb3inSeconds = (long long)[[TSSAppSetting getInstance].timebomb3 longLongValue] * 24 * 60 * 60;
    long long deta = llnowinSeconds - lllastLogintimeinSeconds;
    
    if(deta>=timebomb2inSeconds) {
        //*nsmsg = [NSString stringWithFormat:@"You have not do activation over %@ days, suggest do activation.", [TSSAppSetting getInstance].timebomb1];
        return TIMEBOMB2_EXPIRE;
    }
    if(deta>=timebomb1inSeconds) {
        return TIMEBOMB1_EXPIRE;
    }
    if (deta>=timebomb3inSeconds) {
        NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"MM-dd"];
        NSString *nowDate = [dateFormatter stringFromDate:[NSDate date]];
        if (![nowDate isEqualToString:[userDefault objectForKey:@"nowDate"]]) {
            [userDefault setObject:nowDate forKey:@"nowDate"];
            [userDefault synchronize];
            return TIMEBOMB_ALERT;
        }
    }
    //*nsmsg = [NSString stringWithFormat:@"You have not do activation over %@ days. Please do activation first.", [TSSAppSetting getInstance].timebomb2];
    return TIMEBOMB_PASS;
}

+ (BOOL)isSystemBackDated:(NSDate *)lastLoginTime {
    if (!lastLoginTime) {
        return YES;
    }
    NSDate *now = [NSDate date];
    if (!lastLoginTime) {
        return YES;
    }
    if ([now isBeforeDate:[lastLoginTime dateByAddingTimeInterval:((-1)*3600*24)]]) {
        return YES;
    }
    return NO;
}

+ (void) writeTestTimeStr: (NSString *)timeLogStr toTestFileName: (NSString *)testFileName andTimeInterval: (NSTimeInterval)timeInterval
{
    NSData *timeData = [timeLogStr dataUsingEncoding: NSUTF8StringEncoding];
    [TSSSecurity writeResponseData:timeData toTestFileName:testFileName andTimeInterval:timeInterval];
}

+ (void) writeResponseData: (NSData *)returnData toTestFileName: (NSString *)testFileName andTimeInterval: (NSTimeInterval)timeInterval
{
    NSString * documentFolderPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    NSString *filePath = [NSString stringWithFormat: @"%@/%@_%f.txt", documentFolderPath, testFileName, timeInterval];
    [[NSFileManager defaultManager] createFileAtPath:filePath contents:nil attributes:[NSDictionary dictionaryWithObject:NSFileProtectionComplete forKey: NSFileProtectionKey]];

    NSFileHandle* pfile = [NSFileHandle fileHandleForWritingAtPath:filePath];
    [pfile writeData: returnData];
    [pfile closeFile];
}

+ (NSString *)enCodeDataBase64:(NSString *)base64String{
    
    NSData *data = [base64String dataUsingEncoding:NSUTF8StringEncoding];
    
    NSData *base64Data = [data base64EncodedDataWithOptions:0];
    
    NSString *baseString = [[NSString alloc]initWithData:base64Data encoding:NSUTF8StringEncoding];
    
    return baseString;
}

+ (NSString *)deCodeDataBase64:(NSString *)base64String{
    
    NSData *data = [[NSData alloc]initWithBase64EncodedString:base64String options:NSDataBase64DecodingIgnoreUnknownCharacters];
    
    NSString *string = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
    
    return string;
}

@end
