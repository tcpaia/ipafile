//
//  AppDelegate.h
//  TSSProject
//
//  Created by TSS on 15/12/1.
//  Copyright © 2015年 AIA. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

@class ICSDrawerController;

@interface AppDelegate : UIResponder <UIApplicationDelegate,UIAlertViewDelegate>

@property (strong, nonatomic) UIWindow *window;

- (void)getAddressFromLocation:(CLLocation *)location completionHandler:(void (^)(NSMutableDictionary *placemark))completionHandler failureHandler:(void (^)(NSError *error))failureHandler;

- (void)showTimeoutAlert;

@end

