//
//  LoginViewController.m
//  TSSProject
//
//  Created by TSS on 16/2/25.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import "LoginViewController.h"
#import "SystemTss.h"
#import "TSSMenuController.h"
//#import "ICSPlainColorViewController.h"
#import "TSSAppData.h"


@interface LoginViewController ()

@property (strong, nonatomic) UIView *scrollView1;//first screen(0,0,1042,768)
@property (strong, nonatomic) UILabel *lblWord1;
@property (strong, nonatomic) UIButton *btnSignIn1;

@property (strong, nonatomic) UIView *scrollView2;//second screen(1042,01042,768)
@property (strong, nonatomic) UILabel *lblCode;
@property (strong, nonatomic) UITextField *textCode;//code
@property (strong, nonatomic) UILabel *lblPWD;
@property (strong, nonatomic) UITextField *textPWD;//password
@property (strong, nonatomic) UIButton *btnSignIn2;

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //there are two screen layout in scroll view, each screen has a uiview
    //for storing component
    [self setLayout];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self selectedItemAtIndex:0];
}
-(void)setLayout
{
    _vScroll.contentSize = CGSizeMake(SCREEN_WEIGHT*2, SCREEN_HEIGHT);
    _vScroll.delegate = self;
    [self loginView1UILayout];
    [self loginView2UILayout];
}
-(void)loginView1UILayout
{
    _scrollView1 = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 400, 400)];
    //_scrollView1.backgroundColor = [UIColor redColor];
    _scrollView1.backgroundColor = [UIColor clearColor];
    _scrollView1.center = self.view.center;
    _lblWord1 = [[UILabel alloc] initWithFrame:CGRectMake(50, 100, 300, 40)];
    _lblWord1.text = CustomLocalizedString(@"loginScrollView1Word", nil);
    _lblWord1.textColor = [UIColor whiteColor];
    //_lblWord1.backgroundColor = [UIColor whiteColor];
    _lblWord1.textAlignment = NSTextAlignmentCenter;
    _btnSignIn1 = [[UIButton alloc] initWithFrame:CGRectMake(100, 180, 200, 28)];
    [_btnSignIn1 setBackgroundColor:[UIColor redColor]];
    [_btnSignIn1 setTitle:NSLocalizedString(@"signIn", nil) forState:UIControlStateNormal];
    [_vScroll addSubview:_scrollView1];
    [_scrollView1 addSubview:_btnSignIn1];
    [_scrollView1 addSubview:_lblWord1];
    [_btnSignIn1 addTarget:self action:@selector(btnSignInPressed) forControlEvents:UIControlEventTouchUpInside];
}

-(void)loginView2UILayout
{
    float weight = SCREEN_WEIGHT;
    NSLog(@"%s weight:%f",__func__,weight);
    _scrollView2 = [[UIView alloc] initWithFrame:CGRectMake(SCREEN_WEIGHT, 0, 500, 400)];
    //_scrollView2.backgroundColor = [UIColor redColor];
    _scrollView1.backgroundColor = [UIColor clearColor];
    _scrollView2.center = CGPointMake(SCREEN_WEIGHT+SCREEN_WEIGHT/2,SCREEN_HEIGHT/2);
    [_vScroll addSubview:_scrollView2];
    
    int space = 4;
    _lblCode =[[UILabel alloc] initWithFrame:CGRectMake(space, 50, 100, 28)];
    //_lblCode.text = NSLocalizedString(@"client", nil);
    _lblCode.text = CustomLocalizedString(@"client", nil);
    _lblCode.textColor = [UIColor whiteColor];
    //_lblCode.backgroundColor = [UIColor yellowColor];
    _lblCode.textAlignment = NSTextAlignmentCenter;
    _textCode = [[UITextField alloc] initWithFrame:CGRectMake(space+100+space, 50, 100, 28)];
    //_textCode.borderStyle = UITextBorderStyleLine;
    _textCode.backgroundColor = [UIColor lightGrayColor];
    _textCode.placeholder = CustomLocalizedString(@"client", nil);
    _textCode.textAlignment = NSTextAlignmentCenter;
    _lblPWD =[[UILabel alloc] initWithFrame:CGRectMake(space+100+space+100+space, 50, 100, 28)];
    _lblPWD.text = CustomLocalizedString(@"password", nil);
    _lblPWD.textColor = [UIColor whiteColor];
    //_lblPWD.backgroundColor = [UIColor yellowColor];
    _lblPWD.textAlignment = NSTextAlignmentCenter;
    _textPWD = [[UITextField alloc] initWithFrame:CGRectMake(space+100+space+100+space+100+space, 50, 100, 28)];
    _textPWD.borderStyle = UITextBorderStyleLine;
    _textPWD.backgroundColor = [UIColor lightGrayColor];
    _textPWD.placeholder = CustomLocalizedString(@"password", nil);
    _textPWD.textAlignment = NSTextAlignmentCenter;
    
    [_scrollView2 addSubview:_lblCode];
    [_scrollView2 addSubview:_textCode];
    [_scrollView2 addSubview:_lblPWD];
    [_scrollView2 addSubview:_textPWD];
    
    _btnSignIn2 = [[UIButton alloc] initWithFrame:CGRectMake(150, 180, 200, 28)];
    [_btnSignIn2 setBackgroundColor:[UIColor redColor]];
    [_btnSignIn2 setTitle:CustomLocalizedString(@"signIn", nil) forState:UIControlStateNormal];
    [_scrollView2 addSubview:_btnSignIn2];


    [_btnSignIn2 addTarget:self action:@selector(btnSignIn2Pressed) forControlEvents:UIControlEventTouchUpInside];
    
    
    NSArray *dataArray = @[@{@"image":@"sun.png",@"title":@"EN"},
                           @{@"image":@"clouds.png",@"title":@"Chinese"},
                           @{@"image":@"snow.png",@"title":@"EN-US"},
                           @{@"image":@"rain.png",@"title":@"Indoesia"},
                           @{@"image":@"windy.png",@"title":@"France"},];
    NSMutableArray *dropdownItems = [[NSMutableArray alloc] init];
    for (int i = 0; i < dataArray.count; i++) {
        NSDictionary *dict = dataArray[i];
        
        IGLDropDownItem *item = [[IGLDropDownItem alloc] init];
        //[item setIconImage:[UIImage imageNamed:dict[@"image"]]];
        [item setText:dict[@"title"]];
        [dropdownItems addObject:item];
    }

    IGLDropDownMenu *dropDownMenu = [[IGLDropDownMenu alloc] init];
    dropDownMenu.menuText = CustomLocalizedString(@"selectLanguage", nil);
    dropDownMenu.itemAnimationDelay = 0.;
    dropDownMenu.rotate = IGLDropDownMenuRotateRandom;
    dropDownMenu.dropDownItems = dropdownItems;
    dropDownMenu.paddingLeft = 15;
    [dropDownMenu setFrame:CGRectMake(150, 150, 200, 28)];
    dropDownMenu.type = IGLDropDownMenuTypeNormal;
    dropDownMenu.delegate = self;
    
   [dropDownMenu reloadView];
    
    [_scrollView2 addSubview:dropDownMenu];
}
#pragma mark SignIn2
- (void)btnSignIn2Pressed
{
    TSSMenuController *menuVC = [UFStoryboard(@"Main") instantiateViewControllerWithIdentifier:@"menu_controller_id"];
    
    menuVC.paneViewControllerType = TSSPaneViewControllerTypePlain;
    
    ICSPlainColorViewController *plainColorVC = [[ICSPlainColorViewController alloc] init];
    
    [TSSAppData getInstance].drawer = [[ICSDrawerController alloc] initWithLeftViewController:menuVC
                                                                         centerViewController:plainColorVC];
    
    [self presentViewController:[TSSAppData getInstance].drawer  animated:NO completion:nil];

}
#pragma mark SignIn
- (void)btnSignInPressed {
    [UIView animateWithDuration:1 delay:0.0f options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [_vScroll scrollRectToVisible:CGRectMake(SCREEN_WEIGHT, 0, SCREEN_WEIGHT, SCREEN_HEIGHT) animated:NO];
    } completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)selectedItemAtIndex:(NSInteger)index
{
    
    NSString *currentLanguage = [[NSUserDefaults standardUserDefaults]objectForKey:AppLanguage];
    if ([currentLanguage isEqualToString: @"en"]) {
        [[NSUserDefaults standardUserDefaults] setObject:@"zh-Hans" forKey:AppLanguage];
    }else
    {
        [[NSUserDefaults standardUserDefaults] setObject:@"en" forKey:AppLanguage];
    }
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self reLoadUIString];

}

- (void)reLoadUIString
{
    _lblWord1.text = NSLocalizedString(@"loginScrollView1Word", nil);
    [_btnSignIn1 setTitle:NSLocalizedString(@"signIn", nil) forState:UIControlStateNormal];
    _lblCode.text = CustomLocalizedString(@"client", nil);
    _textCode.placeholder = CustomLocalizedString(@"client", nil);
    _lblPWD.text = CustomLocalizedString(@"password", nil);
    _textPWD.placeholder = CustomLocalizedString(@"password", nil);
    [_btnSignIn2 setTitle:CustomLocalizedString(@"signIn", nil) forState:UIControlStateNormal];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
