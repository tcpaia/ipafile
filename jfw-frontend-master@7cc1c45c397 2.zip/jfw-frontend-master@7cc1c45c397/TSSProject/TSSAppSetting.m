//
//  TSSAppSetting.m
//  TSSProject
//
//  Created by TSS on 16/4/6.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import "TSSAppSetting.h"
#import "Singleton.h"
#import "TSSFileManager.h"
#import "SystemTss.h"
#import "EncrypationObject.h"

#import "TSSAppDataBase.h"
#import "NetworkInfoBean.h"
#import "NetworkInfoDao.h"
#import "TSSAppData.h"
@implementation TSSAppSetting

SYNTHESIZE_SINGLETON_FOR_CLASS(TSSAppSetting)

@synthesize serverUrl;
@synthesize settingsPath;
@synthesize settingsDictionary;
@synthesize timeoutMinute;

@synthesize newsFeedUrl;
@synthesize nameSpace;

- (instancetype) init {
    self = [super init];
    if (self) {
        self.settingsPath = [[NSBundle mainBundle] pathForResource:@"Setting.plist" ofType:nil];
        self.settingsDictionary = [NSDictionary dictionary];
        @try {
            BOOL fileExsit = [[TSSFileManager defaultFileManager] fileExits:self.settingsPath];
            if (!fileExsit) {
                DLog(@"Fatal Error, Settings database not exsited...");
                exit(-1);
            }
            self.settingsDictionary = [NSDictionary dictionaryWithContentsOfFile:self.settingsPath];
        }
        @catch (NSException *exception) {
            DLog(@"exception == %@", exception);
        }
        @finally {
            DLog(@"finally");
        }
        self.sumKey = self.settingsDictionary[@"sumKey"];
        BOOL isBool = [[EncrypationObject getInstance] encryptionFilePath:self.settingsPath];
        DLog(@"%d",isBool);
        self.buildVesion = BUILD_VERSION_PRO_SGP;
#if LOGIN_WITHOUT_ACTIVATION >= 1
        self.buildVesion = BUILD_VERSION_SIT_COE;
#if TEST_NET_RESPONSE_TIME > 0
        self.buildVesion = BUILD_VERSION_UAT_SGP;
#endif
#endif
//        [[TSSAppDataBase getInstance] initCommonDb];
        [[TSSAppDataBase getInstance] createCommonDbForTest];
//        [[TSSAppDataBase getInstance] initCommonInfoTestDb];
        NetworkInfoBean *networkInfoBean = [[NetworkInfoDao getInstance] selectNetworkInfoBeanByBuildVesion: self.buildVesion];
        self.serverUrl = networkInfoBean.serverURL;
        self.loginPageUrl = networkInfoBean.loginPageURL;
        self.webServicesUrl = networkInfoBean.webServicesURL;
        
#if LOGIN_WITHOUT_ACTIVATION >= 0
        if ([self.buildVesion isEqualToString:BUILD_VERSION_SIT_SGP]) {
//            self.serverUrl = @"http://10.48.113.153:8280/imosmart/RestfulService/callAction/";
            self.serverUrl = @"http://10.72.5.60:8080/imosmart/RestfulService/callAction/";
            self.loginPageUrl = @"http://10.48.113.153:8180/ipos/AgentActivationIL?CMD=TOKEN";
            self.webServicesUrl = @"http://10.48.113.153:8180/ipos/ServerWS";
        }
        else if([self.buildVesion isEqualToString:BUILD_VERSION_DEMO])
        {
            self.serverUrl = @"http://54.169.209.137/imosmart1/RestfulService/callAction/";
        }
        else if([self.buildVesion isEqualToString:BUILD_VERSION_SIT_COE])
        {
//            self.serverUrl = @"http://10.72.5.40:8080/imosmart/RestfulService/callAction/";
//            self.serverUrl = @"http://10.72.5.63:8080/imosmart/RestfulService/callAction/";
            
            self.serverUrl = @"http://10.121.111.29:8280/imosmart/RestfulService/callAction/";
            self.loginPageUrl = @"http://10.121.111.29:8180/ipos/AgentActivationIL?CMD=TOKEN";
            self.webServicesUrl = @"http://10.121.111.29:8180/ipos/ServerWS";
            
//            self.serverUrl = @"http://sinagsljbs01.aia.biz:8280/imosmart/RestfulService/callAction/";
//            self.loginPageUrl = @"http://sinagsljbs01.aia.biz:8180/ipos/AgentActivationIL?CMD=TOKEN";
//            self.webServicesUrl = @"http://sinagsljbs01.aia.biz:8180/ipos/ServerWS";
        }
        else if([self.buildVesion isEqualToString:BUILD_VERSION_UAT_SGP])
        {
            //bau
            //            self.serverUrl = @"https://iposuat.aia.com.sg/imosmart/RestfulService/callAction/";//AFnetworking
            //            [TSSAppData getInstance].sslCertFile = @"ipos_uat";
            
            //azure
            self.serverUrl = @"https://jfwazuat.aia.com.sg/imosmart/RestfulService/callAction/";//AFnetworking
            [TSSAppData getInstance].sslCertFile = @"azure_uat";
            

            self.loginPageUrl = @"https://iposuat.aia.com.sg/ipos3/AgentActivationIL?CMD=TOKEN";
            self.webServicesUrl = @"https://iposuat.aia.com.sg/ipos3/ServerWS";//soap request
        }
        else if([self.buildVesion isEqualToString:BUILD_VERSION_PRO_SGP])
        {
            //self.serverUrl = @"https://mypageapp.aia.com.sg/imosmart/RestfulService/callAction/";
            self.serverUrl = @"https://jfwaz.aia.com.sg/imosmart/RestfulService/callAction/";

            self.loginPageUrl = @"https://ipos.aia.com.sg/ipos/AgentActivationIL?CMD=TOKEN";
            self.webServicesUrl = @"https://ipos.aia.com.sg/ipos/ServerWS";
            
            [TSSAppData getInstance].sslCertFile = @"ipos_prod";

        }
#endif
        
        if([self.buildVesion isEqualToString:BUILD_VERSION_SIT_COE])
        {
            self.serverUrl = @"http://10.121.111.29:8280/imosmart/RestfulService/callAction/";
            self.loginPageUrl = @"http://10.121.111.29:8180/ipos/AgentActivationIL?CMD=TOKEN";
            self.webServicesUrl = @"http://10.121.111.29:8180/ipos/ServerWS";
        }
        
        
//        self.serverUrl = @"http://10.72.5.55:8080/imosmart/RestfulService/callAction/";
//
//        //            self.serverUrl = @"http://10.121.111.29:8280/imosmart/RestfulService/callAction/";
//        self.loginPageUrl = @"http://10.121.111.29:8180/ipos/AgentActivationIL?CMD=TOKEN";
//        self.webServicesUrl = @"http://10.121.111.29:8180/ipos/ServerWS";
        
        self.timeoutMinute = 20;
        self.majorVersion = @"1";
        self.minVersion = @"62";
//        self.newsFeedUrl = @"http://10.72.5.223:8180/imosmart/RestfulService/callAction/";
        self.newsFeedUrl = networkInfoBean.newsFeedURL;
        self.timebomb1 = @"90";
        self.timebomb2 = @"180";
        self.timebomb3 = @"83";
        self.world = @"Singapore";
        
        //switch
        self.home_sw = @"0";
        self.newsfeed_sw = @"0";
        self.dashboard_sw = @"0";
        self.notifaction_sw = @"0";
        self.customer_sw = @"1";
        self.quick_quote_sw = @"0";
        self.leads_sw = @"0";
        self.follow_up_sw = @"1";
        self.notes_sw = @"0";
        self.google_map_sw = @"0";
//        self.setting_sw = @"1";
        self.nomination_sw = @"1";
        self.settings_sw = @"1";
        self.baidu_map_sw = @"0";
        self.jfw_sw = @"1";
        self.traker_sw = @"1";
        self.logout = @"1";
        self.sharePreUrl = @"";
        self.buildTime = @"7 April 2020";
        self.buildNo = @"1";
        
        self.nameSpace = networkInfoBean.nameSpace;
    }
    return self;
}

@end
