//
//  TSSAppData.h
//  TSSProject
//
//  Created by TSS on 15/12/11.
//  Copyright © 2015年 AIA. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ICSDrawerController.h"

@interface TSSAppData : NSObject

+ (TSSAppData *) getInstance;

@property (strong, nonatomic) ICSDrawerController *drawer;

@property (strong, nonatomic) NSString* sslCertFile;

@property (strong, nonatomic) NSString* agentCode;

@property (strong, nonatomic) NSString* agentCheckingCode;

@property (strong, nonatomic) NSString* agentPassword;

@property (strong, nonatomic) NSString* masterKey;

@property (strong, nonatomic) NSString* deviceToken;

@property (strong, nonatomic) NSString* agentJfwRole;

@property (strong, nonatomic) NSString* agentName;

@property (strong, nonatomic) NSString* address;

@property (assign, nonatomic) BOOL touchOFF;

//如果登陆者是agent，则需要设置领导的code和name
@property (strong, nonatomic) NSString *leaderCode;
@property (strong, nonatomic) NSString *leaderName;

@property (strong, nonatomic) NSString* agentCodeEnyption;

-(NSString*)randomId;


@end
