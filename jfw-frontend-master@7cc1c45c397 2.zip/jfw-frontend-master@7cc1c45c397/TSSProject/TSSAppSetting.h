//
//  TSSAppSetting.h
//  TSSProject
//
//  Created by TSS on 16/4/6.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TSSAppSetting : NSObject



+ (TSSAppSetting *) getInstance;

@property (nonatomic, strong) NSString *serverUrl;
@property (nonatomic, strong) NSString *settingsPath;
@property (nonatomic, strong) NSDictionary *settingsDictionary;
@property (nonatomic, assign) int timeoutMinute;
@property (nonatomic, strong) NSString *majorVersion;
@property (nonatomic, strong) NSString *minVersion;
@property (nonatomic,copy) NSString *newsFeedUrl;
@property (nonatomic, strong) NSString *timebomb1;
@property (nonatomic, strong) NSString *timebomb2;
@property (nonatomic, strong) NSString *timebomb3;
@property (nonatomic, copy) NSString *world;

@property (nonatomic,copy) NSString *home_sw;
@property (nonatomic,copy) NSString *newsfeed_sw;
@property (nonatomic,copy) NSString *dashboard_sw;
@property (nonatomic,copy) NSString *notifaction_sw;
@property (nonatomic,copy) NSString *customer_sw;
@property (nonatomic,copy) NSString *quick_quote_sw;
@property (nonatomic,copy) NSString *leads_sw;
@property (nonatomic,copy) NSString *follow_up_sw;
@property (nonatomic,copy) NSString *notes_sw;
@property (nonatomic,copy) NSString *google_map_sw;
@property (nonatomic,copy) NSString *setting_sw;
@property (nonatomic,copy) NSString *nomination_sw;
@property (nonatomic,copy) NSString *settings_sw;
@property (nonatomic,copy) NSString *jfw_sw;
@property (nonatomic,copy) NSString *traker_sw;
@property (nonatomic,copy) NSString *baidu_map_sw;
@property (nonatomic,copy) NSString *logout;
@property (nonatomic,copy) NSString *sharePreUrl;
@property (nonatomic,copy) NSString *loginPageUrl;
@property (nonatomic,copy) NSString *webServicesUrl;
@property (nonatomic,copy) NSString *buildTime;
@property (nonatomic,copy) NSString *buildNo;
@property (nonatomic,copy) NSString *sumKey;
@property (nonatomic,copy) NSString *buildVesion;

@property (nonatomic,copy) NSString *nameSpace;
@end
