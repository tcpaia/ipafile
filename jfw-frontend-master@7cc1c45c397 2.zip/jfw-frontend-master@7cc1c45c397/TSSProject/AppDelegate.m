//
//  AppDelegate.m
//  TSSProject
//
//  Created by TSS on 15/12/1.
//  Copyright © 2015年 AIA. All rights reserved.
//

#import "AppDelegate.h"
#import "TSSSettingsUtil.h"
#import "TSSMenuController.h"
#import "ViewController.h"
#import "ICSDrawerController.h"
#import "TSSAppData.h"
#import "SystemTss.h"
#import "LoginViewController.h"
#import "SmartLoginViewController.h"
#import "TSSValidationUtil.h"
#import "TSSAppSetting.h"
#import "TSSFactoryComponent.h"
#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import "NewsFeedViewController.h"
#import "DashboardLeaderViewController.h"
#import "CustomerViewController.h"
#import "AppointmentViewController.h"
#import "TSSSecurity.h"
#import "TSSAppDataBase.h"
#import "SetUpViewController.h"
#import "Availability.h"
#import "ADBMobile.h"
#import "NetworkingManager.h"

#define KTouchItemPublicPosition @"touch1"
#define KTouchItemDashboard @"touch2"
#define KTouchItemCustomer @"touch3"
#define KTouchItemAppointment @"touch4"


@interface AppDelegate ()

@property (nonatomic) int suspendTimeStartFrom;
@property (nonatomic) BOOL didEnterBackGround;
@property (strong, nonatomic) UIImageView *backgroundImage;

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    [[NetworkingManager getInstance] startMonitoringNetwork];
    [ADBMobile setDebugLogging:YES];
    [[TSSSettingsUtil getInstance] readingSettingPreference];
    [[FBSDKApplicationDelegate sharedInstance] application:application
                             didFinishLaunchingWithOptions:launchOptions];
    UIUserNotificationSettings *notiSettings = [UIUserNotificationSettings settingsForTypes:(UIUserNotificationTypeNone | UIUserNotificationTypeBadge | UIUserNotificationTypeSound | UIUserNotificationTypeAlert) categories:nil];
    [[UIApplication sharedApplication] registerUserNotificationSettings:notiSettings];
    [[UIApplication sharedApplication] registerForRemoteNotifications];
    
    application.applicationIconBadgeNumber = 0;
    #ifdef __IPHONE_9_0
    [self init3DTouchActionShow:YES];
    #endif
    
    if([TSSSecurity jailbroken]) {
        [[TSSFactoryComponent getInstance] showAlertViewByType:SIInfomationType message:@"Smart can not run on jailbroken device" handler:^(SIAlertView *alertView) {
            exit(0);
        } otherHandler:nil];
        return NO;
    }
    
    if([TSSSecurity jailbrokenOC]) {
        [[TSSFactoryComponent getInstance] showAlertViewByType:SIInfomationType message:@"Smart can not run on jailbroken device" handler:^(SIAlertView *alertView) {
            exit(0);
        } otherHandler:nil];
        return NO;
    }
    [[TSSAppDataBase getInstance] initLanguageDb];
    
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    self.didEnterBackGround = YES;
    self.suspendTimeStartFrom = [[NSDate date] timeIntervalSince1970];
    
    UIImageView *myHomepage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Icon-76.png"]];
    myHomepage.frame = CGRectMake(0, 0, SCREEN_WEIGHT, SCREEN_HEIGHT);
    self.backgroundImage = myHomepage;
    [self.window addSubview:myHomepage];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"removedata" object:nil];
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    
    [[TSSSettingsUtil getInstance] readingSettingPreference];
    [self.backgroundImage removeFromSuperview];
    
    //send notification MonthTableViewcontroller reloaddata
    int indexTag = 0;
    NSDictionary *dict = [[NSDictionary alloc]initWithObjectsAndKeys:@(indexTag),@"indexTag", nil];
    NSNotification *notification = [NSNotification notificationWithName:@"reloaddata" object:nil userInfo:dict];
    [[NSNotificationCenter defaultCenter] postNotification:notification];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"loadDataSource" object:nil];
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    [self calculateInativeTime];
  
}

- (void)calculateInativeTime
{
    int now = [[NSDate date] timeIntervalSince1970];
    
    NSLog(@"applicationDidBecomeActive %d %d-%d=%d", self.didEnterBackGround, self.suspendTimeStartFrom, now, now-self.suspendTimeStartFrom);
    
    if(self.didEnterBackGround && (now - self.suspendTimeStartFrom > ([TSSAppSetting getInstance].timeoutMinute) * 60))
    {
        NSString *alert_str = FORMAT(@"Smart has been inactive for %d minutes.\n Smart will auto logout", [TSSAppSetting getInstance].timeoutMinute);
        
        [[TSSFactoryComponent getInstance] showAlertViewByType:SIInfomationType message:alert_str handler:^(SIAlertView *alertView) {
            exit(0);
        } otherHandler:nil];
    }
    //reset the flag
    self.didEnterBackGround = NO;
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}
- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation {
    BOOL handled = [[FBSDKApplicationDelegate sharedInstance] application:application
                                                                  openURL:url
                                                        sourceApplication:sourceApplication
                                                               annotation:annotation
                    ];
    // Add any custom logic here.
    return handled;
}


- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
    NSLog(@"deviceToken == %@",deviceToken);
    NSString *dt = [[deviceToken description] stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"<>"]];
    dt = [dt stringByReplacingOccurrencesOfString:@" " withString:@""];
    //NSLog(@"APN trimmed device token: %@", dt);
//    if ([AppVariable getInstance].ShouldLogDeviceToken) {
//        TFSLogInfo(@"deviceToken == %@,APN trimmed device token: %@", deviceToken, dt)
//    }
    if (![TSSValidationUtil isNilOrEmptyString:dt]) {
        [TSSAppData getInstance].deviceToken = [NSString stringWithFormat:@"%@", dt];
    } else {
        [TSSAppData getInstance].deviceToken = @"";
    }
    
}

- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error {
    //DLog(@"error == %@",error);
    //if ([AppVariable getInstance].ShouldLogDeviceToken) {
      //  TFSLogError(@"didFailToRegisterForRemoteNotificationsWithError error = %@",error);
    //}
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult result))completionHandler {
    //DLog(@"didReceiveRemoteNotification.userInfo == %@",userInfo);
    //remoteNotiDict = userInfo;
    //[self handelRemoteDictionary:userInfo];
    //completionHandler(UIBackgroundFetchResultNoData);
}

- (void)application:(UIApplication *)application
performActionForShortcutItem:(UIApplicationShortcutItem *)shortcutItem
  completionHandler:(void(^)(BOOL succeeded))completionHandler{
    
    NSNotification * notice = [NSNotification notificationWithName:NOTIFICATION_CLOSE object:nil userInfo:nil];
    //发送消息
    [[NSNotificationCenter defaultCenter]postNotification:notice];
    if([shortcutItem.type isEqualToString:KTouchItemDashboard])
    {

//        DashboardLeaderViewController *dashBoard = [[DashboardLeaderViewController alloc] initWithNibName:@"BaseViewController" bundle:nil];
//        dashBoard.titleTXT = @"Dashboard";
//       [[TSSAppData getInstance].drawer replaceCenterViewControllerWithViewController:dashBoard];
        SetUpViewController *tSetup = [[SetUpViewController alloc] initWithNibName:@"BaseViewController" bundle:nil];
        tSetup.titleTXT = @"tSetup";
       [[TSSAppData getInstance].drawer replaceCenterViewControllerWithViewController:tSetup];
    }
    else if([shortcutItem.type isEqualToString:KTouchItemCustomer])
    {
        CustomerViewController *cutVc = [[CustomerViewController alloc]initWithNibName:@"BaseViewController" bundle:nil];
        [cutVc.navigationController popToRootViewControllerAnimated:YES];
        cutVc.titleTXT = @"Customer profiles";
        [[TSSAppData getInstance].drawer replaceCenterViewControllerWithViewController:cutVc];
    }
    else if([shortcutItem.type isEqualToString:KTouchItemAppointment])
    {        
//        AppointmentViewController *appointment = [[AppointmentViewController alloc] initWithNibName:@"BaseViewController" bundle:nil];
//        appointment.titleTXT = @"Appointment";
//        
//        [[TSSAppData getInstance].drawer replaceCenterViewControllerWithViewController:appointment];
        
        NewsFeedViewController *newsFeed = [[NewsFeedViewController alloc] initWithNibName:@"BaseViewController" bundle:nil];
        newsFeed.titleTXT = @"NewsFeed";
        [[TSSAppData getInstance].drawer replaceCenterViewControllerWithViewController:newsFeed];
    }
}

/**
 *  手动添加3D touch功能
 */
-(void)init3DTouchActionShow:(BOOL)isShow{
    
    /** type 该item 唯一标识符
     localizedTitle ：标题
     localizedSubtitle：副标题
     icon：icon图标 可以使用系统类型 也可以使用自定义的图片
     userInfo：用户信息字典 自定义参数，完成具体功能需求
     */
    
    UIApplication *application = [UIApplication sharedApplication];
   // UIApplicationShortcutIcon *icon1 = [UIApplicationShortcutIcon iconWithType:UIApplicationShortcutIconTypeLove];
//    UIApplicationShortcutItem *item1 = [[UIApplicationShortcutItem alloc] initWithType:KTouchItemPublicPosition localizedTitle:@"我就是我" localizedSubtitle:@"还有什么" icon:icon1 userInfo:nil];
    
    UIApplicationShortcutIcon *icon2 = [UIApplicationShortcutIcon iconWithType:UIApplicationShortcutIconTypeShare];
    UIApplicationShortcutItem *item2 = [[UIApplicationShortcutItem alloc]initWithType:KTouchItemAppointment localizedTitle:@"Newsfeed" localizedSubtitle:@"Newsfeed" icon:icon2 userInfo:nil];
    
    UIApplicationShortcutIcon *icon3 = [UIApplicationShortcutIcon iconWithType:UIApplicationShortcutIconTypeProhibit];
    UIApplicationShortcutItem *item3 = [[UIApplicationShortcutItem alloc]initWithType:KTouchItemCustomer localizedTitle:@"Customer" localizedSubtitle:@"Customer" icon:icon3 userInfo:nil];
    
    UIApplicationShortcutIcon *icon4 = [UIApplicationShortcutIcon iconWithType:UIApplicationShortcutIconTypeCompose];
    UIApplicationShortcutItem *item4 = [[UIApplicationShortcutItem alloc]initWithType:KTouchItemDashboard localizedTitle:@"Settings" localizedSubtitle:@"Settings" icon:icon4 userInfo:nil];
    if (isShow) {
        application.shortcutItems = @[item2,item3,item4];
    }else{
        application.shortcutItems = @[];
    }
}
@end
