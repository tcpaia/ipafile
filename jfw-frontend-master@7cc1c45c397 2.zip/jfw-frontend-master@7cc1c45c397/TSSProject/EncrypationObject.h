//
//  EncrypationObject.h
//  TSSProject
//
//  Created by Lei on 31/03/2017.
//  Copyright © 2017 AIA. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface EncrypationObject : NSObject
+ (EncrypationObject *)getInstance;

- (BOOL)encryptionFilePath:(NSString *)filePath;
- (NSString *)decryptFilePath;
@end
