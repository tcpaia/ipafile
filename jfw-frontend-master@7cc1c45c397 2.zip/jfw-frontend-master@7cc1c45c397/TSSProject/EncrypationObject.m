//
//  EncrypationObject.m
//  TSSProject
//
//  Created by Lei on 31/03/2017.
//  Copyright © 2017 AIA. All rights reserved.
//

#import "EncrypationObject.h"
#import "NSData+AES256.h"
#import "TSSAppData.h"
#define FIlENAME @"AppSettings-encrypted"
static EncrypationObject *share = nil;

@implementation EncrypationObject

+ (EncrypationObject *)getInstance {
    
    if (share == nil) {
        share = [[EncrypationObject alloc]init];
    }
    return share;
}

- (BOOL)encryptionFilePath:(NSString *)filePath{
    NSArray *pathsArray = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *toPath = [[pathsArray firstObject] stringByAppendingPathComponent:FIlENAME];
    NSError *error = nil;
    if ([[NSFileManager defaultManager] fileExistsAtPath:toPath]) {
        [[NSFileManager defaultManager] removeItemAtPath:toPath error:&error];
    }
    NSDictionary *paramsDict = [NSDictionary dictionaryWithContentsOfFile:filePath];
    NSMutableData *sourceData = [[NSMutableData alloc] init];
    NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:sourceData];
    [archiver encodeObject:paramsDict forKey:@"key"];
    [archiver finishEncoding];
    NSData *encryptedData = [sourceData AES256EncryptWithKey:[TSSAppData getInstance].masterKey];
    
    NSFileHandle *fileHandle = [NSFileHandle fileHandleForWritingAtPath:toPath];
    [fileHandle writeData: encryptedData];
    [fileHandle closeFile];
    return YES;
}


- (NSString *)decryptFilePath {
    NSArray *pathsArray = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *toPath = [[pathsArray firstObject] stringByAppendingPathComponent:FIlENAME];
    NSData *decryptData = [[NSData dataWithContentsOfFile:toPath] AES256DecryptWithKey:[TSSAppData getInstance].masterKey];
    NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:decryptData];
    NSDictionary *paramsDict = [unarchiver decodeObjectForKey:@"key"];
    [unarchiver finishDecoding];
    NSString *sumKey = [paramsDict objectForKey:@"sumKey"];
    return sumKey;
}


@end

