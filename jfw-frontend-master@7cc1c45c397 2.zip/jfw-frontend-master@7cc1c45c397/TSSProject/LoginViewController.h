//
//  LoginViewController.h
//  TSSProject
//
//  Created by TSS on 16/2/25.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IGLDropDownMenu.h"

@interface LoginViewController : UIViewController<UIScrollViewDelegate,IGLDropDownMenuDelegate>

@property (strong, nonatomic) IBOutlet UIScrollView *vScroll;


@end
