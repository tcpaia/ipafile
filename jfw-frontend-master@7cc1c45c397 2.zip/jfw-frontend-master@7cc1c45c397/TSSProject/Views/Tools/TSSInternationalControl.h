//
//  TSSInternationalControl.h
//  TSSProject
//
//  Created by 于磊 on 16/4/6.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TSSInternationalControl : NSObject

+(NSBundle *)bundle;

+(void)initUserLanguage;

+(NSString *)userLanguage;

+(void)setUserLanguage:(NSString *)language;


@end
