//
//  DDLocate.m
//  DDMates
//
//  Created by ShawnMa on 12/27/11.
//  Copyright (c) 2011 TelenavSoftware, Inc. All rights reserved.
//

#import "TSLocation.h"

@implementation TSLocation
@synthesize state = _state;
@end
