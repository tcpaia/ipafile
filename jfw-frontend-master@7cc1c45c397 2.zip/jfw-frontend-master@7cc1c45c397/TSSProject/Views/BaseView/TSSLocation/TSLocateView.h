//
//  UICityPicker.h
//  DDMates
//
//  Created by ShawnMa on 12/16/11.
//  Copyright (c) 2011 TelenavSoftware, Inc. All rights reserved.
//


#import <QuartzCore/QuartzCore.h>
#import "TSLocation.h"

@protocol TSLocateViewDelegate <NSObject>

-(void)getSelectIndexValue:(NSString *)value;

@end

@interface TSLocateView : UIView<UIPickerViewDelegate, UIPickerViewDataSource>
@property (nonatomic,strong) NSArray *valueArr;
@property (nonatomic,copy) NSString *key;
@property (strong, nonatomic) UIPickerView *locatePicker;
@property (strong, nonatomic) TSLocation *locate;
@property (nonatomic,weak)id <TSLocateViewDelegate>kDelegate;

- (id)initWithFrame:(CGRect)frame andKeyCode:(NSString *)keyCode andDataSource:(NSArray *)dataSource ;
//显示的view
- (void)showInView:(UIView *)view;

-(void)dismissView;

@end
