//
//  UICityPicker.m
//  DDMates
//
//  Created by ShawnMa on 12/16/11.
//  Copyright (c) 2011 TelenavSoftware, Inc. All rights reserved.
//

#import "TSLocateView.h"

#define kDuration 0.3
#import "SystemTss.h"
#import "ColorDefine.h"
@implementation TSLocateView
@synthesize valueArr;
@synthesize locatePicker;
@synthesize locate;
@synthesize key;

- (id)initWithFrame:(CGRect)frame andKeyCode:(NSString *)keyCode andDataSource:(NSArray *)dataSource
{
    self = [super initWithFrame:frame];
    if (self) {
        key = keyCode;
        self.frame = frame;
        self.userInteractionEnabled = YES;
        //标题图片
        UIImageView *titleView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WEIGHT, 45)];
        titleView.userInteractionEnabled = YES;
        titleView.backgroundColor = UIColorMakeRGBA(240, 241, 242, 1);
        [self addSubview:titleView];
        //标题
        UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(100, 0, SCREEN_WEIGHT - 200, 45)];
        titleLabel.textAlignment = NSTextAlignmentCenter;
        titleLabel.textColor = UIColorMakeRGBA(203, 203, 203,1);
        titleLabel.backgroundColor = [UIColor clearColor];
        [titleView addSubview:titleLabel];
        //取消按钮
        UIButton *canalBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 80, 45)];
        canalBtn.userInteractionEnabled = YES;
        [canalBtn setTitleColor:UIColorMakeRGBA(203, 203, 203,1) forState:UIControlStateNormal];
        [canalBtn addTarget:self action:@selector(canalBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [canalBtn setTitle:@"<  >" forState:UIControlStateNormal];
        [titleView addSubview:canalBtn];
        //确定按钮
        UIButton *sureBtn = [[UIButton alloc]initWithFrame:CGRectMake(SCREEN_WEIGHT - 80, 0, 80, 45)];
        sureBtn.userInteractionEnabled = YES;
        [sureBtn setTitleColor:UIColorMakeRGBA(0, 122, 255, 1) forState:UIControlStateNormal];
        sureBtn.titleLabel.font = [UIFont systemFontOfSize:15 weight:0.5];
        [sureBtn setTitle:@"Done" forState:UIControlStateNormal];
        [sureBtn addTarget:self action:@selector(sureBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [titleView addSubview:sureBtn];
        //创建locatePicker
        locatePicker = [[UIPickerView alloc]initWithFrame:CGRectMake(0, 45, SCREEN_WEIGHT, 225)];
        locatePicker.backgroundColor = UIColorMakeRGBA(203, 203, 203,1);
        locatePicker.dataSource = self;
        locatePicker.delegate = self;
        [self addSubview:locatePicker];
        //加载数据
        valueArr = dataSource;
        
        //初始化默认数据
        self.locate = [[TSLocation alloc] init];
        self.locate.state = [[valueArr objectAtIndex:0] objectForKey:key];
        
    }
    return self;
}

- (void)showInView:(UIView *) view
{
    
    CATransition *animation = [CATransition  animation];
    animation.delegate = self;
    animation.duration = kDuration;
    animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    animation.type = kCATransitionPush;
    animation.subtype = kCATransitionFromTop;
    [self setAlpha:1.0f];
    [self.layer addAnimation:animation forKey:@"TSLocateView"];
    
    self.frame = CGRectMake(0, view.frame.size.height - self.bounds.size.height, [UIScreen mainScreen].bounds.size.width, self.bounds.size.height);
    
    [view addSubview:self];
}

#pragma mark - PickerView lifecycle

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return [valueArr count];
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return [[valueArr objectAtIndex:row] objectForKey:key];
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    
    self.locate.state = [[valueArr objectAtIndex:row] objectForKey:key];
    
}


#pragma mark - Button lifecycle

- (void)canalBtnAction
{
    [self dismissView];
    
}

- (void)sureBtnAction
{
    [self dismissView];
    
    [self.kDelegate getSelectIndexValue:self.locate.state];
    
}


-(void)dismissView
{
    CATransition *animation = [CATransition  animation];
    animation.delegate = self;
    animation.duration = kDuration;
    animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    animation.type = kCATransitionPush;
    animation.subtype = kCATransitionFromBottom;
    [self setAlpha:0.0f];
    [self.layer addAnimation:animation forKey:@"TSLocateView"];
    [self performSelector:@selector(removeFromSuperview) withObject:nil afterDelay:kDuration];
}

@end
