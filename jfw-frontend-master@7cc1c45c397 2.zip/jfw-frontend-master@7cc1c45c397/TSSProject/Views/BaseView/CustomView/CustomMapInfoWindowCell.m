//
//  CustomMapInfoWindowCell.m
//  TSSProject
//
//  Created by 于磊 on 2016/10/20.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import "CustomMapInfoWindowCell.h"

@implementation CustomMapInfoWindowCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    [self setInitialization];
}

-(void)setInitialization
{
    self.userInteractionEnabled = YES;
    self.backgroundColor = [UIColor whiteColor];
    self.headerIv.layer.cornerRadius = 30;
    self.headerIv.layer.masksToBounds = YES;
    self.headerIv.layer.borderColor = [UIColor groupTableViewBackgroundColor].CGColor;
    self.headerIv.layer.borderWidth = 0.5;
    self.phoneButton.layer.cornerRadius = 15;
    self.phoneButton.layer.masksToBounds = YES;
    self.shareButton.layer.cornerRadius = 15;
    self.shareButton.layer.masksToBounds = YES;
    
}

-(NSString *)restorationIdentifier
{
    return kCustomMapInfoWindowCellReuseId;
}

+(CGFloat)defaultHeigh
{
    return 190;
}



@end
