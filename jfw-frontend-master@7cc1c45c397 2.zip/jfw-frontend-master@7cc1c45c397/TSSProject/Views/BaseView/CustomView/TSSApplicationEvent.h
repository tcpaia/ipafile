//
//  TSSApplicationEvent.h
//  TSSProject
//
//  Created by 于磊 on 16/8/1.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


@protocol TSSApplicationEventDelegate <NSObject>

- (void)messageFeedBackStatus:(BOOL)status;

@end

@interface TSSApplicationEvent : NSObject

+(instancetype)shareInstance;

-(BOOL)phoneEvent:(NSString *)mobile;

-(void)messageEvent:(NSString *)email;

@property (nonatomic,weak) UIViewController *viewC;

@property (nonatomic,weak) id <TSSApplicationEventDelegate> delegate;

@end
