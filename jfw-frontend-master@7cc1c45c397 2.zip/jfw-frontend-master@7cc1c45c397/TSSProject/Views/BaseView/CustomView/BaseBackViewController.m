//
//  BaseBackViewController.m
//  TSSProject
//
//  Created by TSS on 16/4/14.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import "BaseBackViewController.h"
#import "SystemTss.h"
#import "TSSValidationUtil.h"
#import "TSSFactoryComponent.h"
@interface BaseBackViewController ()

@end

@implementation BaseBackViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.titleLabel.text = _tXttitle;
    self.titleLabel.font = [UIFont fontWithName:AIASans_Condensed_Header size:17];
    NSNotificationCenter * center = [NSNotificationCenter defaultCenter];
    //添加当前类对象为一个观察者，name和object设置为nil，表示接收一切通知
    [center addObserver:self selector:@selector(closeView) name:NOTIFICATION_CLOSE object:nil];
    // Do any additional setup after loading the view from its nib.
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(wTextFieldTextChanged:) name:UITextFieldTextDidEndEditingNotification object:nil];
     [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(wTextViewTextChanged:) name:UITextViewTextDidEndEditingNotification object:nil];

    
}

-(void)wTextFieldTextChanged:(id)sender{
    
    NSNotification * noti = (NSNotification*)sender;
    
    UITextField * textF = noti.object;
    
    NSString * str = [TSSValidationUtil filterHTML:textF.text];
    if ([str isEqualToString:textF.text]) {
        
        
    }
    else{
        
        textF.text = str;
        [[TSSFactoryComponent getInstance] showDialog:self andMessage:@"<> is illegal character."];
        
    }
}

-(void)wTextViewTextChanged:(id)sender{
    
    NSNotification * noti = (NSNotification*)sender;
    
    UITextView * textF = noti.object;
    
    NSString * str1 = textF.text;

    NSString * str = [TSSValidationUtil filterHTML:textF.text];
    
    if ([str isEqualToString:str1]) {
        
        
    }
    else{
        
        [[TSSFactoryComponent getInstance] showDialog:self andMessage:@"<> is illegal character."];
        textF.text = str;

        
    }
}

-(void)dealloc{
    
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UITextFieldTextDidEndEditingNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UITextViewTextDidEndEditingNotification object:nil];
    
    
}

-(instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
       
    }
    return self;

}

-(void)closeView{
    DLog(@"%s",__func__);
   [self dismissViewControllerAnimated:YES completion:nil];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btnBackClick:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}



@end
