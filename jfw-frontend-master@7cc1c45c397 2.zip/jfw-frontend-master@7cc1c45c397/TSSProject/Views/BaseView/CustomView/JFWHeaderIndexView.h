//
//  JFWHeaderIndexView.h
//  TSSProject
//
//  Created by 于磊 on 2017/1/20.
//  Copyright © 2017年 AIA. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JFWHeaderIndexView : UIView

@property (weak, nonatomic) IBOutlet UILabel *jfwTitleLabel;

+(float)defaultHeight;

@end
