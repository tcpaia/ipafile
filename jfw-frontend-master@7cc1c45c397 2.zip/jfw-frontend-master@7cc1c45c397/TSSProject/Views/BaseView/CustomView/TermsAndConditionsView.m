//
//  TermsAndConditionsView.m
//  TSSProject
//
//  Created by Lei on 08/05/2017.
//  Copyright © 2017 AIA. All rights reserved.
//

#import "TermsAndConditionsView.h"
#import "SystemTss.h"
#import "MultiLanguageControl.h"

@implementation TermsAndConditionsView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self = [[[NSBundle mainBundle] loadNibNamed:@"TermsAndConditionsView" owner:self options:nil] lastObject];
        self.frame = frame;
        [self initUI];
    }
    return self;
}

- (void)initUI {
    self.stepButton2.layer.borderWidth = 2;
    self.stepButton1.layer.cornerRadius = self.stepButton1.bounds.size.width/2;
    self.stepButton2.layer.cornerRadius = self.stepButton2.bounds.size.width/2;
    self.stepButton2.layer.borderColor = UI_COLOR_JFW_INDEXBUTTON_BORDER_COLOR.CGColor;
    
    self.termsTitle.text = MuliteLocalizedString(@"TermsConditionsTitle");
    [self.agreeBtn setTitle:MuliteLocalizedString(@"AgreeBtnTitle") forState:UIControlStateNormal];
    [self.disAgreeBtn setTitle:MuliteLocalizedString(@"DisagreeBtnTitle") forState:UIControlStateNormal];
}


@end
