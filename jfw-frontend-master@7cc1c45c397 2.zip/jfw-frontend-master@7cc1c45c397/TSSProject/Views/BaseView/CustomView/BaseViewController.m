//
//  BaseViewController.m
//  TSSProject
//
//  Created by TSS on 16/4/14.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import "BaseViewController.h"
#import "SystemTss.h"

@interface BaseViewController ()

@end

@implementation BaseViewController

@synthesize labTitle;
@synthesize titleTXT;
@synthesize megNumberTXT;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.labTitle.text = [titleTXT uppercaseString];
    self.labTitle.adjustsFontSizeToFitWidth = YES;
    self.messageBtn.messageNum.hidden = YES;
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    //self.isUploadViewC = NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - ICSDrawerControllerPresenting

- (void)drawerControllerWillOpen:(ICSDrawerController *)drawerController
{
    self.view.userInteractionEnabled = NO;
}

- (void)drawerControllerDidClose:(ICSDrawerController *)drawerController
{
    self.view.userInteractionEnabled = YES;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btnMenuClick:(id)sender {
    [self.drawer open];
}
@end
