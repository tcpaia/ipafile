//
//  CreatePasswordView.h
//  TSSProject
//
//  Created by Lei on 09/05/2017.
//  Copyright © 2017 AIA. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TSSForbidPasteTextField.h"
@protocol CreatePasswordViewDelegate <NSObject>

- (void) submitPassword;
- (void) activationFailHandler:(NSString*) details;
@end

@interface CreatePasswordView : UIView<UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UILabel *passwordLab;
@property (weak, nonatomic) IBOutlet UILabel *confirmLab;
@property (weak, nonatomic) IBOutlet TSSForbidPasteTextField *passwordTf;
@property (weak, nonatomic) IBOutlet TSSForbidPasteTextField *rePasswordTf;
@property (weak, nonatomic) IBOutlet UILabel *promptLab;
@property (weak, nonatomic) IBOutlet UIButton *submitButton;
@property (weak, nonatomic) IBOutlet UIView *bacView;
@property (nonatomic,weak) UIViewController *viewC;
@property (nonatomic,weak) id <CreatePasswordViewDelegate> delegate;
@end
