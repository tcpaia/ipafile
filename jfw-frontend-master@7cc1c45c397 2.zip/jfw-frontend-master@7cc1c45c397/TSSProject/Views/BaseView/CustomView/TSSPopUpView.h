//
//  TSSPopUpView.h
//  demo
//
//  Created by 于磊 on 16/3/30.
//  Copyright © 2016年 yulei. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol TSSPopUpViewDelegate <NSObject>

-(void)controlBtnAction:(UIButton *)btn;

@end

@interface TSSPopUpView : UIView

-(void)show;

-(void)dismiss;

-(id)initWithFrame:(CGRect)frame andControlArr:(NSArray *)controlArr;
-(id)initDisplayWebViewFrame:(CGRect)frame;
@property (nonatomic ,weak)id<TSSPopUpViewDelegate>delegate;

@end
