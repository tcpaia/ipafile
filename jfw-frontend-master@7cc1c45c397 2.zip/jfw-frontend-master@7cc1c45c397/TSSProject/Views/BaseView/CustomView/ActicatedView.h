//
//  ActicatedView.h
//  TSSProject
//
//  Created by Lei on 21/03/2017.
//  Copyright © 2017 AIA. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ActicatedView : UIView
@property (weak, nonatomic) IBOutlet UIButton *btnActivateHere;
@property (weak, nonatomic) IBOutlet UIButton *btnForgetPassword;
@property (weak, nonatomic) IBOutlet UILabel *userLab;

+(CGFloat) defaultHeight;
@end
