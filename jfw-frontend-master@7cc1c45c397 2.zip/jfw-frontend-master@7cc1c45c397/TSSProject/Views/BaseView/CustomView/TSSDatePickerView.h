//
//  TSSDatePickerView.h
//  TSSProject
//
//  Created by 于磊 on 16/4/22.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^MYBlock)(NSString *time);

@interface TSSDatePickerView : UIView

@property (nonatomic,copy) MYBlock block;

+(instancetype) shareInstance;

-(void)show;

-(void)dismiss;

-(void)dateFormat:(NSString *)format;

-(void)dateFormat:(NSString *)format andSpecialDate: (NSDate *) specialDate;

-(void)setMinDateToCurrentDate;

-(void)setMinDateToNil;

@end
