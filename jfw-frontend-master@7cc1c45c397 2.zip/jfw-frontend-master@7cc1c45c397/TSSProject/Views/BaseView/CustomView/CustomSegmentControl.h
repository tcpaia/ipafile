//
//  CustomSegmentControl.h
//  TSSProject
//
//  Created by 于磊 on 2017/1/16.
//  Copyright © 2017年 AIA. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol CustomSegmentControlDelegate <NSObject>

- (void)getSelfTagwithSelectedSegmentIndex:(NSDictionary *)dic;

@end

@interface CustomSegmentControl : UIView
@property (weak, nonatomic) IBOutlet UIButton *segmentYes;
@property (weak, nonatomic) IBOutlet UIButton *segmentNo;

@property (weak, nonatomic) IBOutlet UIImageView *imgYes;
@property (weak, nonatomic) IBOutlet UIImageView *imgNo;
@property (nonatomic,weak) id<CustomSegmentControlDelegate>delegate;


- (void) setSegmentIndex:(int)segmentIndex;

@end
