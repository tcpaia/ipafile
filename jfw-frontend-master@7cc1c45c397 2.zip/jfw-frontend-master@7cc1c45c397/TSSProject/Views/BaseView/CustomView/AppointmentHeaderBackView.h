//
//  AppointmentHeaderBackView.h
//  TSSProject
//
//  Created by Lei on 14/03/2017.
//  Copyright © 2017 AIA. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppointmentHeaderBackView : UIView
@property (weak, nonatomic) IBOutlet UIView *backView;
@property (weak, nonatomic) IBOutlet UIButton *addAppointmentBtn;
@property (weak, nonatomic) IBOutlet UIButton *leftBtn;
@property (weak, nonatomic) IBOutlet UIButton *rightBtn;

+ (CGFloat)defaultHeight;

@end
