//
//  MenuHeadTableViewCell.h
//  demo
//
//  Created by 于磊 on 16/3/30.
//  Copyright © 2016年 yulei. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIViewController+TSS.h"

static NSString * const kMenuHeadCellReuseId = @"kMenuHeadCellReuseId";

@interface MenuHeadTableViewCell : UITableViewCell

@property (nonatomic,strong) UIImageView *headImgView;
@property (weak, nonatomic) IBOutlet UIButton *headBtnIV;

@property (weak, nonatomic) IBOutlet UILabel *nameLabel;

@property (weak, nonatomic) UIViewController *delegate;

- (IBAction)headBtnIvAction:(UIButton *)sender;

+ (CGFloat)defaultHeight;

@property (strong, nonatomic) IBOutlet UIImageView *iCloseView;

@property(nonatomic,weak) UIViewController *VC;
@end
