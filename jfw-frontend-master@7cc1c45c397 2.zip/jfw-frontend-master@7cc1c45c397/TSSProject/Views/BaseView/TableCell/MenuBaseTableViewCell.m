//
//  MenuBaseTableViewCell.m
//  TSSProject
//
//  Created by TSS on 16/3/28.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import "MenuBaseTableViewCell.h"
#import "SystemTss.h"
@implementation MenuBaseTableViewCell

@synthesize vImage;
@synthesize tTitle;
@synthesize btnNotification;

- (void)awakeFromNib {
    // Initialization code
    [super awakeFromNib];
    [self initialize];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}
- (NSString *)reuseIdentifier {
    return kMenuBaseCellReuseId;
}

- (void)initialize {
#ifdef __IPHONE_8_0
   // if (IOS_VERSION_8_OR_LATER) {
       // self.layoutMargins = UIEdgeInsetsZero;
        //self.preservesSuperviewLayoutMargins = NO;
   // }
#endif
    //self.selectionStyle = UITableViewCellSelectionStyleNone;
    
    
    self.tTitle.adjustsFontSizeToFitWidth = YES;
    self.backgroundColor = UI_COLOR_MENU_SUB_BACKCOLOR;
}

+ (CGFloat)defaultHeight {
    return 46;
}

- (void)layoutSubviews{
    [super layoutSubviews];
    self.tTitle.text = [self.tTitle.text uppercaseString];
}

@end
