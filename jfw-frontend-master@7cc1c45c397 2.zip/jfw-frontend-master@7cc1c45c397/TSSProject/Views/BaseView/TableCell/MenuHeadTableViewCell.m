//
//  MenuHeadTableViewCell.m
//  demo
//
//  Created by 于磊 on 16/3/30.
//  Copyright © 2016年 yulei. All rights reserved.
//

#import "MenuHeadTableViewCell.h"
#import "SystemTss.h"
#import "TSSFactoryComponent.h"
#import "TSSAppData.h"
#import "AgentProfileBean.h"
#import "AgentProfileDao.h"
#import "NetworkingManager.h"
#import "MultiLanguageControl.h"

@interface MenuHeadTableViewCell ()

@end

@implementation MenuHeadTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    [self initialization];
}

-(void)initialization
{
    self.contentView.backgroundColor = UI_COLOR_MENU_HEADER_BACKCOLOR;
    self.headBtnIV.layer.masksToBounds = YES;
    self.headBtnIV.layer.cornerRadius = self.headBtnIV.bounds.size.width/2;
    self.nameLabel.font = [UIFont fontWithName:AIASans_Condensed_Header size:20];
    
    self.headImgView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.headBtnIV.bounds.size.width, self.headBtnIV.bounds.size.height)];
    self.headImgView.layer.masksToBounds = YES;
    self.headImgView.layer.cornerRadius = self.headImgView.bounds.size.width/2;
    [self.headBtnIV addSubview:self.headImgView];

    [_iCloseView addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(close:)]];
    [_iCloseView setUserInteractionEnabled:YES];
    _iCloseView.hidden = YES;
}

-(void)close:(UITapGestureRecognizer *)gestureRecognizer
{
    UIAlertController *alertview=[UIAlertController alertControllerWithTitle:@"Message" message:MuliteLocalizedString(@"LogoutAlert") preferredStyle:UIAlertControllerStyleAlert];
    // 设置按钮
    UIAlertAction *cancel=[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        //点击按钮的响应事件；
    }];
    UIAlertAction *defult = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        //点击按钮的响应事件；
        exit(0);
    }];
    [alertview addAction:cancel];
    [alertview addAction:defult];
    [_VC presentViewController:alertview animated:YES completion:nil];
}

-(NSString *)restorationIdentifier
{
    return kMenuHeadCellReuseId;
}

- (IBAction)headBtnIvAction:(UIButton *)sender
{
    [[TSSFactoryComponent getInstance] showDialog:self.delegate andMessage:@"Choose an image" andCamera:@"Camera" andPhoto:@"Photos"];
    [TSSFactoryComponent getInstance].MYBlock = ^(NSData *imgData)
    {
        AgentProfileBean *tAgent = [[AgentProfileDao getInstance] getBeanWithCode:[TSSAppData getInstance].agentCode];
        tAgent.agentphoto = [imgData base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
        tAgent.photoStatus = UPLOAD_STATUS_FAILED;
        [tAgent save];
        [[NetworkingManager getInstance] uploadAgenPhoto:imgData withCallback:^(id obj) {
            NSString *status = (NSString *)obj;
            tAgent.photoStatus = status;
            [tAgent save];
        }];

        [self.headImgView setImage:[UIImage imageWithData:imgData]];
        [self.headBtnIV setTitle:@"" forState:UIControlStateNormal];
        [[NSNotificationCenter defaultCenter] postNotificationName:kNotificationChangeAgentPhotoByMenu object:nil];
    };
}

+ (CGFloat)defaultHeight
{
    return 120;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
