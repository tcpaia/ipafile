//
//  MenuBaseTableViewCell.h
//  TSSProject
//
//  Created by TSS on 16/3/28.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import <UIKit/UIKit.h>

static NSString * const kMenuBaseCellReuseId = @"kMenuBaseCellReuseId";

@interface MenuBaseTableViewCell : UITableViewCell

+ (CGFloat)defaultHeight;
@property (strong, nonatomic) IBOutlet UIImageView *vImage;
@property (strong, nonatomic) IBOutlet UILabel *tTitle;
@property (strong, nonatomic) IBOutlet UIButton *btnNotification;

@end
