//
//  SearchLocationTableViewCell.h
//  TSSProject
//
//  Created by 强刘 on 2017/5/20.
//  Copyright © 2017年 AIA. All rights reserved.
//

#import <UIKit/UIKit.h>

static NSString *const kSearchLocationTableViewCellReuseId = @"kSearchLocationTableViewCellReuseId";

@interface SearchLocationTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *iName;

@property (strong, nonatomic) IBOutlet UILabel *iAddress;

+(CGFloat)defaultHeigh;

@end
