//
//  SearchLocationTableViewCell.m
//  TSSProject
//
//  Created by 强刘 on 2017/5/20.
//  Copyright © 2017年 AIA. All rights reserved.
//

#import "SearchLocationTableViewCell.h"

@implementation SearchLocationTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    [self setInitialization];
    self.iAddress.numberOfLines = 0;
}

-(void)setInitialization
{
    [self setSelectionStyle:UITableViewCellSelectionStyleNone];
}

-(NSString *)restorationIdentifier
{
    return kSearchLocationTableViewCellReuseId;
}

+(CGFloat)defaultHeigh
{
    return 94;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
