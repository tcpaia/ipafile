//
//  TSSMultTableView.h
//  demo
//
//  Created by 于磊 on 16/8/30.
//  Copyright © 2016年 yulei. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol TSSMultTableViewDelegate,TSSMultTableViewDatasource;

typedef UITableViewCell TSSMultTableViewCell;

typedef UITableViewRowAnimation TSSMultTableViewRowAnimation;

typedef NS_ENUM(NSInteger, TSSMultTableViewCellEditingStyle) {
    TSSMultTableViewCellEditingStyleNone,
    TSSMultTableViewCellEditingStyleDelete,
    TSSMultTableViewCellEditingStyleInsert
};


@interface TSSMultTableView : UIView<UITableViewDelegate,UITableViewDataSource>


@property (nonatomic, strong, readonly) UITableView *tableView;

@property (nonatomic, assign, readwrite) id<TSSMultTableViewDatasource> datasource;

@property (nonatomic, assign, readwrite) id<TSSMultTableViewDelegate> delegate;

@property (nonatomic, copy, readwrite) NSArray *openSectionArray;

@property (nonatomic, strong, readwrite) UIView *tableViewHeader;

/**
 *  Cell重用机制（一）
 *
 *  @param identifier Cell标识
 *
 *  @return Cell
 */
- (TSSMultTableViewCell *)dequeueReusableCellWithIdentifier:(NSString *)identifier;

/**
 *  Cell重用机制（二）
 *
 *  @param identifier Cell标识
 *  @param indexPath
 *
 *  @return Cell
 */
- (TSSMultTableViewCell *)dequeueReusableCellWithIdentifier:(NSString *)identifier
                                              forIndexPath:(NSIndexPath *)indexPath;
/**
 *  刷新数据源
 */
- (void)reloadData;

/**
 *  注册cell（一）
 *
 *  @param nib
 *  @param identifier
 */
- (void)registerNib:(UINib *)nib forCellReuseIdentifier:(NSString *)identifier ;

/**
 *  注册cell（二）
 *
 *  @param cellClass
 *  @param identifier
 */
- (void)registerClass:(Class)cellClass forCellReuseIdentifier:(NSString *)identifier;

/**
 *  删除cell
 *
 *  @param indexPaths
 *  @param animation
 */
- (void)deleteRowsAtIndexPaths:(NSArray<NSIndexPath *> *)indexPaths withRowAnimation:(UITableViewRowAnimation)animation;

@end

/**
 *  数据源
 */
@protocol TSSMultTableViewDatasource <NSObject>

@required

/**
 *  每个section的行数
 *
 *  @param mTableView
 *  @param section
 *
 *  @return 每个section的行数
 */
- (NSInteger)mTableView:(TSSMultTableView *)mTableView numberOfRowsInSection:(NSInteger)section;

/**
 *  Cell显示
 *
 *  @param mTableView
 *  @param indexPath
 *
 *  @return Cell
 */
- (TSSMultTableViewCell *)mTableView:(TSSMultTableView *)mTableView
              cellForRowAtIndexPath:(NSIndexPath *)indexPath;

@optional

/**
 *  section的数量
 *
 *  @param mTableView
 *
 *  @return section的数量
 */
- (NSInteger)numberOfSectionsInTableView:(TSSMultTableView *)mTableView;              // Default is 1

/**
 *  头部的title
 *
 *  @param tableView mTableView
 *  @param section   section
 *
 *  @return
 */
-(NSString *)mTableView:(TSSMultTableView *)mTableView titleForHeaderInSection:(NSInteger)section;

//Edit

/**
 *  cell是否可以编辑
 *
 *  @param mTableView
 *  @param indexPath
 */
- (BOOL)mTableView:(TSSMultTableView *)mTableView canEditRowAtIndexPath:(NSIndexPath  *)indexPath;

/**
 *  cell编辑后回调
 *
 *  @param tableView
 *  @param editingStyle
 *  @param indexPath
 */
- (void)mTableView:(TSSMultTableView *)tableView commitEditingStyle:(TSSMultTableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath;

@end

/**
 *  代理
 */
@protocol TSSMultTableViewDelegate <NSObject>

@optional

#pragma  ---- New record tap action by aley---
-(void)recordMultTableViewHeadTapAction;


/**
 *  每个Cell的高度
 *
 *  @param mTableView
 *  @param indexPath
 *
 *  @return 每个Cell的高度
 */
- (CGFloat)mTableView:(TSSMultTableView *)mTableView heightForRowAtIndexPath:(NSIndexPath *)indexPath;

/**
 *  每个section的高度
 *
 *  @param mTableView
 *  @param section
 *
 *  @return 每个section的高度
 */
- (CGFloat)mTableView:(TSSMultTableView *)mTableView heightForHeaderInSection:(NSInteger)section;

/**
 *  section View
 *
 *  @param mTableView
 *  @param section
 *
 *  @return section View
 */
- (UIView *)mTableView:(TSSMultTableView *)mTableView viewForHeaderInSection:(NSInteger)section;

/**
 *  即将打开指定列表回调
 *
 *  @param mTableView
 *  @param section
 */
- (void)mTableView:(TSSMultTableView *)mTableView willOpenHeaderAtSection:(NSInteger)section;

/**
 *
 *  即将关闭列表回调
 *  @param mTableView
 *  @param section
 */
- (void)mTableView:(TSSMultTableView *)mTableView willCloseHeaderAtSection:(NSInteger)section;

/**
 *  点击Cell回调
 *
 *  @param mTableView
 *  @param indexPath
 */
- (void)mTableView:(TSSMultTableView *)mTableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;

//Edit

/**
 *
 *  设置cell的编辑类型
 *  @param mTableView
 *  @param indexPath
 *
 *  @return
 */
- (TSSMultTableViewCellEditingStyle)mTableView:(TSSMultTableView *)mTableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath;

/**
 *  设置cell编辑状态之删除的文本
 *
 *  @param mTableView
 *  @param indexPath
 
 *  @return
 */
- (NSString *)mTableView:(TSSMultTableView *)mTableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath;


/**
 *  ...易拓展出你想要的tableview的功能，写法可以参照上面的定义
 */

@end
