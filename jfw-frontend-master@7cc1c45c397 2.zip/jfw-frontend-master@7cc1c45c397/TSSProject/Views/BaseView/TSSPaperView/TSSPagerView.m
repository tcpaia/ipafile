//
//  TSSPagerView.m
//  demo
//
//  Created by 于磊 on 16/4/13.
//  Copyright © 2016年 yulei. All rights reserved.
//

#import "TSSPagerView.h"
#import "TSSBaseView.h"
#import "UIParameter.h"
#import "SystemTss.h"
#define MaxNums  10
#define CurrentPage  @"currentPage"
@implementation TSSPagerView
{
    TSSBaseView *pagerView;
    NSArray *myArray;
    NSArray *classArray;
    NSArray *colorArray;
    NSMutableArray *viewNumArray;
    BOOL viewAlloc[MaxNums];
    BOOL fontChangeColor;
}

- (void)dealloc
{
    [pagerView removeObserver:self forKeyPath:CurrentPage];
}

- (instancetype)initWithTitles:(NSArray *)titles WithVCs:(NSArray *)childVCs WithColorArrays:(NSArray *)colors {
    if (self = [super init]) {
        //Need You Edit,title for the toptabbar
        self.frame = CGRectMake(0, TopViewHigh, FUll_VIEW_WIDTH, FUll_VIEW_HEIGHT - TopViewHigh);
        myArray = titles;
        classArray = childVCs;
        colorArray = colors;
        [self createPagerView:myArray WithVCs:classArray WithColors:colorArray];
    }
    return self;
}

- (instancetype)initWithTitles:(NSArray *)titles aFrame:(CGRect)aFrame WithVCs:(NSArray *)childVCs WithColorArrays:(NSArray *)colors {
    if (self = [super init]) {
        //Need You Edit,title for the toptabbar
        self.frame = aFrame;
        myArray = titles;
        classArray = childVCs;
        colorArray = colors;
        [self createPagerView:myArray WithVCs:classArray WithColors:colorArray];
    }
    return self;
}

#pragma mark - CreateView
- (void)createPagerView:(NSArray *)titles WithVCs:(NSArray *)childVCs WithColors:(NSArray *)colors {
    viewNumArray = [NSMutableArray array];
    //No Need to edit
    if (colors.count > 0) {
        for (NSInteger i = 0; i < colors.count; i++) {
            switch (i) {
                case 0:
                    _selectColor = colors[0];
                    break;
                case 1:
                    _unselectColor = colors[1];
                    break;
                case 2:
                    _underlineColor = colors[2];
                    break;
                default:
                    break;
            }
        }
    }
    if (titles.count > 0 && childVCs.count > 0) {
        pagerView = [[TSSBaseView alloc] initWithFrame:CGRectMake(0, 0, FUll_VIEW_WIDTH, FUll_VIEW_HEIGHT - TopViewHigh) WithSelectColor:_selectColor WithUnselectorColor:_unselectColor WithUnderLineColor:_underlineColor];
        pagerView.titleArray = myArray;
      [pagerView addObserver:self forKeyPath:CurrentPage options:NSKeyValueObservingOptionOld | NSKeyValueObservingOptionNew context:nil];
        [self addSubview:pagerView];
        //First ViewController present to the screen
        if (classArray.count > 0 && myArray.count > 0) {
            
            for (int i = 0; i < classArray.count; i ++)
            {
                UIViewController *vc = [classArray objectAtIndex:i];
                vc.view.frame = CGRectMake(i*FUll_VIEW_WIDTH, 0, FUll_VIEW_WIDTH, pagerView.scrollView.bounds.size.height);
                [pagerView.scrollView addSubview:vc.view];
            }
            viewAlloc[0] = YES;
            [pagerView.scrollView setContentSize:CGSizeMake(FUll_VIEW_WIDTH *classArray.count, 0)];
        }
    }else {
        DLog(@"You should correct titlesArray or childVCs count!");
    }
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context {
    if ([keyPath isEqualToString:@"currentPage"]) {
        NSInteger page = [change[@"new"] integerValue];
        
        if (myArray.count > 5) {
            CGFloat topTabOffsetX = 0;
            if (page >= 2) {
                if (page <= myArray.count - 3) {
                    topTabOffsetX = (page - 2) * More5LineWidth;
                }
                else {
                    if (page == myArray.count - 2) {
                        topTabOffsetX = (page - 3) * More5LineWidth;
                    }else {
                        topTabOffsetX = (page - 4) * More5LineWidth;
                    }
                }
            }
            else {
                if (page == 1) {
                    topTabOffsetX = 0 * More5LineWidth;
                }else {
                    topTabOffsetX = page * More5LineWidth;
                }
            }
            [pagerView.topTab setContentOffset:CGPointMake(topTabOffsetX, 0) animated:YES];
        }
    }
}

@end
