//
//  TSSPagerView.h
//  demo
//
//  Created by 于磊 on 16/4/13.
//  Copyright © 2016年 yulei. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface TSSPagerView : UIView

- (instancetype)initWithTitles:(NSArray *)titles WithVCs:(NSArray *)childVCs WithColorArrays:(NSArray *)colors;

- (instancetype)initWithTitles:(NSArray *)titles aFrame:(CGRect)aFrame WithVCs:(NSArray *)childVCs WithColorArrays:(NSArray *)colors;
@property (strong, nonatomic) UIColor *selectColor; /**<  选中时的颜色   **/
@property (strong, nonatomic) UIColor *unselectColor; /**<  未选中时的颜色   **/
@property (strong, nonatomic) UIColor *underlineColor; /**<  下划线的颜色   **/

@end
