//
//  TSSBaseView.m
//  demo
//
//  Created by 于磊 on 16/4/13.
//  Copyright © 2016年 yulei. All rights reserved.
//

#import "TSSBaseView.h"
#import "UIParameter.h"
#import "SystemTss.h"

@interface TSSBaseView ()

@end

@implementation TSSBaseView {
    UIView *lineBottom;
    UIView *topTabBottomLine;
    NSMutableArray *btnArray;
    NSArray *titlesArray; /**<  标题   **/
    NSInteger arrayCount; /**<  topTab数量   **/
    UIColor *selectBtn;
    UIColor *unselectBtn;
    UIColor *underline;
}

- (instancetype)initWithFrame:(CGRect)frame WithSelectColor:(UIColor *)selectColor WithUnselectorColor:(UIColor *)unselectColor WithUnderLineColor:(UIColor *)underlineColor
{
    self = [super initWithFrame:frame];
    if (self) {
        if ([selectColor isKindOfClass:[UIColor class]]) {
            selectBtn = selectColor;
        }
        if ([unselectColor isKindOfClass:[UIColor class]]) {
            unselectBtn = unselectColor;
        }
        if ([underlineColor isKindOfClass:[UIColor class]]) {
            underline = underlineColor;
        }
    }
    return self;
}

#pragma mark - SetMethod
- (void)setTitleArray:(NSArray *)titleArray {
    titlesArray = titleArray;
    arrayCount = titleArray.count;
    self.scrollView.frame = CGRectMake(0, 0, FUll_VIEW_WIDTH, FUll_VIEW_HEIGHT - TopViewHigh);
    self.topTab.frame = CGRectMake(0,0, FUll_VIEW_WIDTH, PageBtn);
    [self addSubview:self.scrollView];
    [self addSubview:self.topTab];
   
}

#pragma mark - GetMethod
- (UIScrollView *)scrollView {
    if (!_scrollView) {
        _scrollView = [[UIScrollView alloc] init];
        _scrollView.userInteractionEnabled = YES;
        _scrollView.delegate = self;
        _scrollView.scrollEnabled = YES;
        _scrollView.tag = 318;
        _scrollView.backgroundColor = UIColorFromRGB(0xfafafa);
        _scrollView.contentSize = CGSizeMake(FUll_VIEW_WIDTH * titlesArray.count, 0);
        _scrollView.pagingEnabled = YES;
        _scrollView.showsHorizontalScrollIndicator = NO;
        _scrollView.alwaysBounceHorizontal = YES;
    }
    return _scrollView;
}

- (UIScrollView *)topTab {
    if (!_topTab) {
        _topTab = [[UIScrollView alloc] init];
        _topTab.backgroundColor = UI_COLOR_SMART_RED;
        _topTab.delegate = self;
        _topTab.tag = 917;
        _topTab.scrollEnabled = YES;
        _topTab.alwaysBounceHorizontal = YES;
        _topTab.showsHorizontalScrollIndicator = NO;
        CGFloat additionCount = 0;
        if (arrayCount > 5) {
            additionCount = (arrayCount - 5.0) / 5.0;
        }
        _topTab.contentSize = CGSizeMake((1 + additionCount) * FUll_VIEW_WIDTH, 0);
        btnArray = [NSMutableArray array];
       
        for (NSInteger i = 0; i < titlesArray.count; i++) {
            UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
            button.tag = i;
            button.titleLabel.font = Smart_AIASans_14;
            if ([titlesArray[i] hasSuffix:@"png"]) {
                [button setImage:[UIImage imageNamed:titlesArray[i]] forState:UIControlStateNormal];
    
            }else {
                [button setTitle:titlesArray[i] forState:UIControlStateNormal];

            }
            
            if ([titlesArray[i] hasSuffix:@"png"])
            {
                if (titlesArray.count > 5) {
                    button.frame = CGRectMake(FUll_VIEW_WIDTH / 5 * i + 25, 8, 25, 25);
                }else {
                    button.frame = CGRectMake(FUll_VIEW_WIDTH / titlesArray.count * i + 25, 8, 25, 25);
                }
            }
            else
            {
                if (titlesArray.count > 5) {
                    button.frame = CGRectMake(FUll_VIEW_WIDTH / 5 * i, 13, FUll_VIEW_WIDTH / 5, 18);
                }else {
                    button.frame = CGRectMake(FUll_VIEW_WIDTH / titlesArray.count * i,13, FUll_VIEW_WIDTH / titlesArray.count, 18);
                }
            }
            
            [_topTab addSubview:button];
            [button addTarget:self action:@selector(touchAction:) forControlEvents:UIControlEventTouchUpInside];
            [btnArray addObject:button];
            if (i == 0) {
                if (selectBtn) {
                    [button setTitleColor:selectBtn forState:UIControlStateNormal];
                }else {
                    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
                }
                [UIView animateWithDuration:0.3 animations:^{
                    button.transform = CGAffineTransformMakeScale(1.15, 1.15);
                }];
            } else {
                if (unselectBtn) {
                    [button setTitleColor:unselectBtn forState:UIControlStateNormal];
                }else {
                    [button setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
                }
            }
        }
        //创建tabTop下方总览线
        topTabBottomLine = [UIView new];
        topTabBottomLine.backgroundColor = UIColorFromRGB(0xcecece);
        [_topTab addSubview:topTabBottomLine];
        //创建选中移动线
        lineBottom = [UIView new];
        if (underline) {
            lineBottom.backgroundColor = underline;
        }else {
            lineBottom.backgroundColor = UIColorFromRGB(0xff6262);
        }
        [_topTab addSubview:lineBottom];
    }
    return _topTab;
}

#pragma mark - BtnMethod
- (void)touchAction:(UIButton *)button {
    
    [_scrollView setContentOffset:CGPointMake(FUll_VIEW_WIDTH * button.tag, 0) animated:YES];
    self.currentPage = (FUll_VIEW_WIDTH * button.tag + FUll_VIEW_WIDTH / 2) / FUll_VIEW_WIDTH;
}

#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    if (scrollView.tag == 318) {
        self.currentPage = (NSInteger)((scrollView.contentOffset.x + FUll_VIEW_WIDTH / 2) / FUll_VIEW_WIDTH);
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if (scrollView.tag == 318) {
        NSInteger yourPage = (NSInteger)((scrollView.contentOffset.x + FUll_VIEW_WIDTH / 2) / FUll_VIEW_WIDTH);
        CGFloat additionCount = 0;
        CGFloat yourCount = 1.0 / arrayCount;
        if (arrayCount > 5) {
            additionCount = (arrayCount - 5.0) / 5.0;
            yourCount = 1.0 / 5.0;
            lineBottom.frame = CGRectMake(scrollView.contentOffset.x / 5, PageBtn - 3, yourCount * FUll_VIEW_WIDTH, 2);
        }else {
            lineBottom.frame = CGRectMake((scrollView.contentOffset.x / arrayCount)+(FUll_VIEW_WIDTH / titlesArray.count-60)/2, PageBtn - 3, 60, 2);
        }
        for (NSInteger i = 0;  i < btnArray.count; i++) {
            if (unselectBtn) {
                [btnArray[i] setTitleColor:unselectBtn forState:UIControlStateNormal];
            }else {
                [btnArray[i] setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
            }
            UIButton *changeButton = btnArray[i];
            [UIView animateWithDuration:0.3 animations:^{
                changeButton.transform = CGAffineTransformMakeScale(1, 1);
            }];
        }
        if (selectBtn) {
            [btnArray[yourPage] setTitleColor:selectBtn forState:UIControlStateNormal];
        }else {
            [btnArray[yourPage] setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        }
        UIButton *changeButton = btnArray[yourPage];
        [UIView animateWithDuration:0.3 animations:^{
            changeButton.transform = CGAffineTransformMakeScale(1.15, 1.15);
        }];
    }
}

#pragma mark - LayOutSubViews
- (void)layoutSubviews {
    [super layoutSubviews];
    [self initUI];
}

- (void)initUI {
    CGFloat yourCount = 1.0 / arrayCount;
    CGFloat additionCount = 0;
    if (arrayCount > 5) {
        additionCount = (arrayCount - 5.0) / 5.0;
        yourCount = 1.0 / 5.0;
    }
    lineBottom.frame = CGRectMake((FUll_VIEW_WIDTH / titlesArray.count-60)/2, PageBtn - 3,60, 2);
    topTabBottomLine.frame = CGRectMake(0, PageBtn - 1, (1 + additionCount) * FUll_VIEW_WIDTH, 1);
    topTabBottomLine.hidden =YES;
}

@end
