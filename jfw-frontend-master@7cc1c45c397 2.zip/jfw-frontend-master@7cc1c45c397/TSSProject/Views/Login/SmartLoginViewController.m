//
//  SmartLoginViewController.m
//  TSSProject
//
//  Created by TSS on 16/3/24.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import "SmartLoginViewController.h"
#import "SystemTss.h"
#import "TSSAppSetting.h"
#import "TSSAppData.h"
#import "TSSAppDataBase.h"

#import "TSSMenuController.h"
#import "FollowUpAndNoteViewController.h"
#import "ActivateViewController.h"
#import "ActicatedView.h"
#import "TSSFactoryComponent.h"
#import "TSSForbidPasteTextField.h"

#import "TSSFileManager.h"
#import "TSSValidationUtil.h"
#import "NetworkingManager.h"
#import "MultiLanguageControl.h"

#import "PDKeyChain.h"
#import "TSSSecurity.h"
#import "NSDate+Ex.h"
#import "UIHyperlinksButton.h"

#import "AgentProfileBean.h"
#import "AgentProfileDao.h"
#import "EventLogDao.h"
#import "LanguageDao.h"
#import "FollowUpAndNoteBean.h"
#import "FollowUpAndNoteDao.h"
#import "jfwDao.h"
#import "jfwBean.h"
#import "CustomerInfoDao.h"
#import "CustomerInfoBean.h"
#import "AppointmentCustomerDao.h"
#import "AppointmentCustomerBean.h"
#import "AppointmentCommentsBean.h"
#import "AppointmentCommentsDao.h"
#import "NotificatinBean.h"
#import "NotificationDao.h"
#import "NominationInfoDao.h"

#import "NSData+AES256.h"
#import "NSData+Base64.h"

#import <LocalAuthentication/LocalAuthentication.h>

typedef NS_ENUM(NSUInteger, TSSPolicyDeviceOwnerAuthentication) {
    TSSPolicyDeviceOwnerAuthenticationNone,
    TSSPolicyDeviceOwnerAuthenticationBiometrics,
    TSSPolicyDeviceOwnerAuthenticationBiometricsLockout
};

@interface SmartLoginViewController ()<UITextFieldDelegate,UIAlertViewDelegate>
@property (strong, nonatomic)  UITextField *edtCode;
@property (strong, nonatomic)  UITextField *edtPassword;
@property (strong, nonatomic)  UIButton *btnLogin;

@property (strong, nonatomic) UIButton *btnTouchId;
@property (strong, nonatomic) UIScrollView *scrollView;

@property (assign, nonatomic) BOOL needChangeDatabaseFromMD5ToSHA256Flag;

@end



@implementation SmartLoginViewController

//Pass Timebomb1 Timebomb2 ActivationTimeEmpty

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    [self launchAnimation];
}

#pragma mark - Private Methods
- (void)launchAnimation
{
    
    UIImageView *launchView=[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WEIGHT, SCREEN_HEIGHT)];
    //将图片添加到UIImageView对象中
    launchView.image=[UIImage imageNamed:@"aialoginmobile.png"];
    UIWindow *mainWindow = [UIApplication sharedApplication].keyWindow;
    [mainWindow addSubview:launchView];
    [mainWindow bringSubviewToFront:launchView];
    [self.view addSubview:launchView];
    
    [UIView animateWithDuration:1.0f delay:0.5f options:UIViewAnimationOptionBeginFromCurrentState animations:^{
        launchView.alpha = 0.0f;
        launchView.layer.transform = CATransform3DScale(CATransform3DIdentity, 2.0f, 2.0f, 1.0f);
    } completion:^(BOOL finished) {
        [launchView removeFromSuperview];
    }];
}

- (UIColor *)getColor:(NSString*)hexColor
{
    unsigned int red,green,blue;
    NSRange range;
    range.length = 2;
    
    range.location = 0;
    [[NSScanner scannerWithString:[hexColor substringWithRange:range]]scanHexInt:&red];
    
    range.location = 2;
    [[NSScanner scannerWithString:[hexColor substringWithRange:range]]scanHexInt:&green];
    
    range.location = 4;
    [[NSScanner scannerWithString:[hexColor substringWithRange:range]]scanHexInt:&blue];
    
    return [UIColor colorWithRed:(float)(red/255.0f)green:(float)(green / 255.0f) blue:(float)(blue / 255.0f)alpha:1.0f];
}

- (void) initUIControl
{
    self.view.backgroundColor = [UIColor whiteColor];
    self.scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WEIGHT, SCREEN_HEIGHT)];
    BOOL showTouchID = [self showLoginWithTouchID];

    [self.scrollView setContentSize:CGSizeMake(SCREEN_WEIGHT, 667)];
    if (showTouchID) {
        [self.scrollView setContentSize:CGSizeMake(SCREEN_WEIGHT, 667 + 50)];
    }
    [self.view addSubview:self.scrollView];
    
    UIImageView *imgView = [[UIImageView alloc]initWithFrame:CGRectMake((SCREEN_WEIGHT - 155)/2, 93, 155, 117)];
    imgView.image = [UIImage imageNamed:@"Page 1"];
    [self.scrollView addSubview:imgView];
    
    CGRect imgFrame = imgView.frame;
    UILabel *imoSmartTitle = [[UILabel alloc]initWithFrame:CGRectMake(10, imgFrame.size.height + imgFrame.origin.y + 10, SCREEN_WEIGHT - 20, 42)];
    [imoSmartTitle setText:MuliteLocalizedString(@"JointFieldWork")];
    imoSmartTitle.textAlignment = NSTextAlignmentCenter;
    imoSmartTitle.font = [UIFont fontWithName:AIASans_Condensed_Header size:36];
    [self.scrollView addSubview:imoSmartTitle];
    
    CGFloat origin_Y = imoSmartTitle.frame.origin.y + imoSmartTitle.bounds.size.height + 37;
    CGFloat origin_X = 37;
    CGFloat height = 40;
    
    self.edtCode = [[TSSForbidPasteTextField alloc]initWithFrame:CGRectMake(origin_X, origin_Y, SCREEN_WEIGHT - 37*2, height)];
    self.edtPassword = [[TSSForbidPasteTextField alloc]initWithFrame:CGRectMake(origin_X, origin_Y + height + 30, SCREEN_WEIGHT - origin_X*2, height)];
    self.btnLogin = [[UIButton alloc]initWithFrame:CGRectMake(origin_X, self.edtPassword.frame.origin.y + self.edtPassword.bounds.size.height + 39, SCREEN_WEIGHT - origin_X*2, height)];
    
    [self.btnLogin addTarget:self action:@selector(loginClick:) forControlEvents:UIControlEventTouchUpInside];
    self.btnLogin.backgroundColor = UI_COLOR_SMART_RED;
    [self.btnLogin setTitle:MuliteLocalizedString(@"LoginBtnTitle") forState:UIControlStateNormal];
    self.btnLogin.titleLabel.font = [UIFont fontWithName:AIASans_Condensed_Header size:20];
    
    self.btnTouchId = [[UIButton alloc]initWithFrame:CGRectMake(origin_X, self.btnLogin.frame.origin.y + self.btnLogin.bounds.size.height + 37, SCREEN_WEIGHT - origin_X*2, height)];
    [self.btnTouchId addTarget:self action:@selector(clickLoginWithTouchID) forControlEvents:UIControlEventTouchUpInside];
    self.btnTouchId.backgroundColor = UI_COLOR_SMART_RED;
    [self.btnTouchId setTitle:MuliteLocalizedString(@"LoginWithTouchIDBtnTitle") forState:UIControlStateNormal];
    self.btnTouchId.titleLabel.font = [UIFont fontWithName:AIASans_Condensed_Header size:20];
    
    CGRect loginBtnFrame = self.btnLogin.frame;
    if (showTouchID) {
        loginBtnFrame = self.btnTouchId.frame;
    }
    
    //show version build
    loginBtnFrame.origin.y += loginBtnFrame.size.height;
    loginBtnFrame.origin.x += loginBtnFrame.size.width/2 - 30;
    loginBtnFrame.size.width -= loginBtnFrame.size.width/2 - 30;
    loginBtnFrame.size.height = 20;
    UILabel *versionlabel = [[UILabel alloc]initWithFrame:loginBtnFrame];
    versionlabel.font = [UIFont fontWithName:@"Aril" size:10];
    versionlabel.textColor = UI_COLOR_VERSION_TITLE_COLOR;
    versionlabel.textAlignment = NSTextAlignmentRight;
    versionlabel.adjustsFontSizeToFitWidth = YES;
    if ([[TSSAppSetting getInstance].buildVesion isEqualToString:BUILD_VERSION_UAT_SGP]) {
        versionlabel.text = [NSString stringWithFormat:@"UAT Version %@.%@(build %@ - %@)",[TSSAppSetting getInstance].majorVersion,[TSSAppSetting getInstance].minVersion,[TSSAppSetting getInstance].buildNo,[TSSAppSetting getInstance].buildTime];
    }
    
    if ([[TSSAppSetting getInstance].buildVesion isEqualToString:BUILD_VERSION_SIT_SGP]) {
        versionlabel.text = [NSString stringWithFormat:@"SIT Version %@.%@(build %@ - %@)",[TSSAppSetting getInstance].majorVersion,[TSSAppSetting getInstance].minVersion,[TSSAppSetting getInstance].buildNo,[TSSAppSetting getInstance].buildTime];
    }
    
    if ([[TSSAppSetting getInstance].buildVesion isEqualToString:BUILD_VERSION_PRO_SGP]) {
        versionlabel.text = [NSString stringWithFormat:@"PROD Version %@.%@(build %@ - %@)",[TSSAppSetting getInstance].majorVersion,[TSSAppSetting getInstance].minVersion,[TSSAppSetting getInstance].buildNo,[TSSAppSetting getInstance].buildTime];
    }
    
    [self.scrollView addSubview:self.edtCode];
    [self.scrollView addSubview:self.edtPassword];
    [self.scrollView addSubview:self.btnLogin];
    if (showTouchID) {
        [self.scrollView addSubview:self.btnTouchId];
    }
    [self.scrollView addSubview:versionlabel];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self initUIControl];
    ActicatedView *activateView = [[ActicatedView alloc]initWithFrame:CGRectMake(0, SCREEN_HEIGHT - [ActicatedView defaultHeight], SCREEN_WEIGHT, [ActicatedView defaultHeight])];
    [activateView.btnActivateHere addTarget:self action:@selector(activatedButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    [activateView.btnForgetPassword addTarget:self action:@selector(fogetPasswordButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    activateView.userLab.text = MuliteLocalizedString(@"NewUser");
    UIColor* linkColor = [self getColor:@"22A8DA"];
    NSMutableAttributedString* tncString = [[NSMutableAttributedString alloc] initWithString:MuliteLocalizedString(@"ActivateHere")];
    [tncString addAttribute:NSUnderlineStyleAttributeName value:@(NSUnderlineStyleSingle) range:(NSRange){0,[tncString length]}];
    [tncString addAttribute:NSUnderlineColorAttributeName  value:linkColor range:(NSRange){0,[tncString length]}];
    [tncString addAttribute:NSForegroundColorAttributeName value:linkColor range:(NSRange){0,[tncString length]}];
    [activateView.btnActivateHere setAttributedTitle:tncString forState:UIControlStateNormal];
    
    //forget pwd btn - border
    tncString = [[NSMutableAttributedString alloc] initWithString:MuliteLocalizedString(@"ForgetPassword")];
    [tncString addAttribute:NSUnderlineStyleAttributeName value:@(NSUnderlineStyleSingle) range:(NSRange){0,[tncString length]}];
    [tncString addAttribute:NSUnderlineColorAttributeName  value:linkColor range:(NSRange){0,[tncString length]}];
    [tncString addAttribute:NSForegroundColorAttributeName value:linkColor range:(NSRange){0,[tncString length]}];
    [activateView.btnForgetPassword setAttributedTitle:tncString forState:UIControlStateNormal];
    
    if (SCREEN_HEIGHT > 568) {
        [self.view addSubview:activateView];
    }else {
        activateView.frame = CGRectMake(0, self.scrollView.contentSize.height - 100, SCREEN_WEIGHT, 100);
        [self.scrollView addSubview:activateView];;
    }
    [self setLeftView:_edtCode];
    _edtCode.textColor = UI_COLOR_HOME_HEADER_COLOR;
    _edtCode.delegate = self;
    _edtCode.placeholder = MuliteLocalizedString(@"FSCCode_placeholder");
    _edtCode.clearButtonMode = UITextFieldViewModeWhileEditing;
    _edtCode.layer.borderColor = [UIColor groupTableViewBackgroundColor].CGColor;
    _edtCode.layer.borderWidth = 1;
    //_edtCode.font = [UIFont fontWithName:AIASans_Condensed_Header size:20];
    [self setLeftView:_edtPassword];
    
    _edtPassword.textColor = UI_COLOR_HOME_HEADER_COLOR;
    _edtPassword.leftView = [[UIView alloc]initWithFrame:CGRectMake(6, 0, 6, 0)];
    _edtPassword.leftView.backgroundColor = [UIColor clearColor];
    _edtPassword.placeholder = MuliteLocalizedString(@"Password_placeholder");
    _edtPassword.secureTextEntry = YES;
    _edtPassword.delegate = self;
    _edtPassword.clearButtonMode = UITextFieldViewModeWhileEditing;
    _edtPassword.layer.borderColor = [UIColor groupTableViewBackgroundColor].CGColor;
    _edtPassword.layer.borderWidth = 1;
    
    if ([[TSSAppSetting getInstance].buildVesion isEqualToString:BUILD_VERSION_SIT_COE]) {
        _edtCode.text = @"";
        _edtPassword.text = @"";
    }
//    _edtCode.text = @"36249";
//    _edtPassword.text = @"Password100";
    //_edtPassword.font = [UIFont fontWithName:AIASans_Condensed_Header size:20];
    
    //close keyboard while clicking outside keyboard
    self.view.userInteractionEnabled = YES;
    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(fingerTapped:)];
    [self.view addGestureRecognizer:singleTap];
    
    //INIT setting.plist file
    NSString *webServerUrl = [TSSAppSetting getInstance].serverUrl;
    DLog(@"%s",__func__);
    DLog(@"SmartLoginViewController %@",webServerUrl);
    
    self.navigationController.navigationBar.hidden = YES;
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(wTextFieldTextChanged:) name:UITextFieldTextDidEndEditingNotification object:nil];
    
}

-(void)wTextFieldTextChanged:(id)sender{
    
    NSNotification * noti = (NSNotification*)sender;
    
    UITextField * textF = noti.object;
    
    NSString * str = [TSSValidationUtil filterHTML:textF.text];
    if ([str isEqualToString:textF.text]) {
        
        
    }
    else{
        
        textF.text = str;
        [[TSSFactoryComponent getInstance] showDialog:self andMessage:@"<> is illegal character."];
        
    }
}


-(void)dealloc{
    
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UITextFieldTextDidEndEditingNotification object:nil];
    
}


- (void)setLeftView:(UITextField *)textField {
    textField.leftViewMode = UITextFieldViewModeAlways;
    textField.leftView = [[UIView alloc]initWithFrame:CGRectMake(6, 0, 6, 0)];
    textField.leftView.backgroundColor = [UIColor clearColor];
}


/**
 * close keyboard while clicking outside keyboard
 * NOTICE:
 */
- (void)fingerTapped:(UITapGestureRecognizer *)gestureRecognizer
{
    [self.view endEditing:YES];
}

/**
 * close keyboard while clicking textfield go button
 * NOTICE:
 */
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [_edtCode resignFirstResponder];
    [_edtPassword resignFirstResponder];
    return YES;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//判断是否支持touchid，如果支持，出现lougin with touchid按钮，不支持则不出现
- (BOOL)showLoginWithTouchID
{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *switchOn = [userDefaults objectForKey:TOUCHID_LOGIN_SWITCH];
    
//    剩下的是没有设置，或者设置成on的，需要判断是否设备已经设置了指纹识别
    BOOL deviceSupport = NO;
    TSSPolicyDeviceOwnerAuthentication auth = [self currentPolicyDeviceOwnerAuthentication];
    if (auth == TSSPolicyDeviceOwnerAuthenticationNone) {
        [userDefaults setObject:TOUCHID_LOGIN_DEVICE_UNSUPPORTED forKey:TOUCHID_LOGIN_DEVICE];
        deviceSupport = NO;
    } else {
        [userDefaults setObject:TOUCHID_LOGIN_DEVICE_SUPPORTED forKey:TOUCHID_LOGIN_DEVICE];
        deviceSupport = YES;
    }
    
    //设备可以使用touchid，但是选择了不使用
    if ([switchOn isEqualToString:TOUCHID_LOGIN_SWITCH_OFF]) {
        return NO;
    }
    //多个用户已登陆
    if ([switchOn isEqualToString:TOUCHID_UNABLE]) {
        return NO;
    }
    
    return deviceSupport;
}

- (TSSPolicyDeviceOwnerAuthentication) currentPolicyDeviceOwnerAuthentication
{
    LAContext *context = [[LAContext alloc] init];
    NSError *error = nil;
    BOOL authenticationWithBiometrics = [context canEvaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics error:&error];
    DLog(@"authenticationWithBiometrics error.code = %ld, error.message = %@", (long)error.code, error.localizedDescription);
    if (authenticationWithBiometrics) {
        DLog(@"支持指纹识别");
        return TSSPolicyDeviceOwnerAuthenticationBiometrics;
    } else if (error.code == kLAErrorBiometryLockout) { //LAErrorBiometryLockout
        BOOL authentication = [context canEvaluatePolicy:LAPolicyDeviceOwnerAuthentication error:&error];
        DLog(@"authentication error = %ld, error.localizedDescription = %@, authentication = %d", (long)error.code, error.localizedDescription, authentication);
        if (authentication) {
            return TSSPolicyDeviceOwnerAuthenticationBiometricsLockout;
        }
    }
    DLog(@"不支持指纹识别");
    return TSSPolicyDeviceOwnerAuthenticationNone;
}


- (void) clickLoginWithTouchID
{
    BOOL checkFlag = [self checkBeforeLoginTouchID];
    if (checkFlag == NO) {
        return;
    }
    
    //创建LAContext
    LAContext *context = [[LAContext alloc] init];
    //这个属性是设置指纹输入失败之后的弹出框的选项
    context.localizedFallbackTitle = @"";
    NSError *error = nil;
    TSSPolicyDeviceOwnerAuthentication auth = [self currentPolicyDeviceOwnerAuthentication];
    DLog(@"auth = %lu", (unsigned long)auth);
    if (auth == TSSPolicyDeviceOwnerAuthenticationBiometricsLockout) {
        [self showSystemTouchIDSettings];
    } else if (auth == TSSPolicyDeviceOwnerAuthenticationBiometrics) {
        //请按home键指纹解锁 Press the home key to unlock the fingerprint
         [context evaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics localizedReason:@"Unlock iMO Smart with Touch ID" reply:^(BOOL success, NSError * _Nullable error) {
            if (success) {
                //验证成功，主线程处理UI
                dispatch_async(dispatch_get_main_queue(), ^{
                    DLog(@"验证成功 刷新主界面");
                    // 更UI
                    
                    NSString *agentCode = [PDKeyChain keyChainLoad:TOUCHID_LOGIN_AGENT];
                    NSString *agentPass = [PDKeyChain keyChainLoad:TOUCHID_LOGIN_PASS];
                    
                    NSString *enagentCode = [PDKeyChain keyChainLoad:TOUCHID_LOGIN_AGENT_ENCRTION];
                    NSString *enagentPass = [PDKeyChain keyChainLoad:TOUCHID_LOGIN_PASS_ENCRTION];
                    
                    if ([agentCode isEqualToString:enagentCode]) {
                        agentCode = [TSSSecurity deCodeDataBase64:enagentCode];
                        agentPass = [TSSSecurity deCodeDataBase64:enagentPass];
                    }
                    if (![TSSValidationUtil isNilOrEmptyString:agentCode] && ![TSSValidationUtil isNilOrEmptyString:agentPass]) {
                        [TSSAppData getInstance].agentCode = agentCode;
                        [TSSAppData getInstance].agentPassword = agentPass;
                        [self fillMadstkeyAndGoToLogin];
                    } else {
                        //说明之前有登陆，但是没有记录过TOUCHID_LOGIN_AGENT，提醒用户先登陆一次
                        [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"TouchIDFirstNeedLoginPassword")];
                        return;
                    }
                });
            } else {
                DLog(@"evaluatePolicy error = %@", error);
                switch (error.code) {
                    case LAErrorAuthenticationFailed:
                    {
                        DLog(@"授权失败");
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [self showSystemTouchIDSettings];
                        });
                        break;
                    }
                    case LAErrorUserCancel:
                    {
                        DLog(@"用户取消验证Touch ID");
                        break;
                    }
                    case LAErrorUserFallback:
                    {
                        [[NSOperationQueue mainQueue] addOperationWithBlock:^{
                            DLog(@"用户选择输入密码，切换主线程处理");
                        }];
                        break;
                    }
                    case LAErrorSystemCancel:
                    {
                        DLog(@"系统取消授权，如其他APP切入");
                        DLog(@"Authentication was cancelled by the system");
                        break;
                    }
                    case LAErrorPasscodeNotSet:
                    {
                        DLog(@"系统未设置密码");
                        break;
                    }
                    case LAErrorTouchIDNotAvailable:
                    {
                        DLog(@"设备Touch ID不可用，例如未打开");
                        break;
                    }
                    case LAErrorTouchIDNotEnrolled:
                    {
                        DLog(@"设备Touch ID不可用，用户未录入");
                        break;
                    }
                    case LAErrorTouchIDLockout:
                    {
                        DLog(@"Authentication was not successful, because there were too many failed Touch ID attempts and Touch ID is now locked.");
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [self showSystemTouchIDSettings];
                        });
                        break;
                    }
                    case LAErrorAppCancel:
                    {
                        DLog(@"Authentication was canceled by application");
                        break;
                    }
                    case LAErrorInvalidContext:
                    {
                        DLog(@"LAContext passed to this call has been previously invalidated.");
                        break;
                    }

                    default:
                    {
                        [[NSOperationQueue mainQueue] addOperationWithBlock:^{
                            DLog(@"其他情况，切换主线程处理");
                            dispatch_async(dispatch_get_main_queue(), ^{
                                [self showSystemTouchIDSettings];
                            });
                        }];
                        break;
                    }
                }
            }
        }];
    } else {
        //不支持指纹识别，LOG出错误详情
        DLog(@"不支持指纹识别: %@", error.localizedDescription);
        NSString *message = nil;
        switch (error.code) {
            case LAErrorTouchIDNotEnrolled:
            {
                DLog(@"TouchID is not enrolled");
                message = MuliteLocalizedString(@"LoginErrorTouchIDNotEnrolled");
                break;
            }
            case LAErrorPasscodeNotSet:
            {
                DLog(@"A passcode has not been set");
                message = MuliteLocalizedString(@"LoginErrorTouchIDPasscodeNotSet");
                break;
            }
            default:
            {
                DLog(@"TouchID not available");
                message = MuliteLocalizedString(@"LoginErrorTouchIDNotAvailable");
                break;
            }
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            [[TSSFactoryComponent getInstance] showDialog:self andMessage:message];
        });
    }
}

- (void)showSystemTouchIDSettings {
    UIAlertController *alertview=[UIAlertController alertControllerWithTitle:@"Login" message:MuliteLocalizedString(@"UnableRecogniseFingerprint") preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancel=[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    UIAlertAction *defult = [UIAlertAction actionWithTitle:@"Settings" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        NSString *settingsString = @"App-Prefs:root=TOUCHID_PASSCODE";
        NSURL *url = [NSURL URLWithString:settingsString];
        if ([[UIApplication sharedApplication] canOpenURL:url]) {
            [[UIApplication sharedApplication] openURL:url];
        }
    }];
    [alertview addAction:cancel];
    [alertview addAction:defult];
    [self presentViewController:alertview animated:YES completion:nil];
}

- (BOOL) checkBeforeLoginTouchID
{
    //判断是否有db文件存在
    NSString * documentFolderPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSArray* tempArray = [fileManager contentsOfDirectoryAtPath: documentFolderPath error: nil];
    NSUInteger dbFileCount = 0;
    for (NSString *fileName in tempArray) {
        if ([fileName containsString: @".db"]&&![fileName containsString:@"CommonInfo"]) {
            dbFileCount++;
        }
    }
    if (dbFileCount < 1) {
        //Please activate your App under New User before using it or please input correct FSC Code and Password again.
        [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"ActivationMessage")];
        return NO;
    }
    if (dbFileCount > 1) {
        [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"ManyAgentMakeTouchIDUnabled")];
        return NO;
    }
    
    NSString *agentCode = [PDKeyChain keyChainLoad:TOUCHID_LOGIN_AGENT];
    NSString *agentPass = [PDKeyChain keyChainLoad:TOUCHID_LOGIN_PASS];
    
    NSString *enagentCode = [PDKeyChain keyChainLoad:TOUCHID_LOGIN_AGENT_ENCRTION];
    
    if ([agentCode isEqualToString:enagentCode]&&![TSSValidationUtil isNilOrEmptyString:agentCode]) {
        //说明TOUCHID_LOGIN_AGENT已经是加密过的了，需要解密
        agentCode = [TSSSecurity deCodeDataBase64:agentCode];
    }
    
    if ([TSSValidationUtil isNilOrEmptyString: agentCode] || [TSSValidationUtil isNilOrEmptyString:agentPass]) {
        [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"TouchIDFirstNeedLoginPassword")];
        return NO;
    } else {
        NSString * agentFolder = FORMAT(@"%@/%@",documentFolderPath,[TSSSecurity sha256:agentCode]);
        NSString * masterKeyFile = FORMAT(@"%@/%@.mkf",agentFolder,[TSSSecurity sha256:agentCode]);
        BOOL existeMadstkey = [TSSFileManager fileExits:masterKeyFile];
        if (!existeMadstkey) {
            //Your Account has been locked.Please re-active the App under the link “Activate here”.
            [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"AccountLocked")];
            return NO;
        }
        
        //check login times
        if ([[PDKeyChain keyChainLoad:kLoginErrorCountKey] intValue]  > 4) {
            [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"AccountLocked")];
            [self deleteMasterKeyFile];
            return NO;
        }
    }
    return YES;
}

- (void) fillMadstkeyAndGoToLogin
{
#if LOGIN_WITHOUT_ACTIVATION < 1
    if ([[TSSAppSetting getInstance].buildVesion isEqualToString:BUILD_VERSION_SIT_SGP]||
        [[TSSAppSetting getInstance].buildVesion isEqualToString:BUILD_VERSION_UAT_SGP]||
        [[TSSAppSetting getInstance].buildVesion isEqualToString:BUILD_VERSION_PRO_SGP]
        ||[[TSSAppSetting getInstance].buildVesion isEqualToString:BUILD_VERSION_SIT_COE]) {
        
        BOOL errorFlag = NO;
        self.needChangeDatabaseFromMD5ToSHA256Flag = [self needChangeDatabaseFromMD5ToSHA256];
//        if ([self needChangeDatabaseFromMD5ToSHA256]) {
        if (self.needChangeDatabaseFromMD5ToSHA256Flag) {
            errorFlag = [self changeDatabaseFromMD5ToSHA256];
        }
        if (errorFlag == YES) {
            return;
        }
        NSString * documentFolderPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];

        NSString* ddbName = [TSSSecurity sha256:[TSSAppData getInstance].agentCode];
        NSString *dbName = FORMAT(@"%@.db",ddbName);
        NSString * dbNamePath = FORMAT(@"%@/%@",documentFolderPath,dbName);
        BOOL existed = [TSSFileManager fileExits:dbNamePath];
        if(!existed)
        {
            //Please activate your App under New User before using it or please input correct FSC Code and Password again.
            [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"ActivationMessage")];
            return;
        }
        
        NSString * agentFolder = FORMAT(@"%@/%@",documentFolderPath,[TSSSecurity sha256:[TSSAppData getInstance].agentCode]);
        NSString * masterKeyFile = FORMAT(@"%@/%@.mkf",agentFolder,[TSSSecurity sha256:[TSSAppData getInstance].agentCode]);
        BOOL existeMadstkey = [TSSFileManager fileExits:masterKeyFile];
        if (!existeMadstkey) {
            //Your Account has been locked.Please re-active the App under the link “Activate here”.
            [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"AccountLocked")];
            return;
        }
        
        //check login times
        if ([[PDKeyChain keyChainLoad:kLoginErrorCountKey] intValue]  > 4) {
            [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"AccountLocked")];
            [self deleteMasterKeyFile];
            return;
        }
        //check master key locally!!
        NSString *masterkey = [TSSSecurity decryptMasterKeyFile:[TSSAppData getInstance].agentCode withPassword:[TSSAppData getInstance].agentPassword];
        DLog(@"##activation master key:%@", masterkey);
        if ([TSSValidationUtil isNilOrEmptyString:masterkey]) {
            DLog(@"LOGIN-id & password check failed");
            int count = [[PDKeyChain keyChainLoad:kLoginErrorCountKey] intValue];
            [PDKeyChain keyChainSaveKey:kLoginErrorCountKey withkeyChainValue:[NSString stringWithFormat:@"%d",++count]];
            //Please input correct FSC Code and Password.
            [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"WrongPassword")];
            [[TSSFactoryComponent getInstance] hideProgressMessage:YES];
            return;
        } else {
            DLog(@"LOGIN-id & password check passed");
            [TSSAppData getInstance].masterKey = masterkey;
        }
        
    }
#endif
    
#if LOGIN_WITHOUT_ACTIVATION > 0
    BOOL errorFlag = NO;
    self.needChangeDatabaseFromMD5ToSHA256Flag = [self needChangeDatabaseFromMD5ToSHA256];

    if (self.needChangeDatabaseFromMD5ToSHA256Flag) {
        errorFlag = [self changeDatabaseFromMD5ToSHA256];
    }
    if (errorFlag == YES) {
        return;
    }
#endif
    
    DLog(@"LOGIN-id started..");
    [self connectionToServerForLogin];
}

- (IBAction)loginClick:(id)sender
{
    DLog(@"%d",[[PDKeyChain keyChainLoad:kLoginErrorCountKey] intValue]);
    if ([TSSValidationUtil isNilOrEmptyString:_edtCode.text]||
        [TSSValidationUtil isNilOrEmptyString:_edtPassword.text])
    {
        //You must input both of the FSC Code and Password
        [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"EmptyCodeAndPassword")];
        return;
    }

    if (_edtCode.text.length > 10)
    {
        [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"FSCLengthAlert")];
        return;
    }
    
    if (_edtPassword.text.length > 50)
    {
        [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"FSCPasswordAlert")];
        return;
    }
    
    [TSSAppData getInstance].agentCode = _edtCode.text;
    [TSSAppData getInstance].agentPassword = _edtPassword.text;

    [self fillMadstkeyAndGoToLogin];

}

- (BOOL) needChangeDatabaseFromMD5ToSHA256
{
    NSString * documentFolderPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];

    NSString *md5DbName = FORMAT(@"%@.db",[TSSSecurity md5:[TSSAppData getInstance].agentCode]);
    NSString * md5DbNamePath = FORMAT(@"%@/%@",documentFolderPath,md5DbName);
    BOOL md5DBExist = [TSSFileManager fileExits:md5DbNamePath];
    
    NSString *sha256DbName = FORMAT(@"%@.db",[TSSSecurity sha256:[TSSAppData getInstance].agentCode]);
    NSString * sha256DbNamePath = FORMAT(@"%@/%@",documentFolderPath,sha256DbName);
    BOOL sha256DBExist = [TSSFileManager fileExits:sha256DbNamePath];
    if (md5DBExist == YES && sha256DBExist == NO) {
        return YES;
    }
    return NO;
}

- (BOOL) changeDatabaseFromMD5ToSHA256
{
    NSString * documentFolderPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    NSString * md5AgentFolder = FORMAT(@"%@/%@",documentFolderPath,[TSSSecurity md5:[TSSAppData getInstance].agentCode]);
    NSString * md5MasterKeyFile = FORMAT(@"%@/%@.mkf",md5AgentFolder,[TSSSecurity md5:[TSSAppData getInstance].agentCode]);
    BOOL existeMD5Madstkey = [TSSFileManager fileExits:md5MasterKeyFile];
    if (!existeMD5Madstkey) {
        //Your Account has been locked.Please re-active the App under the link “Activate here”.
        [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"AccountLocked")];
        return YES;
    }
    if ([[PDKeyChain keyChainLoad:kLoginErrorCountKey] intValue]  > 4) {
        [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"AccountLocked")];
        [self deleteMD5MasterKeyFile];
        return YES;
    }
    //check master key locally!!
    NSString *masterkey = [TSSSecurity md5DecryptMasterKeyFile:[TSSAppData getInstance].agentCode withPassword:[TSSAppData getInstance].agentPassword];
    DLog(@"##activation master key MD5:%@", masterkey);
    if ([TSSValidationUtil isNilOrEmptyString:masterkey]) {
        DLog(@"LOGIN-id & password check failed");
        int count = [[PDKeyChain keyChainLoad:kLoginErrorCountKey] intValue];
        [PDKeyChain keyChainSaveKey:kLoginErrorCountKey withkeyChainValue:[NSString stringWithFormat:@"%d",++count]];
        //Please input correct FSC Code and Password.
        [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"WrongPassword")];
        [[TSSFactoryComponent getInstance] hideProgressMessage:YES];
        return YES;
    }
    //check md5 ok, begin change to sha256
    [UIApplication sharedApplication].idleTimerDisabled = YES;
    
    DLog(@"changeDatabaseFromMD5ToSHA256:LOGIN-id & password check passed");
    [TSSAppData getInstance].masterKey = masterkey;
    
    
    NSString *md5DbName = FORMAT(@"%@.db",[TSSSecurity md5:[TSSAppData getInstance].agentCode]);
    NSString * md5DbNamePath = FORMAT(@"%@/%@",documentFolderPath,md5DbName);
    NSString *sha256DbName = FORMAT(@"%@.db",[TSSSecurity sha256:[TSSAppData getInstance].agentCode]);
    NSString * sha256DbNamePath = FORMAT(@"%@/%@",documentFolderPath,sha256DbName);
    NSError *error;
    @try
    {
        //1.copy masterkeyfile
        [TSSSecurity encryptMasterKeyWithPassword:[TSSAppData getInstance].agentCode withPassword:[TSSAppData getInstance].agentPassword];
        NSString * sha256AgentFolder = FORMAT(@"%@/%@",documentFolderPath,[TSSSecurity sha256:[TSSAppData getInstance].agentCode]);
        NSString * sha256MasterKeyFile = FORMAT(@"%@/%@.mkf",sha256AgentFolder,[TSSSecurity sha256:[TSSAppData getInstance].agentCode]);
        BOOL existeSHA5Madstkey = [TSSFileManager fileExits:sha256MasterKeyFile];
        if (!existeSHA5Madstkey) {
            //Your Account has been locked.Please re-active the App under the link “Activate here”.
            [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"AccountLocked")];
            return YES;
        }
        NSString *sha256Masterkey = [TSSSecurity decryptMasterKeyFile:[TSSAppData getInstance].agentCode withPassword:[TSSAppData getInstance].agentPassword];
        if ([TSSValidationUtil isNilOrEmptyString:sha256Masterkey]) {
            DLog(@"changeDatabaseFromMD5ToSHA256 LOGIN-id & password check failed");
            [TSSAppData getInstance].masterKey = nil;
            int count = [[PDKeyChain keyChainLoad:kLoginErrorCountKey] intValue];
            [PDKeyChain keyChainSaveKey:kLoginErrorCountKey withkeyChainValue:[NSString stringWithFormat:@"%d",++count]];
            //Please input correct FSC Code and Password.
            [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"WrongPassword")];
            [[TSSFactoryComponent getInstance] hideProgressMessage:YES];
            return YES;
        }
        
        //2.copy database
        BOOL copyDb = [[NSFileManager defaultManager] copyItemAtPath:md5DbNamePath toPath:sha256DbNamePath error:&error];
        if (copyDb == YES) {
            DLog(@"changeDatabaseFromMD5ToSHA256:copy data base success");

        } else {
            [[NSFileManager defaultManager] removeItemAtPath:sha256DbNamePath error:&error];
            [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"AccountLocked")];
            return YES;
        }
    }
    @catch (NSException *e)
    {
        [[NSFileManager defaultManager] removeItemAtPath:sha256DbNamePath error:&error];
        DLog(@"changeDatabaseFromMD5ToSHA256 exception: %@", e);
        [TSSAppData getInstance].masterKey = nil;
        int count = [[PDKeyChain keyChainLoad:kLoginErrorCountKey] intValue];
        [PDKeyChain keyChainSaveKey:kLoginErrorCountKey withkeyChainValue:[NSString stringWithFormat:@"%d",++count]];
        //Please input correct FSC Code and Password.
        [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"WrongPassword")];
        [[TSSFactoryComponent getInstance] hideProgressMessage:YES];
        return YES;
    }
    
    return NO;
}

- (void)deleteMD5MasterKeyFile {
    NSString * documentFolderPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    NSString * agentFolder = FORMAT(@"%@/%@",documentFolderPath,[TSSSecurity md5:[TSSAppData getInstance].agentCode]);
    NSString * masterKeyFile = FORMAT(@"%@/%@.mkf",agentFolder,[TSSSecurity md5:[TSSAppData getInstance].agentCode]);
    
    DLog(@"encryptMasterKeyWithPassword masterKayFile MD5:%@", masterKeyFile);
    BOOL existed = [TSSFileManager fileExits:masterKeyFile];
    
    if(existed)
    {
        DLog(@"Deleting exiting masterkey file MD5: %@", masterKeyFile);
        [TSSFileManager deleteFile:masterKeyFile];
    } else {
        DLog(@"Not exiting masterkey file MD5: %@", masterKeyFile);
    }
}

- (void)deleteMasterKeyFile {
    NSString * documentFolderPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];

    NSString * agentFolder = FORMAT(@"%@/%@",documentFolderPath,[TSSSecurity sha256:[TSSAppData getInstance].agentCode]);
    NSString * masterKeyFile = FORMAT(@"%@/%@.mkf",agentFolder,[TSSSecurity sha256:[TSSAppData getInstance].agentCode]);
    
    DLog(@"encryptMasterKeyWithPassword masterKayFile:%@", masterKeyFile);
    BOOL existed = [TSSFileManager fileExits:masterKeyFile];
    
    if(existed)
    {
        DLog(@"Deleting exiting masterkey file: %@", masterKeyFile);
        [TSSFileManager deleteFile:masterKeyFile];
    } else {
        DLog(@"Not exiting masterkey file: %@", masterKeyFile);
    }
}

-(void)connectionToServerForLogin
{
    DLog(@"connectionToServerForLogin Started");
    [[TSSFactoryComponent getInstance] showProgressWithLoading];
    
#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
#endif
    [[NetworkingManager getInstance] checkServerConnecting:^(id response){
#if TEST_NET_RESPONSE_TIME > 0
        NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
        DLog(@"*************************login test----- checkServerConnecting: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
#endif
        if ([response isKindOfClass:[NSError class]]) {
            DLog(@"networking error %@",response);
            [self goToHome:nil];
        }
        else
        {
            DLog(@"networking success");
#if TEST_NET_RESPONSE_TIME > 0
            NSDictionary *resultDic = (NSDictionary *)response;
            NSString *returnValStr = [resultDic objectForKey:@"returnVal"];
            NSString *returnValStr1 = [resultDic objectForKey:@"returnVal1"];
            NSData *nsval  = [[NSData dataWithBase64EncodedString:returnValStr] AES256DecryptWithKey:[TSSSecurity encryptionKey]];
            [TSSSecurity writeResponseData:nsval toTestFileName: @"checkServerConnecting" andTimeInterval:requestEndTime];
            NSData *nsval1  = [[NSData dataWithBase64EncodedString:returnValStr1] AES256DecryptWithKey:[TSSSecurity encryptionKey]];
            if(![TSSValidationUtil isNilOrNull:nsval] && nsval.length > 0) {
                resultDic = [NSJSONSerialization JSONObjectWithData:nsval options:0 error:nil];
            }
            else{
                resultDic = [NSJSONSerialization JSONObjectWithData:nsval1 options:0 error:nil];
            }
            DLog(@"*************************login test-----checkServerConnecting: count = %ld", resultDic.count);
#endif
            
            //to validation agent code
            [[NetworkingManager getInstance] checkAgentProfile:^(id response){
                if ([response isKindOfClass:[NSError class]]) {
                    DLog(@"networking connecting failed %@",response);
                    [self goToHome:nil];
                }
                else
                {
                    DLog(@"success to get agent profile");
                    [self goToHome:response];
                }
            }];
        }
        
    }];
}

-(void)goToHome:(id)response
{
    [self goToHomePage:response];
    [[TSSFactoryComponent getInstance] hideProgressMessage:YES];
}



- (void)goToHomePage:(NSDictionary*)aAgentDic
{
    if ([TSSValidationUtil isNilOrNull:aAgentDic])
    {
        DLog(@"goToHomePage with NULL agent dic");
        NSString *materkey = [TSSSecurity decryptMasterKeyFile:[TSSAppData getInstance].agentCode withPassword:[TSSAppData getInstance].agentPassword];
        NSString *agtstr = [NSString stringWithFormat:@"%@,%@,%@", [TSSAppData getInstance].agentCode, [TSSAppData getInstance].agentPassword, materkey ];
        
        DLog(@"LOGIN AGENT: %@", agtstr);
        if ([TSSValidationUtil isNilOrEmptyString:materkey]) {
            //@"Please input correct FSC Code and Password"
            [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"WrongPassword")];
            
            [[TSSFactoryComponent getInstance] hideProgressMessage:YES];
            return ;
        }
        
    }
    //online decrypt db to do
    [[TSSAppDataBase getInstance] initSmartDB];
    AgentProfileBean *tAgent = [[AgentProfileDao getInstance] getBeanWithCode:[TSSAppData getInstance].agentCode];
    if (!tAgent)
    {
        tAgent = [[AgentProfileBean alloc] init];
        tAgent.isfirstlogin = @"1";
        tAgent.agentcode = [TSSAppData getInstance].agentCode;
        NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
        NSString *agentCode = [PDKeyChain keyChainLoad:TOUCHID_AGENT];

        if ([TSSValidationUtil isNilOrEmptyString:agentCode]) {
            
            NSString * key = [TSSSecurity enCodeDataBase64:[TSSAppData getInstance].agentCode];
            NSString * pd = [TSSSecurity enCodeDataBase64:[TSSAppData getInstance].agentPassword];
            [PDKeyChain keyChainSaveKey:TOUCHID_AGENT withkeyChainValue:key];
            [PDKeyChain keyChainSaveKey:TOUCHID_PASS withkeyChainValue:pd];
            
        }
        else
        {
            [user setObject:TOUCHID_UNABLE forKey:TOUCHID_SWITCH];
        }
        
        NSString *enagentCode = [PDKeyChain keyChainLoad:TOUCHID_AGENT_ENCRTION];
        if ([TSSValidationUtil isNilOrEmptyString:enagentCode]) {
            //account use base64 can dec
            NSString * key = [TSSSecurity enCodeDataBase64:[TSSAppData getInstance].agentCode];
            NSString * pd = [TSSSecurity enCodeDataBase64:[TSSAppData getInstance].agentPassword];
            [PDKeyChain keyChainSaveKey:TOUCHID_AGENT_ENCRTION withkeyChainValue:key];
            [PDKeyChain keyChainSaveKey:TOUCHID_PASS_ENCRTION withkeyChainValue:pd];
            
        }else{
            [user setObject:TOUCHID_UNABLE forKey:TOUCHID_SWITCH];
        }
        
    }
    else
    {
        tAgent.isfirstlogin = @"0";
    }
    // Check timebomb:
    // 90 days to do activation;
    // 180 days to destroy db.
    if (!tAgent) {
        //Please do activation first.
        [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"FirstActivation")];
        [[TSSFactoryComponent getInstance] hideProgressMessage:YES];
        return ;
    }
    
    NSNumber *tLastNetworkingNum = [NSNumber numberWithLongLong:(tAgent.agentlastlogintime.longLongValue/1000)];
    NSDate *tLastNetworkingDate = [NSDate convertNumberToDateNoDateFormat:tLastNetworkingNum];
    if ([TSSSecurity isSystemBackDated:tLastNetworkingDate]) {
        //Your device's time is wrong, please check it.
        [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"WrongDeviceTime")];
        [[TSSFactoryComponent getInstance] hideProgressMessage:YES];
        return;
    }
    NSString *tCheckTimebomb = [TSSSecurity checkNoTimebomb:tAgent.agentlastlogintime];

#if LOGIN_WITHOUT_ACTIVATION < 1
    if([tCheckTimebomb isEqualToString:AGENT_LASTTIME_EMPTY]) {
        //Please activate your App under New User before using it or please input correct FSC Code and Password again.
        [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"ActivationMessage")];
        [[TSSFactoryComponent getInstance] hideProgressMessage:YES];
        return;
    }
#endif

    if([tCheckTimebomb isEqualToString:TIMEBOMB_ALERT]){
        long long llnowinSeconds = [[NSDate date] timeIntervalSince1970];
        long long lllastLogintimeinSeconds = [tAgent.agentlastlogintime longLongValue] / 1000.0;
        long long timebomb1inSeconds = (long long)[[TSSAppSetting getInstance].timebomb1 longLongValue] * 24 * 60 * 60;
        long long deta = llnowinSeconds - lllastLogintimeinSeconds;
        deta = deta/24/60/60;
        NSString *msg = FORMAT(@"Your password will expire in %lld days. To change your password, please access the link “Activate here.”", ((long long)[[TSSAppSetting getInstance].timebomb1 longLongValue]-deta));
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Information" message:msg preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
            [self checkAppVersionfromStaging:tAgent andDic:aAgentDic];
        }];
        [alert addAction:cancelAction];
        [self presentViewController:alert animated:YES completion:nil];
        return;
    }
    if([tCheckTimebomb isEqualToString:TIMEBOMB1_EXPIRE]){
        //Your current password has expired.Please re-activate the App under the link “Activate here”.
        [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"PasswordExpired")];
        [[TSSFactoryComponent getInstance] hideProgressMessage:YES];
        return;
    }
    
    if([tCheckTimebomb isEqualToString:TIMEBOMB2_EXPIRE]){
        //destroy db
        NSString * documentFolderPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
        NSString* ddbName = [TSSSecurity sha256:[TSSAppData getInstance].agentCode];
        NSString *dbName = FORMAT(@"%@.db",ddbName);
        NSString * dbNamePath = FORMAT(@"%@/%@",documentFolderPath,dbName);
        BOOL existed = [TSSFileManager fileExits:dbNamePath];
        if(existed)
        {
            DLog(@"Deleting exiting db file");
            [TSSFileManager deleteFile:dbNamePath];
        }
        [[TSSFactoryComponent getInstance] hideProgressMessage:YES];
        return;
    }

#if LOGIN_WITHOUT_ACTIVATION < 1
    if([tCheckTimebomb isEqualToString:TIMEBOMB_PASS]){
#endif    
        [self checkAppVersionfromStaging:tAgent andDic:aAgentDic];
#if LOGIN_WITHOUT_ACTIVATION < 1
    }
#endif

}

-(void) checkAppVersionfromStaging:(AgentProfileBean*)tAgent andDic:(NSDictionary*)aAgentDic
{
#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
#endif
    [[NetworkingManager getInstance] checkServerConnecting:^(id response)
     {
#if TEST_NET_RESPONSE_TIME > 0
         NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
         DLog(@"*************************login test-----checkAppVersionfromStaging_checkServerConnecting: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
#endif
         if ([response isKindOfClass:[NSError class]]) {
             [self loginUploadAndGoToHome:tAgent andDic:aAgentDic];
         }
         else{
#if TEST_NET_RESPONSE_TIME > 0         
             NSDictionary *resultDic = (NSDictionary *)response;
             NSString *returnValStr = [resultDic objectForKey:@"returnVal"];
             NSString *returnValStr1 = [resultDic objectForKey:@"returnVal1"];
             NSData *nsval  = [[NSData dataWithBase64EncodedString:returnValStr] AES256DecryptWithKey:[TSSSecurity encryptionKey]];

             [TSSSecurity writeResponseData:nsval toTestFileName: @"checkAppVersionfromStaging_checkServerConnecting" andTimeInterval:requestEndTime];

             NSData *nsval1  = [[NSData dataWithBase64EncodedString:returnValStr1] AES256DecryptWithKey:[TSSSecurity encryptionKey]];
             if(![TSSValidationUtil isNilOrNull:nsval] && nsval.length > 0) {
                 resultDic = [NSJSONSerialization JSONObjectWithData:nsval options:0 error:nil];
             }
             else{
                 resultDic = [NSJSONSerialization JSONObjectWithData:nsval1 options:0 error:nil];
             }
             DLog(@"*************************login test-----checkAppVersionfromStaging_checkServerConnecting: count = %ld", resultDic.count);
#endif             
             [[NetworkingManager getInstance] checkAppVersion:^(id obj) {
                 if (![obj isKindOfClass:[NSError class]]) {
                     if(![TSSValidationUtil isNilOrNull:obj]){
                         NSString *message = [(NSDictionary*)obj objectForKey:@"message"];
                         if([message isEqualToString:@"FORCE UPDATE"]){
                             int imajorVersionStaging = [[(NSDictionary *)obj objectForKey:@"majorVersion"] intValue];
                             int iminorVersionStaging = [[(NSDictionary *)obj objectForKey:@"minorVersion"] intValue];
                             NSString * msg = [NSString stringWithFormat:@"There is a new Joint Field Work App version for upgrade (Version %d.%d). Kindly update the App or you can login to Agent Internet Portal to download.", imajorVersionStaging, iminorVersionStaging];
                             UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Information" message:msg preferredStyle:UIAlertControllerStyleAlert];
                             UIAlertAction *defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                                 //Force update
                                 NSString *openUrl = [(NSDictionary *)obj objectForKey:@"packageUrl"];
                                 [[UIApplication sharedApplication] openURL:[NSURL URLWithString:openUrl]];
                             }];
                             [alert addAction:defaultAction];
                             [self presentViewController:alert animated:YES completion:nil];
                         }else if ([message isEqualToString:@"LATEST VERSION"]) {
                             [self loginUploadAndGoToHome:tAgent andDic:aAgentDic];
                         }
                     }
                 }else {
                     [self loginUploadAndGoToHome:tAgent andDic:aAgentDic];
                 }
             }];
         }
     }];
}

-(void)loginUploadAndGoToHome:(AgentProfileBean*)tAgent andDic:(NSDictionary*)aAgentDic
{
    DLog(@"loginUploadAndGoToHome Started: %@", aAgentDic);
    
    if ([tAgent.isfirstlogin isEqualToString:@"1"]) {
    }
    
    //update agent info
    if (![TSSValidationUtil isNilOrNull:aAgentDic]) {
        tAgent.agentname = [aAgentDic objectForKey:@"agentName"];
        tAgent.agenttype = [aAgentDic objectForKey:@"agentType"];
        tAgent.agentlevelcode = [aAgentDic objectForKey:@"levelCode"];
        tAgent.jfwrole = [aAgentDic objectForKey:@"rolejfw"];
        tAgent.agentstatus = [aAgentDic objectForKey:@"status"];
        tAgent.agentleadercode = [aAgentDic objectForKey:@"managerCode"];
        tAgent.agentleadername = [aAgentDic objectForKey:@"managerName"];
        [TSSAppData getInstance].masterKey = [aAgentDic objectForKey:@"masterKey"];
        tAgent.agentmasterkey = [aAgentDic objectForKey:@"masterKey"];
        tAgent.setupManagerCode = [aAgentDic objectForKey:@"setupManagerCode"];
        tAgent.setupManagerName = [aAgentDic objectForKey:@"setupManagerName"];
        if (![TSSValidationUtil isNilOrNull:[aAgentDic objectForKey:@"agentPhoto"]]) {
            tAgent.agentphoto = [aAgentDic objectForKey:@"agentPhoto"];
        }
        DLog(@"##staging agent dic: %@", aAgentDic);
        /*
         {
         DistAgtCode = "";
         agencyCode = 02108;
         agentCode = 36249;
         agentName = "TMAU SKI CHED";
         agentPhoto = "";
         agentPhotoVersion = 0;
         agentProfileId = 2;
         agentType = Agent;
         branch = ALL;
         city = ALL;
         createdBy = system;
         createdDateTime = "2017-03-14 16:06:04.676";
         encryptPassword = f6e0a1e2ac41945a9aa7ff8a8aaa0cebc12a3bcc981a929ad5cf810a090e11ae;
         lastUpdateDateTime = "Thu Mar 16 10:09:35 SGT 2017";
         levelCode = L;
         managerBranch = "";
         managerCity = "";
         managerCode = 36249;
         managerName = "";
         masterKey = 79ca77150a579136c8487a10746ba213;
         role = "";
         rolejfw = leader;
         servertimestamp = 1489630175938;
         status = A;
         timebomb = "";
         token2fa = 4924827bfd976723975c8dc5788bed26;
         updatedBy = system;
         }
         */
        
        DLog(@"##staging master key: %@", tAgent.agentmasterkey);
        
        if(![TSSValidationUtil isNilOrEmptyString:[TSSAppData getInstance].masterKey]) {
            [TSSSecurity encryptMasterKeyWithPassword:[TSSAppData getInstance].agentCode withPassword:[TSSAppData getInstance].agentPassword];
        }
    }
    NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
    NSString *agentCode = [PDKeyChain keyChainLoad:TOUCHID_LOGIN_AGENT];
    NSString *enagentCode = [PDKeyChain keyChainLoad:TOUCHID_LOGIN_AGENT_ENCRTION];
    
    if ([agentCode isEqualToString:enagentCode]&&![TSSValidationUtil isNilOrEmptyString:agentCode]) {
        //说明TOUCHID_LOGIN_AGENT已经是加密过的了，需要解密
        agentCode = [TSSSecurity deCodeDataBase64:agentCode];
    }
    
    if ([TSSValidationUtil isNilOrEmptyString:agentCode] || [agentCode isEqualToString: [TSSAppData getInstance].agentCode]) {
        
        NSString * key = [TSSSecurity enCodeDataBase64:[TSSAppData getInstance].agentCode];
        NSString * pd = [TSSSecurity enCodeDataBase64:[TSSAppData getInstance].agentPassword];
        
        [PDKeyChain keyChainSaveKey:TOUCHID_LOGIN_AGENT withkeyChainValue:key];
        [PDKeyChain keyChainSaveKey:TOUCHID_LOGIN_PASS withkeyChainValue:pd];
    } else {
        
        [user setObject:TOUCHID_UNABLE forKey:TOUCHID_LOGIN_SWITCH];
    }
    
    if ([TSSValidationUtil isNilOrEmptyString:agentCode] || [agentCode isEqualToString: [TSSAppData getInstance].agentCode]) {
        NSString * key = [TSSSecurity enCodeDataBase64:[TSSAppData getInstance].agentCode];
        NSString * pd = [TSSSecurity enCodeDataBase64:[TSSAppData getInstance].agentPassword];
        
        [PDKeyChain keyChainSaveKey:TOUCHID_LOGIN_AGENT_ENCRTION withkeyChainValue:key];
        [PDKeyChain keyChainSaveKey:TOUCHID_LOGIN_PASS_ENCRTION withkeyChainValue:pd];
        
    } else{
        [user setObject:TOUCHID_UNABLE forKey:TOUCHID_LOGIN_SWITCH];
    }
    
    [tAgent save];
    
    if ([tAgent.agentstatus isEqualToString:@"L"]) {
        //Invalid FSC Code. Access denied.
        [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"InvalidFSCCode")];
        return ;
    }
    
    [[TSSFactoryComponent getInstance] hideProgressMessage:YES];
    [TSSAppData getInstance].masterKey = tAgent.agentmasterkey;
    [TSSAppData getInstance].agentJfwRole = tAgent.jfwrole;
    [TSSAppData getInstance].agentName = tAgent.agentname;
    
    //如果登陆的人是fsc，则需设置leader的code和name在内存当中
    if ([[TSSAppData getInstance].agentJfwRole isEqualToString: Agent]) {
        //        if ([TSSValidationUtil isNilOrEmptyString:tAgent.setupManagerCode]) {
        [TSSAppData getInstance].leaderCode = tAgent.agentleadercode;
        [TSSAppData getInstance].leaderName = tAgent.agentleadername;
        //        } else {
        //            [TSSAppData getInstance].leaderCode = tAgent.setupManagerCode;
        //            [TSSAppData getInstance].leaderName = tAgent.setupManagerName;
        //        }
    }
    
    TSSMenuController *menuVC = [UFStoryboard(@"Main") instantiateViewControllerWithIdentifier:@"menu_controller_id"];
    
    FollowUpAndNoteViewController *appointmentVc = [[FollowUpAndNoteViewController alloc] initWithNibName:@"BaseViewController" bundle:nil];
    appointmentVc.titleTXT = @"AIA";
    [TSSAppData getInstance].drawer = [[ICSDrawerController alloc] initWithLeftViewController:menuVC centerViewController:appointmentVc];
    DLog(@"GOTO HOME PAGE VIEW");
    
    [self presentViewController:[TSSAppData getInstance].drawer animated:YES completion:^{
        [PDKeyChain  keyChainSaveKey:kLoginErrorCountKey withkeyChainValue:@"0"];
    }];
    [[EventLogDao getInstance] eventSaveByType:SMART_LOGIN];
    
    NSString *key = [NSString stringWithFormat: @"%@%@", [TSSAppData getInstance].agentCode, FIRST_LOGIN_STATUS];
    NSString *enkey =  [TSSSecurity sha256:key];
    NSString *loginStatus = [PDKeyChain keyChainLoad:key];
    NSString *enloginStatus = [PDKeyChain keyChainLoad:enkey];
    
    if (![loginStatus isEqualToString:enloginStatus]&&[TSSValidationUtil isNilOrEmptyString:enloginStatus]) {
        loginStatus = enloginStatus;
    }
    
    BOOL agentFirstLogin = NO;
    
    if (self.needChangeDatabaseFromMD5ToSHA256Flag) {
        agentFirstLogin = NO;
        if (loginStatus == nil) {
            [PDKeyChain keyChainSaveKey:enkey withkeyChainValue:FIRST_LOGIN_STATUS_SECOND_LOGIN_SUCCESS];
        }
    } else {
        if ([loginStatus isEqualToString: FIRST_LOGIN_STATUS_FIRST_ACTIVATION_SUCCESS]) {
            agentFirstLogin = YES;
            [PDKeyChain keyChainSaveKey:enkey withkeyChainValue:FIRST_LOGIN_STATUS_FIRST_LOGIN_SUCCESS];
        } else if ([loginStatus isEqualToString: FIRST_LOGIN_STATUS_FIRST_LOGIN_SUCCESS]) {
            [PDKeyChain keyChainSaveKey:enkey withkeyChainValue:FIRST_LOGIN_STATUS_SECOND_LOGIN_SUCCESS];
        }
    }
    
#if LOGIN_WITHOUT_ACTIVATION >= 1
    //如果需要更换数据库名，说明之前登陆过，这种情况不算是首次登陆
    if (self.needChangeDatabaseFromMD5ToSHA256Flag) {
        agentFirstLogin = NO;
        if (loginStatus == nil) {
            [PDKeyChain keyChainSaveKey:enkey withkeyChainValue:FIRST_LOGIN_STATUS_SECOND_LOGIN_SUCCESS];
            
            
        }
    } else
        
        if (loginStatus == nil) {
            agentFirstLogin = YES;
            [PDKeyChain keyChainSaveKey:enkey withkeyChainValue:FIRST_LOGIN_STATUS_FIRST_LOGIN_SUCCESS];
            
            
        } else if ([loginStatus isEqualToString: FIRST_LOGIN_STATUS_FIRST_LOGIN_SUCCESS]) {
            [PDKeyChain keyChainSaveKey:enkey withkeyChainValue:FIRST_LOGIN_STATUS_SECOND_LOGIN_SUCCESS];
            
            
        }
    
    
#endif
    
    if (agentFirstLogin) {
        //如果是首次登陆，即activation之后的登陆，则无需上传，下载event也放在进入followupandnote界面去下载
        //首次登录以后，自动添加一个用户，名字是prospect
        [self addProspectCustomer];
        [self downLoadCustomer];
        
#if DOWNLOAD_DELETED_AND_CREATE_DATE_TIME_LONG_DATA == 1
        NSString *firstDownLoadDeteletedFollowupKey = [NSString stringWithFormat: @"%@%@", [TSSAppData getInstance].agentCode, FIRST_DOWNLOAD_DELETE_FOLLOWUP];
        NSString *enfirstDownLoadDeteletedFollowupKey =  [TSSSecurity sha256:firstDownLoadDeteletedFollowupKey];
        [PDKeyChain keyChainSaveKey:enfirstDownLoadDeteletedFollowupKey withkeyChainValue:FIRST_DOWNLOAD_DELETE_NO_NEED];
        
        NSString *firstDownLoadDeteletedJFWKey = [NSString stringWithFormat: @"%@%@", [TSSAppData getInstance].agentCode, FIRST_DOWNLOAD_DELETE_JFW];
        NSString *enfirstDownLoadDeteletedJFWKey =  [TSSSecurity sha256:firstDownLoadDeteletedJFWKey];
        [PDKeyChain keyChainSaveKey:enfirstDownLoadDeteletedJFWKey withkeyChainValue:FIRST_DOWNLOAD_DELETE_NO_NEED];
        
        NSString *firstDownLoadCreateDateTimeLongFollowupKey = [NSString stringWithFormat: @"%@%@", [TSSAppData getInstance].agentCode, FIRST_DOWNLOAD_CREATE_DATE_TIME_LONG_FOLLOWUP];
        NSString *enfirstDownLoadCreateDateTimeLongFollowupKey =  [TSSSecurity sha256:firstDownLoadCreateDateTimeLongFollowupKey];
        [PDKeyChain keyChainSaveKey:enfirstDownLoadCreateDateTimeLongFollowupKey withkeyChainValue:FIRST_DOWNLOAD_DELETE_NO_NEED];
#endif
        
        [self uploadDataToServer];
        [self downloadJFW];
        [self downLoadNotifications];
        
    } else {
        [self upLoadAgentPhoto];
        [self downLoadCustomer];
        [self uploadDataToServer];
        [self upLoadCustomer];
        [self upLoadAppointment];
        [self uploadAppointmentStatus];
        [self downloadAppointment];
        [self downloadJFW];
        [self uploadNotificationreadStatus];
        [self downLoadNotifications];
    }
    
    [TSSAppData getInstance].agentCheckingCode = [TSSAppData getInstance].agentCode;
    
    
}

-(void)addProspectCustomer{
    //首次登录以后，自动添加一个用户，名字是prospect
    if ([[TSSAppData getInstance].agentJfwRole isEqualToString: Agent]) {
        NSArray * dbArr = [[CustomerInfoDao getInstance] getBeansWithName:@"PROSPECT"];
        BOOL state = YES;
        for (CustomerInfoBean * customer in dbArr) {
            if ([customer.fullname isEqualToString:@"PROSPECT"]) {
                state = NO;
                break;
            }
        }
        if (state) {
            CustomerInfoBean *testcustomer = [[CustomerInfoBean alloc]init];
            testcustomer.fullname = @"PROSPECT";
            testcustomer.firstname = @"PROSPECT";
            testcustomer.customerType = @"1";
            testcustomer.status = @"1";
            testcustomer.customerUuid = [[TSSAppData getInstance] randomId];
            testcustomer.agentcode = [TSSAppData getInstance].agentCode;
            testcustomer.internalId = @"";
            testcustomer.oid =@"";
            testcustomer.lastname = @"";
            testcustomer.gender = @"";
            testcustomer.age = @"";
            testcustomer.contacttype = @"";
            testcustomer.smoker = @"";
            testcustomer.maritalstatus = @"";
            testcustomer.occupationcode = @"";
            testcustomer.email = @"";
            testcustomer.mobile = @"";
            testcustomer.notes = @"";
            testcustomer.companyname = @"";
            NSNumber *createNum = [NSDate convertNSDateToNSNumber:[NSDate date]];
            NSString *createDate = [NSString stringWithFormat:@"%lld",(long long)[createNum longLongValue]*1000];
            NSString *updateDate = [NSString stringWithFormat:@"%lld",(long long)[createNum longLongValue]*1000];
            testcustomer.createddatetimelong =createDate;
            testcustomer.lastupdatedatetimelong = updateDate;
            NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
            [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss.SSS"];
            testcustomer.createddatetime = [formatter stringFromDate:[NSDate date]];
            testcustomer.childrennum = @"";
            testcustomer.address = @"";
            testcustomer.internalRole = @"";
            testcustomer.createby = [TSSAppData getInstance].agentCode;
            //testcustomer.uploadStatus = UPLOAD_STATUS_FAILED;
            [testcustomer save];
            
        }
    }
}

- (void)activatedButtonAction:(UIButton *)sender
{
    [[TSSFactoryComponent getInstance] showProgressWithLoading];
    [[NetworkingManager getInstance] checkServerConnecting:^(id response){
        
        [[TSSFactoryComponent getInstance] hideProgressMessage:YES];
        if ([response isKindOfClass:[NSError class]]) {
            DLog(@"networking error %@",response);
            //No active network available. Please check your internet connectivity.
            [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"NoActiveNetwork")];
        }
        else
        {
            DLog(@"networking success");
            [self startUpActivatePage:ACTIVATION_TYPE_NEW_USER];
        }
    }];
}

- (void)fogetPasswordButtonAction:(UIButton *)sender
{
    [[TSSFactoryComponent getInstance] showProgressWithLoading];
    [[NetworkingManager getInstance] checkServerConnecting:^(id response){
        
        [[TSSFactoryComponent getInstance] hideProgressMessage:YES];
        if ([response isKindOfClass:[NSError class]]) {
            DLog(@"networking error %@",response);
            //No active network available. Please check your internet connectivity.
            [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"NoActiveNetwork")];
        }
        else
        {
            DLog(@"networking success");
            [self startUpActivatePage:ACTIVATION_TYPE_FORGET_PASSWORD];
        }
    }];
}

- (void)startUpActivatePage:(int)activateType {
    
    DLog(@"ACTIVATION TYPE:%@", [NSString stringWithFormat:@"%d", activateType]);
    ActivateViewController *activateVc = [[ActivateViewController alloc]initWithNibName:@"BaseBackViewController" bundle:nil];
    activateVc.activationType = activateType;
    activateVc.tXttitle = MuliteLocalizedString(@"ActivationTitle");
    if (activateType == ACTIVATION_TYPE_FORGET_PASSWORD) {
        activateVc.tXttitle = MuliteLocalizedString(@"ForgetPasswordTitle");
    }
    [self presentViewController:activateVc animated:YES completion:nil];
}


#pragma mark -
#pragma mark download and upload method
- (void)upLoadAgentPhoto {
    AgentProfileBean *tAgent = [[AgentProfileDao getInstance] getBeanWithCode:[TSSAppData getInstance].agentCode];
    if ([tAgent.photoStatus isEqualToString:UPLOAD_STATUS_FAILED]) {
        NSData *imgData = [[NSData alloc]initWithBase64EncodedString:tAgent.agentphoto options:NSDataBase64Encoding64CharacterLineLength];
        //post server
        [[NetworkingManager getInstance] uploadAgenPhoto:imgData withCallback:^(id obj) {
            NSString *status = (NSString *)obj;
            tAgent.photoStatus = status;
            [tAgent save];
        }];
    }
}

-(void)uploadDataToServer
{
    //upload events log, if success deletes logs
    [[NetworkingManager getInstance] eventLogUpload:^(id response)
     {
         if ([response isKindOfClass:[NSError class]])
         {
             DLog(@"eventLogUpload failed %@",response);
         }
         else
         {
             DLog(@"success to upload eventlogs");
             
         }
     }];

    [[TSSFactoryComponent getInstance] hideProgressMessage:YES];
}


- (void)upLoadCustomer
{
    [[NetworkingManager getInstance] uploadcustomers:@[] withContactHistoryList:@[] withCallBack:^(id obj) {
        if (![obj isKindOfClass:[NSError class]])
        {
            NSArray *arr = (NSArray *)obj;
            if (arr.count > 0)
            {
                CustomerInfoBean *aCustBean = nil;
                for (NSDictionary *subDic in arr)
                {
                    aCustBean = [[CustomerInfoDao getInstance] getBeanWithCustomerUUId:[subDic objectForKey:@"id"]];
                    aCustBean.oid = [subDic objectForKey:@"oid"];
                    aCustBean.customerType = @"1";
                    aCustBean.uploadStatus = @"1";
                    [aCustBean save];
                }
            }
        }
    }];
}

- (void)downLoadCustomer
{
    CustomerInfoBean *temp = nil;
    NSString *lastUpdateTimelong = @"";
    NSMutableArray *datas = [[CustomerInfoDao getInstance] getBeansWithCount:1];
    NSString *sign = @"";
    if (datas.count > 0)
    {
        temp = [datas firstObject];
        lastUpdateTimelong = [TSSValidationUtil converStringToEmptyString:temp.lastupdatedatetimelong];
        sign = @">";
    }
    else
    {
        NSDate *tToday = [NSDate date];
        lastUpdateTimelong = [NSString stringWithFormat:@"%lld",(long long)([tToday timeIntervalSince1970]*1000)];
        sign = @"<";
    }

    [[NetworkingManager getInstance] downloadCustomerLastUpdateTime:lastUpdateTimelong andRecordNo:@"0" andLater:sign andCallBack:^(id obj) {
        
        if (![obj isKindOfClass:[NSError class]])
        {
            
        }
    }];

}
/*
- (void)downLoadCustomerWithoutImage
{
    CustomerInfoBean *temp = nil;
    NSString *lastUpdateTimelong = @"";
    NSMutableArray *datas = [[CustomerInfoDao getInstance] getBeansWithCount:1];
    NSString *sign = @"";
    if (datas.count > 0)
    {
        temp = [datas firstObject];
        lastUpdateTimelong = [TSSValidationUtil converStringToEmptyString:temp.lastupdatedatetimelong];
        sign = @">";
    }
    else
    {
        NSDate *tToday = [NSDate date];
        lastUpdateTimelong = [NSString stringWithFormat:@"%lld",(long long)([tToday timeIntervalSince1970]*1000)];
        sign = @"<";
    }
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        [[NetworkingManager getInstance] downloadCustomerLastUpdateTime:lastUpdateTimelong andRecordNo:@"0" andLater:sign andFetchFlag:DOWNLOAD_TEXT andOids:nil andCallBack:^(id obj) {
            if (![obj isKindOfClass:[NSError class]])
            {
                CustomerInfoBean *ciBean = nil;
                NSMutableArray *allCustomerInfo = [[CustomerInfoDao getInstance] selectAll];
                int allCount = allCustomerInfo.count;
                NSMutableArray *oids = [NSMutableArray array];
                for (int i = 0; i < allCount; i++) {
                    ciBean = [allCustomerInfo objectAtIndex: i];
                    [oids addObject: [NSDictionary dictionaryWithObject:ciBean.oid forKey:@"oid"]];
//                    if (oids.count == 30){
//                        [self downLoadCustomerWithImageForOids: oids];
//                        oids = [NSMutableArray array];
//                    }
                }
                if (oids.count > 0) {
                    [self downLoadCustomerWithImageForOids: oids];
                }
            }
        }];
    });
}

- (void) downLoadCustomerWithImageForOids: (NSMutableArray *)oids
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        [[NetworkingManager getInstance] downloadCustomerLastUpdateTime:@"" andRecordNo:@"" andLater:@"" andFetchFlag:DOWNLOAD_IMAGE andOids:oids andCallBack:^(id obj) {
            if (![obj isKindOfClass:[NSError class]])
            {
                
            }
        }];
    });
}
*/
-(void)downloadAppointment
{
    [self updateDataSourceAction];
}

-(void)updateDataSourceAction
{
    NSArray *tFollowArray = [[FollowUpAndNoteDao getInstance] getBeansWithCount:1];
    FollowUpAndNoteBean *tNewBean = nil;
    if (tFollowArray.count>0) {
        tNewBean = [tFollowArray firstObject];
    }
    NSString *tLastTimeLong = [TSSValidationUtil converStringToEmptyString:tNewBean.lastUpdateDateTimeLong];
    
#if DOWNLOAD_DELETED_AND_CREATE_DATE_TIME_LONG_DATA == 1
    //判断是否之前下载过删除过的代码
    NSString *firstDownLoadDeteletedFollowupKey = [NSString stringWithFormat: @"%@%@", [TSSAppData getInstance].agentCode, FIRST_DOWNLOAD_DELETE_FOLLOWUP];
    NSString *enfirstDownLoadDeteletedFollowupKey =  [TSSSecurity sha256:firstDownLoadDeteletedFollowupKey];
    
    NSString *firstDownLoadDeteletedFollowup = [PDKeyChain keyChainLoad:firstDownLoadDeteletedFollowupKey];
    NSString *enfirstDownLoadDeteletedFollowup = [PDKeyChain keyChainLoad:enfirstDownLoadDeteletedFollowupKey];
    
    if (firstDownLoadDeteletedFollowup == nil&&enfirstDownLoadDeteletedFollowup == nil) {
        NSString *tempLastTimeLong = tLastTimeLong;
        if ([TSSValidationUtil isNilOrEmptyString:tempLastTimeLong] == NO) {
            tempLastTimeLong = [NSString stringWithFormat: @"%lld",(tLastTimeLong.longLongValue + 1LL)];
        }
        
        [[NetworkingManager getInstance] downloadDeletedAppointmentEvent:tempLastTimeLong andCallBack:^(id obj) {
            if ([obj isKindOfClass:[NSError class]])
            {
            }
            else
            {
            }
        }];
    }
    
    //判断是否之前下载过FollowUpAndNote的createdatetime_long
    NSString *firstDownLoadCreateDateTimeLongFollowupKey = [NSString stringWithFormat: @"%@%@", [TSSAppData getInstance].agentCode, FIRST_DOWNLOAD_CREATE_DATE_TIME_LONG_FOLLOWUP];
    //NSString *firstDownLoadCreateDateTimeLongFollowup = [userDefaults objectForKey: firstDownLoadCreateDateTimeLongFollowupKey];
    NSString *firstDownLoadCreateDateTimeLongFollowup = [PDKeyChain keyChainLoad:firstDownLoadCreateDateTimeLongFollowupKey];
    firstDownLoadCreateDateTimeLongFollowup = nil;
    if (firstDownLoadCreateDateTimeLongFollowup == nil) {
        NSString *tempLastTimeLong = tLastTimeLong;
        if ([TSSValidationUtil isNilOrEmptyString:tempLastTimeLong] == NO) {
            tempLastTimeLong = [NSString stringWithFormat: @"%lld",(tLastTimeLong.longLongValue + 1LL)];
        }
        
        [[NetworkingManager getInstance] downloadCreateDateTimeForAppointmentEvent:tempLastTimeLong andCallBack:^(id obj) {
            if ([obj isKindOfClass:[NSError class]])
            {

            }
            else
            {

            }
        }];
    }
#endif
    
    [[NetworkingManager getInstance] appointmentEventDownload:tLastTimeLong andRecordNo:@"0" andCallBack:^(id obj) {
        
        if ([obj isKindOfClass:[NSError class]])
        {

        }
        else
        {
            if (![obj isKindOfClass:[NSDictionary class]]) {
                NSArray *arr = (NSArray *)obj;
                if (arr.count > 0)
                {
                }
            }
        }
    }];
}

-(void)downloadJFW
{
    [self loadHeaderJFWData];
}

-(void)loadHeaderJFWData
{
    JfwBean *tJFW = [[JfwDao getInstance] getBeansDESCWithCount:1];
    NSString *lastUpdateTime = [TSSValidationUtil converStringToEmptyString:[tJFW.lastupdatedatetimelong stringValue]];
    [self loadJFWFromServer:lastUpdateTime later:@">" count:@"0"];
}

-(void)loadJFWFromServer:(NSString*)aDate later:(NSString*)sign count:(NSString*)aCount
{
    
    if ([[NetworkingManager getInstance] currentNetworkStatus] == YES)
    {

#if DOWNLOAD_DELETED_AND_CREATE_DATE_TIME_LONG_DATA == 1
        //判断是否之前下载过删除过的代码
        NSString *firstDownLoadDeteletedJFWKey = [NSString stringWithFormat: @"%@%@", [TSSAppData getInstance].agentCode, FIRST_DOWNLOAD_DELETE_JFW];
        NSString *enfirstDownLoadDeteletedJFWKey =  [TSSSecurity sha256:firstDownLoadDeteletedJFWKey];
        NSString *firstDownLoadDeteletedJFW = [PDKeyChain keyChainLoad:enfirstDownLoadDeteletedJFWKey];
        if (firstDownLoadDeteletedJFW == nil) {
            NSString *tempLastTimeLong = aDate;
            if ([TSSValidationUtil isNilOrEmptyString:tempLastTimeLong] == NO) {
                tempLastTimeLong = [NSString stringWithFormat: @"%lld",(aDate.longLongValue + 1LL)];
            }
            [[NetworkingManager getInstance] downloadDeletedJFW:tempLastTimeLong andCallBack:^(id obj) {
                if ([obj isKindOfClass:[NSError class]])
                {

                }
                else
                {

                }
            }];
        }
#endif
        
      [[NetworkingManager getInstance] jfwDownLoad:aDate andRecordNo:aCount andLater:sign oids:nil fetchFlag:DOWNLOAD_TEXT andCallBack:^(id obj) 
         {
             if ([obj isKindOfClass:[NSString class]]) {
                 return;
             }
         }];
    }
}

-(void)upLoadAppointment
{
    [[NetworkingManager getInstance] appointmentUploadAndEventList:@[] andCallBack:^(id obj) {

    }];
}

- (void)uploadAppointmentStatus{
    
    [[NetworkingManager getInstance] upLoadJfwStatusWithJfwStatus:@[] withCallBack:^(id obj) {
        NSArray *arr = (NSArray *)obj;
        AppointmentCommentsBean *aCommetBean = nil;
        for (NSDictionary *subDic in arr) {
            aCommetBean = [[AppointmentCommentsDao getInstance] getBeanWithEventId:[subDic objectForKey:@"eventId"]];
            aCommetBean.uploadStatus = UPLOAD_STATUS_OK;
            [aCommetBean save];
        }
    }];
}

- (void)downLoadNotifications
{
    NSArray *datas = [[NotificationDao getInstance] getBeansWithCount:1];
    NotificatinBean *temp;
    if (datas.count > 0)
    {
        temp = [datas firstObject];
    }
    NSString *lastUpdateTimelong = [TSSValidationUtil converStringToEmptyString:temp.lastupdatedatetimeLong];

    [[NetworkingManager getInstance] downLoadNotifactionAndLastUpdateTime:lastUpdateTimelong andRecordNo:@"0" andCallBack:^(id obj) {
        
        
        if (![obj isKindOfClass:[NSError class]]) {
            NSArray *arr = (NSArray *)obj;
            if (arr.count > 0)
            {
#if TEST_NET_RESPONSE_TIME > 0
                NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
#endif
                NotificatinBean *find = nil;
                NSMutableArray *intoDBArr = [NSMutableArray array];
                for (NotificatinBean *notiBean in arr)
                {
                    find = [[NotificationDao getInstance] getBeanWithoid:notiBean.oid];
                    if(find != nil)
                    {
                        find.readStatus = notiBean.readStatus;
                        find.uploadStatus = UPLOAD_STATUS_OK;
                        [intoDBArr addObject: find];
                    }
                    else
                    {
                        [intoDBArr addObject: notiBean];
                    }
                }
                [[NotificationDao getInstance] saveOrUpdateArray: intoDBArr];
#if TEST_NET_RESPONSE_TIME > 0
                NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
                DLog(@"*************************SmartLoginViewController----- downLoadNotifications: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
#endif
                [[NSNotificationCenter defaultCenter] postNotificationName:kAlertRefreshFollowUpAndNote object:nil];
                
            }
        }
    }];
    
}

- (void)uploadNotificationreadStatus {
    [[NetworkingManager getInstance] notificationUploadAndNotifyList:nil andCallBack:^(id obj) {
    }];
}

- (void)authenticateUser
{
    //初始化上下文对象
    LAContext* context = [[LAContext alloc] init];
    //错误对象
    NSError* error = nil;
    NSString* result = @"Unlock iMO Smart with Touch ID";
    
    //首先使用canEvaluatePolicy 判断设备支持状态
    if ([context canEvaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics error:&error]) {
        //支持指纹验证
        DLog(@"支持指纹识别");
        [context evaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics localizedReason:result reply:^(BOOL success, NSError *error) {
            if (success) {
                //验证成功，主线程处理UI
                dispatch_async(dispatch_get_main_queue(), ^{
                    DLog(@"验证成功 刷新主界面");
                    // 更UI
                    NSString *agentCode = [PDKeyChain keyChainLoad:TOUCHID_AGENT];
                    NSString *agentPass = [PDKeyChain keyChainLoad:TOUCHID_PASS];
                    
                    NSString *enagentCode = [PDKeyChain keyChainLoad:TOUCHID_AGENT_ENCRTION];
                    NSString *enagentPass = [PDKeyChain keyChainLoad:TOUCHID_PASS_ENCRTION];
                    
                    if (![TSSValidationUtil isNilOrEmptyString:agentCode]&&![TSSValidationUtil isNilOrEmptyString:agentPass]) {
                        
                        //agentcode 是加密过的，需要解密
                        if ([agentCode isEqualToString:enagentCode]) {
                            agentCode = [TSSSecurity deCodeDataBase64:enagentCode];
                            agentPass = [TSSSecurity deCodeDataBase64:enagentPass];
                        }
                        
                        //??????????????????判断不出是不是加密的
                        [TSSAppData getInstance].agentCode = agentCode;
                        [TSSAppData getInstance].agentPassword = agentPass;
                        [self connectionToServerForLogin];
                    }
                    else
                    {
                        //Agent Code is empty
                        UIAlertView *tAlert = [[UIAlertView alloc] initWithTitle:@"Information" message:MuliteLocalizedString(@"AgentCodeEmpty") delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
                        [tAlert show];
                    }
                    
                });
                
            }
            else
            {
                DLog(@"authenticateUser 1: %@",error.localizedDescription);
                switch (error.code) {
                    case LAErrorSystemCancel:
                    {
                        DLog(@"Authentication was cancelled by the system");
                        //切换到其他APP，系统取消验证Touch ID
                        DLog(@"切换到其他APP，系统取消验证Touch ID");
                        NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
                        [user setObject:@"off" forKey:TOUCHID_SWITCH];
                        break;
                    }
                    case LAErrorUserCancel:
                    {
                        DLog(@"Authentication was cancelled by the user");
                        //用户取消验证Touch ID
                        DLog(@"用户取消验证Touch ID");
                        NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
                        [user setObject:@"off" forKey:TOUCHID_SWITCH];
                        break;
                    }
                    case LAErrorUserFallback:
                    {
                        DLog(@"User selected to enter custom password");
                        [[NSOperationQueue mainQueue] addOperationWithBlock:^{
                            //用户选择输入密码，切换主线程处理
                            DLog(@"用户选择输入密码，切换主线程处理");
                            NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
                            [user setObject:@"off" forKey:TOUCHID_SWITCH];
                        }];
                        break;
                    }
                    default:
                    {
                        [[NSOperationQueue mainQueue] addOperationWithBlock:^{
                            //其他情况，切换主线程处理
                            DLog(@"其他情况，切换主线程处理");
                            NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
                            [user setObject:@"off" forKey:TOUCHID_SWITCH];
                        }];
                        break;
                    }
                }
            }
        }];
    }
    else
    {
        //不支持指纹识别，LOG出错误详情
        //[self goToHomePage];
        NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
        [user setObject:@"off" forKey:TOUCHID_SWITCH];
        switch (error.code) {
            case LAErrorTouchIDNotEnrolled:
            {
                DLog(@"TouchID is not enrolled");
                break;
            }
            case LAErrorPasscodeNotSet:
            {
                DLog(@"A passcode has not been set");
                break;
            }
            default:
            {
                DLog(@"TouchID not available");
                break;
            }
        }
        
        DLog(@"authenticateUser 2: %@",error.localizedDescription);
    }
}

- (int) checkTimeBomb:(NSArray *) timeBombArray
{
    int noOfSecondIn24Hours =(24*3600);
    
    int now = [[NSDate date] timeIntervalSince1970]/noOfSecondIn24Hours;
    
    // NSString * fscCode = [timeBombArray objectAtIndex:0];
    int expiredPeriod = [(NSString*)[timeBombArray objectAtIndex:1] intValue];
    int gracePeriod = [(NSString*)[timeBombArray objectAtIndex:2] intValue];
    //int destructionDate = [(NSString*)[timeBombArray objectAtIndex:3] intValue];
    int utcTimeStamp = ([(NSString*)[timeBombArray objectAtIndex:4] longLongValue]) / (noOfSecondIn24Hours * 1000);
    if(expiredPeriod == -1)
    {
        return TIME_BOMB_STATUS_UNLIMITED_USAGE;
    }
    
    int totalDays = (utcTimeStamp + expiredPeriod - now);
    if(totalDays > 0 && totalDays < gracePeriod)
    {
        NSString *msg =FORMAT(@"Your license will expire within the next %d days.\nPlease re-activate your account to extend your license for another %d days", totalDays, expiredPeriod);
        UIAlertView *tAlert = [[UIAlertView alloc] initWithTitle:@"Information" message:msg delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        [tAlert show];
    }
    
    if(totalDays < 0)
    {
        NSString *msg = @"license expired";
        UIAlertView *tAlert = [[UIAlertView alloc] initWithTitle:@"Information" message:msg delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        [tAlert show];
        
        return TIME_BOMB_STATUS_LICENSE_EXPIRED;
    }
    
    return -1;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    
    // iphone 6
    if (SCREEN_HEIGHT <= 667) {
        [self animateTextField:textField andUp:YES ];
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    
    if (SCREEN_HEIGHT <= 667) {
        [self animateTextField:textField andUp:NO ];
    }
}

-(void)animateTextField:(UITextField *) textFiled andUp:(BOOL) up
{
    const int movementDistance = textFiled.frame.origin.y - textFiled.bounds.size.height*4;//360;
    const float movementDuration = .3f;
    int movement = (up ? - movementDistance : movementDistance);
    [UIView beginAnimations:@"animate" context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:movementDuration];
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    [UIView commitAnimations];
}
@end
