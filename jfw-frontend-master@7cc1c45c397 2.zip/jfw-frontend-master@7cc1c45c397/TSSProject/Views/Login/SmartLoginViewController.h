//
//  SmartLoginViewController.h
//  TSSProject
//
//  Created by TSS on 16/3/24.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SmartLoginViewController : UIViewController

@end
