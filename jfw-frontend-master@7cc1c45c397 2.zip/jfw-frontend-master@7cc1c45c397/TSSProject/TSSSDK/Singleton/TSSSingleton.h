//
//  TSSSingleton.h
//  TSSActionDemo
//
//  Created by yijin on 12/16/15.
//  Copyright (c) 2015 yijin. All rights reserved.
//

#ifndef TSSActionDemo_TSSSingleton_h
#define TSSActionDemo_TSSSingleton_h

#define TSS_SYNTHESIZE_SINGLETON_FOR_CLASS(classname) \
\
+(instancetype)sharedInstance\
{\
    static classname *shared##classname = nil;\
    static dispatch_once_t onceToken = 0;\
    dispatch_once(&onceToken, ^{\
        shared##classname = [[classname alloc] init]; });\
    return shared##classname;\
}\

#endif
