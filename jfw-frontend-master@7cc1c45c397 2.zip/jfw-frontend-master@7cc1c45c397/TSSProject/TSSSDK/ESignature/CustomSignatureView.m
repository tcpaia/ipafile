

#import "CustomSignatureView.h"

#import "TSSValidationUtil.h"

#define kDuration 0.3
#define DATE_NORMAL @"yy-MM-dd HH:mm"

static CustomSignatureView *share = nil;

@implementation CustomSignatureView
{
    PJRSignatureView *pjrsignatureView;
    UILabel *dateLabel;
}


+(instancetype)shareInstance
{
    if (!share)
    {
        share = [[CustomSignatureView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    }
    return share;
}

-(instancetype)initWithFrame:(CGRect)frame
{
   self = [super initWithFrame:frame];
    if (self)
    {
        self = [[[NSBundle mainBundle] loadNibNamed:@"CustomSignatureView" owner:self options:nil] lastObject];
        self.frame = frame;
        self.backgroundColor = [UIColor clearColor];
        self.backView.layer.borderWidth = 1;
        self.backView.layer.borderColor = [UIColor blackColor].CGColor;
        self.signatureview.layer.borderWidth = 1;
        self.signatureview.layer.borderColor = [UIColor groupTableViewBackgroundColor].CGColor;
    }
    return self;
}

-(void)initDrawingboard
{
    [self layoutIfNeeded];
    pjrsignatureView = [[PJRSignatureView alloc]initWithFrame:CGRectMake(0, 0, self.signatureview.frame.size.width, self.signatureview.bounds.size.height)];
    pjrsignatureView.delegate = self;
    [self.signatureview addSubview:pjrsignatureView];
    
    CGRect signFrame = pjrsignatureView.frame;
    dateLabel = [[UILabel alloc]initWithFrame:CGRectMake(signFrame.size.width - 170, signFrame.size.height - 25, 150, 20)];
    dateLabel.textAlignment = NSTextAlignmentRight;
    [pjrsignatureView addSubview:dateLabel];
}

- (void)showInView:(UIView *) view
{
    [self initDrawingboard];
    CATransition *animation = [CATransition  animation];
    animation.delegate = self;
    animation.duration = kDuration;
    animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    animation.type = kCATransitionPush;
    animation.subtype = kCATransitionFromLeft;
    [self setAlpha:1.0f];
    [self.layer addAnimation:animation forKey:@"animationkey"];
    [view addSubview:self];
}


- (IBAction)signatureAction:(UIButton *)sender
{
    
    switch (sender.tag) {
        case 0:
        {
            [self cancalAction];
        }
            break;
        case 1:
        {
            [self removeAction];
        }
            break;
        case 2:
        {
            [self sureAction];
        }
            break;
    }

}

#pragma mark PJRSignatureViewDelegate
- (void)isBeginDraw:(BOOL)isDraw {
    self.isSignature = isDraw;
}

#pragma mark - Button lifecycle

- (void)cancalAction
{
    [pjrsignatureView clearSignature];
    [dateLabel removeFromSuperview];
    [self dissmiss];
}

-(void)removeAction
{
    [pjrsignatureView clearSignature];
    dateLabel.text = @"" ;
}

- (void)sureAction
{
    [self dissmiss];
    
    if (self.isSignature == YES) {
        NSDate *date = [NSDate date];
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:DATE_NORMAL];
        dateLabel.text = [dateFormatter stringFromDate:date];
        
        if (![TSSValidationUtil isNilOrNull:[pjrsignatureView getSignatureImage]])
        {
            self.block([pjrsignatureView getSignatureImage]);
        }
        
        pjrsignatureView = nil;
    }
}

-(void)dissmiss
{
    CATransition *animation = [CATransition  animation];
    animation.delegate = self;
    animation.duration = kDuration;
    animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    animation.type = kCATransitionPush;
    animation.subtype = kCATransitionFromRight;
    [self setAlpha:0.0f];
    [self.layer addAnimation:animation forKey:@"animationkey"];
    [self performSelector:@selector(removeFromSuperview) withObject:nil afterDelay:kDuration];
}

@end
