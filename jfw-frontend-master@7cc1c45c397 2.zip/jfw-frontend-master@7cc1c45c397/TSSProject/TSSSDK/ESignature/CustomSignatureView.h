

#import <UIKit/UIKit.h>
#import "PJRSignatureView.h"

typedef void (^MYBlock)(UIImage *image);

@interface CustomSignatureView : UIView<CAAnimationDelegate,PJRSignatureViewDelegate>

+(instancetype) shareInstance;

@property (weak, nonatomic) IBOutlet UIView *backView;

@property (weak, nonatomic) IBOutlet UIView *signatureview;
@property (nonatomic,assign) BOOL isSignature;
@property (nonatomic,copy) MYBlock block;
//显示的view
- (void)showInView:(UIView *)view;

-(void)removeAction;

@end
