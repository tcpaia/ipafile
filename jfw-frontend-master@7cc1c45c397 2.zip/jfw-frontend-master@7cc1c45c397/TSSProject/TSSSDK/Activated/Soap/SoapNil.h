//
//  SoapNil.h
//  Giant
//
//  Created by Jason Kichline on 7/2/09.
//  Copyright 2009 andCulture. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface SoapNil : NSObject {

}

@end
