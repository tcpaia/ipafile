/*
 *  Tfs.h
 *  TfsCore
 *
 *  Created by CKC on 7/23/10.
 *  All rights reserved. © Treasure Frontier System Sdn. Bhd.
 *
 */
#define UIColorMakeRGBA(nRed, nGreen, nBlue, nAlpha) [UIColor colorWithRed:(nRed)/255.0f green:(nGreen)/255.0f blue:(nBlue)/255.0f alpha:nAlpha]
#define AbstractMethod [NSException raise:NSInternalInconsistencyException format:@"You must override %@ in a subclass %@", NSStringFromSelector(_cmd), [self class]]

#define Method_TravelBack - (void) travelBack{[self.navigationController popViewControllerAnimated:YES];}

#define Add_SwipeGestureRecognizer \
UISwipeGestureRecognizer *recognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(travelBack)];\
[self.view addGestureRecognizer:recognizer];\
[recognizer release];

#define FORMAT(format, ...) [NSString stringWithFormat:(format), ##__VA_ARGS__]
#define NSNUMBER_INT(value) [NSNumber numberWithInt:(value)]

#import "SynthesizeSingleton.h"
#import "TFHardwareUtil.h"
#import "TFSLog.h"
#import "TFConstant.h"
