//
//  TFHardwareUtil.m
//  iPoS_IOS
//
//  Created by Kok Chin Chan on 2/23/12.
//  All rights reserved. © Treasure Frontier System Sdn. Bhd.
//

#import "TFHardwareUtil.h"
#include <sys/types.h>
#include <sys/sysctl.h>

static NSNumber *canMakePhoneCalls = nil;
static BOOL IsSimulator = NO;
static BOOL isiPhone = NO;
static BOOL isiPad = NO;

@implementation TFHardwareUtil

+ (void) initialize
{
	UIDevice* thisDevice = [UIDevice currentDevice];
	if(thisDevice.userInterfaceIdiom == UIUserInterfaceIdiomPad)
	{
		isiPad = YES;
	}
	else
	{
		isiPhone = YES;
	}
	
	
#if TARGET_IPHONE_SIMULATOR
	IsSimulator = YES;
	canMakePhoneCalls = [[NSNumber alloc] initWithBool:YES];
	
#endif
}

+ (BOOL) isiPhone
{
	return isiPhone;
}

+ (BOOL) isiPad
{
	return isiPad;
}

+ (BOOL) isSimulator
{
	return IsSimulator;
}

+ (BOOL) isRotationLanscape
{
	return UIInterfaceOrientationIsLandscape([UIDevice currentDevice].orientation);
}

+ (CGRect) getCurrentDeviceScreenSize
{
	//this give the full screen size
	CGRect screenRect =[[UIScreen mainScreen] bounds];	
	//this give the full screen size minus the status bar 20 pixels
	//CGRect screenRect =[[UIScreen mainScreen] applicationFrame];
	if (UIInterfaceOrientationIsLandscape([UIDevice currentDevice].orientation))
	{
		CGFloat w = screenRect.size.width;
		screenRect.size.width = screenRect.size.height;
		screenRect.size.height = w;
	}
	return screenRect;
}

//+ (NSString *) getSerialNumber
//{
//	return [[UIDevice currentDevice] uniqueIdentifier];
//}

+ (BOOL) deviceCanMakePhoneCalls
{
	if (canMakePhoneCalls==nil)
	{
		if ([UIApplication instancesRespondToSelector:@selector(canOpenURL:)]) {
			// OS 3.0+, so use canOpenURL
			UIApplication *app = [UIApplication sharedApplication];
			canMakePhoneCalls = [NSNumber numberWithBool:([app canOpenURL:[NSURL URLWithString:@"tel:+44-1234-567890"]])];
		}
		else 
		{
			// OS 2.x, so check for iPhone
			UIDevice *device = [UIDevice currentDevice];
			canMakePhoneCalls = [NSNumber numberWithBool:([device.model isEqualToString:@"iPhone"])];
		}
	}
    return [canMakePhoneCalls boolValue];
}
/*****For citi M2 by aiait********/
/*
+ (BOOL) isJailbroken
{
	BOOL jailbroken = NO;
	NSString *cydiaPath = @"/Applications/Cydia.app";
    //	NSString *aptPath = @"/private/var/lib/apt/";
	
	if ([[NSFileManager defaultManager] fileExistsAtPath:cydiaPath]) {
		//jailbroken = YES;
        return YES;
	}
	
    //	if ([[NSFileManager defaultManager] fileExistsAtPath:aptPath]) {
    //		jailbroken = YES;
    //	}
    
    if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"cydia://package/com.example.package"]]) {
        return YES;
    }
    
    FILE *f = fopen("/bin/bash", "r");
    if (f != NULL)
    {
        //Device is jailbroken
        jailbroken = YES;
    }
    fclose(f);
    
    return jailbroken;
}*/

+ (BOOL) isJailbroken
{
    if ([[NSFileManager defaultManager]
         fileExistsAtPath:@"/Applications/Cydia.app"]){
        return YES;
    }else if([[NSFileManager defaultManager]
              fileExistsAtPath:@"/Library/MobileSubstrate/MobileSubstrate.dylib"]){
              return YES;
    }else if([[NSFileManager defaultManager]
                        fileExistsAtPath:@"/bin/bash"]){
        return YES;
    }else if([[NSFileManager defaultManager]
              fileExistsAtPath:@"/usr/sbin/sshd"]){
        return YES;
    }else if([[NSFileManager defaultManager]
              fileExistsAtPath:@"/etc/apt"]){
        return YES;
    }
    
    NSError *error;
    NSString *stringToBeWritten = @"This is a test.";
    NSData *stringToBeWrittenData = [stringToBeWritten dataUsingEncoding: NSUTF8StringEncoding];
    NSFileHandle *fileHandle = [NSFileHandle fileHandleForWritingAtPath:@"/private/jailbreak.txt"];
    [fileHandle writeData: stringToBeWrittenData];
    [fileHandle closeFile];
    if(error==nil){
        //Device is jailbroken
        return YES;
    } else {
        [[NSFileManager defaultManager]
         removeItemAtPath:@"/private/jailbreak.txt" error:nil];
    }
    
    if([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"cydia://package/com.example.package"]]){
        return YES;
    }
    
    return NO;
}
/************end***********/

/* New Method to detect JailBroken Device - 30 Dec 2015 */
+ (BOOL) isEditedVersion{
    
    BOOL isDirectory;
    if ([[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/%@%@%@%@%@%@%@", @"App", @"lic",@"ati", @"ons/", @"Cyd", @"ia.a", @"pp"]]
        
        || [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/%@%@%@%@%@%@%@", @"App", @"lic",@"ati", @"ons/", @"bla", @"ckra1n.a", @"pp"]]
        
        || [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/%@%@%@%@%@%@%@", @"App", @"lic",@"ati", @"ons/", @"Fake", @"Carrier.a", @"pp"]]
        
        || [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/%@%@%@%@%@%@%@", @"App", @"lic",@"ati", @"ons/", @"Ic", @"y.a", @"pp"]]
        
        || [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/%@%@%@%@%@%@%@", @"App", @"lic",@"ati", @"ons/", @"Inte", @"lliScreen.a", @"pp"]]
        
        || [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/%@%@%@%@%@%@%@", @"App", @"lic",@"ati", @"ons/", @"MxT", @"ube.a", @"pp"]]
        
        || [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/%@%@%@%@%@%@%@", @"App", @"lic",@"ati", @"ons/", @"Roc", @"kApp.a", @"pp"]]
        
        || [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/%@%@%@%@%@%@%@", @"App", @"lic",@"ati", @"ons/", @"SBSet", @"ttings.a", @"pp"]]
        
        || [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/%@%@%@%@%@%@%@", @"App", @"lic",@"ati", @"ons/", @"Wint", @"erBoard.a", @"pp"]]
        
        || [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/%@%@%@%@%@%@", @"pr", @"iva",@"te/v", @"ar/l", @"ib/a", @"pt/"] isDirectory:&isDirectory]
        
        || [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/%@%@%@%@%@%@", @"pr", @"iva",@"te/v", @"ar/l", @"ib/c", @"ydia/"] isDirectory:&isDirectory]
        
        || [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/%@%@%@%@%@%@", @"pr", @"iva",@"te/v", @"ar/mobile", @"Library/SBSettings", @"Themes/"] isDirectory:&isDirectory]
        
        || [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/%@%@%@%@%@%@", @"pr", @"iva",@"te/v", @"ar/t", @"mp/cyd", @"ia.log"]]
        
        || [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/%@%@%@%@%@", @"pr", @"iva",@"te/v", @"ar/s", @"tash/"] isDirectory:&isDirectory]
        
        || [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/%@%@%@%@%@%@", @"us", @"r/l",@"ibe", @"xe", @"c/cy", @"dia/"] isDirectory:&isDirectory]
        
        || [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/%@%@%@%@%@", @"us", @"r/b",@"in", @"s", @"shd"]]
        
        || [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/%@%@%@%@%@", @"us", @"r/sb",@"in", @"s", @"shd"]]
        
        || [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/%@%@%@%@%@%@", @"us", @"r/l",@"ibe", @"xe", @"c/cy", @"dia/"] isDirectory:&isDirectory]
        
        || [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/%@%@%@%@%@%@", @"us", @"r/l",@"ibe", @"xe", @"c/sftp-", @"server"]]
        
        || [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/%@%@%@%@%@%@",@"/Syste",@"tem/Lib",@"rary/Lau",@"nchDae",@"mons/com.ike",@"y.bbot.plist"]]
        
        || [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/%@%@%@%@%@%@%@%@",@"/Sy",@"stem/Lib",@"rary/Laun",@"chDae",@"mons/com.saur",@"ik.Cy",@"@dia.Star",@"tup.plist"]]
        
        || [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/%@%@%@%@%@", @"/Libr",@"ary/Mo",@"bileSubstra",@"te/MobileSubs",@"trate.dylib"]]
        
        || [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/%@%@%@%@%@", @"/va",@"r/c",@"ach",@"e/a",@"pt/"] isDirectory:&isDirectory]
        
        || [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/%@%@%@%@", @"/va",@"r/l",@"ib",@"/apt/"] isDirectory:&isDirectory]
        
        || [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/%@%@%@%@", @"/va",@"r/l",@"ib/c",@"ydia/"] isDirectory:&isDirectory]
        
        || [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/%@%@%@%@", @"/va",@"r/l",@"og/s",@"yslog"]]
        
        || [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/%@%@%@", @"/bi",@"n/b",@"ash"]]
        
        || [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/%@%@%@", @"/b",@"in/",@"sh"]]
        
        || [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/%@%@%@", @"/et",@"c/a",@"pt/"]isDirectory:&isDirectory]
        
        || [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/%@%@%@", @"/etc/s",@"sh/s",@"shd_config"]]
        
        || [[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/%@%@%@%@%@", @"/us",@"r/li",@"bexe",@"c/ssh-k",@"eysign"]]||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/Applications/Cydia.app"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/Library/MobileSubstrate/MobileSubstrate.dylib"] ||
        
        [[NSFileManager defaultManager] fileExistsAtPath:@"/usr/sbin/sshd"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/usr/libexec/ssh-keysign"] ||
        
        [[NSFileManager defaultManager] fileExistsAtPath:@"/private/var/lib/apt"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/var/cache/apt"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/var/lib/apt"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/var/lib/cydia"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/var/log/syslog"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/var/tmp/cydia.log"] ||
        
        [[NSFileManager defaultManager] fileExistsAtPath:@"/bin/bash"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/bin/sh"] ||
        
        [[NSFileManager defaultManager] fileExistsAtPath:@"/etc/apt"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/etc/ssh/sshd_config"] ||
        [[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"cydia://package/com.example.package"]])  {
        return YES;
    }
    
    FILE *f = NULL ;
    if ((f = fopen("/bin/bash", "r")) ||
        (f = fopen("/Applications/Cydia.app", "r")) ||
        (f = fopen("/Library/MobileSubstrate/MobileSubstrate.dylib", "r")) ||
        (f = fopen("/usr/sbin/sshd", "r")) ||
        (f = fopen("/etc/apt", "r")))  {
        fclose(f);
        return YES;
    }
    fclose(f);
    
    //Try to write file in private
    NSError *error;
    NSString *stringToBeWritten = @"This is a test.";
    NSData *stringToBeWrittenData = [stringToBeWritten dataUsingEncoding: NSUTF8StringEncoding];
    NSFileHandle *fileHandle = [NSFileHandle fileHandleForWritingAtPath:@"/private/jailbreak.txt"];
    [fileHandle writeData: stringToBeWrittenData];
    [fileHandle closeFile];
    [[NSFileManager defaultManager] removeItemAtPath:@"/private/jailbreak.txt" error:nil];
    if(error == nil)
    {
        return YES;
    }
    
    //SandBox Integrity Check
//    int pid = fork();
//    if(!pid){
//        exit(0);
//    }
//    if(pid>=0){
//        return YES;
//    }
    
    return NO;
}
/************END***********/

+ (NSString *) platformCode
{
    size_t size;
    sysctlbyname("hw.machine", NULL, &size, NULL, 0);
    char *machine = malloc(size);
    if (machine == NULL) {
        return @"";
    }
    sysctlbyname("hw.machine", machine, &size, NULL, 0);
    NSString *platform = [NSString stringWithUTF8String:machine];
    free(machine);
    return platform;
}

// Public method to use
+ (PlatformType) platform 
{
    NSString *platform = [TFHardwareUtil platformCode];
    if ([platform isEqualToString:@"iPhone1,1"])    return kiPhone1G;
    if ([platform isEqualToString:@"iPhone1,2"])    return kiPhone3G;
    if ([platform isEqualToString:@"iPhone2,1"])    return kiPhone3GS;
    if ([platform isEqualToString:@"iPhone3,1"])    return kiPhone4;
    if ([platform isEqualToString:@"iPhone3,2"])    return kiPhone4Verizon;
    if ([platform isEqualToString:@"iPhone4,1"])    return kiPhone4S;
    if ([platform isEqualToString:@"iPod1,1"])      return kiPodTouch1G;
    if ([platform isEqualToString:@"iPod2,1"])      return kiPodTouch2G;
    if ([platform isEqualToString:@"iPod3,1"])      return kiPodTouch3G;
    if ([platform isEqualToString:@"iPod4,1"])      return kiPodTouch4G;
    if ([platform isEqualToString:@"iPad1,1"])      return kiPad;
    if ([platform isEqualToString:@"iPad2,1"])      return kiPad2Wifi;
    if ([platform isEqualToString:@"iPad2,2"])      return kiPad2GSM;
    if ([platform isEqualToString:@"iPad2,3"])      return kiPad2CMDA;
	if ([platform isEqualToString:@"iPad3,1"])      return kiPad3Wifi;
    if ([platform isEqualToString:@"iPad3,2"])      return kiPad3GSM;
    if ([platform isEqualToString:@"iPad3,3"])      return kiPad3CMDA;
    if ([platform isEqualToString:@"i386"])         return kSimulator;
	if ([platform isEqualToString:@"x86_64"])       return kSimulator;
	
    return kUnknownPlatform;
}


+ (NSString *) platformString
{
    PlatformType platform = [TFHardwareUtil platform];
	
	switch (platform)
	{
		case kiPhone1G: return @"iPhone 1G";
		case kiPhone3G: return @"iPhone 3G";
		case kiPhone3GS: return @"iPhone 3GS";
		case kiPhone4: return @"iPhone 4";
		case kiPhone4Verizon: return @"Verizon iPhone 4";
		case kiPhone4S: return @"iPhone 4S";
		case kiPodTouch1G: return @"iPod Touch 1G";
		case kiPodTouch2G: return @"iPod Touch 2G";
		case kiPodTouch3G: return @"iPod Touch 3G";
		case kiPodTouch4G: return @"iPod Touch 4G";
		case kiPad: return @"iPad";
		case kiPad2Wifi: return @"iPad 2 (WiFi)";
		case kiPad2GSM: return @"iPad 2 (GSM)";
		case kiPad2CMDA: return @"iPad 2 (CDMA)";
		case kSimulator: return @"Simulator";
		case kiPad3Wifi: return @"iPad 3 (WiFi)";
		case kiPad3GSM: return @"iPad 3 (GSM)";
		case kiPad3CMDA: return @"iPad 3 (CDMA)";
		default: return @"unknownPlatform";
	}

}

@end
