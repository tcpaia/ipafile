//
//  TFHardwareUtil.h
//  iPoS_IOS
//
//  Created by Kok Chin Chan on 2/23/12.
//  All rights reserved. © Treasure Frontier System Sdn. Bhd.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
typedef enum {
    kUnknownPlatform = 0,
    kiPhone1G,
    kiPhone3G,
    kiPhone3GS,
    kiPhone4,
    kiPhone4Verizon,
    kiPhone4S,
    kiPodTouch1G,
    kiPodTouch2G,
    kiPodTouch3G,
    kiPodTouch4G,
    kiPad,
    kiPad2Wifi,
    kiPad2GSM,
    kiPad2CMDA,
	kiPad3Wifi,
    kiPad3GSM,
    kiPad3CMDA,
    kSimulator
} PlatformType;

@interface TFHardwareUtil : NSObject

+ (NSString *) getSerialNumber;

+ (BOOL) isiPhone;
+ (BOOL) isiPad;
+ (BOOL) isSimulator;

+ (BOOL) isRotationLanscape;
+ (CGRect) getCurrentDeviceScreenSize;

+ (BOOL) deviceCanMakePhoneCalls;
/* Method Name Change to check JailBreak device */
//+ (BOOL)isJailbroken;
+ (BOOL)isEditedVersion;
/* END - 30 Dec 2015 */
+ (NSString *) platformString;

@end
