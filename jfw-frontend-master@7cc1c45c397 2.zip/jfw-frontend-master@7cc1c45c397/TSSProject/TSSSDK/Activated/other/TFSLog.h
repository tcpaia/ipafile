//
//  TFSLog.h
//  TFSLog
//
//  Created by kelvin on 5/7/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

/**
 * Log utility
 */

#import <Foundation/Foundation.h>

enum
{
    TFSLOGDEBUG = 1,
    TFSLOGINFO = 2,
    TFSLOGWARNING = 3,
    TFSLOGERROR = 4
};
typedef NSUInteger TFSLogType;

@interface TFSLog : NSObject 
{
    NSString        *prefix;
    NSString        *filepath;
    NSString        *filename;
	NSDateFormatter *formatter;
    int              maxFiles;
    int              maxFileSize;
}

/**
 * the prefix for log message
 */
@property (nonatomic, retain) NSString      *prefix;

/**
 * the file path 
 */
@property (nonatomic, retain) NSString      *filepath;
@property (nonatomic, retain) NSString      *filename;
@property (nonatomic, retain) NSDateFormatter *formatter;
@property (nonatomic) int                    maxFiles;
@property (nonatomic) int                    maxFileSize;

//- (id)init __attribute__((deprecated));
- (id)initWithPrefix:(NSString *)vPrefix maxFiles:(int)vMaxFiles maxFileSize:(int)vMaxFileSize;
- (id)initWithPrefix:(NSString *)vPrefix maxFiles:(int)vMaxFiles;
- (id)initWithPrefix:(NSString *)vPrefix maxFileSize:(int)vMaxFileSize;
- (id)initWithPrefix:(NSString *)vPrefix;

- (void) setPrefix:(NSString *)vPrefix maxFiles:(int)vMaxFiles maxFileSize:(int)vMaxFileSize;

+ (TFSLog *) getInstance;

#pragma mark - Get Log Path
- (NSString *)getDocumentLogPath;
- (NSString *)getResourceLogPath;

#pragma mark - IO method
- (void)createFile;
- (void)deleteFile:(NSString *)file;
- (void)writeFile:(NSString *)data;
- (NSString *)readFile;

#pragma mark - Log method
- (void)logString:(NSString *)log type:(TFSLogType)type;
- (void)logError:(NSError *)error;
- (void)logException:(NSException *)exception;

#pragma mark - Initialize Checking
- (void)checkLogPath;
- (void)checkMaxFiles;
- (void)checkMaxFileSize;

#pragma mark - Get method
- (NSString *)getLatestFile;
- (NSMutableArray *)getLatestFiles:(int)n;

@end
