//
//  TFConstant.h
//  TfsCore
//
//  Created by CKC on 4/6/11.
//  All rights reserved. © Treasure Frontier System Sdn. Bhd.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


#define UNLIMITED_PERIOD 0
#define DATE_INVALID -1001
#define DATE_AFTER_NOW -1002
#define DATE_BEYONG_LIMIT -1004

@interface TFConstant : NSObject
{
	NSString *PROGRAM_NAME;
	
	/**
	 * If positive value means number of months,<br>
	 * else negative is number of days.
	 */
	int EXPIRED_PERIOD;
	
	/**
	 * How many day of buffer before activation day.<br>
	 * Must be negative value.
	 */
	int EXPIRED_BUFFER;
	
	int buildID;
	
	/**
	 * Specific this is a demo version, the user name will set to TFS DEMO.
	 */
	BOOL DEMO_VERSION;
	
	NSString *programNameVersion;

}

@property (nonatomic, retain) NSString *PROGRAM_NAME;
@property (nonatomic) int EXPIRED_PERIOD;
@property (nonatomic) int EXPIRED_BUFFER;
@property (nonatomic) int buildID;
@property (nonatomic) BOOL DEMO_VERSION;
@property (nonatomic, retain) NSString *programNameVersion;

+ (TFConstant *) getInstance;

- (void) setTFConstantWithProgramName:(NSString *)programName expiredPeriod:(int)expiredPeriod expiredBuffer:(int)expiredBuffer buildId:(int)buildId programNameVersion:(NSString *)programNameVersion_;

@end
