//
//  TFConstant.m
//  TfsCore
//
//  Created by CKC on 4/6/11.
//  All rights reserved. © Treasure Frontier System Sdn. Bhd.
//

#import "TFConstant.h"
#import "SynthesizeSingleton.h"
#import "TFHardwareUtil.h"
#import "TFSCore.h"

@implementation TFConstant
@synthesize PROGRAM_NAME;
@synthesize EXPIRED_PERIOD;
@synthesize EXPIRED_BUFFER;
@synthesize buildID;
@synthesize DEMO_VERSION;
@synthesize programNameVersion;


SYNTHESIZE_SINGLETON_FOR_CLASS(TFConstant);


- (void) setTFConstantWithProgramName:(NSString *)programName expiredPeriod:(int)expiredPeriod expiredBuffer:(int)expiredBuffer buildId:(int)buildId programNameVersion:(NSString *)programNameVersion_
{
	self.PROGRAM_NAME = programName;
	self.programNameVersion = programNameVersion_;
	
	if ([TFHardwareUtil isSimulator])
	{
		if ([TFHardwareUtil isiPad])
		{
			self.PROGRAM_NAME = FORMAT(@"%@ (iPad Simulator)", programName);
		}
		else if ([TFHardwareUtil isiPhone])
		{
			self.PROGRAM_NAME = FORMAT(@"%@ (iPhone Simulator)", programName);
		}
	}
	else
	{
		if ([TFHardwareUtil isiPad])
		{
			self.PROGRAM_NAME = FORMAT(@"%@ (iPad)", programName);
		}
		else if ([TFHardwareUtil isiPhone])
		{
			self.PROGRAM_NAME = FORMAT(@"%@ (iPhone)", programName);
		}
	}
	
	self.EXPIRED_BUFFER = expiredBuffer > 0 ? -expiredBuffer : expiredBuffer;
	self.EXPIRED_PERIOD = expiredPeriod;
	self.buildID = buildId;
}


- (void) dealloc
{
	[PROGRAM_NAME release];
	[programNameVersion release];
	
	[super dealloc];
}

@end
