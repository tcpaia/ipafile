//
//  GFCalendarCell.m
//
//  Created by Mercy on 2016/11/9.
//  Copyright © 2016年 Mercy. All rights reserved.
//

#import "GFCalendarCell.h"
#import "SystemTss.h"

static NSString *currentValue;

@implementation GFCalendarCell

- (instancetype)initWithFrame:(CGRect)frame {
    
    if (self = [super initWithFrame:frame]) {
        
        [self addSubview:self.todayCircle];
        [self addSubview:self.todayLabel];
        [self addSubview:self.dayCircle];//小圆点
    }
    
    return self;
}

- (UIView *)todayCircle {
    if (_todayCircle == nil) {
        _todayCircle = [[UIView alloc] initWithFrame:CGRectMake(0.0, 0.0, 0.70 * self.bounds.size.height, 0.70 * self.bounds.size.height)];
        _todayCircle.center = CGPointMake(0.5 * self.bounds.size.width, 0.5 * self.bounds.size.height);
        _todayCircle.layer.cornerRadius = 0.5 * _todayCircle.frame.size.width;
    }
    return _todayCircle;
}

- (UILabel *)todayLabel {
    if (_todayLabel == nil) {
        _todayLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0, 0.0, 0.70 * self.bounds.size.height, 0.70 * self.bounds.size.height)];
        _todayLabel.center = CGPointMake(0.5 * self.bounds.size.width, 0.5 * self.bounds.size.height);
        _todayLabel.textAlignment = NSTextAlignmentCenter;
        _todayLabel.font = [UIFont fontWithName:@"Arial" size:16.0];
        _todayLabel.backgroundColor = [UIColor clearColor];
    }
    return _todayLabel;
}

// ! 小圆点尺寸部分
- (UIView *)dayCircle {
    if (_dayCircle == nil) {
        _dayCircle = [[UIView alloc] initWithFrame:CGRectMake(0.0, 0.0, 0.14 * self.bounds.size.height, 0.14 * self.bounds.size.height)];
        _dayCircle.center = CGPointMake(0.5 * self.bounds.size.width, 0.95 * self.bounds.size.height);
        _dayCircle.layer.cornerRadius = 0.5 * _dayCircle.frame.size.width;
    }
    return _dayCircle;
}

- (void) setCurrentDate:(NSString *)dateValue {
    currentValue = [self coverFomart:dateValue];
}

- (NSString *)coverFomart:(NSString *)fomart {
    
   return [NSString stringWithFormat:@"%ld%ld%@",(long)self.month.year,(long)self.month.month,fomart];
}

- (void)setSelected:(BOOL)selected {
    if (self.todayCircle.backgroundColor ) {
        if (selected) {
            self.todayCircle.backgroundColor = UI_COLOR_JFW_CALENDAR_TITLE;
            self.todayLabel.textColor = [UIColor whiteColor];
        } else {
            NSString *string = [self coverFomart:self.todayLabel.text];
            if ([string isEqualToString:currentValue]) {
                self.todayCircle.backgroundColor = UI_COLOR_SMART_RED;
                self.todayLabel.textColor = [UIColor whiteColor];
            }else{
                self.todayCircle.backgroundColor = [UIColor clearColor];
                self.todayLabel.textColor = UI_COLOR_JFW_CALENDAR_TITLE;
            }
        }
    }
}

@end
