//
//  GFCalendarView.m
//
//  Created by Mercy on 2016/11/9.
//  Copyright © 2016年 Mercy. All rights reserved.
//

#import "GFCalendarView.h"
#import "NSDate+GFCalendar.h"
#import "SystemTss.h"

@interface GFCalendarView() <GFCalendarScrollViewCountDelegate>

@property (nonatomic, strong) UIButton *calendarHeaderButton;
@property (nonatomic, strong) UIView *weekHeaderView;
@end


@implementation GFCalendarView

#pragma mark - Initialization
- (instancetype)initWithFrameOrigin:(CGPoint)origin width:(CGFloat)width {
    
    // 根据宽度计算 calender 主体部分的高度
    CGFloat weekLineHight = 0.85 * (width / 7.0);
    CGFloat monthHeight = 6 * weekLineHight;
    
    // 星期头部栏高度
    CGFloat weekHeaderHeight = 0.6 * weekLineHight;
    
    // calendar 头部栏高度
    CGFloat calendarHeaderHeight = 0.8 * weekLineHight;
    
    // 最后得到整个 calender 控件的高度
    _calendarHeight = calendarHeaderHeight + weekHeaderHeight + monthHeight;
    
    if (self = [super initWithFrame:CGRectMake(origin.x, origin.y, width, _calendarHeight)])
    {
        _calendarHeaderButton = [self setupCalendarHeaderButtonWithFrame:CGRectMake(0.0, 0.0, width, calendarHeaderHeight)];
        _weekHeaderView = [self setupWeekHeadViewWithFrame:CGRectMake(0.0, calendarHeaderHeight, width, weekHeaderHeight)];
        _calendarScrollView = [self setupCalendarScrollViewWithFrame:CGRectMake(0.0, calendarHeaderHeight + weekHeaderHeight, width, monthHeight)];
        
        [self addSubview:_calendarHeaderButton];
        [self addSubview:_weekHeaderView];
        [self addSubview:_calendarScrollView];
        
        // 注册 Notification 监听
        [self addNotificationObserver];
    }
    return self;
}

- (void)dealloc {
    // 移除监听
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (UIButton *)setupCalendarHeaderButtonWithFrame:(CGRect)frame {
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = frame;
    button.backgroundColor = [UIColor whiteColor];
    [button setTitleColor:UI_COLOR_JFW_CALENDAR_TITLE forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont fontWithName:AIASans_Condensed_Header size:18];
    [button addTarget:self action:@selector(refreshToCurrentMonthAction:) forControlEvents:UIControlEventTouchUpInside];
    
    return button;
}

- (UIView *)setupWeekHeadViewWithFrame:(CGRect)frame {
    
    CGFloat height = frame.size.height;
    CGFloat width = frame.size.width / 7.0;
    
    UIView *view = [[UIView alloc] initWithFrame:frame];
    UIView *topLine = [[UIView alloc]initWithFrame:CGRectMake(0, 0, frame.size.width, 2)];
    topLine.backgroundColor = UIColorMakeRGBA(219, 218, 212, 1);
    [view addSubview:topLine];
    UIView *bottomLine = [[UIView alloc]initWithFrame:CGRectMake(0, frame.size.height, frame.size.width, 1)];
    bottomLine.backgroundColor = [UIColor groupTableViewBackgroundColor];
    [view addSubview:bottomLine];

    NSArray *weekArray = @[@"S", @"M", @"T", @"W", @"T", @"F", @"S"];
    UILabel *label = nil;
    for (int i = 0; i < 7; ++i) {

        label = [[UILabel alloc] initWithFrame:CGRectMake(i * width, 0.0, width, height)];
        label.backgroundColor = [UIColor clearColor];
        label.text = weekArray[i];
        label.textColor = UI_COLOR_JFW_NAME_TITLE;
        label.font = [UIFont fontWithName:AIASans_Condensed_Header size:14];
        label.textAlignment = NSTextAlignmentCenter;
        [view addSubview:label];
    }
    
    return view;
}

- (GFCalendarScrollView *)setupCalendarScrollViewWithFrame:(CGRect)frame {
    GFCalendarScrollView *scrollView = [[GFCalendarScrollView alloc] initWithFrame:frame];
    scrollView.countDelegate = self;
    return scrollView;
}

- (void)setDidSelectDayHandler:(DidSelectDayHandler)didSelectDayHandler {
    _didSelectDayHandler = didSelectDayHandler;
    if (_calendarScrollView != nil) {
        _calendarScrollView.didSelectDayHandler = _didSelectDayHandler; // 传递 block
    }
}

- (void)addNotificationObserver {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeCalendarHeaderAction:) name:@"ChangeCalendarHeaderNotification" object:nil];
}


#pragma mark - Actions

- (void)refreshToCurrentMonthAction:(UIButton *)sender {
    
    [_calendarScrollView refreshToCurrentMonth];

    NSArray *e_Months = @[@"Jan",@"Feb",@"Mar",@"Apr",@"May",@"June",@"July",@"Aug",@"Sep",@"Oct",@"Nov",@"Dec"];
    NSArray *Months = @[@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"11",@"12"];
    NSString *y = [sender.titleLabel.text substringFromIndex:4];
    NSString *m = [[sender.titleLabel.text substringToIndex:4] stringByReplacingOccurrencesOfString:@" " withString:@""];
    [e_Months enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([m isEqualToString:[e_Months objectAtIndex:idx]]) {
            [self.delegate refreshToCurrentMonthActionDelegate:[NSString stringWithFormat:@"%@ %@",[Months objectAtIndex:idx],y]];
        }
    }];

}

- (void)changeCalendarHeaderAction:(NSNotification *)sender {
    
    NSDictionary *dic = sender.userInfo;
    
    NSNumber *year = dic[@"year"];
    NSNumber *month = dic[@"month"];
    BOOL changeScrollView = [dic[@"changeScrollView"] boolValue];
    
    
    NSArray *e_Months = @[@"Jan",@"Feb",@"Mar",@"Apr",@"May",@"June",@"July",@"Aug",@"Sep",@"Oct",@"Nov",@"Dec"];
    NSString *title = [NSString stringWithFormat:@"%@ %@", [e_Months objectAtIndex:[month intValue] - 1],year];
    
    [_calendarHeaderButton setTitle:title forState:UIControlStateNormal];
    if (changeScrollView) {
       [self.delegate refreshToCurrentMonthActionDelegate:[NSString stringWithFormat:@"%d %@",[month intValue],year]];
    }
}
- (NSDictionary *) getDictionaryForDayAndEventCountForMonth: (NSString *) month
{
    return [self.delegate getDictionaryForDayAndEventCountForMonth: month];
}

- (void) refreshToCurrentMonth
{
    [_calendarScrollView refreshToCurrentMonth];
}
@end
