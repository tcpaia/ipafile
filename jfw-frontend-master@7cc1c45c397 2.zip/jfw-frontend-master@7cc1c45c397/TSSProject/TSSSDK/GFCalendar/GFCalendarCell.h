//
//  GFCalendarCell.h
//
//  Created by Mercy on 2016/11/9.
//  Copyright © 2016年 Mercy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GFCalendarMonth.h"

@interface GFCalendarCell : UICollectionViewCell
@property (nonatomic, strong) GFCalendarMonth *month;
@property (nonatomic, strong) UIView *todayCircle; //!< 标示'今天'
@property (nonatomic, strong) UILabel *todayLabel; //!< 标示日期（几号）
@property (nonatomic, strong) UIView *dayCircle; // !< 小圆点，标示日期是否含有FollowUpAndNote

- (void) setCurrentDate:(NSString *)dateValue;

@end
