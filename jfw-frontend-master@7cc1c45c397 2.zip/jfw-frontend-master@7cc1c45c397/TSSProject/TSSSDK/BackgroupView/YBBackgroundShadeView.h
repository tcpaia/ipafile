//
//  YBBackgroundShadeView.h
//  RuiBaoMall
//
//  Created by 李信达 on 2017/2/7.
//  Copyright © 2017年 李信达. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YBBackgroundShadeView : UIVisualEffectView


+(YBBackgroundShadeView *) defaultShadeView;

-(void) appearShade;

-(void) disAppearShade;


@end
