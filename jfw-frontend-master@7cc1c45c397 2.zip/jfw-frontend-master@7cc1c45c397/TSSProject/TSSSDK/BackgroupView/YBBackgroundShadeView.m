//
//  YBBackgroundShadeView.m
//  RuiBaoMall
//
//  Created by 李信达 on 2017/2/7.
//  Copyright © 2017年 李信达. All rights reserved.
//

#import "YBBackgroundShadeView.h"
#import "SystemTss.h"

@implementation YBBackgroundShadeView

+(YBBackgroundShadeView *) defaultShadeView{
    static YBBackgroundShadeView * s_ShadeView = nil;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        UIBlurEffect *effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleLight];
        s_ShadeView = [[YBBackgroundShadeView alloc]initWithEffect:effect];
        s_ShadeView.frame = CGRectMake(0, 0, SCREEN_WEIGHT, SCREEN_HEIGHT);
    });
    
    return s_ShadeView;
}

-(void) appearShade{
    UIWindow * keyW = [UIApplication sharedApplication].keyWindow;
    [keyW addSubview:self];
}

-(void) disAppearShade{
    [self removeFromSuperview];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
