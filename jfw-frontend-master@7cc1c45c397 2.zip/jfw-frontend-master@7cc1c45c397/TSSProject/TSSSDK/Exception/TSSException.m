//
//  TSSException.m
//  TSSExceptionDemo
//
//  Created by yijin on 12/7/15.
//  Copyright (c) 2015 yijin. All rights reserved.
//

#import "TSSException.h"
@implementation TSSException

+(instancetype) excetionWithCode:(NSString *) code_ Level:(ExceptionLevel) level_ Message:(NSString *) msg_ ExceptionLog:(NSString *) log_{
    TSSException *exception = [[TSSException alloc]  initWithName:@"TSSException" reason:msg_ userInfo:nil];
    exception.code = code_;
    exception.level = level_;
    exception.msg = msg_;
    exception.log = log_;
    return exception;
}
@end
