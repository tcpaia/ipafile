//
//  TSSException.h
//  TSSExceptionDemo
//
//  Created by yijin on 12/7/15.
//  Copyright (c) 2015 yijin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TSSExceptionHandler.h"

@interface TSSException : NSException
@property (nonatomic, copy) NSString *code;
@property (nonatomic, assign) ExceptionLevel level;
@property (nonatomic, copy) NSString *msg;
@property (nonatomic, copy) NSString *log;

+(instancetype) excetionWithCode:(NSString *) code_ Level:(ExceptionLevel) level_ Message:(NSString *) msg_ ExceptionLog:(NSString *) log_;
@end
