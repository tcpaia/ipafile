//
//  TSSExceptionHandler.h
//  TSSExceptionDemo
//
//  Created by yijin on 12/10/15.
//  Copyright (c) 2015 yijin. All rights reserved.
//

#ifndef TSSExceptionDemo_TSSExceptionHandler_h
#define TSSExceptionDemo_TSSExceptionHandler_h

typedef enum
{
    TSS_System= 0,
    Business = 1
} ExceptionLevel;

#import "TSSException.h"
#define ThrowException(condition,code,leve,msg,log){\
if(condition) {\
        @throw [TSSException excetionWithCode:code Level:leve Message:msg ExceptionLog:log];\
    }\
}\

#endif
