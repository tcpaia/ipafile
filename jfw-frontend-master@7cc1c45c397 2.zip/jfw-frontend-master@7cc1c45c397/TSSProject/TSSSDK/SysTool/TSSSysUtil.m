//
//  TSSSysUtil.m
//  TSSProject
//
//  Created by TSS on 16/5/19.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import "TSSSysUtil.h"
#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@implementation TSSSysUtil

/*
 * test codes run time start
 */
+ (uint64_t) recordTimeStart
{
     uint64_t tStart = mach_absolute_time();
    return tStart;
}

+ (void) recordTimeEnd:(uint64_t)aStart
{
    uint64_t end = mach_absolute_time();
    uint64_t elapsed = end - aStart;
    mach_timebase_info_data_t info;
    if (mach_timebase_info (&info) != KERN_SUCCESS)
    {
        printf ("mach_timebase_info failed\n");
    }
    uint64_t nanosecs = elapsed * info.numer / info.denom;
    uint64_t millisecs = nanosecs / 1000000;
    DLog(@">>>>>>>>>>cost time = %llu ms", millisecs);
}

+ (BOOL) checkCameraAvalable
{
    BOOL isCameraValid = YES;
    double version = [[UIDevice currentDevice].systemVersion doubleValue];
    if(version>=7.0f){
        // 判断程序的隐私设置是否授予权限
        AVAuthorizationStatus authStatus = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
        if (authStatus != AVAuthorizationStatusAuthorized)
        {
            isCameraValid = NO;
        }
        
    }
    return isCameraValid;
}

@end
