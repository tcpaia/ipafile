//
//  TSSZipUtil.m
//  TSSProject
//
//  Created by TSS on 16/6/15.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import "TSSZipUtil.h"
//#import "CkoZip.h"
#import "ZipFile.h"
#import "ZipException.h"
#import "FileInZipInfo.h"
#import "ZipWriteStream.h"
#import "ZipReadStream.h"
#import "TSSFileManager.h"

@implementation TSSZipUtil

+ (void) zipFileWithPassword:(NSString *)password fileName:(NSString *)fileName fileInPath:(NSString *)fileInPath fileOutPath:(NSString *)fileOutPath
{
    [TSSZipUtil zipFileWithPassword:password fileName:fileName fileData:[NSData dataWithContentsOfFile:fileInPath] fileOutPath:fileOutPath];
}

+ (void) zipFileWithPassword:(NSString *)password fileName:(NSString *)fileName fileData:(NSData *)theFileData fileOutPath:(NSString *)fileOutPath
{    
    ZipFile	*theZipFile	= [[ZipFile alloc] initWithFileName:fileOutPath mode:ZipFileModeCreate];
    NSDate *theDate = [NSDate date];

    ZipWriteStream	*theStream;
    
    // Write the file
    if (password!=nil && [password length] > 0)
    {
        uLong		theCRC				= crc32( 0L,NULL, 0L );
        theCRC							= crc32( theCRC, (const Bytef*)[theFileData bytes], [theFileData length] );
        theStream						= [theZipFile writeFileInZipWithName:fileName fileDate:theDate compressionLevel:ZipCompressionLevelBest password:password crc32:theCRC];
    }
    else
    {
        theStream						= [theZipFile writeFileInZipWithName:fileName fileDate:theDate compressionLevel:ZipCompressionLevelBest];
    }
    
    [theStream writeData:theFileData];
    [theStream finishedWriting];
    
    // Close and release the zip file
    if (theZipFile) {
        [theZipFile close];
    }
}

+ (void) zipFileWithPassword:(NSString *)password fileNames:(NSArray *)fileNames fileData:(NSArray *)fileData fileOutPath:(NSString *)fileOutPath
{
    ZipFile	*theZipFile	= [[ZipFile alloc] initWithFileName:fileOutPath mode:ZipFileModeCreate];
    NSDate *theDate = [NSDate date];
    
    for (int i=0; i<fileNames.count; i++)
    {
        
        ZipWriteStream	*theStream;
        NSData *theFileData = [fileData objectAtIndex:i];
        NSString *fileName = [fileNames objectAtIndex:i];
        
        // Write the file
        if (password!=nil && [password length] > 0)
        {
            uLong		theCRC				= crc32( 0L,NULL, 0L );
            theCRC							= crc32( theCRC, (const Bytef*)[theFileData bytes], [theFileData length] );
            theStream						= [theZipFile writeFileInZipWithName:fileName fileDate:theDate compressionLevel:ZipCompressionLevelBest password:password crc32:theCRC];
        }
        else
        {
            theStream						= [theZipFile writeFileInZipWithName:fileName fileDate:theDate compressionLevel:ZipCompressionLevelBest];
        }
        
        [theStream writeData:theFileData];
        [theStream finishedWriting];
        
    }
    
    // Close and release the zip file
    if (theZipFile)
    {
        [theZipFile close];
    }
}

+ (NSData *) zipFileWithPassword:(NSString *)password fileName:(NSString *)fileName fileInPath:(NSString *)fileInPath
{
    return [TSSZipUtil zipFileWithPassword:password fileName:fileName fileData:[NSData dataWithContentsOfFile:fileInPath]];
}

+ (NSData *) zipFileWithPassword:(NSString *)password fileName:(NSString *)fileName fileData:(NSData *)fileData
{
    NSString *outFile = [TSSFileManager createTmpFileNameWithExtension:@"tmp"];
    
    [TSSZipUtil zipFileWithPassword:password fileName:fileName fileData:fileData fileOutPath:outFile];
    
    if (![TSSFileManager fileExits:outFile]) return nil;
    if ([TSSFileManager getFileSize:outFile]<=0) return nil;
    
    NSData *data = [NSData dataWithContentsOfFile:outFile];
    
    [TSSFileManager deleteFile:outFile];
    
    return data;
}

+ (NSData *) zipFileWithPassword:(NSString *)password fileNames:(NSArray *)fileNames fileData:(NSArray *)fileData
{
    NSString *outFile = [TSSFileManager createTmpFileNameWithExtension:@"tmp"];
    
    [TSSZipUtil zipFileWithPassword:password fileNames:fileNames fileData:fileData fileOutPath:outFile];
    
    if (![TSSFileManager fileExits:outFile]) return nil;
    if ([TSSFileManager getFileSize:outFile]<=0) return nil;
    
    NSData *data = [NSData dataWithContentsOfFile:outFile];
    
    [TSSFileManager deleteFile:outFile];
    
    return data;
}
@end
