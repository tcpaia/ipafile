//
//  TSSSysUtil.h
//  TSSProject
//
//  Created by TSS on 16/5/19.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <mach/mach_time.h>

@interface TSSSysUtil : NSObject

/*
 * test codes run time start
 */
+ (uint64_t) recordTimeStart;

+ (void) recordTimeEnd:(uint64_t)aStart;

+ (BOOL) checkCameraAvalable;

@end
