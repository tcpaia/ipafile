//
//  TSSHardWareUtil.h
//  TSSProject
//
//  Created by TSS on 16/5/13.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface TSSHardWareUtil : NSObject

+ (NSString *) getSerialNumber;

+ (BOOL) isiPhone;
+ (BOOL) isiPad;
+ (BOOL) isSimulator;
+ (BOOL) isRotationLanscape;
+ (CGRect) getCurrentDeviceScreenSize;

+ (BOOL) deviceCanMakePhoneCalls;

+ (NSString *) platformString;
+ (NSString *) platformCode;

/*
 * Get device OS version
 * AZ - 5/29/14 - Phase III - #02892
 */
+ (NSString *) deviceSystemVersion;
/*
 * Get APP bundle short version
 * AZ - 5/29/14 - Phase III - #02892
 */
+ (NSString *) systemBundleVersion;


@end
