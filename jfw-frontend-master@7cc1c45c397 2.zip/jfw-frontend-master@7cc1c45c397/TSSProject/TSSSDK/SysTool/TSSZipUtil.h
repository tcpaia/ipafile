//
//  TSSZipUtil.h
//  TSSProject
//
//  Created by TSS on 16/6/15.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface TSSZipUtil : NSObject

//+ (void) zipFileWithPassword:(NSString *)password fileIn:(NSString *)fileIn fileOut:(NSString *)fileOut;

+ (void) zipFileWithPassword:(NSString *)password fileName:(NSString *)fileName fileInPath:(NSString *)fileInPath fileOutPath:(NSString *)fileOutPath;

+ (void) zipFileWithPassword:(NSString *)password fileName:(NSString *)fileName fileData:(NSData *)theFileData fileOutPath:(NSString *)fileOutPath;

+ (void) zipFileWithPassword:(NSString *)password fileNames:(NSArray *)fileNames fileData:(NSArray *)fileData fileOutPath:(NSString *)fileOutPath;

+ (NSData *) zipFileWithPassword:(NSString *)password fileName:(NSString *)fileName fileInPath:(NSString *)fileInPath;

+ (NSData *) zipFileWithPassword:(NSString *)password fileName:(NSString *)fileName fileData:(NSData *)fileData;

@end
