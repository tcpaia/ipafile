//
//  TSSFileLog.h
//  TSSProject
//
//  Created by TSS on 15/12/15.
//  Copyright © 2015年 AIA. All rights reserved.
//

#import <Foundation/Foundation.h>

enum
{
    TSSLOGDEBUG = 1,
    TSSLOGINFO = 2,
    TSSLOGWARNING = 3,
    TSSLOGERROR = 4,
    TSSLOGFATAL = 5
};
typedef NSUInteger TSSLogType;

#define CONSOLE_THRESHOLD TSSLOGINFO //Used to set console log level - default TFSLOGINFO
#define FILE_THRESHOLD TSSLOGWARNING //Used to set file log level - default TFSLOGWARNING

@interface TSSFileLog : NSObject
{
    NSString        *prefix;
    NSString        *filepath;
    NSString        *filename;
    NSDateFormatter *formatter;
    int              maxFiles;
    int              maxFileSize;
}

/**
 * the prefix for log message
 */
@property (nonatomic, retain) NSString      *prefix;

/**
 * the file path
 */
@property (nonatomic, retain) NSString      *filepath;
@property (nonatomic, retain) NSString      *filename;
@property (nonatomic, retain) NSDateFormatter *formatter;
@property (nonatomic) int                    maxFiles;
@property (nonatomic) int                    maxFileSize;

//- (id)init __attribute__((deprecated));
- (id)initWithPrefix:(NSString *)vPrefix maxFiles:(int)vMaxFiles maxFileSize:(int)vMaxFileSize;
- (id)initWithPrefix:(NSString *)vPrefix maxFiles:(int)vMaxFiles;
- (id)initWithPrefix:(NSString *)vPrefix maxFileSize:(int)vMaxFileSize;
- (id)initWithPrefix:(NSString *)vPrefix;

- (void) setPrefix:(NSString *)vPrefix maxFiles:(int)vMaxFiles maxFileSize:(int)vMaxFileSize;

+ (TSSFileLog *) getInstance;

#pragma mark - Get Log Path
- (NSString *)getDocumentLogPath;
- (NSString *)getResourceLogPath;

#pragma mark - IO method
- (void)createFile;
- (void)deleteFile:(NSString *)file;
- (void)writeFile:(NSString *)data;
- (NSString *)readFile;

#pragma mark - Log method
- (void)logString:(NSString *)log type:(TSSLogType)type;
- (void)logError:(NSError *)error;
- (void)logException:(NSException *)exception;

#pragma mark - Initialize Checking
- (void)checkLogPath;
- (void)checkMaxFiles;
- (void)checkMaxFileSize;

#pragma mark - Get method
- (NSString *)getLatestFile;
- (NSMutableArray *)getLatestFiles:(int)n;

@end
