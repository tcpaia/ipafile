//
//  TSSFileLog.m
//  TSSProject
//
//  Created by TSS on 15/12/15.
//  Copyright © 2015年 AIA. All rights reserved.
//

#import "TSSFileLog.h"
#import "Singleton.h"


@implementation TSSFileLog


@synthesize prefix;
@synthesize filepath;
@synthesize filename;
@synthesize maxFiles;
@synthesize maxFileSize;
@synthesize formatter;

SYNTHESIZE_SINGLETON_FOR_CLASS(TSSFileLog);


- (id) init
{
    self = [self initWithPrefix:@"TSSAIA" maxFiles:10 maxFileSize:100];
    return self;
    
}

- (id) initWithPrefix:(NSString *) vPrefix maxFiles:(int) vMaxFiles maxFileSize:(int) vMaxFileSize
{
    self = [super init];
    
    if (self)
    {
        self.prefix = vPrefix;
        maxFiles = vMaxFiles;
        maxFileSize = vMaxFileSize * 1024; //Turn to KB
        self.formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"yyyy'-'MM'-'dd HH':'mm':'ss\t"];
        
        [self checkLogPath];
    }
    
    return self;
}

- (id) initWithPrefix:(NSString *) vPrefix maxFiles:(int) vMaxFiles
{
    return [self initWithPrefix:vPrefix maxFiles:vMaxFiles maxFileSize:5];
}

- (id) initWithPrefix:(NSString *) vPrefix maxFileSize:(int) vMaxFileSize
{
    return [self initWithPrefix:vPrefix maxFiles:5 maxFileSize:vMaxFileSize];
}

- (id) initWithPrefix:(NSString *) vPrefix
{
    return [self initWithPrefix:vPrefix maxFiles:5 maxFileSize:5];
}

- (void) setPrefix:(NSString *) vPrefix maxFiles:(int) vMaxFiles maxFileSize:(int) vMaxFileSize
{
    self.prefix = vPrefix;
    maxFiles = vMaxFiles;
    maxFileSize = vMaxFileSize * 1024; //Turn to KB
    
    [self checkLogPath];
}

#pragma mark - Get Log Path

- (NSString *) getDocumentLogPath
{
    return [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject] stringByAppendingPathComponent:@"Log"];
}

- (NSString *) getResourceLogPath
{
    NSString *resourcePath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"Log"];
    
    return resourcePath;
}

#pragma mark - IO method

- (void) createFile
{
    NSDateFormatter *formatter1 = [[NSDateFormatter alloc] init];
    
    [formatter1 setDateFormat:@"yyyyMMddHHmmss"];
    
    NSString *suffix = [formatter1 stringFromDate:[NSDate date]];
    
    self.filename = [NSString stringWithFormat:@"%@_%@.log", self.prefix, suffix];
    self.filename = [self.filepath stringByAppendingPathComponent:self.filename];
    
    NSString *create = [[NSString alloc] init];
    NSData *createData = [create dataUsingEncoding: NSUTF8StringEncoding];
    NSFileHandle * writeHandle = [NSFileHandle fileHandleForWritingAtPath: self.filename];
    [writeHandle writeData: createData];
    [writeHandle closeFile];
    
    [self checkMaxFiles];
}

- (void) deleteFile:(NSString *) file
{
    [[NSFileManager defaultManager] removeItemAtPath:file error:nil];
}

- (void) writeFile:(NSString *) data
{
    @autoreleasepool //Release memory immediately after used
    {
        NSString *content = [[self readFile] stringByAppendingFormat:@"\n\n%@", data];
        NSData *contentData = [content dataUsingEncoding: NSUTF8StringEncoding];
        NSFileHandle * writeHandle = [NSFileHandle fileHandleForWritingAtPath: self.filename];
        [writeHandle writeData: contentData];
        [writeHandle closeFile];
        
        [self checkMaxFileSize];
    }
}

- (NSString *) readFile
{
    return [NSString stringWithContentsOfFile:self.filename encoding:NSUTF8StringEncoding error:nil];
}

#pragma mark - Log method

- (void) logString:(NSString *) log type:(TSSLogType)type
{

    
    if (type >= CONSOLE_THRESHOLD || type >= FILE_THRESHOLD) //log depend on log level set
    {
        @autoreleasepool //Release memory immediately after used
        {
            NSString *data = [self.formatter stringFromDate:[NSDate date]];
            
            if (type == TSSLOGDEBUG)
            {
                data = [data stringByAppendingFormat:@"DEBUG\t%@", log];
            }
            else if (type == TSSLOGINFO)
            {
                data = [data stringByAppendingFormat:@"INFO\t%@", log];
            }
            else if (type == TSSLOGWARNING)
            {
                data = [data stringByAppendingFormat:@"WARNING\t%@", log];
            }
            else if (type == TSSLOGERROR)
            {
                data = [data stringByAppendingFormat:@"ERROR\t%@", log];
            }
            else if (type == TSSLOGFATAL)
            {
                data = [data stringByAppendingFormat:@"FATAL\t%@", log];
            }
            
            if(type >= CONSOLE_THRESHOLD)
            {
                DLog(@"logString: %@", data);
            }
            if(type >= FILE_THRESHOLD)
            {
                [self writeFile:data];
            }
        }
    }
}

- (void) logError:(NSError *) error
{
    NSString *data = [self.formatter stringFromDate:[NSDate date]];
    
    data = [data stringByAppendingFormat:@"ERROR\t *** Terminating app due to uncaught exception of class 'NSError'\n%@\nterminate called throwing an exception", error];
    
    [self writeFile:data];
}

- (void) logException:(NSException *) exception
{
    NSString *data = [self.formatter stringFromDate:[NSDate date]];
    
    data = [data stringByAppendingFormat:@"ERROR\t *** Terminating app due to uncaught exception '%@', reason: '%@'\n*** First throw call stack:%@%@\nuser info:%@\nterminate called throwing an exception",
            [exception name],
            [exception reason],
            [exception callStackReturnAddresses],
            [exception callStackSymbols],
            [exception userInfo]];
    
    [self writeFile:data];
}

#pragma mark - Initialize Checking

- (void) checkLogPath
{
    /**
     *  By default, set Document path as default path
     */
    self.filepath = [self getDocumentLogPath];
    
    /**
     *  Create path if path is not exists
     */
    if (![[NSFileManager defaultManager] fileExistsAtPath:self.filepath])
    {
        [[NSFileManager defaultManager] createDirectoryAtPath:self.filepath withIntermediateDirectories:NO attributes:nil error:nil];
    }
    
    self.filename = [self getLatestFile];
}

- (void) checkMaxFiles
{
    NSMutableArray *files = [self getLatestFiles:0];
    
    if ([files count] < 1)
    {
        [self createFile];
    }
    else
    {
        if ([files count] > maxFiles)
        {
            while ([files count] > maxFiles)
            {
                [self deleteFile:[files lastObject]];
                [files removeLastObject];
            }
        }
    }
}

- (void) checkMaxFileSize
{
    NSDictionary *dictionary = [[NSFileManager defaultManager] attributesOfItemAtPath:self.filename error:nil];
    
    NSNumber *fileSize = (NSNumber *) [dictionary objectForKey:NSFileSize];
    
    if ([fileSize intValue] > maxFileSize)
    {
        [self createFile];
    }
}

#pragma mark - Get method

- (NSString *) getLatestFile
{
    [self checkMaxFiles];
    
    NSString *returnString = [[self getLatestFiles:1] objectAtIndex:0];
    
    return returnString;
}

- (NSMutableArray *) getLatestFiles:(int) n
{
    NSMutableArray *returnArray = [NSMutableArray arrayWithCapacity:n];
    
    NSArray *files = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:self.filepath error:nil];
    
    for (NSString *file in files)
    {
        NSComparisonResult result = [file compare:self.prefix options:NSRegularExpressionSearch range:NSMakeRange(0, [self.prefix length])];
        
        if (result == NSOrderedSame)
        {
            [returnArray addObject:[self.filepath stringByAppendingPathComponent:file]];
        }
    }
    
    for (int i = 0; i < [returnArray count] / 2; i++)
    {
        [returnArray exchangeObjectAtIndex:i withObjectAtIndex:([returnArray count] - i - 1)];
    }
    
    if (n == 0)
    {
        return returnArray;
    }
    
    if ([returnArray count] > n)
    {
        while ([returnArray count] > n)
        {
            [returnArray removeLastObject];
        }
    }
    
    return returnArray;
}

@end
