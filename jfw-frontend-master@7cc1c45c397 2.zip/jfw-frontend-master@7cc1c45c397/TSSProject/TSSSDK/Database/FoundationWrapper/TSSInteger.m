//
//  TSSInteger.m
//  TSSProject
//
//  Created by TSS on 15/12/17.
//  Copyright © 2015年 AIA. All rights reserved.
//

#import "TSSInteger.h"


static const int MIN_VALUE = 0x80000000;
static const int MAX_VALUE = 0x7fffffff;

@implementation TSSInteger
@synthesize value;

+ (int) MIN_VALUE
{
    return MIN_VALUE;
}

+ (int) MAX_VALUE
{
    return MAX_VALUE;
}

+ (id) integerWithInt:(int)v
{
    return [[TSSInteger alloc] initWithInt:v];
}

+ (id) integerWithString:(NSString *)s
{
    return [[TSSInteger alloc] initWithString:s];
}

+ (id) integerWithHexString:(NSString *)s
{
    return [[TSSInteger alloc] initWithHexString:s];
}

- (id) initWithInt:(int)v
{
    if ((self = [super init]))
    {
        self.value = v;
    }
    return (self);
}

- (id) initWithString:(NSString *)s
{
    if ((self = [super init]))
    {
        self.value = [s intValue];
    }
    return (self);
}

- (id) initWithHexString:(NSString *)s
{
    if ((self = [super init]))
    {
        self.value = [TSSInteger hex2Int:s];
    }
    return (self);
}

- (id)copyWithZone:(NSZone*)zone
{
    TSSInteger *objectCopy = [[TSSInteger allocWithZone:zone] init];
    
    objectCopy.value = self.value;
    return objectCopy;
}

- (NSString *) description
{
    return [NSString stringWithFormat:@"%d", self.value];
}

- (BOOL)isEqual:(id)object
{
    return [object isKindOfClass:[self class]] && self.value == ((TSSInteger *) object).value;
}

- (int) compareTFInteger:(TSSInteger *) i
{
    if (i==nil) return 1;
    if (self.value == i.value) return 0;
    return self.value > i.value ? 1 : -1;
}

- (int) compareTo:(id)o
{
    if (o==nil) return 1;
    if ([o isKindOfClass:[self class]]) return [self compareTFInteger:(TSSInteger *) o];
    return 1;
}

- (NSUInteger) hashCode
{
    return self.value;
}

+ (int) hex2Int:(NSString *)hex
{    
    if (hex==nil || hex.length==0) return 0;
    hex = [hex lowercaseString];
    int output = 0;
    
    for (int i=hex.length-1,ri=0; i>=0; i--,ri++)
    {
        char c = [hex characterAtIndex:i];
        double v = pow(16,ri);
        
        if (c>='0' && c<='9')
        {
            output += (c-'0')*v;
        }
        else if (c>='a' && c<='f')
        {
            output += (c-'a'+10)*v;
        }
    }
    return output;
}

@end
