//
//  TSSInteger.h
//  TSSProject
//
//  Created by TSS on 15/12/17.
//  Copyright © 2015年 AIA. All rights reserved.
//


#import <Foundation/Foundation.h>
#import "TSSComparable.h"

#define INTEGER_MIN_VALUE	0x80000000
#define INTEGER_MAX_VALUE	0x7fffffff


@interface TSSInteger : NSObject <NSCopying, TSSComparable>
{
    int value;
}

@property int value;

+ (int) MIN_VALUE;
+ (int) MAX_VALUE;

+ (id) integerWithInt:(int)v;
+ (id) integerWithString:(NSString *)s;
+ (id) integerWithHexString:(NSString *)s;

- (id) initWithInt:(int)v;
- (id) initWithString:(NSString *)s;
- (id) initWithHexString:(NSString *)s;

- (BOOL)isEqual:(id)object;
- (int) compareTFInteger:(TSSInteger *) i;
- (int) compareTo:(id)o;
- (NSUInteger) hashCode;

+ (int) hex2Int:(NSString *)hex;

@end
