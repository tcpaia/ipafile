//
//  TSSArray.m
//  TSSProject
//
//  Created by TSS on 15/12/17.
//  Copyright © 2015年 AIA. All rights reserved.
//

#import "TSSArray.h"

@implementation TSSArray
@synthesize array;


+ (id) arrayWithObjects:(id)firstObj, ...
{
    TSSArray *a = [[TSSArray alloc] init];
    
    va_list args;
    va_start(args, firstObj);
    for (id arg = firstObj; arg != nil; arg = va_arg(args, id))
    {
        [a addObject:arg];
    }
    va_end(args);
    
    return a;
}

- (id)init
{
    if ((self = [super init]))
    {
        self.array = [[NSMutableArray alloc] init];
    }
    return self;
}

- (id) initWithCapacity:(NSUInteger)numItems
{
    if ((self = [super init]))
    {
        self.array = [[NSMutableArray alloc] initWithCapacity:numItems];
        for (int i = 0; i < numItems; i++)
        {
            [self.array addObject:[NSNull null]];
        }
    }
    return self;
}

- (id) initWithObjects:(id)firstObj, ...
{
    if ((self = [self init]))
    {
        va_list args;
        va_start(args, firstObj);
        for (id arg = firstObj; arg != nil; arg = va_arg(args, id))
        {
            [self addObject:arg];
        }
        va_end(args);
    }
    return self;
}

- (void) addObject:(id) value
{
    if (value == nil) [self.array addObject:[NSNull null]];
    else [self.array addObject:value];
}

- (void) deleteObject:(id) value
{
    if (value == nil) return;
    [self.array removeObject:value];
}

- (void) deleteObjectAtIndex:(NSUInteger)index
{
    if (index >= [self count]) return;
    [self.array removeObjectAtIndex:index];
}

- (id) getObjectAtIndex:(NSUInteger)index
{
    if (index >= [self count]) return nil;
    id value = [self.array objectAtIndex:index];
    if (value == [NSNull null]) return nil;
    return value;
}

- (void) setObjectAtIndex:(NSUInteger)index with:(id)value
{
    if (index >= [self count]) return;
    if (value == nil) [self.array replaceObjectAtIndex:index withObject:[NSNull null]];
    else [self.array replaceObjectAtIndex:index withObject:value];
}

- (BOOL) containsObject:(id)value
{
    if (value==nil) return NO;
    return [self.array containsObject:value];
}

- (int) findObject:(id)value
{
    if (value==nil) return -1;
    for (int i = 0; i < [self count]; i++)
    {
        if ([[self.array objectAtIndex:i] isEqual:value]) return i;
    }
    return -1;
}

- (NSUInteger) count
{
    return [self.array count];
}

- (void) sort:(BOOL)ascending
{
    if ([self.array count]==0) return;
    
    [self.array sortUsingSelector:@selector(compare:)];
    
    if (!ascending)
    {
        NSMutableArray *a = [[NSMutableArray  alloc] initWithCapacity:self.array.count];
        for (int i = self.array.count-1; i >=0 ; i--)
        {
            [a addObject:[self.array objectAtIndex:i]];
        }
        self.array = a;
    }
}

- (NSString *) componentsJoinedByString:(NSString *)separator
{
    return [self.array componentsJoinedByString:separator];
}

- (NSString *) description
{
    return [self.array componentsJoinedByString:@", "];
}

- (NSUInteger) length
{
    return [self.array count];
}

@end
