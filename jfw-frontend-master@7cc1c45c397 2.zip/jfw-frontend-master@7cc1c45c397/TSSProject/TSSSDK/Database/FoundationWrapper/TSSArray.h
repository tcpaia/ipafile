//
//  TSSArray.h
//  TSSProject
//
//  Created by TSS on 15/12/17.
//  Copyright © 2015年 AIA. All rights reserved.
//
#import <Foundation/Foundation.h>

@interface TSSArray : NSObject {
    
    NSMutableArray *array;
}

@property (nonatomic, retain) NSMutableArray *array;
@property (nonatomic, readonly) NSUInteger length;

+ (id) arrayWithObjects:(id)firstObj, ... NS_REQUIRES_NIL_TERMINATION;

- (id) initWithObjects:(id)firstObj, ... NS_REQUIRES_NIL_TERMINATION;

- (id) initWithCapacity:(NSUInteger)numItems;

- (void) addObject:(id) value;

- (void) deleteObject:(id) value;

- (void) deleteObjectAtIndex:(NSUInteger)index;

- (id) getObjectAtIndex:(NSUInteger)index;

- (void) setObjectAtIndex:(NSUInteger)index with:(id)value;

- (BOOL) containsObject:(id)value;

- (int) findObject:(id)value;

- (void) sort:(BOOL)ascending;

- (NSUInteger) count;

- (NSString *) componentsJoinedByString:(NSString *)separator;

@end
