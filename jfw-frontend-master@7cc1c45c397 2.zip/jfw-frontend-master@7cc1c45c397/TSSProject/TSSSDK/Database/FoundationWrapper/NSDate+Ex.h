//
//  NSDate+Ex.h
//  Wrapper
//
//  Created by TSS on 15/12/22.
//  Copyright © 2015年 EL-Apple. All rights reserved.
//

#import <Foundation/Foundation.h>

#define DATE_TIME @"HH:mm"
#define DATE_YMD @"yyyy-MM-dd"
#define DATE_NORMAL @"yyyy-MM-dd HH:mm"
#define kNSDateFormatter13 @"yyyy-MM-dd HH:mm:ss.SSS"


///////////////////////////////////////////////////////////////////////////////////
#pragma mark - NSDateFormatter
//NSDateFormatter
#define kNSDateFormatter1 @"MMM dd, yyyy"
#define kNSDateFormatter2 @"MMM dd, yyyy h:mm a"
#define kNSDateFormatter3 @"HH:mm"
#define kNSDateFormatter4 @"yyyyMMdd"
#define kNSDateFormatter5 @"MMM yyyy"
#define kNSDateFormatter6 @"MMM dd, yyyy HH:mm"
#define kNSDateFormatter7 @"MMM dd, yyyy"
#define kNSDateFormatter8 @"MMMM"
#define kNSDateFormatter9 @"yyyy"
#define kNSDateFormatter10 @"MMM dd, yyyy HH"
#define kNSDateFormatter11 @"MMM dd, yyyy HH:mm:ss"
#define kNSDateFormatter12 @"dd LLL,yyyy"
#define kNSDateFormatter13 @"yyyy-MM-dd HH:mm:ss.SSS"
#define kNSDateFormatter14 @"yyyy-MM-dd HH:mm:ss SSS"
#define kNSDateFormatter15 @"dd-MMM-yyyy h:mm a"
#define kNSDateFormatter16 @"dd-MMM-yyyy"
#define kNSDateFormatter17 @"h:mm a"
#define kNSDateFormatter18 @"dd-MMM-yyyy h:mm a"
#define kNSDateFormatter19 @"M yyyy"
#define kNSDateFormatter20 @"mm" //only get minutes
#define kNSDateFormatter21 @"dd-MMM-yyyy HH:mm:ss"
#define kNSDateFormatter22 @"dd MMM yyyy"


@interface NSDate (Ex)

+ (NSDate *) convertNumberToDateNoDateFormat:(NSNumber *)numberDate;
+ (NSNumber *) convertDateToNumberNoDateFormat:(NSDate *)date;

+ (NSDate *) parseStringWithStringDate:(NSString *)text withFormat:(NSString *)format;
+ (NSDate *) getCurrentDateWithNormalFormat;
+ (NSDate *) parseDateWithNormalFormat:(NSString *)strDate;

+ (NSString *)convertChineseDateToEnglishDate:(NSString *)dateString;
+ (NSString *)convertChineseTimeToEnglishTime:(NSString *)dateTime;
+ (NSString *)convertTimeFormat:(NSString *)dateTime;

- (NSString *)formatDateDefaultFormat;
- (NSString *)formatDateTimeDefaultFormat;
+ (NSNumber *)convertNSDateToNSNumber:(NSDate *)date;
+ (NSDate *) convertNSStringToNSDate:(NSString *)aDateStr;
+ (NSDate *) convertNSStringToNSDateWithFormat:(NSString *)format withDateString:(NSString *)aDateStr;

+ (NSString *) convertBirthdayToAge:(NSString *)birthday;
- (NSString *)formatDateTimeHHMM;
- (NSString *)parseStringFormatDateTime:(NSString*)dateFormat;

+ (NSString *)cutOffdateTime:(NSString *)dateTime withTimeFormat:(NSString *)format;
+ (NSDate *)getNowDateFromatAnDate:(NSDate *)anyDate ;
+(NSInteger) calcDaysFromBegin:(NSDate *)inBegin end:(NSDate *)inEnd;

- (BOOL) isBeforeDate:(NSDate *)secondDate;
//self > secondDate
- (BOOL) isAfterDate:(NSDate *)secondDate;
//self (<= || <) secondDate
- (BOOL) isBeforeDate:(NSDate *)secondDate withEqual:(BOOL) equalFlag;
//self (>= || >) secondDate
- (BOOL) isAfterDate:(NSDate *)secondDate withEqual:(BOOL) equalFlag;
@end
