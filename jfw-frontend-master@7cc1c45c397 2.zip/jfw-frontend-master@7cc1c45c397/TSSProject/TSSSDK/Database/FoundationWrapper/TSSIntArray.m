//
//  TSSIntArray.m
//  TSSProject
//
//  Created by TSS on 15/12/17.
//  Copyright © 2015年 AIA. All rights reserved.
//

#import "TSSIntArray.h"
#import "TSSValidationUtil.h"

@implementation TSSIntArray

+ (id) arrayWithInts:(int)firstInt, ...
{
    TSSIntArray *a = [[TSSIntArray alloc] init];
    
    va_list args;
    va_start(args, firstInt);
    for (int arg = firstInt; arg != INTEGER_MAX_VALUE; arg = va_arg(args, int))
    {
        [a addInt:arg];
    }
    va_end(args);
    
    return a;
}

- (id) initWithInts:(int)firstInt, ...
{
    if ((self = [super init]))
    {
        va_list args;
        va_start(args, firstInt);
        for (int arg = firstInt; arg != INTEGER_MAX_VALUE; arg = va_arg(args, int))
        {
            [self addInt:arg];
        }
        va_end(args);
    }
    return self;
}

- (void) addInt:(int) value
{
    [self.array addObject:[NSNumber numberWithInt:value]];
}

- (void) deleteInt:(int) value
{
    [super deleteObject:[NSNumber numberWithInt:value]];
}

- (int) getIntAtIndex:(NSUInteger)index
{
    if (index >= [self count]) return 0;
    if ([TSSValidationUtil isNilOrNull:[self.array objectAtIndex:index]]) return 0;
    return [(NSNumber *)[self.array objectAtIndex:index] intValue];
}

- (void) setIntAtIndex:(NSUInteger)index with:(int)value
{
    [super setObjectAtIndex:index with:[NSNumber numberWithInt:value]];
}

- (BOOL) containsInt:(int)value
{
    return [super containsObject:[NSNumber numberWithInt:value]];
}

- (int) findInt:(int)value
{
    for (int i = 0; i < [self count]; i++)
    {
        if ([self getIntAtIndex:i] == value) return i;
    }
    return -1;
}

- (int *) toIntArray
{
    int count = [self count];
    int *a = malloc(sizeof(int)*count);
    if (a == NULL) {
        return NULL;
    }
    for (int i = 0; i < count; i++)
    {
        a[i] = [[self.array objectAtIndex:i] intValue];
    }
    
    return a;
}

@end
