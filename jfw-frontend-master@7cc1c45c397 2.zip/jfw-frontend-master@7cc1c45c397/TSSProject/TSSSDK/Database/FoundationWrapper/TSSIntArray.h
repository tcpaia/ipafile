//
//  TSSIntArray.h
//  TSSProject
//
//  Created by TSS on 15/12/17.
//  Copyright © 2015年 AIA. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TSSArray.h"
#import "TSSInteger.h"

@interface TSSIntArray : TSSArray {
    
}

+ (id) arrayWithInts:(int)firstInt, ...;

- (id) initWithInts:(int)firstInt, ...;

- (void) addInt:(int) value;

- (void) deleteInt:(int) value;

- (int) getIntAtIndex:(NSUInteger)index;

- (void) setIntAtIndex:(NSUInteger)index with:(int)value;

- (BOOL) containsInt:(int)value;

- (int) findInt:(int)value;

- (int *) toIntArray;

@end
