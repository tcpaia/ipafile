//
//  NSDate+Ex.m
//  Wrapper
//
//  Created by TSS on 15/12/22.
//  Copyright © 2015年 EL-Apple. All rights reserved.
//

#import "NSDate+Ex.h"
#import "TSSValidationUtil.h"
#import "NSString+Ex.h"



@implementation NSDate (Ex)

+ (NSDate *) convertNumberToDateNoDateFormat:(NSNumber *)numberDate
{
    NSDate *aDate = [NSDate dateWithTimeIntervalSince1970:[numberDate longLongValue]];
    return aDate;
}

+ (NSNumber *) convertDateToNumberNoDateFormat:(NSDate *)date
{
    return [NSNumber numberWithInt:[date timeIntervalSince1970]];
}

+ (NSDate *) parseStringWithStringDate:(NSString *)text withFormat:(NSString *)format
{
    if ([TSSValidationUtil isNilOrEmptyString:text]) return nil;
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];

    [formatter setDateFormat:format];
    return [formatter dateFromString:text];
}

+ (NSDate *) getCurrentDateWithNormalFormat
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:DATE_NORMAL];
    NSString *strDate = [dateFormatter stringFromDate:[NSDate date]];
    NSString *currentYear = [strDate subString:0 toIndex:4];
    NSString *currentMonth = [strDate subString:5 toIndex:7];
    NSString *currentDay = [strDate subString:8 toIndex:10];
    return [NSDate dateWithYear:currentYear.intValue month:currentMonth.intValue day:currentDay.intValue];
}

+ (NSDate *) parseDateWithNormalFormat:(NSString *)strDate
{
    NSString *nsDateYear = [strDate subString:0 toIndex:4];
    NSString *nsDateMonth = [strDate subString:4 toIndex:6];
    NSString *nsDateDay = [strDate subString:6 toIndex:8];
    return [NSDate dateWithYear:nsDateYear.intValue month:nsDateMonth.intValue day:nsDateDay.intValue];
}

- (NSString *)parseStringFormatDateTime:(NSString*)dateFormat
{
    NSDateFormatter *dateTimeFormatter = nil;
    if (dateTimeFormatter==nil)
    {
        dateTimeFormatter = [[NSDateFormatter alloc] init];
        [dateTimeFormatter setDateFormat:dateFormat];
    }
    
    return [dateTimeFormatter stringFromDate:self];
}

+ (NSDate *) dateWithYear:(int)year month:(int)month day:(int)day
{
    NSDateComponents *components = [[NSDateComponents alloc] init];
    [components setSecond:0];
    [components setMinute:0];
    [components setHour:0];
    [components setDay:day];
    [components setMonth:month];
    [components setYear:year];
    
    NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDate *d = [gregorian dateFromComponents:components];
    return d;
}
- (NSString *)formatDateDefaultFormat
{
    NSDateFormatter* dateFormatter = nil;
    if (!dateFormatter) {
        dateFormatter = [[NSDateFormatter alloc] init];
        //zhenhuan fix PIR  2071 change date format to MM-DD-YYYY
        dateFormatter.dateFormat = DATE_YMD;
    }
    return [dateFormatter stringFromDate:self];
}

+ (NSString *)convertChineseDateToEnglishDate:(NSString *)dateString
{
    NSArray *compent = [dateString componentsSeparatedByString:@"-"];
    __block NSString *month = [NSString stringWithFormat:@"%d",[compent[0] intValue]];;
    NSString *date = [NSString stringWithFormat:@"%d",[compent[1] intValue]];
    
    NSArray *c_Months = @[@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"11",@"12"];
    NSArray *e_Months = @[@"January",@"Febrary",@"March",@"April",@"May",@"June",@"July",@"August",@"September",@"October",@"November",@"December"];
    [c_Months enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([month isEqualToString:(NSString *)obj])
        {
            month = e_Months[idx];
        }
        
    }];
    
    return [NSString stringWithFormat:@"%@ %@ %@",date,month,compent[2]];
}

+ (NSString *)convertChineseTimeToEnglishTime:(NSString *)dateTime
{
    NSString *dateString = [dateTime substringToIndex:10];
    NSString *time = [dateTime substringFromIndex:11];
    NSArray *compent = [dateString componentsSeparatedByString:@"-"];
    __block NSString *month = [NSString stringWithFormat:@"%d",[compent[1] intValue]];
    NSString *date = [NSString stringWithFormat:@"%d",[compent[2] intValue]];
    NSString *year = compent[0];
    NSArray *c_Months = @[@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"11",@"12"];
    NSArray *e_Months = @[@"Jan",@"Feb",@"Mar",@"Apr",@"May",@"June",@"July",@"Aug",@"Sep",@"Oct",@"Nov",@"Dec"];
    [c_Months enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([month isEqualToString:(NSString *)obj])
        {
            month = e_Months[idx];
        }
        
    }];
    
    return [NSString stringWithFormat:@"%@,%@.%@.%@",time,date,month,year];
}

+ (NSString *)convertTimeFormat:(NSString *)dateTime
{
    NSString *dateString = [dateTime substringToIndex:10];
    NSString *time = [dateTime substringFromIndex:11];
    NSArray *compent = [dateString componentsSeparatedByString:@"-"];
    __block NSString *month = [NSString stringWithFormat:@"%d",[compent[1] intValue]];
    NSString *date = [NSString stringWithFormat:@"%d",[compent[2] intValue]];
    NSString *year = compent[0];
    
    if ([time longLongValue] > 12) {
        time = [NSString stringWithFormat:@"%@ PM",time];
    }else {
        time = [NSString stringWithFormat:@"%@ AM",time];
    }
    return [NSString stringWithFormat:@"%@ / %@ / %@ %@",month,date,year,time];
}

+ (NSString *)cutOffdateTime:(NSString *)dateTime withTimeFormat:(NSString *)format
{
    NSString *timeString;
    if ([format isEqualToString:DATE_YMD]) {
        timeString = [dateTime substringToIndex:10];
    }else {
        timeString = [dateTime substringFromIndex:11];
    }
    return timeString;
}

- (NSString *) formatDateTimeDefaultFormat
{
    NSDateFormatter *dateTimeFormatter = nil;
    if (dateTimeFormatter==nil)
    {
        dateTimeFormatter = [[NSDateFormatter alloc] init];
        [dateTimeFormatter setDateFormat:DATE_NORMAL];
    }
    
    return [dateTimeFormatter stringFromDate:self];
}

- (NSString *)formatDateTimeHHMM
{
    NSDateFormatter *dateTimeFormatter = nil;
    if (dateTimeFormatter==nil)
    {
        dateTimeFormatter = [[NSDateFormatter alloc] init];
        
        [dateTimeFormatter setDateFormat:DATE_TIME];
    }
    
    return [dateTimeFormatter stringFromDate:self];
}

+ (NSDate *) convertNSStringToNSDate:(NSString *)aDateStr
{
    NSDate *date;
    if (!aDateStr) {
        date = [NSDate date];
    } else {
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:kNSDateFormatter13];
        date = [dateFormatter dateFromString:aDateStr];
    }
    return date;
}

+ (NSDate *) convertNSStringToNSDateWithFormat:(NSString *)format withDateString:(NSString *)aDateStr
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:format];

    NSDate *date = [dateFormatter dateFromString:aDateStr];
    return date;
}

+ (NSNumber *) convertNSDateToNSNumber:(NSDate *)date
{
    NSNumber *number;
    if (date != nil)
    {
        number = [NSNumber numberWithDouble:[date timeIntervalSince1970]];
    }
    return number;
}

+ (NSString *)convertBirthdayToAge:(NSString *)birthday
{
    //计算年龄
    NSString *birth = birthday;
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:DATE_YMD];
    //生日
    NSDate *birthDay = [dateFormatter dateFromString:birth];
    //当前时间
    NSString *currentDateStr = [dateFormatter stringFromDate:[NSDate date]];
    NSDate *currentDate = [dateFormatter dateFromString:currentDateStr];
//    DLog(@"currentDate %@ birthDay %@",currentDateStr,birth);
    NSTimeInterval time=[currentDate timeIntervalSinceDate:birthDay];
    int age = ((int)time)/(3600*24*365);
    return [NSString stringWithFormat:@"%d",age];
}

+ (NSDate *)getNowDateFromatAnDate:(NSDate *)anyDate {
    //设置源日期时区
    NSTimeZone* sourceTimeZone = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];//或GMT
    //设置转换后的目标日期时区
    NSTimeZone* destinationTimeZone = [NSTimeZone localTimeZone];
    //得到源日期与世界标准时间的偏移量
    NSInteger sourceGMTOffset = [sourceTimeZone secondsFromGMTForDate:anyDate];
    //目标日期与本地时区的偏移量
    NSInteger destinationGMTOffset = [destinationTimeZone secondsFromGMTForDate:anyDate];
    //得到时间偏移量的差值
    NSTimeInterval interval = destinationGMTOffset - sourceGMTOffset;
    //转为现在时间
    NSDate* destinationDateNow = [[NSDate alloc] initWithTimeInterval:interval sinceDate:anyDate];
    return destinationDateNow;
}

//计算两个日期之间的天数
+(NSInteger) calcDaysFromBegin:(NSDate *)inBegin end:(NSDate *)inEnd
{
    NSInteger unitFlags = NSCalendarUnitDay| NSCalendarUnitMonth | NSCalendarUnitYear;
    NSCalendar *cal = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDateComponents *comps = [cal components:unitFlags fromDate:inBegin];
    NSDate *newBegin  = [cal dateFromComponents:comps];
    
    NSCalendar *cal2 = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDateComponents *comps2 = [cal2 components:unitFlags fromDate:inEnd];
    NSDate *newEnd  = [cal2 dateFromComponents:comps2];
    
    NSTimeInterval interval = [newEnd timeIntervalSinceDate:newBegin];
    NSInteger beginDays=((NSInteger)interval)/(3600*24);

    return beginDays;
}

- (BOOL)isBeforeDate:(NSDate *)secondDate {
    return [self isBeforeDate:secondDate withEqual:NO];
}

//self > secondDate
- (BOOL)isAfterDate:(NSDate *)secondDate {
    return [self isAfterDate:secondDate withEqual:NO];
}

- (BOOL)isBeforeDate:(NSDate *)secondDate withEqual:(BOOL)equalFlag {
    if ([[self earlierDate:secondDate] isEqualToDate:self]) {
        if (!equalFlag && [self isEqualToDate:secondDate]) {
            return NO;
        }
        return YES;
    }
    return NO;
}

- (BOOL)isAfterDate:(NSDate *)secondDate withEqual:(BOOL)equalFlag {
    if ([[self laterDate:secondDate] isEqualToDate:self]) {
        if (!equalFlag && [self isEqualToDate:secondDate]) {
            return NO;
        }
        return YES;
    }
    return NO;
}
@end
