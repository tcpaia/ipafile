//
//  TSSComparable.h
//  TSSProject
//
//  Created by TSS on 15/12/17.
//  Copyright © 2015年 AIA. All rights reserved.
//

#ifndef TSSComparable_h
#define TSSComparable_h


@protocol TSSComparable

@required

- (int) compareTo:(id)o;

@end


#endif /* TSSComparable_h */
