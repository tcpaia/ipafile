//
//  NSString+Ex.m
//  TSSProject
//
//  Created by TSS on 15/12/17.
//  Copyright © 2015年 AIA. All rights reserved.
//

#import "NSString+Ex.h"
#import "TSSValidationUtil.h"


@implementation NSString (Ex)

- (NSInteger) indexOf:(NSString *) format
{
    NSUInteger index = [self rangeOfString:format].location;
    
    if (index == NSNotFound) return -1;
    return index;
}

- (NSInteger) indexOf:(NSString *) format fromIndex: (NSUInteger)fromIndex
{
    NSUInteger index = [self rangeOfString:format options:NSLiteralSearch range:NSMakeRange(fromIndex, [self length]-fromIndex)].location;
    
    if (index == NSNotFound) return -1;
    return index;
}

- (NSInteger) lastIndexOf:(NSString *) format
{
    NSUInteger index = [self rangeOfString:format options:NSBackwardsSearch].location;
    
    if (index == NSNotFound) return -1;
    return index;
}

- (NSString *) subString:(NSUInteger) fromIndex toIndex:(NSUInteger) toIndex
{
    if (toIndex<fromIndex) return nil;
    
    if (toIndex >= [self length]) {
        toIndex = [self length];
    }
    
    return [self substringWithRange:NSMakeRange(fromIndex, toIndex - fromIndex)];
}

- (BOOL) contains:(NSString *)str
{
    return ([self rangeOfString:str].location != NSNotFound);
}

- (BOOL) equalsIgnoreCase:(NSString *) str
{
    return [self caseInsensitiveCompare:str] == NSOrderedSame;
}

- (NSString *) trim
{
    return [self stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}

- (NSString *) ltrim
{
    NSInteger i;
    NSCharacterSet *cs = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    for(i = 0; i < [self length]; i++)
    {
        if ( ![cs characterIsMember: [self characterAtIndex: i]] ) break;
    }
    return [self substringFromIndex: i];
}

- (NSString *) rtrim
{
    NSInteger i;
    NSCharacterSet *cs = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    for(i = [self length] -1; i >= 0; i--)
    {
        if ( ![cs characterIsMember: [self characterAtIndex: i]] ) break;
    }
    return [self substringToIndex: (i+1)];
}

- (NSString *) replace:(NSString *) find replaceWith: (NSString *)replace
{
    return [self stringByReplacingOccurrencesOfString:find withString:replace];
}

- (BOOL) startsWith:(NSString *) format
{
    return [self hasPrefix:format];
}

- (BOOL) endsWith:(NSString *) format
{
    return [self hasSuffix:format];
}

- (NSString *)toUpperCase
{
    return [self uppercaseString];
}

- (NSString *)toLowerCase
{
    return [self lowercaseString];
}

-(NSString *) reverseString
{
    NSMutableString *reversedStr;
    int len = [self length];
    
    // Auto released string
    reversedStr = [NSMutableString stringWithCapacity:len];
    
    // Probably woefully inefficient...
    while (len > 0)
        [reversedStr appendString:
         [NSString stringWithFormat:@"%C", [self characterAtIndex:--len]]];
    
    return reversedStr;
}

- (NSString *) componentsSeparatedByString:(NSString *) string atIndex:(int) index
{
    NSArray *array = [self componentsSeparatedByString:string];
    if (array && array.count >= index) {
        return [array objectAtIndex:index];
    } else {
        return nil;
    }
}

- (NSString *)escapeHTML
{
    NSString *temp = self;
    temp = [TSSValidationUtil convertNilToEmptyString:temp];
    
    temp = [temp replace:@"amp;" replaceWith:@""];
    temp = [temp replace:@"&#13;" replaceWith:@"\r"];
    temp = [temp replace:@"&lt;" replaceWith:@"<"];
    temp = [temp replace:@"&gt;" replaceWith:@">"];
    temp = [temp replace:@"&apos;" replaceWith:@"'"];
    temp = [temp replace:@"&quot;" replaceWith:@"\""];
    //temp = [temp replace:@"&amp;" replaceWith:@"&"];
    return temp;
}

+(NSString *)countNumAndChangeformat:(NSString *)num
{
    int count = 0;
    long long int a = num.longLongValue;
    while (a != 0)
    {
        count ++;
        a /= 10;
    }
    NSMutableString *string = [NSMutableString stringWithString:num];
    NSMutableString *newstring = [NSMutableString string];
    while (count > 3)
    {
        count -= 3;
        NSRange rang = NSMakeRange(string.length - 3, 3);
        NSString *str = [string substringWithRange:rang];
        [newstring insertString:str atIndex:0];
        [newstring insertString:@"," atIndex:0];
        [string deleteCharactersInRange:rang];
    }
    [newstring insertString:string atIndex:0];
    return  newstring;
}


@end

