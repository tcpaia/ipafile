//
//  NSString+Ex.h
//  TSSProject
//
//  Created by TSS on 15/12/17.
//  Copyright © 2015年 AIA. All rights reserved.
//
#import <Foundation/Foundation.h>


@interface NSString (Ex)

- (NSInteger) indexOf:(NSString *) format;
- (NSInteger) indexOf:(NSString *) format fromIndex: (NSUInteger)fromIndex;
- (NSInteger) lastIndexOf:(NSString *) format;

- (NSString *) subString:(NSUInteger) fromIndex toIndex:(NSUInteger) toIndex;

- (BOOL) contains:(NSString *)str;

- (BOOL) equalsIgnoreCase:(NSString *) str;

- (NSString *) ltrim;
- (NSString *) rtrim;
- (NSString *) trim;
- (NSString *) replace:(NSString *) find replaceWith: (NSString *)replace;

- (BOOL) startsWith:(NSString *) format;
- (BOOL) endsWith:(NSString *) format;

- (NSString *)toUpperCase;
- (NSString *)toLowerCase;

-(NSString *) reverseString;
- (NSString *) componentsSeparatedByString:(NSString *) string atIndex:(int) index;
- (NSString *)escapeHTML;
+(NSString *)countNumAndChangeformat:(NSString *)num;
@end
