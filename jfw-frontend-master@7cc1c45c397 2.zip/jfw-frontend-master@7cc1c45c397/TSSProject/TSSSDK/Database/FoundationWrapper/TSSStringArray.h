//
//  TSSStringArray.h
//  TSSProject
//
//  Created by TSS on 15/12/17.
//  Copyright © 2015年 AIA. All rights reserved.
//
#import "TSSArray.h"


@interface TSSStringArray : TSSArray {
    
}

+ (id) arrayWithCapacity:(NSUInteger)numItems;

+ (id) arrayWithStrings:(NSString *)firstString, ... NS_REQUIRES_NIL_TERMINATION;

- (id) initWithStrings:(NSString *)firstString, ... NS_REQUIRES_NIL_TERMINATION;

- (void) addString:(NSString *) value;

- (void) deleteString:(NSString *) value;

- (NSString *) getStringAtIndex:(NSUInteger)index;

- (void) setStringAtIndex:(NSUInteger)index with:(NSString *)value;

- (BOOL) containsString:(NSString *)value;

- (int) findString:(NSString *)value;

@end
