//
//  TSSStringArray.m
//  TSSProject
//
//  Created by TSS on 15/12/17.
//  Copyright © 2015年 AIA. All rights reserved.
//

#import "TSSStringArray.h"
#import "TSSArray.h"


@implementation TSSStringArray

+ (id) arrayWithCapacity:(NSUInteger)numItems
{
    return [[TSSStringArray alloc] initWithCapacity:numItems];
}

+ (id) arrayWithObjects:(id)firstObj, ...
{
    TSSStringArray *a = [[TSSStringArray alloc] init];
    
    va_list args;
    va_start(args, firstObj);
    for (id arg = firstObj; arg != nil; arg = va_arg(args, id))
    {
        [a addObject:arg];
    }
    va_end(args);
    
    return a;
}


- (id) initWithObjects:(id)firstObj, ...
{
    if ((self = [self init]))
    {
        va_list args;
        va_start(args, firstObj);
        for (id arg = firstObj; arg != nil; arg = va_arg(args, id))
        {
            [self addObject:arg];
        }
        va_end(args);
    }
    return self;
}


+ (id) arrayWithStrings:(NSString *)firstString, ...
{
    TSSStringArray *a = [[TSSStringArray alloc] init];
    
    va_list args;
    va_start(args, firstString);
    for (NSString *arg = firstString; arg != nil; arg = va_arg(args, NSString *))
    {
        [a addString:arg];
    }
    va_end(args);
    
    return a;
}

- (id) initWithStrings:(NSString *)firstString, ...
{
    if ((self = [super init]))
    {
        va_list args;
        va_start(args, firstString);
        for (NSString *arg = firstString; arg != nil; arg = va_arg(args, NSString *))
        {
            [self addString:arg];
        }
        va_end(args);
    }
    return self;
}

- (void) addString:(NSString *) value
{
    [super addObject:value];
}

- (void) deleteString:(NSString *) value
{
    [super deleteObject:value];
}

- (NSString *) getStringAtIndex:(NSUInteger)index
{
    return [super getObjectAtIndex:index];
}

- (void) setStringAtIndex:(NSUInteger)index with:(NSString *)value
{
    [super setObjectAtIndex:index with:value];
}

- (BOOL) containsString:(NSString *)value
{
    return [super containsObject:value];
}

- (int) findString:(NSString *)value
{
    if (value== nil) return -1;
    for (int i = 0; i < [self count]; i++)
    {
        if ([[self getStringAtIndex:i] isEqualToString:value]) return i;
    }
    return -1;
}


@end
