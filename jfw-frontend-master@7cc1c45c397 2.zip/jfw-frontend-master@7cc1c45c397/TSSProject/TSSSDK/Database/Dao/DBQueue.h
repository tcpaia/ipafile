//
//  DBQueue.h
//  TSSProject
//
//  Created by TSS on 15/12/17.
//  Copyright © 2015年 AIA. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDB.h"
#import "sqlite3.h"
#import "AIABlockConstant.h"
#import "TSSStringArray.h"
#import "SystemTss.h"


@interface DBQueue : NSObject

SHAREDINSTANCE_DECLARATION(DBQueue)

@property (nonatomic, strong) FMDatabaseQueue *dbQueue;
@property (nonatomic, strong) FMDatabase *sqlite_db;
@property (nonatomic, strong) NSString *dbName;
@property (nonatomic, strong) NSString *dbPath;
@property (nonatomic, strong) NSString *dbKey;

- (instancetype)initWithDBName:(NSString *)dbName dbKey:(NSString *)dbKey isAppGroupPath:(BOOL)isAppGroupPath;
- (void)init:(NSString *)dbName dbKey:(NSString *)dbKey dbPath:(NSString*)path;
- (void)init:(NSString *)dbName dbKey:(NSString *)dbKey reKey:(NSString*)reKey isAppGroupPath:(BOOL)isAppGroupPath;
- (void)createTable;
- (void)insertTestRecord;

- (NSMutableArray *)query:(NSString *)querySql block:(AIASetBeanValueBlock)block;
- (BOOL)saveOrUpdate:(NSString *)sql;
- (BOOL)saveOrUpdate:(NSString *)sql args:(NSMutableDictionary *) args;
- (NSMutableDictionary *)query:(Bean *)bean tableName:(NSString *) tableName primaryColumnName:(NSString *) primaryColumnName columnDetails:(NSMutableArray *) columnDetails;
//sql injection for add parameters ?
- (NSMutableArray *) select:(NSString *)sql includeMetadata:(BOOL)includeMetadata parameters:(NSArray*)parameters;

@end
