//
//  AbstractDao.m
//  TSSProject
//
//  Created by TSS on 15/12/17.
//  Copyright © 2015年 AIA. All rights reserved.
//

#import "AbstractDao.h"
#import "DBQueue.h"
#import "TSSValidationUtil.h"
#import "SystemTss.h"
#import "FoundationWrapper.h"
#import "CoreConstant.h"
#import "TSSAppData.h"

@interface AbstractDao()

@property (nonatomic, strong) DBQueue *dq;

@end

@implementation AbstractDao

long long int lastTimestamp;
static NSString *hardwareId;
static NSString *prefixPrimaryKey;

+ (void) initialize
{
    //hardwareId = [[NSString alloc] initWithString:[[AIAHardwareUtil getSerialNumber] replace:@"-" replaceWith:@""]];
    hardwareId = @"ipad";
}

+ (AbstractDao *)sharedInstance
{
    static AbstractDao *sharedInstance;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        sharedInstance = [[AbstractDao alloc] init];
    });
    return sharedInstance;
}
- (instancetype)init:(NSString *)tableName_ primaryColumnName:(NSString *)primaryColumnName_ columnDetails:(NSMutableArray *)columnDetails_
{
    self = [super init];
    if (self) {
        self.tableName = tableName_;
        self.columnDetails = columnDetails_;
        self.primaryColumnName = primaryColumnName_;

        [self.columnDetails insertObject:[NSMutableArray arrayWithObjects:self.primaryColumnName, FORMAT(@"%@%@", SQLITE_SQL_TEXT, SQLITE_SQL_PRIMARY_KEY), SQLITE_T_STRING, nil] atIndex:0];
        [self.columnDetails addObject:[NSMutableArray arrayWithObjects:UPDATE_COLUMN_NAME, SQLITE_T_DATE_TIME, nil]];
        [self.columnDetails addObject:[NSMutableArray arrayWithObjects:CREATE_COLUMN_NAME, SQLITE_T_DATE_TIME, nil]];
        
        int length = [self.columnDetails count];
        for (int i = 1; i < length; i++)
        {
            NSMutableArray *row = [self.columnDetails objectAtIndex:i];
            if ([row count]==2)
            {
                [row insertObject:[self convertType:[[self.columnDetails objectAtIndex:i] objectAtIndex:1]] atIndex:1];
            }
        }
        [self createSqlStatement];
    }
    return self;
}
- (void) initWithDB
{
    @try
    {
        [self openDB];
    }
    @catch (NSException *e)
    {

    }
}
- (void)createTable
{
    [_dq createTable];
}
- (void)insertTestRecord
{
    [_dq insertTestRecord];
}
- (NSMutableArray *)selectAll
{
    return [self selectAllWhere:nil parameters:nil];
}

- (id) selectFirst
{
    NSMutableArray *array = [self selectAll];
    return [TSSValidationUtil isNilOrNull:array] ? nil : [array objectAtIndex:0];
}

- (BOOL)saveOrUpdate:(Bean *)bean
{
    [self createSqlStatement];
    
    NSMutableDictionary *args =[self getBeanValue:bean];
    NSDate *now = [NSDate date];

    DBQueue *dq =_dq;
    
    if ([TSSValidationUtil convertNullToNil:[args objectForKey:self.primaryColumnName]]==nil)
    {
        //set IDkey
        NSString *idKey = [self getNextId];
        [args setObject:idKey forKey:self.primaryColumnName];

        if (bean.idKey ==nil) {
            [args setObject:now forKey:CREATE_COLUMN_NAME];
            [args setObject:now forKey:UPDATE_COLUMN_NAME];
            [dq saveOrUpdate:self.insertSql args:args];
            bean.idKey = idKey;
        }else
        {
            [args setObject:now forKey:UPDATE_COLUMN_NAME];
            [dq saveOrUpdate:self.updateSql args:args];
        }
    }else{

        [args setObject:now forKey:UPDATE_COLUMN_NAME];
        [dq saveOrUpdate:self.updateSql args:args];
    }
    
    return YES;
}
- (BOOL)saveOrUpdateArray:(NSMutableArray *)beanArray{
    
    [_dq.sqlite_db beginTransaction];
    @try {
        for (Bean *bean in beanArray) {
            [self saveOrUpdate:bean];
        }
    }
    @catch (NSException *exception) {
        [_dq.sqlite_db rollback];
    }
    @finally {
        [_dq.sqlite_db commit];
    }
    return YES;
}

- (void) initWithDB:(DBQueue *)dbQeue
{
    @try
    {
        _dq = dbQeue;
        [self openDB:dbQeue];
    }
    @catch (NSException *e)
    {

    }
}

- (BOOL)openDB:(DBQueue *)dbQueue
{
    [dbQueue saveOrUpdate:[self createTableSql]];
    return YES;
}


- (BOOL)openDB
{
    _dq = [DBQueue sharedInstance];
    [_dq saveOrUpdate:[self createTableSql]];
    
    return YES;
}

- (void) createSqlStatement
{
    NSMutableString *colString = [[NSMutableString alloc] init];
    [colString appendFormat:@"INSERT INTO %@ (", self.tableName];
    NSMutableString *valString = [[NSMutableString alloc] init];
    [valString appendString:@"VALUES ("];
    
    [colString appendFormat:@"%@, ", self.primaryColumnName];
    [valString appendFormat:@":%@, ",self.primaryColumnName];
    
    int length = [self.columnDetails count];
    for (int i = 1; i < length; i++)
    {
        [colString appendFormat:@"%@, ",[[self.columnDetails objectAtIndex:i] objectAtIndex:0]];
        [valString appendFormat:@":%@, ",[[self.columnDetails objectAtIndex:i] objectAtIndex:0]];
    }
    [colString replaceCharactersInRange:NSMakeRange([colString length]-2, 1) withString:@")"];
    [valString replaceCharactersInRange:NSMakeRange([valString length]-2, 1) withString:@")"];
    
    self.insertSql = [NSString stringWithFormat:@"%@ %@", colString, valString];
    [colString replaceCharactersInRange:NSMakeRange(0, 6) withString:@"REPLACE"];
    self.replaceSql = [NSString stringWithFormat:@"%@ %@", colString, valString];
    
    
    NSMutableString *sql = [[NSMutableString alloc] init];
    [sql appendFormat:@"UPDATE %@ SET ", self.tableName];
    
    for (int i=1; i<length; i++)
    {
        [sql appendFormat:@"%@ = :%@, ", [[self.columnDetails objectAtIndex:i] objectAtIndex:0],[[self.columnDetails objectAtIndex:i] objectAtIndex:0]];
    }
    [sql replaceCharactersInRange:NSMakeRange([sql length]-2, 1) withString:@" "];
    [sql appendFormat:@"WHERE %@ = :%@", self.primaryColumnName, self.primaryColumnName];
    self.updateSql = [NSString stringWithFormat:@"%@", sql];
    
}

- (NSString *) createTableSql
{

    NSMutableString *sql = [NSMutableString stringWithFormat:@"CREATE TABLE IF NOT EXISTS %@ (", self.tableName];
    [sql appendFormat:@"%@ %@",
     [[self.columnDetails objectAtIndex:0] objectAtIndex:0],
     [[self.columnDetails objectAtIndex:0] objectAtIndex:1]

     ];
    
    int length = [self.columnDetails count];
    
    for (int i = 1; i < length; i++)
    {
        [sql appendFormat:@", %@ %@",
         [[self.columnDetails objectAtIndex:i] objectAtIndex:0],
         [[self.columnDetails objectAtIndex:i] objectAtIndex:1]
         ];
    }
    [sql appendString:@")"];
    
    return sql;
}

- (NSString *) getNextId
{
    long long int timestamp = (long long int)([[NSDate date] timeIntervalSince1970]*1000);
    while (lastTimestamp == timestamp)
    {
        timestamp = (long long int)([[NSDate date] timeIntervalSince1970]*1000);
    }
    
    lastTimestamp = timestamp;
    return FORMAT(@"%lld%@", timestamp,[TSSAppData getInstance].agentCode);
}

+ (void) setPrimaryKeyPrefix:(NSString *)pref
{
    prefixPrimaryKey = [[NSString alloc] initWithString:pref];
}

- (BOOL) get:(Bean *)bean
{
    NSMutableDictionary *ht=[_dq query:bean tableName:self.tableName primaryColumnName:self.primaryColumnName columnDetails:self.columnDetails];
    if ([ht allKeys].count>0) {
        [self setBeanValue:ht forBean:bean];
        return YES;
    }
    else
    {
        return NO;
    }
}

//get with id
- (id) getWithId:(NSString *) idKey
{
    return [self selectWithId:idKey];
}

- (id) selectWithId: (NSString *) idKey
{
    Bean *bean = [self createBean];
    bean.idKey = idKey;
    
    if ([self get: bean])
    {
        return bean;
    }else{
        return nil;
    }
}

- (id) selectOneWhere:(NSString *) whereClause
{
    NSMutableArray *result = [self selectAllWhere:whereClause parameters:nil];
    
    if (result.count > 0)
    {
        return [result objectAtIndex:0];
    }
    else
    {
        return nil;
    }
}

- (NSUInteger) selectCountForCountSubSql: (NSString *)countSubSql andWhere:(NSString *)whereClause andParameters: (NSArray *) parameters
{
    NSMutableString *sql = [NSMutableString stringWithFormat: @"select %@ as quantity from %@ %@ ", countSubSql, self.tableName, whereClause];
    NSMutableArray *result = [self excuteSql:sql parameters:parameters];
    if (result != nil && result.count > 0) {
        NSDictionary *dic = [result objectAtIndex: 0];
        NSNumber *num = [dic objectForKey: @"quantity"];
        return [num integerValue];
    }
    return 0;
}

- (NSMutableArray *) selectbysql: (NSString *) sql parameters:(NSArray*)parameters andConvertResutToBeanFlag: (BOOL) convertFlag
{
    
    NSMutableArray *result = nil;
    
    @try
    {
        DBQueue *dq =_dq;
        result = [dq select: sql includeMetadata: YES parameters:parameters];
    }
    @catch (NSException *e)
    {
        DLog(@"selectbysql Exception:%@",[e description]);
        return nil;
    }
    
    if (convertFlag == YES) {
        NSMutableArray *res =nil;
        if (result!=nil && result.count >0) {
            @try {
                res = [self convertResultSetToBean: result sqliteDao: self];
            } @catch (NSException *e) {
                DLog(@"selectbysql Exception:%@",[e description]);
            }
            return res;
        }
    }
    return result;
}

- (NSMutableArray *) selectAllWhere: (NSString *) whereClause parameters:(NSArray*)parameters
{
    NSString *sql = [NSString stringWithFormat: @"SELECT * FROM %@ %@", self.tableName, [TSSValidationUtil convertNilToEmptyString: whereClause]];
    NSMutableArray *result = nil;
    
    @try
    {
        DBQueue *dq =_dq;
        result = [dq select: sql includeMetadata:YES parameters:parameters];
    }
    @catch (NSException *e)
    {
        DLog(@"selectAllWhere Exception:%@",[e description]);
        return nil;
    }
    
    NSMutableArray *res =nil;
    if (result!=nil && result.count >0) {
        res = [self convertResultSetToBean: result sqliteDao: self];
    }
    
    return res;
}

- (NSMutableArray *) excuteSql: (NSString *)sql
{
    NSMutableArray *result = nil;
    
    @try
    {
        DBQueue *dq =_dq;
        result = [dq select: sql includeMetadata: YES parameters:nil];
    }
    @catch (NSException *e)
    {
        return nil;
    }
    
    NSMutableArray *res =nil;
    if (result!=nil && result.count >0) {
        res = [self convertResultSetToBean: result sqliteDao: self];
    }
    
    return res;
}

- (NSMutableArray *) excuteSql: (NSString *)sql parameters:(NSArray*)parameters
{
    NSMutableArray *result = nil;

    @try
    {
        DBQueue *dq =_dq;
        result = [dq select: sql includeMetadata: NO parameters:parameters];
    }
    @catch (NSException *e)
    {
        return nil;
    }
    return result;
}

//delete all records
- (BOOL) deleteAll
{
    return [self deleteAllWhere:nil];
}

//delete record with id IDKey
- (BOOL)deleteWithID:(NSString *)IDKey
{
    if (IDKey == nil) return YES;
    return [self deleteAllWhere:[NSString stringWithFormat:@" WHERE %@ = '%@'", self.primaryColumnName, IDKey]];
}

- (BOOL) deleteAllWhere: (NSString *) whereClause
{
    @try
    {
        //if (self.pool != nil)
        {
            DBQueue *dq =_dq;
            if (whereClause == nil || [whereClause length] == 0)
            {
                NSMutableString *delsql =[NSMutableString stringWithFormat:@"DELETE FROM %@ ",self.tableName];
                [dq saveOrUpdate:delsql];
            }
            else
            {
                NSMutableString *delsql =[NSMutableString stringWithFormat:@"DELETE FROM %@ ",self.tableName];
                [delsql appendString:whereClause];
                [dq saveOrUpdate:delsql];
            }
        }
    }
    @catch (NSException *e)
    {
        return NO;
    }
    
    return YES;
}
//add column
- (void) addColumn:(NSString *)columnName type:(NSString *)type
{
    [_dq saveOrUpdate:[NSString stringWithFormat:@"ALTER TABLE %@ ADD %@ %@", self.tableName, columnName, type]];
}

- (void) updateTableAddColumn
{
    NSString *execSql = FORMAT(@"select * from sqlite_master where type='table' and name='%@'", self.tableName);
    
    NSMutableArray *arr =[_dq select:execSql includeMetadata:YES parameters:nil];
    if ([TSSValidationUtil isNilOrNull:arr] || 0 == arr.count) return;
    
    NSString *createSql =[[arr objectAtIndex:0] objectForKey:@"sql"];
    
    if (createSql == nil || [createSql isEqualToString:@""]) return;
    
    int length = [self.columnDetails count];
    NSString *searchSql = nil;
    for (int i = 0; i < length; i++)
    {
        searchSql = FORMAT(@"%@", [[self.columnDetails objectAtIndex:i] objectAtIndex:0]);
        
        if ([[createSql uppercaseString] indexOf:[searchSql uppercaseString]] > 0)
        {
            
        } else {
            @try {
                
                NSString *sql = [NSString stringWithFormat:@"ALTER TABLE %@ ADD %@ %@", self.tableName, [[self.columnDetails objectAtIndex:i] objectAtIndex:0], [[self.columnDetails objectAtIndex:i] objectAtIndex:1]];
                DLog(@"Alter table : %@", sql);
                DBQueue *dq =_dq;
                [dq saveOrUpdate:sql];
            }
            @catch (NSException *exception) {
                
            }
            @finally {
                
            }
        }
    }
}


- (int) getColumnBeanType:(NSString *)columnName
{
    NSInteger idx = [columnName indexOf:@"."];
    if (idx>=0) columnName = [columnName substringFromIndex:idx+1];
    NSUInteger length = [self.columnDetails count];
    
    for (int i = 0; i < length; i++)
    {
        if ([[[self.columnDetails objectAtIndex:i] objectAtIndex:0] equalsIgnoreCase:columnName])
            return [[[self.columnDetails objectAtIndex:i] objectAtIndex:2] intValue];
    }
    
    return -1;
}

- (NSMutableArray *) convertResultSetToBean:(NSMutableArray *) resultSet sqliteDao: (AbstractDao *) dao
{
    int count = [resultSet count];
    
    NSMutableArray *beans = [NSMutableArray arrayWithCapacity:count];
    
    [resultSet enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        id bean = [dao createBean];
        [dao setBeanValue:obj forBean:bean];
        
        [beans addObject:bean];
    }];
    return beans;
}

- (NSString *) convertType:(NSString *)type;
{
    switch ([type intValue])
    {
        case SQLITE_I_STRING:
            return SQLITE_SQL_TEXT;
            
        case SQLITE_I_DOUBLE:
        case SQLITE_I_FLOAT:
            return SQLITE_SQL_REAL;
            
        case SQLITE_I_BYTE_ARRAY:
            return SQLITE_SQL_BLOB;
    }
    return SQLITE_SQL_INTEGER;
}

- (TSSIntArray *) getColumnTypes:(TSSStringArray *)columnNames forSqliteDao: (AbstractDao *) dao
{
    int length = [columnNames count];
    TSSIntArray *types = [[TSSIntArray alloc] init];
    
    for (int i = 0; i < length; i++)
    {
        [types addInt:[dao getColumnBeanType:(NSString *)[columnNames getStringAtIndex:i]]];
    }
    return types;
}

- (NSMutableDictionary *) getBeanValue:(Bean *) bean
{
    //AbstractMethod;
    return nil;
}
- (void) setBeanValue:(NSMutableDictionary *) htRow forBean: (Bean *) bean
{
   // AbstractMethod;
}
- (id) createBean
{
   // AbstractMethod;
    return nil;
}

-(NSMutableArray*)readValuesFromTablePlist:(NSString*)tableName
{
    NSString *plist_name = FORMAT(@"%@.plist",tableName);
    NSString *settingPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:plist_name];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if (![fileManager fileExistsAtPath:settingPath])
    {
        DLog(@"Don't exist table plist file");
        
        return nil;
    }
    NSDictionary *tableColumeItems = [[NSMutableDictionary alloc] initWithContentsOfFile:settingPath];
    
    NSMutableArray *tableColumeItemsArray = [NSMutableArray array];
    
    NSArray *keys;
    int i, count;
    id key, value;
    keys = [tableColumeItems allKeys];
    count = [keys count];
    for (i=0; i<count; i++)
    {
        key = [keys objectAtIndex:i];
        value = [tableColumeItems objectForKey:key];
        
        NSMutableArray *tempArray = [NSMutableArray arrayWithObjects:key,value, nil];
        [tableColumeItemsArray addObject:tempArray];
    }

    return tableColumeItemsArray;
}

- (NSMutableArray *)getColumns:(NSArray *)columns andDatas:(NSArray *)datas{
    NSMutableArray *array = [NSMutableArray arrayWithCapacity:datas.count];
    NSArray *data = nil;
    NSMutableDictionary *dict = nil;
    int j = 0;
    for (int i = 0; i < datas.count; i++) {
        data = datas[i];
        dict = [NSMutableDictionary dictionary];
        for (j = 0; j < data.count; j++) {
            [dict setValue:data[j] forKey:columns[j]];
        }
        [array addObject:dict];
    }
    return array;
}

- (void) saveDataFromWebServiceForTable:(NSDictionary *)dict{
    NSArray *columns = dict[BP_WEBSERVICE_COLUMNS];
    NSArray *datas = dict[BP_WEBSERVICE_DATAS];
    NSMutableArray *dataArray = [self getColumns:columns andDatas:datas];
    Bean *bean = nil;
    NSMutableArray *beanArray = [NSMutableArray arrayWithCapacity:dataArray.count];
    for (int i = 0; i < dataArray.count; i++) {
        bean = [self createBean];
        [self setBeanValue:dataArray[i] forBean:bean];
        
        [beanArray addObject:bean];
    }
    [self saveOrUpdateArray:beanArray];
}
@end

