//
//  DBQueue.m
//  TSSProject
//
//  Created by TSS on 15/12/17.
//  Copyright © 2015年 AIA. All rights reserved.
//

#import "DBQueue.h"
#import "TSSValidationUtil.h"
#import "AppDelegate.h"
#import "FoundationWrapper.h"
#import "CoreConstant.h"

@implementation DBQueue
SHAREDINSTANCE_IMPLEMENTATION(DBQueue)

@synthesize sqlite_db;

- (instancetype)init
{
    self = [super init];
    if (self) {
        return self;
    }
    else
    {
        return nil;
    }
    
}

- (instancetype)initWithDBName:(NSString *)dbName dbKey:(NSString *)dbKey isAppGroupPath:(BOOL)isAppGroupPath
{
    self = [super init];
    if (self) {

        self.dbName = dbName;
        self.dbKey = dbKey;
        
        if (isAppGroupPath)
        {
            _dbQueue = [FMDatabaseQueue databaseQueueWithPath:[self dbAppGroupPath]];
        }
        else
        {
            _dbQueue = [FMDatabaseQueue databaseQueueWithPath:[self dbDocumentPath]];
        }
        
        [_dbQueue inDatabase:^(FMDatabase *db)
         {
             if (![TSSValidationUtil isNilOrNull:_dbKey])
             {
                 [db setKey:_dbKey];
             }
             self.sqlite_db = db;
             
         }];
    }
    return self;
}


- (void)init:(NSString *)dbName dbKey:(NSString *)dbKey dbPath:(NSString*)path
{
    self.dbName = dbName;
    self.dbKey = dbKey;
    
    if ([path isEqualToString:APP_GROUP_PATH])
    {
        _dbQueue = [FMDatabaseQueue databaseQueueWithPath:[self dbAppGroupPath]];
    }
    else if([path isEqualToString:DOCUMENT_PATH])
    {    DLog(@"---%@",[self dbDocumentPath]);

        _dbQueue = [FMDatabaseQueue databaseQueueWithPath:[self dbDocumentPath]];
    }
    else
    {
        _dbQueue = [FMDatabaseQueue databaseQueueWithPath:[self applicationResourceDirectory]];
    }
    
        [_dbQueue inDatabase:^(FMDatabase *db)
         {
             if (![TSSValidationUtil isNilOrNull:_dbKey])
             {
                 [db setKey:_dbKey];
                 //[db setKeyWithData:_dbKey];
             }
             self.sqlite_db = db;
             
         }];
}

- (void)init:(NSString *)dbName dbKey:(NSString *)dbKey reKey:(NSString*)reKey isAppGroupPath:(BOOL)isAppGroupPath
{
    self.dbName = dbName;
    self.dbKey = dbKey;
    
    if (isAppGroupPath)
    {
        _dbQueue = [FMDatabaseQueue databaseQueueWithPath:[self dbAppGroupPath]];
    }
    else
    {    DLog(@"---%@",[self dbDocumentPath]);
        
        _dbQueue = [FMDatabaseQueue databaseQueueWithPath:[self dbDocumentPath]];
    }
    
    [_dbQueue inDatabase:^(FMDatabase *db)
     {
         if (![TSSValidationUtil isNilOrNull:_dbKey])
         {
             [db setKey:_dbKey];
             [db rekey:reKey];
         }
         self.sqlite_db = db;
         
     }];

}

- (NSString *)dbAppGroupPath
{
    return nil;
}

- (NSString *)applicationResourceDirectory
{
    NSString *resourcePath = [[NSBundle mainBundle] resourcePath];
   NSString *dbPath =  [resourcePath stringByAppendingPathComponent:self.dbName];
    return dbPath;
}

- (NSString *)dbDocumentPath
{
    if (!_dbPath) {
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        _dbPath = [documentsDirectory stringByAppendingPathComponent:_dbName];
    }
    DLog(@"Database path: %@", _dbPath);
    return _dbPath;
}

- (void)createTable
{
    [_dbQueue inDatabase:^(FMDatabase *db) {
        [db executeUpdate:@"create table IF NOT EXISTS AgentProfile(AgentProfileID text primary key, AgentCode text NOT NULL, AgentName text, Age integer);"];
        [db executeUpdate:@"create table IF NOT EXISTS TestTable(IDKey text primary key, Column1 text, Column2 integer, Column3 blob, CreateTime integer, LastUpdateTime integer);"];
        
    }];
}

- (void)insertTestRecord
{
    [_dbQueue inDatabase:^(FMDatabase *db) {
        [db executeUpdate:@"insert into AgentProfile values (?,?,?,?)",@"id_1",@"agtCode_1",@"agtName_1", @4];
        [db executeUpdate:@"insert into TestTable (IDKey"
         ",Column1"
         ",Column2"
         ",Column3"
         ",CreateTime"
         ",LastUpdateTime"
         ")"
         "values (?"
         ",?"
         ",?"
         ",?"
         ",?"
         ",?"
         ")"
         ,@"idkey1"
         ,@"column1"
         ,@4
         ,[@"asdf" dataUsingEncoding:NSUTF8StringEncoding]
         ,@([[NSDate date] timeIntervalSince1970]*1000)
         ,@([[NSDate date] timeIntervalSince1970]*1000)
         ];
        [db executeUpdate:@"insert into TestTable (IDKey"
         ",Column1"
         ",Column2"
         ",Column3"
         ",CreateTime"
         ",LastUpdateTime"
         ")"
         "values (?"
         ",?"
         ",?"
         ",?"
         ",?"
         ",?"
         ")"
         ,@"idkey2"
         ,@"column1"
         ,@4
         ,[@"asdf" dataUsingEncoding:NSUTF8StringEncoding]
         ,@([[NSDate date] timeIntervalSince1970]*1000)
         ,@([[NSDate date] timeIntervalSince1970]*1000)
         ];
        if ([db hadError]) {

        }
    }];
}

- (NSMutableArray *)query:(NSString *)querySql block:(AIASetBeanValueBlock)block
{
    NSMutableArray *resultArr = [NSMutableArray array];
    FMResultSet *result = [self.sqlite_db executeQuery:querySql];
    while ([result next]) {
        if (block) {
            Bean *bean = block(result);
            [resultArr addObject:bean];
        }
    }
    if ([sqlite_db hadError]) {

    }
    return resultArr;
}
- (NSMutableDictionary *)query:(Bean *)bean tableName:(NSString *) tableName primaryColumnName:(NSString *) primaryColumnName columnDetails:(NSMutableArray *) columnDetails
{
    NSString *idKey = bean.idKey;
    if (idKey==nil) return NO;
    NSString *query =[NSString stringWithFormat:@"SELECT * FROM %@ WHERE %@ = ?",tableName,primaryColumnName];
    NSArray *parameters = [NSArray arrayWithObjects: idKey, nil];
    
    __block NSMutableDictionary *ht = nil;
    
    FMResultSet *result = [self.sqlite_db executeQuery:query withArgumentsInArray: parameters];

    int numFields =[result columnCount];
    
    ht =[[NSMutableDictionary alloc] initWithCapacity:numFields];
    
    int i = 0;
    NSString *columnName = nil;
    while ([result next]) {
        for (i = 0; i < numFields; i++)
        {
            columnName =[result columnNameForIndex:i];
            if ([result columnIndexIsNull:i]) {
                [ht setObject:[NSNull null] forKey:columnName];
                continue;
            }
            
            switch ([self getColumnBeanType:columnName columnDetails:columnDetails])
            {
                case SQLITE_I_STRING: [ht setObject:[result stringForColumnIndex:i] forKey:columnName]; break;
                case SQLITE_I_INTEGER: [ht setObject:[NSNumber numberWithInt:[result intForColumnIndex:i]] forKey:columnName]; break;
                case SQLITE_I_LONG: [ht setObject:[NSNumber numberWithLongLong:[result longForColumnIndex:i]] forKey:columnName]; break;
                case SQLITE_I_DOUBLE: [ht setObject:[NSNumber numberWithDouble:[result doubleForColumnIndex:i]] forKey:columnName]; break;
                case SQLITE_I_SHORT: [ht setObject:[NSNumber numberWithShort:[result intForColumnIndex:i]] forKey:columnName]; break;
                case SQLITE_I_FLOAT: [ht setObject:[NSNumber numberWithFloat:[result doubleForColumnIndex:i]] forKey:columnName]; break;
                case SQLITE_I_DATE: [ht setObject:[NSNumber numberWithInt:[result intForColumnIndex:i]] forKey:columnName]; break;
                case SQLITE_I_DATE_TIME: [ht setObject:[NSDate dateWithTimeIntervalSince1970:[result longForColumnIndex:i]/1000.0] forKey:columnName]; break;
                case SQLITE_I_BOOLEAN: [ht setObject:[NSNumber numberWithInt:[result intForColumnIndex:i]] forKey:columnName]; break;
                case SQLITE_I_BYTE_ARRAY: [ht setObject:[TSSValidationUtil convertNilToNull:[result dataForColumnIndex:i]] forKey:columnName]; break;
            }
        }
    }

    if ([self.sqlite_db hadError]) {

    }
    return ht;
}
- (BOOL)saveOrUpdate:(NSString *)sql
{

    if ([TSSValidationUtil isNilOrEmptyString:sql]) {
        return NO;
    }
    __block BOOL returnValue = YES;
    
    [self.sqlite_db executeUpdate:sql];
    if ([self.sqlite_db hadError]) {
        returnValue = NO;
    }

    return returnValue;
}


- (BOOL)saveOrUpdate:(NSString *)sql args:(NSMutableDictionary *) args
{
    if ([TSSValidationUtil isNilOrEmptyString:sql]) {
        return NO;
    }
    __block BOOL returnValue = YES;
    
    [self.sqlite_db executeUpdate:sql withParameterDictionary:args ];
    if ([self.sqlite_db hadError]) {
        returnValue = NO;
    }
    return returnValue;
}
- (int) getColumnBeanType:(NSString *)columnName columnDetails:(NSMutableArray *) columnDetails
{
    NSInteger idx = [columnName indexOf:@"."];
    if (idx>=0) columnName = [columnName substringFromIndex:idx+1];
    NSUInteger length = [columnDetails count];
    
    for (int i = 0; i < length; i++)
    {
        if ([[[columnDetails objectAtIndex:i] objectAtIndex:0] equalsIgnoreCase:columnName])
            return [[[columnDetails objectAtIndex:i] objectAtIndex:2] intValue];
    }
    
    return -1;
}
- (NSMutableArray *) select:(NSString *)sql includeMetadata:(BOOL)includeMetadata parameters:(NSArray*)parameters
{
    return [self select:sql includeMetadata:includeMetadata columnMap:nil parameters:parameters];
}
- (NSMutableArray *) select:(NSString *)sql includeMetadata:(BOOL)includeMetadata columnMap:(NSDictionary *)columnMap parameters:(NSArray*)parameters
{
    
    FMResultSet *query = [self.sqlite_db executeQuery:sql withArgumentsInArray:parameters];
    
    int count = [query columnCount];
    
    NSMutableArray *result = [NSMutableArray arrayWithCapacity:count];
    
    while ([query next]) {
        [result addObject:[query resultDictionary]];
    }
    return result;
}


@end
