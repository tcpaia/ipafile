//
//  TestDao.m
//  TSSProject
//
//  Created by TSS on 15/12/17.
//  Copyright © 2015年 AIA. All rights reserved.
//

#import "TestDao.h"
#import "TestBean.h"
#import "Singleton.h"
#import "TSSValidationUtil.h"
#import "SystemTss.h"
#import "TSSFileManager.h"
//#import "TestBeanConstant.h"

@implementation TestDao


SYNTHESIZE_SINGLETON_FOR_CLASS(TestDao);

- (id) init
{
    //TEST_BEAN_COLUMN_DETAILS;
    NSMutableArray *tableColumes = [self readValuesFromTablePlist:TEST_BEAN_TABLE];
    self = [super init:TEST_BEAN_TABLE primaryColumnName:BEAN_ID columnDetails:tableColumes];
    
    if (self) {
        self.setBeanValueBlock = ^(FMResultSet *result)
        {
            TestBean *o = [TestBean new];
            return o;
        };
        self.getBeanValueBlock = ^(Bean *bean) {
            return [NSMutableDictionary dictionary];
        };
    }
    return self;
}

- (void) initWithDB
{
    @try
    {
        [self openDB];
    }
    @catch (NSException *e)
    {

    }
}

- (NSMutableDictionary *) getBeanValue:(Bean *) bean
{
    NSMutableDictionary *ht = [NSMutableDictionary dictionaryWithCapacity:[self.columnDetails count]];
    TestBean *o = (TestBean *) bean;
    NSMutableArray *temp = [NSMutableArray arrayWithArray:[o allPropertyNames]];
    for (int i=0; i<temp.count; i++)
    {
        [self htSetObject:ht forBean:o selName:[temp objectAtIndex:i]];
    }
    
    [ht setObject:[TSSValidationUtil convertNilToNull:o.idKey] forKey:BEAN_ID];
    [ht setObject:[TSSValidationUtil convertNilToNull:o.updatedate] forKey:UPDATE_COLUMN_NAME];
    [ht setObject:[TSSValidationUtil convertNilToNull:o.createdate] forKey:CREATE_COLUMN_NAME];
    
    return ht;
}

-(void)htSetObject:(NSMutableDictionary*) ht forBean:(TestBean*)bean selName:(NSString*)name;
{
    [ht setObject:[TSSValidationUtil convertNilToNull:[bean doGetMethord:name]] forKey:name];
}

- (void) setBeanValue:(NSMutableDictionary *) ht forBean: (Bean *) bean
{
    TestBean *o = (TestBean *) bean;
    
    o.idKey = [TSSValidationUtil convertNullToNil:[ht objectForKey:BEAN_ID]];
    o.updatedate = [TSSValidationUtil convertNullToNil:[ht objectForKey:UPDATE_COLUMN_NAME]];
    o.createdate = [TSSValidationUtil convertNullToNil:[ht objectForKey:CREATE_COLUMN_NAME]];
    
    [o assginToPropertyWithDictionary:ht];
}

- (id) createBean
{
    return [[TestBean alloc] init];
}

@end
