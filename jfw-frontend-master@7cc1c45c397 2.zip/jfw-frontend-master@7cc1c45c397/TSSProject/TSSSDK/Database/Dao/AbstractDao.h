//
//  AbstractDao.h
//  TSSProject
//
//  Created by TSS on 15/12/17.
//  Copyright © 2015年 AIA. All rights reserved.
//

#import "Bean.h"
#import "FMDB.h"
#import "AIABlockConstant.h"
#import "TSSStringArray.h"
#import "TSSIntArray.h"
#import "DBQueue.h"

#define UPDATE_COLUMN_NAME @"updatedate"
#define CREATE_COLUMN_NAME @"createdate"

#define BP_WEBSERVICE_COLUMNS @"columns"
#define BP_WEBSERVICE_DATAS @"data"

#define EXTEND_GOAL_USERCODE @"usercode"
#define EXTEND_GOAL_KPI @"kpi"
#define EXTEND_GOAL_SUMVALUE @"sumvalue"


@interface AbstractDao : NSObject

+ (AbstractDao *)sharedInstance;
- (instancetype)init:(NSString *)tableName_ primaryColumnName:(NSString *)primaryColumnName_ columnDetails:(NSMutableArray *)columnDetails_;
- (void) initWithDB;

@property (nonatomic, retain) NSString *insertSql;
@property (nonatomic, retain) NSString *updateSql;
@property (nonatomic, retain) NSString *replaceSql;
@property (nonatomic, strong) NSString *tableName;
@property (nonatomic, strong) NSString *primaryColumnName;
@property (nonatomic, strong) NSMutableArray *columnDetails;
@property (nonatomic, strong) AIASetBeanValueBlock setBeanValueBlock;
@property (nonatomic, strong) AIAGetBeanValueBlock getBeanValueBlock;

+ (void) setPrimaryKeyPrefix:(NSString *)pref;
- (void)createTable;

//update
- (BOOL)saveOrUpdate:(Bean *)bean;
- (BOOL)saveOrUpdateArray:(NSMutableArray *)beanArray;
- (BOOL)openDB:(DBQueue *)dbQueue;
- (void) initWithDB:(DBQueue *)dbQeue;
- (BOOL)openDB;
- (NSMutableDictionary *) getBeanValue:(Bean *) bean;
- (void) setBeanValue:(NSMutableDictionary *) htRow forBean: (Bean *) bean;
- (id) createBean;
//delete
- (BOOL) deleteAll;
- (BOOL) deleteWithID: (NSString *) IDKey;
- (BOOL) deleteAllWhere: (NSString *) whereClause;
//get
- (NSMutableArray *)selectAll;
- (id) selectFirst;
- (id) getWithId:(NSString *) idKey;
- (id) selectWithId: (NSString *) idKey;
- (id) selectOneWhere:(NSString *) whereClause;
- (NSUInteger) selectCountForCountSubSql: (NSString *)countSubSql andWhere:(NSString *)whereClause andParameters: (NSArray *) parameters;
//FOR SQL INJECTION
- (NSMutableArray *) selectAllWhere: (NSString *) whereClause parameters:(NSArray*)parameters;

//add column
- (void) addColumn:(NSString *)columnName type:(NSString *)type;
- (void) updateTableAddColumn;
- (NSMutableArray *) excuteSql: (NSString *)sql;
- (NSMutableArray *) excuteSql: (NSString *)sql parameters:(NSArray*)parameters;

-(NSMutableArray*)readValuesFromTablePlist:(NSString*)tableName;

- (NSMutableArray *)getColumns:(NSArray *)columns andDatas:(NSArray *)datas;
- (void) saveDataFromWebServiceForTable:(NSDictionary *)dict;
- (NSMutableArray *) selectbysql: (NSString *) sql parameters:(NSArray*)parameters andConvertResutToBeanFlag: (BOOL) convertFlag;

@end

