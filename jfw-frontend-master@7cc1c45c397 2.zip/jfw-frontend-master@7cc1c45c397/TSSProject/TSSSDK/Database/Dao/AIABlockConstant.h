//
//  AIABlockConstant.h
//  TSSProject
//
//  Created by TSS on 15/12/17.
//  Copyright © 2015年 AIA. All rights reserved.
//

#ifndef AIABlockConstant_h
#define AIABlockConstant_h

#import "Bean.h"

typedef Bean* (^AIASetBeanValueBlock)(FMResultSet *result);
typedef NSMutableDictionary* (^AIAGetBeanValueBlock)(Bean *bean);

#endif /* AIABlockConstant_h */
