//
//  TestDao.h
//  TSSProject
//
//  Created by TSS on 15/12/17.
//  Copyright © 2015年 AIA. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AbstractDao.h"

@interface TestDao : AbstractDao

+ (TestDao *) getInstance;

- (void) initWithDB;

@end
