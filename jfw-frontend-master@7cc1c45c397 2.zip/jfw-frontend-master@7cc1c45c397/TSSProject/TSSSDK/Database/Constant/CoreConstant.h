//
//  CoreConstant.h
//  TSSProject
//
//  Created by TSS on 15/12/17.
//  Copyright © 2015年 AIA. All rights reserved.
//

#ifndef CoreConstant_h
#define CoreConstant_h

#define SQLITE_SQL_BLOB @"blob"
#define SQLITE_SQL_INTEGER @"integer"
#define SQLITE_SQL_REAL @"real"
#define SQLITE_SQL_TEXT @"text"
#define SQLITE_SQL_PRIMARY_KEY @" primary key"
#define SQLITE_SQL_AUTOINCREMENT @" autoincrement"


#define SQLITE_T_STRING		@"0"
#define SQLITE_T_INTEGER	@"1"
#define SQLITE_T_LONG		@"2"
#define SQLITE_T_DOUBLE		@"3"
#define SQLITE_T_SHORT		@"4"
#define SQLITE_T_FLOAT		@"5"
#define SQLITE_T_DATE		@"6"
#define SQLITE_T_DATE_TIME	@"7"
#define SQLITE_T_BOOLEAN	@"8"
#define SQLITE_T_BYTE_ARRAY	@"9"

#define SQLITE_I_STRING		0
#define SQLITE_I_INTEGER	1
#define SQLITE_I_LONG		2
#define SQLITE_I_DOUBLE		3
#define SQLITE_I_SHORT		4
#define SQLITE_I_FLOAT		5
#define SQLITE_I_DATE		6
#define SQLITE_I_DATE_TIME	7
#define SQLITE_I_BOOLEAN	8
#define SQLITE_I_BYTE_ARRAY	9


#endif /* CoreConstant_h */
