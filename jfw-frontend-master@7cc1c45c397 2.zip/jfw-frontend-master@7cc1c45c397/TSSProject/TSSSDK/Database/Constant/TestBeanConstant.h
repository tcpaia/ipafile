//
//  TestBeanConstant.h
//  TSSProject
//
//  Created by TSS on 15/12/17.
//  Copyright © 2015年 AIA. All rights reserved.
//

#ifndef TestBeanConstant_h
#define TestBeanConstant_h

#import "CoreConstant.h"

#define	TEST_BEAN_TABLE				@"testBean"

#define	TEST_BEAN_ID				@"beanid"
#define	TEST_BEAN_NAME				@"namestr"
#define	TEST_BEAN_NAME2				@"name2"
#define	TEST_BEAN_INT				@"intnumber"
#define	TEST_BEAN_LONG				@"longnumber"
#define	TEST_BEAN_DOUBLE			@"doublenumber"
#define	TEST_BEAN_SHORT				@"shortnumber"
#define	TEST_BEAN_FLOAT				@"floatnumber"
#define	TEST_BEAN_DATE				@"datenumber"
#define	TEST_BEAN_BOOLEAN			@"booleannumber"
#define	TEST_BEAN_DATETIME			@"datetime"
#define	TEST_BEAN_DATA				@"datavalue"

//#define SQLITE_SQL_BLOB @"blob"
//#define SQLITE_SQL_INTEGER @"integer"
//#define SQLITE_SQL_REAL @"real"
//#define SQLITE_SQL_TEXT @"text"
//#define SQLITE_SQL_PRIMARY_KEY @" primary key"
//#define SQLITE_SQL_AUTOINCREMENT @" autoincrement"
//
//
//#define SQLITE_T_STRING		@"0"
//#define SQLITE_T_INTEGER	@"1"
//#define SQLITE_T_LONG		@"2"
//#define SQLITE_T_DOUBLE		@"3"
//#define SQLITE_T_SHORT		@"4"
//#define SQLITE_T_FLOAT		@"5"
//#define SQLITE_T_DATE		@"6"
//#define SQLITE_T_DATE_TIME	@"7"
//#define SQLITE_T_BOOLEAN	@"8"
//#define SQLITE_T_BYTE_ARRAY	@"9"
//
//#define SQLITE_I_STRING		0
//#define SQLITE_I_INTEGER	1
//#define SQLITE_I_LONG		2
//#define SQLITE_I_DOUBLE		3
//#define SQLITE_I_SHORT		4
//#define SQLITE_I_FLOAT		5
//#define SQLITE_I_DATE		6
//#define SQLITE_I_DATE_TIME	7
//#define SQLITE_I_BOOLEAN	8
//#define SQLITE_I_BYTE_ARRAY	9

#define	TEST_BEAN_COLUMN_DETAILS \
\
NSMutableArray* tableColumns = [[NSMutableArray alloc] init];\
\
[tableColumns addObject: [NSMutableArray arrayWithObjects:TEST_BEAN_NAME,	SQLITE_T_STRING, nil]];\
[tableColumns addObject: [NSMutableArray arrayWithObjects:TEST_BEAN_INT,	SQLITE_T_INTEGER, nil]];\
[tableColumns addObject: [NSMutableArray arrayWithObjects:TEST_BEAN_LONG,	SQLITE_T_LONG, nil]];\
[tableColumns addObject: [NSMutableArray arrayWithObjects:TEST_BEAN_DOUBLE, SQLITE_T_DOUBLE, nil]];\
[tableColumns addObject: [NSMutableArray arrayWithObjects:TEST_BEAN_SHORT,	SQLITE_T_SHORT, nil]];\
[tableColumns addObject: [NSMutableArray arrayWithObjects:TEST_BEAN_FLOAT,	SQLITE_T_FLOAT, nil]];\
[tableColumns addObject: [NSMutableArray arrayWithObjects:TEST_BEAN_DATE,	SQLITE_T_DATE, nil]];\
[tableColumns addObject: [NSMutableArray arrayWithObjects:TEST_BEAN_BOOLEAN, SQLITE_T_BOOLEAN, nil]];\
[tableColumns addObject: [NSMutableArray arrayWithObjects:TEST_BEAN_DATETIME, SQLITE_T_DATE_TIME, nil]];\
[tableColumns addObject: [NSMutableArray arrayWithObjects:TEST_BEAN_DATA,	SQLITE_T_BYTE_ARRAY, nil]];



#endif /* TestBeanConstant_h */
