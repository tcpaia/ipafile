//
//  Bean.m
//  TSSProject
//
//  Created by TSS on 15/12/17.
//  Copyright © 2015年 AIA. All rights reserved.
//

#import "Bean.h"
#import <objc/runtime.h>
#import "SystemTss.h"
#import "TSSValidationUtil.h"

@implementation Bean

- (BOOL)isEqual:(id) object
{
    if (object == nil) {
        return false;
    }
    if (![object isKindOfClass:self.class]) {
        return false;
    }
    Bean *bean = object;
    if (_idKey != nil) {
        return [_idKey isEqual:bean.idKey];
    }
    return [super isEqual:object];
}

- (NSUInteger)hash
{
    if (_idKey == nil)
    {
        return [super hash];
    }
    else
    {
        return [_idKey hash];
    }
}

/**
 * Convert object to primitive type.
 *
 * @param obj <code>NSNumber</code> object.
 * @return Return 0 if <code>obj</code> is <code>nil</code>.
 */
- (short)getShort:(NSNumber *) obj
{
    return [self getShort:obj defaultValue:(short)0];
}

/**
 * Convert object to primitive type.
 *
 * @param obj <code>NSNumber</code> object.
 * @param def default value when <code>obj</code> is nil.
 * @return Return <code>def</code> if <code>obj</code> is <code>nil</code>.
 */
- (short)getShort:(NSNumber *)obj  defaultValue:(short)def
{
    if (obj == nil) {
        return def;
    }
    return obj.shortValue;
}

/**
 * Convert object to primitive type.
 *
 * @param obj <code>NSNumber</code> object.
 * @return Return 0 if <code>obj</code> is <code>nil</code>.
 */
- (int)getInt:(NSNumber *)obj
{
    return [self getInt:obj defaultValue:0];
}

/**
 * Convert object to primitive type.
 *
 * @param obj <code>NSNumber</code> object.
 * @param def default value when <code>obj</code> is nil.
 * @return Return <code>def</code> if <code>obj</code> is <code>nil</code>.
 */
- (int)getInt:(NSNumber *)obj defaultValue:(int)def
{
    if (obj == nil) {
        return def;
    }
    return obj.intValue;
}

/**
 * Convert object to primitive type.
 *
 * @param obj <code>NSNumber</code> object.
 * @return Return 0 if <code>obj</code> is <code>nil</code>.
 */
- (long long int)getLong:(NSNumber *)obj
{
    return [self getLong:obj defaultValue:0];
}

/**
 * Convert object to primitive type.
 *
 * @param obj <code>NSNumber</code> object.
 * @param def default value when <code>obj</code> is nil.
 * @return Return <code>def</code> if <code>obj</code> is <code>nil</code>.
 */
- (long long int)getLong:(NSNumber *)obj defaultValue:(long long int)def
{
    if (obj == nil) return def;
    return obj.longLongValue;
}

/**
 * Convert object to primitive type.
 *
 * @param obj <code>NSNumber</code> object.
 * @return Return 0 if <code>obj</code> is <code>nil</code>.
 */
- (float)getFloat:(NSNumber *)obj
{
    return [self getFloat:obj defaultValue:0.0];
}

/**
 * Convert object to primitive type.
 *
 * @param obj <code>NSNumber</code> object.
 * @param def default value when <code>obj</code> is nil.
 * @return Return <code>def</code> if <code>obj</code> is <code>nil</code>.
 */
- (float)getFloat:(NSNumber *)obj defaultValue:(float)def
{
    if (obj == nil) {
        return def;
    }
    return obj.floatValue;
}

/**
 * Convert object to primitive type.
 *
 * @param obj <code>NSNumber</code> object.
 * @return Return 0 if <code>obj</code> is <code>nil</code>.
 */
- (double)getDouble:(NSNumber *)obj
{
    return [self getDouble:obj defaultValue:0.0];
}

/**
 * Convert object to primitive type.
 *
 * @param obj <code>NSNumber</code> object.
 * @param def default value when <code>obj</code> is nil.
 * @return Return <code>def</code> if <code>obj</code> is <code>nil</code>.
 */
- (double)getDouble:(NSNumber *)obj defaultValue:(double)def
{
    if (obj == nil) return def;
    return obj.doubleValue;
}

/**
 * Convert object to primitive type.
 *
 * @param obj <code>NSNumber</code> object.
 * @return Return <code>false</code> if <code>obj</code> is <code>nil</code>
 *         or <code>FALSE</code>, otherwise return <code>true</code>.
 */
- (BOOL)getBoolean:(NSNumber *)obj
{
    return [self getBoolean:obj defaultValue:NO];
}

/**
 * Convert object to primitive type.
 *
 * @param obj <code>NSNumber</code> object.
 * @param def default value when <code>obj</code> is nil.
 * @return Return <code>def</code> if <code>obj</code> is <code>nil</code>.
 */
- (BOOL)getBoolean:(NSNumber *)obj defaultValue:(BOOL)def
{
    if (obj == nil) return def;
    return obj.intValue == 1;
}

/**
 * Convert object to primitive type.
 *
 * @param obj <code>NSString</code> object.
 * @param def default value when <code>obj</code> is nil.
 * @return Return <code>def</code> if <code>obj</code> is <code>nil</code>.
 */
- (BOOL) getBooleanWithString:(NSString *) obj defaultValue:(BOOL) def
{
    if (obj == nil || [obj isKindOfClass:[NSNull class]]) {
        return def;
    } else {
        if([obj isEqualToString:@"1"]) {
            return YES;
        } else {
            return NO;
        }
    }
}

/**
 * Convert object to String.
 *
 * @param obj <code>NSNumber</code> object.
 * @return Return <code>obj</code> in String.
 */
- (NSString *)getStringDate:(NSNumber *)obj
{
    return [self getStringDate:obj defaultValue:@""];
}

/**
 * Convert object to String.
 *
 * @param obj <code>NSNumber</code> object.
 * @param def default value when <code>obj</code> is nil.
 * @return Return <code>obj</code> in String.
 */
- (NSString *)getStringDate:(NSNumber *)obj defaultValue:(NSString *)def
{
    if (obj == nil) {
        return def;
    }
    return [obj description];
}

/**
 * Convert object to String.
 *
 * @param obj <code>NSDate</code> object.
 * @return Return <code>obj</code> in String.
 */
- (NSString *)getStringDateTime:(NSDate *)obj
{
    return [self getStringDateTime:obj defaultValue:@""];
}

/**
 * Convert object to String.
 *
 * @param obj <code>NSDate</code> object.
 * @param def default value when <code>obj</code> is nil.
 * @return Return <code>obj</code> in String.
 */
- (NSString *)getStringDateTime:(NSDate *)obj defaultValue:(NSString *)def
{
    if (obj == nil) {
        return def;
    }
    return [obj description];
}


/**
 * Save this bean.
 */
- (void)save
{
    //AbstractMethod;
}

/**
 * Delete this bean.
 */
- (void)del
{
    //AbstractMethod;
}

/**
 * SET WITH property name
 */
-(SEL) creatSetterWithPropertyName:(NSString*)propertyName
{
    NSString *prefix = [propertyName substringToIndex:1].uppercaseString;
    NSString *suffix = [propertyName substringFromIndex:1];
    
    propertyName = [prefix stringByAppendingString:suffix];
    
    propertyName = FORMAT(@"set%@:",propertyName);
    
    return NSSelectorFromString(propertyName);
}

/**
 * SET value to bean
 */
-(void)assginToPropertyWithDictionary:(NSDictionary*)data
{
    if (data == nil)
        return;
    NSArray *dicKey = [data allKeys];
    NSString *value = nil;
    for (int i = 0; i<dicKey.count; i++)
    {
        SEL setSel = [self creatSetterWithPropertyName:dicKey[i]];
        
        if ([self respondsToSelector:setSel])
        {
            value = [TSSValidationUtil convertNullToNil:data[dicKey[i]]];
            [self performSelector:setSel onThread:[NSThread currentThread] withObject:value waitUntilDone:YES];
        }
    }
}

/**
 * get all Properties
 */
-(NSArray*)allPropertyNames
{
    NSMutableArray *allNames = [NSMutableArray array];
    
    unsigned int propertCount = 0;
    
    objc_property_t *propertys = class_copyPropertyList([self class], &propertCount);
    
    for (int i=0; i<propertCount; i++)
    {
        objc_property_t property = propertys[i];
        const char * propertyName = property_getName(property);
        [allNames addObject:[NSString stringWithUTF8String:propertyName]];
    }
    
    return allNames;
}


-(NSArray*)allSuperPropertyNames
{
    NSMutableArray *allNames = [NSMutableArray array];
    
    unsigned int propertCount = 0;
    
    objc_property_t *propertys = class_copyPropertyList([self superclass], &propertCount);
    
    for (int i=0; i<propertCount; i++)
    {
        objc_property_t property = propertys[i];
        const char * propertyName = property_getName(property);
        [allNames addObject:[NSString stringWithUTF8String:propertyName]];
    }
    
    return allNames;
}

/**
 * get property name
 */
-(SEL) createGetterWithPropertyName:(NSString*)propertyName
{
    return NSSelectorFromString(propertyName);;
}

/**
 * do get property name
 */
-(id) doGetMethord:(NSString*)propertyName
{
    SEL getSel = [self createGetterWithPropertyName:propertyName];
    
    if ([self respondsToSelector:getSel])
    {
        NSMethodSignature *signature = [self methodSignatureForSelector:getSel];
        NSInvocation *invocation = [NSInvocation invocationWithMethodSignature:signature];
        [invocation setTarget:self];
        [invocation setSelector:getSel];
        NSObject *__unsafe_unretained returnValue = nil;
        [invocation invoke];
        [invocation getReturnValue:&returnValue];
        return returnValue;
    }
    return nil;
}

@end
