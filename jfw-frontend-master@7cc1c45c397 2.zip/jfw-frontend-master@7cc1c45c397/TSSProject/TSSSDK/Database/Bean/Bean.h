//
//  Bean.h
//  TSSProject
//
//  Created by TSS on 15/12/17.
//  Copyright © 2015年 AIA. All rights reserved.
//

#import <Foundation/Foundation.h>

#define	BEAN_ID				@"beanid"

@interface Bean : NSObject

@property (nonatomic, strong) NSString *idKey;
@property (nonatomic, strong) NSNumber *createdate;
@property (nonatomic, strong) NSNumber *updatedate;

/**
 * Convert object to primitive type.
 *
 * @param obj <code>NSNumber</code> object.
 * @return Return 0 if <code>obj</code> is <code>nil</code>.
 */
- (short)getShort:(NSNumber *)obj;

/**
 * Convert object to primitive type.
 *
 * @param obj <code>NSNumber</code> object.
 * @param def default value when <code>obj</code> is nil.
 * @return Return <code>def</code> if <code>obj</code> is <code>nil</code>.
 */
- (short)getShort:(NSNumber *)obj  defaultValue:(short)def;

/**
 * Convert object to primitive type.
 *
 * @param obj <code>NSNumber</code> object.
 * @return Return 0 if <code>obj</code> is <code>nil</code>.
 */
- (int)getInt:(NSNumber *)obj;

/**
 * Convert object to primitive type.
 *
 * @param obj <code>NSNumber</code> object.
 * @param def default value when <code>obj</code> is nil.
 * @return Return <code>def</code> if <code>obj</code> is <code>nil</code>.
 */
- (int)getInt:(NSNumber *)obj defaultValue:(int)def;

/**
 * Convert object to primitive type.
 *
 * @param obj <code>NSNumber</code> object.
 * @return Return 0 if <code>obj</code> is <code>nil</code>.
 */
- (long long int)getLong:(NSNumber *)obj;

/**
 * Convert object to primitive type.
 *
 * @param obj <code>NSNumber</code> object.
 * @param def default value when <code>obj</code> is nil.
 * @return Return <code>def</code> if <code>obj</code> is <code>nil</code>.
 */
- (long long int)getLong:(NSNumber *)obj defaultValue:(long long int)def;

/**
 * Convert object to primitive type.
 *
 * @param obj <code>NSNumber</code> object.
 * @return Return 0 if <code>obj</code> is <code>nil</code>.
 */
- (float)getFloat:(NSNumber *)obj;

/**
 * Convert object to primitive type.
 *
 * @param obj <code>NSNumber</code> object.
 * @param def default value when <code>obj</code> is nil.
 * @return Return <code>def</code> if <code>obj</code> is <code>nil</code>.
 */
- (float)getFloat:(NSNumber *)obj defaultValue:(float)def;

/**
 * Convert object to primitive type.
 *
 * @param obj <code>NSNumber</code> object.
 * @return Return 0 if <code>obj</code> is <code>nil</code>.
 */
- (double)getDouble:(NSNumber *)obj;

/**
 * Convert object to primitive type.
 *
 * @param obj <code>NSNumber</code> object.
 * @param def default value when <code>obj</code> is nil.
 * @return Return <code>def</code> if <code>obj</code> is <code>nil</code>.
 */
- (double)getDouble:(NSNumber *)obj defaultValue:(double)def;

/**
 * Convert object to primitive type.
 *
 * @param obj <code>NSNumber</code> object.
 * @return Return <code>false</code> if <code>obj</code> is <code>nil</code>
 *         or <code>FALSE</code>, otherwise return <code>true</code>.
 */
- (BOOL)getBoolean:(NSNumber *)obj;

/**
 * Convert object to primitive type.
 *
 * @param obj <code>NSNumber</code> object.
 * @param def default value when <code>obj</code> is nil.
 * @return Return <code>def</code> if <code>obj</code> is <code>nil</code>.
 */
- (BOOL)getBoolean:(NSNumber *)obj defaultValue:(BOOL)def;

/**
 * Convert object to primitive type.
 *
 * @param obj <code>NSString</code> object.
 * @param def default value when <code>obj</code> is nil.
 * @return Return <code>def</code> if <code>obj</code> is <code>nil</code>.
 */
- (BOOL) getBooleanWithString:(NSString *) obj defaultValue:(BOOL) def;

/**
 * Convert object to String.
 *
 * @param obj <code>NSNumber</code> object.
 * @return Return <code>obj</code> in String.
 */
- (NSString *)getStringDate:(NSNumber *)obj;

/**
 * Convert object to String.
 *
 * @param obj <code>NSNumber</code> object.
 * @param def default value when <code>obj</code> is nil.
 * @return Return <code>obj</code> in String.
 */
- (NSString *)getStringDate:(NSNumber *)obj defaultValue:(NSString *)def;

/**
 * Convert object to String.
 *
 * @param obj <code>NSDate</code> object.
 * @return Return <code>obj</code> in String.
 */
- (NSString *)getStringDateTime:(NSDate *)obj;

/**
 * Convert object to String.
 *
 * @param obj <code>NSDate</code> object.
 * @param def default value when <code>obj</code> is nil.
 * @return Return <code>obj</code> in String.
 */
- (NSString *)getStringDateTime:(NSDate *)obj defaultValue:(NSString *)def;


/**
 * Save this bean.
 */
- (void)save;

/**
 * Delete this bean.
 */
- (void)del;

-(void)assginToPropertyWithDictionary:(NSDictionary*)data;

-(NSArray*)allPropertyNames;

-(NSArray*)allSuperPropertyNames;

-(SEL) createGetterWithPropertyName:(NSString*)propertyName;

-(id) doGetMethord:(NSString*)propertyName;
@end

