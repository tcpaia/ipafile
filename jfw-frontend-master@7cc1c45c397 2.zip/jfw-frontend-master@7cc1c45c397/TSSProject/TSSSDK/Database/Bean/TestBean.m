//
//  TestBean.m
//  TSSProject
//
//  Created by TSS on 15/12/17.
//  Copyright © 2015年 AIA. All rights reserved.
//

#import "TestBean.h"
#import "TestDao.h"
#import "SystemTss.h"


@implementation TestBean

- (void)save
{
    //[[TestBeanDao getInstance] saveOrUpdate:self];
    [[TestDao getInstance] saveOrUpdate:self];
}

- (void)delete
{
    //[[TestDao getInstance] delete:self.idKey];
}

@end
