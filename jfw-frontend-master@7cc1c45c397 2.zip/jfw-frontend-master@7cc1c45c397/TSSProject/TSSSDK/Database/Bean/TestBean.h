//
//  TestBean.h
//  TSSProject
//
//  Created by TSS on 15/12/17.
//  Copyright © 2015年 AIA. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Bean.h"

@interface TestBean : Bean
{
}

@property (nonatomic, retain) NSString *namestr;
@property (nonatomic, retain) NSNumber *intnumber;
@property (nonatomic, retain) NSNumber *longnumber;
@property (nonatomic, retain) NSNumber *doublenumber;
@property (nonatomic, retain) NSNumber *floatnumber;
@property (nonatomic, retain) NSNumber *datenumber;
@property (nonatomic, retain) NSNumber *booleannumber;
@property (nonatomic, retain) NSDate *datetime;
@property (nonatomic, retain) NSData *datavalue;

- (void)save;
- (void)delete;



@end
