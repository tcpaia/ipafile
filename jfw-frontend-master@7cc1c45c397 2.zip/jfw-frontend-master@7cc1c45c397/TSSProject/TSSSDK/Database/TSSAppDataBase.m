//
//  TSSAppDataBase.m
//  TSSProject
//
//  Created by TSS on 16/4/6.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import "TSSAppDataBase.h"
#import "Singleton.h"
#import "DBQueue.h"
#import "CommonDBQueue.h"

#import "NetworkInfoDao.h"
#import "NetworkInfoBean.h"
#import "TestDao.h"
#import "TestBean.h"
#import "AgentProfileDao.h"
#import "AgentProfileBean.h"
#import "CustomerInfoDao.h"
#import "EventLogDao.h"
#import "LanguageDao.h"
#import "FollowUpAndNoteDao.h"
#import "AppointmentCustomerDao.h"
#import "AppointmentCommentsDao.h"
#import "jfwDao.h"
#import "QuestionDao.h"
#import "NotificationDao.h"
#import "NominatedCadidateDao.h"
#import "NominationInfoDao.h"
#import "NominatedPartnerDao.h"
#import "TrackerResultDao.h"
#import "TrackerResultNewFscDao.h"

#import "TSSAppData.h"
#import "TSSSecurity.h"
#import "TSSAppSetting.h"
#import "TSSValidationUtil.h"

#import "HashValue.h"
#import "NSData+AES256.h"
#import "PDKeyChain.h"

#import "CommonSql.h"

@implementation TSSAppDataBase

SYNTHESIZE_SINGLETON_FOR_CLASS(TSSAppDataBase);
- (void)initSmartDB{
    
    DBQueue *dbQueue = [DBQueue sharedInstance];
    NSString* ddbName = [TSSSecurity sha256:[TSSAppData getInstance].agentCode];
    NSString *dbName = FORMAT(@"%@.db",ddbName);
    
    //如果是测试sit，数据库不加密
    if ([[TSSAppSetting getInstance].buildVesion isEqualToString:BUILD_VERSION_SIT_COE] || [[TSSAppSetting getInstance].buildVesion isEqualToString:BUILD_VERSION_SIT_SGP]) {
        [dbQueue init:dbName dbKey:nil dbPath:DOCUMENT_PATH];
    }
    else
    {
        [dbQueue init:dbName dbKey:[TSSAppData getInstance].masterKey dbPath:DOCUMENT_PATH];
    }
    DLog(@"initSmartDB: %@",dbQueue.dbPath);
    
    [[AgentProfileDao getInstance] initWithDB];
    [[AgentProfileDao getInstance] updateTableAddColumn];
    
    [[CustomerInfoDao getInstance] initWithDB];
    [[CustomerInfoDao getInstance] updateTableAddColumn];
    
    
    [[EventLogDao getInstance] initWithDB];
    [[EventLogDao getInstance] updateTableAddColumn];
    
    [[FollowUpAndNoteDao getInstance] initWithDB];
    [[FollowUpAndNoteDao getInstance] updateTableAddColumn];
    
    [[AppointmentCustomerDao getInstance] initWithDB];
    [[AppointmentCustomerDao getInstance] updateTableAddColumn];
    
    [[AppointmentCommentsDao getInstance] initWithDB];
    [[AppointmentCommentsDao getInstance] updateTableAddColumn];
    
    [[JfwDao getInstance] initWithDB];
    [[JfwDao getInstance] updateTableAddColumn];
    
    [[QuestionDao getInstance] initWithDB];
    [[QuestionDao getInstance] updateTableAddColumn];
    
    [[NotificationDao getInstance] initWithDB];
    [[NotificationDao getInstance] updateTableAddColumn];
    
    [[NominatedCadidateDao getInstance] initWithDB];
    [[NominatedCadidateDao getInstance] updateTableAddColumn];
    
    [[NominationInfoDao getInstance] initWithDB];
    [[NominationInfoDao getInstance] updateTableAddColumn];
    
    [[NominatedPartnerDao getInstance] initWithDB];
    [[NominatedPartnerDao getInstance] updateTableAddColumn];
    
    [[TrackerResultDao getInstance] initWithDB];
    [[TrackerResultDao getInstance] updateTableAddColumn];
    
    [[TrackerResultNewFscDao getInstance] initWithDB];
    [[TrackerResultNewFscDao getInstance] updateTableAddColumn];
}

-(void)initLanguageDb
{
    // init language db
    DBQueue *dbQueueLanguage = [[DBQueue alloc] init];
    [LanguageDao getInstance].tableName = @"message";
    [dbQueueLanguage init:@"language.db3" dbKey:nil dbPath:RESOURCE_PATH];
    [[LanguageDao getInstance] initWithDB:dbQueueLanguage];
}


- (void)initCommonDb
{
    NSString* ddbName = @"CommonInfo";
    NSString *dbName = FORMAT(@"%@.db3",ddbName);
    
    if ([TSSValidationUtil isNilOrEmptyString: [PDKeyChain keyChainLoad:kCommonDBKey]] == YES) {
        [PDKeyChain keyChainSaveKey:kCommonDBKey withkeyChainValue: [TSSSecurity sha256: [[NSBundle mainBundle] bundleIdentifier]]];
    }
    
    CommonDBQueue *commonDBQueue = [[CommonDBQueue alloc] init];
    [commonDBQueue init:dbName dbKey:[PDKeyChain keyChainLoad:kCommonDBKey] dbPath:RESOURCE_PATH];
    [[NetworkInfoDao getInstance] initWithDB: commonDBQueue];
    
    //initial CommonInfoTest.sql
    /*
    NSMutableArray *result = [[NetworkInfoDao getInstance] selectAll];
    NSMutableString *sql = [NSMutableString stringWithFormat: @"delete from %@;\n", NETWORK_INFO_TABLE_NAME];
    for (NetworkInfoBean *networkinfo in result) {
        [sql appendFormat: @"insert into NetworkInfo (beanid, buildVesion, serverURL, loginPageURL, webServicesURL, newsFeedURL, nameSpace) values ('%@','%@','%@','%@','%@','%@','%@'); \n", networkinfo.idKey, networkinfo.buildVesion, networkinfo.serverURL, networkinfo.loginPageURL, networkinfo.webServicesURL, networkinfo.newsFeedURL, networkinfo.nameSpace];
    }
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *initialSqlsFilePath = [documentsDirectory stringByAppendingPathComponent:FORMAT(@"%@.sql", ddbName)];
    if ([[NSFileManager defaultManager] fileExistsAtPath:initialSqlsFilePath] == YES) {
        [[NSFileManager defaultManager] removeItemAtPath:initialSqlsFilePath error:nil];
    }
    [[NSFileManager defaultManager] createFileAtPath:initialSqlsFilePath contents:nil attributes:[NSDictionary dictionaryWithObject:NSFileProtectionComplete forKey: NSFileProtectionKey]];
    [sql writeToFile:initialSqlsFilePath atomically:NO encoding:NSUTF8StringEncoding error:nil];
     */
}

- (void) createCommonDbForTest
{
    NSString* ddbName = @"CommonInfoTest";
    NSString *dbName = FORMAT(@"%@.db3",ddbName);

    if ([TSSValidationUtil isNilOrEmptyString: [PDKeyChain keyChainLoad:kCommonDBKey]] == YES) {
        [PDKeyChain keyChainSaveKey:kCommonDBKey withkeyChainValue: [TSSSecurity sha256: [[NSBundle mainBundle] bundleIdentifier]]];
    }
    
    CommonDBQueue *commonDBQueue = [[CommonDBQueue alloc] init];
    [commonDBQueue init:dbName dbKey:[PDKeyChain keyChainLoad:kCommonDBKey] dbPath:DOCUMENT_PATH];
    [[NetworkInfoDao getInstance] initWithDB: commonDBQueue];
    
//    NSString *resourcePath = [[NSBundle mainBundle] resourcePath];
//    NSString *initialSqlsFilePath = [resourcePath stringByAppendingPathComponent:FORMAT(@"%@.sql", ddbName)];
//    NSString *initialSqlsStr = [NSString stringWithContentsOfFile:initialSqlsFilePath encoding:NSUTF8StringEncoding error:nil];
    //NSArray *initialSqlArray = [initialSqlsStr componentsSeparatedByString:@"\n"];
    
    NSArray * initialSqlArray = [CommonSql sharedcommonSql].sqlArray;
    
    for (NSString * initialSql in initialSqlArray) {
        if (initialSql != nil && initialSql.length > 0) {
            [commonDBQueue saveOrUpdate: initialSql];
        }
    }
}

- (void)initCommonInfoTestDb
{
    NSString* ddbName = @"CommonInfoTest";
    NSString *dbName = FORMAT(@"%@.db3",ddbName);
    
    CommonDBQueue *commonDBQueue = [[CommonDBQueue alloc] init];
    [commonDBQueue init:dbName dbKey:nil dbPath:RESOURCE_PATH];
    [[NetworkInfoDao getInstance] initWithDB: commonDBQueue];
}
@end
