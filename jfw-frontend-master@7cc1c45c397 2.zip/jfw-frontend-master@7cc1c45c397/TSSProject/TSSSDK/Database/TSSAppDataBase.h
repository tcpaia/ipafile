//
//  TSSAppDataBase.h
//  TSSProject
//
//  Created by TSS on 16/4/6.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TSSAppDataBase : NSObject

+ (TSSAppDataBase *) getInstance;

- (void)initSmartDB;
- (void)initLanguageDb;
- (void)initCommonDb;

- (void) createCommonDbForTest;
- (void) initCommonInfoTestDb;
@end
