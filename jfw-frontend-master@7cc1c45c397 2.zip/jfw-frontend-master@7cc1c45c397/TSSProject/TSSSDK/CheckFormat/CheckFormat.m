//
//  CheckFormat.m
//  TSSProject
//
//  Created by 于磊 on 16/8/22.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import "CheckFormat.h"

@implementation CheckFormat

+ (BOOL)validateNum:(NSString *)num{
    NSCharacterSet *unacceptedInput = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789"] invertedSet];
    if ([[num componentsSeparatedByCharactersInSet:unacceptedInput] count] > 1){
        return NO;
    }
    return YES;
}

+ (BOOL)validateMobile:(NSString *)mobile
{
//    NSString *mobileRegex = @"((13[0-9])|(147)|(15[^4,\\D])|(18[0,5-9]))\\d{8}$";
//    NSPredicate *mobileTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",mobileRegex];
//    return [mobileTest evaluateWithObject:mobile];
    return YES;
}

+ (BOOL)validateEmail:(NSString *)email
{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}

@end
