//
//  CheckFormat.h
//  TSSProject
//
//  Created by 于磊 on 16/8/22.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CheckFormat : NSObject

+ (BOOL)validateNum:(NSString *)num;

+ (BOOL)validateMobile:(NSString *)mobile;

+ (BOOL)validateEmail:(NSString *)email;

@end
