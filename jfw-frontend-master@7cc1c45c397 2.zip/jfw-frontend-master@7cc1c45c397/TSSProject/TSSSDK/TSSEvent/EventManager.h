//
//  EventManager.h
//  TSSProject
//
//  Created by 于磊 on 16/4/14.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <EventKit/EventKit.h>

@interface EventManager : NSObject

+(instancetype)shareInstance;

-(NSArray *)getTodayEvent;
-(NSArray *)getThisWeekEventFromSunday;
-(NSArray *)getThisWeekEventFromMonday;
-(NSArray *)getThisMonthFromFirstDay;
-(NSArray *)getThisMonthFromFifteenDaysAgo;
-(NSArray *)getcurrentMonth:(int)month;


-(EKEventStore *)store;

-(BOOL)deleteEvent:(EKEvent *)event;
-(BOOL)createEvent:(EKEvent *)event;
-(BOOL)saveEvent:(EKEvent *)event;
+(NSString *)weekdayStringFromDate:(EKEvent *)event;
+(NSString *)getTime:(NSDate *)date;

@end
