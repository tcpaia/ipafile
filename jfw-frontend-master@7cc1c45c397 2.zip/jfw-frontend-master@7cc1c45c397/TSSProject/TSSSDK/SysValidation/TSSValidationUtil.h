//
//  TSSValidationUtil.h
//  TSSProject
//
//  Created by TSS on 15/12/15.
//  Copyright © 2015年 AIA. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface TSSValidationUtil : NSObject

+ (BOOL) isNilOrEmptyString:(NSString *) value;

+ (id)convertNullToNil:(id) value;

+ (id)convertNilToNull:(id) value;

+ (BOOL)isNilOrNull:(id) value;

+ (id)convertNilToEmptyString:(id) value;

+ (NSString *)convertToJsonString:(id)sourceObject;

+ (id) converStringToEmptyString:(NSString*) tValue;
+ (NSMutableAttributedString *)converAttributedString:(NSString *)changeStr ;

+ (NSString *)filterHTML:(NSString *)html;
@end
