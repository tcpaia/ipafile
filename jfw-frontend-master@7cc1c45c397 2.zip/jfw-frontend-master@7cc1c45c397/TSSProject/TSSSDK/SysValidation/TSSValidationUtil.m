//
//  TSSValidationUtil.m
//  TSSProject
//
//  Created by TSS on 15/12/15.
//  Copyright © 2015年 AIA. All rights reserved.
//

#import "TSSValidationUtil.h"
#import "SystemTss.h"
@implementation TSSValidationUtil

+ (BOOL) isNilOrEmptyString:(NSString *) value
{
    return value==nil || [value isEqualToString:@"null"] || [value isEqualToString:@"(null)"] || [value isEqualToString:@"Null"] || [value isEqualToString:@"NULL"] || value.length==0 || [[value stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]length]==0;
}

+ (id)convertNullToNil:(id) value
{
    if (value == [NSNull null]) return nil;
    else return value;
}

+ (id)convertNilToNull:(id) value
{
    if (value == nil) return [NSNull null];
    else return value;
}

+ (BOOL)isNilOrNull:(id) value
{
    return value==nil || value==[NSNull null];
}

+ (id) convertNilToEmptyString:(id) value
{
    if (value == nil) return @"";
    else return value;
}

+ (id) converStringToEmptyString:(NSString*) tValue
{
    if (tValue.length == 0) return @"";
    else return tValue;
}

+ (NSString *)convertToJsonString:(id)sourceObject {
    NSError *error = nil;
    NSData *jsonData = nil;
    NSString *resultJsonString = nil;
    BOOL isJson = [NSJSONSerialization isValidJSONObject:sourceObject];
    if (!isJson) {
        DLog(@"not JSONObject");
        return resultJsonString;
    }
    @try {
        jsonData = [NSJSONSerialization dataWithJSONObject:sourceObject options:NSJSONWritingPrettyPrinted error:&error];
    }
    @catch (NSException *exception) {
        jsonData = nil;
    }
    if (error) {
        DLog(@"Fatal Error: package json error = %@",error);
    } else if (!jsonData) {
        DLog(@"Fatal Error: package json data is nil");
    } else {
        resultJsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        //        DLog(@"resultJsonString == %@",resultJsonString);
    }
    return resultJsonString;
}


+ (NSMutableAttributedString *)converAttributedString:(NSString *)changeStr {
    NSUInteger fromlength = changeStr.length;
    NSMutableAttributedString *attributedStr = [[NSMutableAttributedString alloc] initWithString:changeStr];;
    [attributedStr addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"Arial" size:16] range:NSMakeRange(0, fromlength)];
    [attributedStr addAttribute:NSForegroundColorAttributeName value:UI_COLOR_SMART_RED range:NSMakeRange(fromlength - 1, 1)];
    return attributedStr;
}

+(NSString *)filterHTML:(NSString *)html
{
    NSScanner * scanner = [NSScanner scannerWithString:html];
    NSString * text = nil;
    while([scanner isAtEnd]==NO)
    {
        [scanner scanUpToString:@"<" intoString:nil];
        [scanner scanUpToString:@">" intoString:&text];
        html = [html stringByReplacingOccurrencesOfString:[NSString stringWithFormat:@"%@>",text] withString:@""];
    }
    return html;
}

@end
