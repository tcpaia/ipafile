//
//  NetworkingManager.h
//  TSSProject
//
//  Created by TSS on 16/2/22.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AdSupport/AdSupport.h>
#import <AFNetworking/AFNetworking.h>
#import "EventLogDao.h"
#import "TrackerRequestModel.h"
#import "TrackerNewFscRequestModel.h"

typedef NS_ENUM(NSInteger, BPNetworkingTask) {
    BPNetworkingTaskServerConnection,
    BPNetworkingTaskSyncData
};

typedef NS_ENUM(NSInteger,BPNetWorkingStatus)
{
    /** 未知网络*/
    BPNetworkStatusUnknown,
    /** 无网络*/
    BPNetworkStatusNotReachable,
    /** 手机网络*/
    BPNetworkStatusReachableViaWWAN,
    /** WIFI网络*/
    BPNetworkStatusReachableViaWiFi
};

typedef void (^CallBack)(id obj);
typedef void (^NetWorkStatus) (BPNetWorkingStatus netStatus);

@protocol NetworkingManagerDelegate <NSObject>
@optional
//Implement this delegate function in your business handler class
//task - Networking tasks
//responseObject - Response dictionary from server
//success - YES means responseObject has correct values as you expected, NO means responseObject is empty or has incorrect values; If task goes to failure:^(NSURLSessionDataTask *task, NSError *error), set responseObject = nil, success = NO, error = NSError
//- (void)completeTaskWithResponseObject:(NSDictionary *)responseObject success:(BOOL)success error:(NSError *)error;
- (void)completeTask:(BPNetworkingTask)task responseObject:(NSDictionary *)responseObject success:(BOOL)success error:(NSError *)error;

@end

@interface NetworkingManager : NSObject


@property (nonatomic, strong) id<NetworkingManagerDelegate> delegate;

+ (NetworkingManager *) getInstance;
- (void)startMonitoringNetwork;
- (void)checkNetStatusWithBlock:(NetWorkStatus)netStatus;
- (BOOL)currentNetworkStatus;
- (NSURLSessionDataTask *) connectToServer; //Connect to server, get server timestamp
- (NSURLSessionDataTask *) syncData; //Sync data

- (void)postUploadWithURLString:(NSString *)URLString
                        fileURL:(NSURL *)fileURL
                     parameters:(id)parameters
                       postData:(NSData *)postData
                timeoutInterval:(NSTimeInterval)timeoutInterval
                  responseBlock:(void (^)(id response))responseBlock;
- (void)checkServerConnecting:(void (^)(id response))responseBlock;
- (void)checkAppVersion:(CallBack)callback;
- (void)checkAgentProfile:(CallBack)callback;

- (void)uploadAgentProfile:(NSDictionary*)agentDict andCallback:(CallBack)callback;
- (void)downSetUpManagerSelectStatus:(NSString *)selectStatus withSetupManagerCode:(NSString *)managerCode withCallBack:(CallBack)callback;
- (void)downloadCustomerLastUpdateTime:(NSString *)lastUpdateTime andRecordNo:(NSString *)recordNo andLater:(NSString*)sign andCallBack:(CallBack)callback;
- (void)downloadCustomerLastUpdateTime:(NSString *)lastUpdateTime andRecordNo:(NSString *)recordNo andLater:(NSString*)sign andFetchFlag: (NSString *)fetchType andOids: (NSArray *)oids andCallBack:(CallBack)callback;
- (void)downLoadNotifactionAndLastUpdateTime:(NSString *)lastUpdateTime andRecordNo:(NSString *)recordNo andCallBack:(CallBack)callback;
- (void)notificationUploadAndNotifyList:(NSArray *)notificationList andCallBack:(CallBack)callback;
- (void)eventLogUpload:(CallBack)callback;
- (void)uploadcustomers:(NSArray *)customers withContactHistoryList:(NSArray *)contactHistoryList withCallBack:(CallBack)callback;

//- (void)getGoogleMapNearbyInfomation:(NSString *)path andParameters:(NSDictionary *)parameters andCallBack:(CallBack)callback;
//- (void)getGoogleMapRouteInfomation:(NSString *)path andParameters:(NSDictionary *)parameters andCallBack:(CallBack)callback;
//- (void)getGoogleMapGeoCodingInfomation:(NSString *)path andParameters:(NSDictionary *)parameters andCallBack:(CallBack)callback;
//- (void)getGoogleMapDistanceInfomation:(NSString *)path andParameters:(NSDictionary *)parameters andCallBack:(CallBack)callback;

- (void)uploadAgenPhoto:(NSData *)photoData withCallback:(CallBack)callback;

- (void)jfwUpload:(NSArray *)aJfwArray andCallBack:(CallBack)callback;

- (void)jfwDownLoad:(NSString *)lastUpdateTime andRecordNo:(NSString *)recordNo andLater:(NSString*)sign oids:(NSMutableArray*)aOids
         fetchFlag:(NSString*)aFetchFlag andCallBack:(CallBack)callback;

- (void)commentsStatusUpload:(NSString *)appointId andStatus:(NSString*)aStatus andComments:(NSString*)aComments andCallBack:(CallBack)callback;

- (void)appointmentUploadAndEventList:(NSArray *)eventList andCallBack:(CallBack)callback;

- (void)appointmentEventDownload:(NSString *)lastUpdateTime andRecordNo:(NSString *)recordNo andCallBack:(CallBack)callback;

- (void)upLoadJfwStatusWithJfwStatus:(NSArray *)jfwStatus withCallBack:(CallBack)callback;
- (void)jfwUploadEmail:(NSString *)jfwOid withCallBack:(CallBack)callback;

- (void) downLoadNominatedCadidatesForCallBack: (CallBack)callback;
- (void) downLoadNominatedHistory:(NSString *)lastUpdateTime andRecordNo:(NSString *)recordNo andLater:(NSString*)sign andCallBack: (CallBack)callback;
- (void) downLoadNominatedPartersByCondensedFlag:(NSString *)condensedFlag andCallBack: (CallBack)callback;
- (void) downLoadTrackerSummaryByRequestModel:(TrackerRequestModel *) requestModel andCallBack: (CallBack)callback;
- (void) downLoadTrackerNewFscByRequestModel:(TrackerNewFscRequestModel *) requestModel andCallBack: (CallBack)callback;

- (void) nominateAssessorUpload:(NSArray *)nominateAssessorList andCallBack:(CallBack)callback;

- (void) downLoadJFWDeleteStatusByGroupIDs : (NSArray *) groupIdDicArray andCollaboratorId:(NSString *) collaboratorId andCallBack:(CallBack)callback;

- (void) downloadDeletedAppointmentEvent:(NSString *)lastUpdateTime andCallBack:(CallBack)callback;
- (void) downloadDeletedJFW:(NSString *)lastUpdateTime andCallBack:(CallBack)callback;
- (void) downloadCreateDateTimeForAppointmentEvent:(NSString *)lastUpdateTime andCallBack:(CallBack)callback;

- (void) updateDefaultAcceptedRoadshowForProd1: (NSArray *)acceptedRoadshowList andCallBack:(CallBack)callback;
@end
