//
//  AnalysisJsonDataManager.m
//  TSSProject
//
//  Created by 于磊 on 16/5/27.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import "AnalysisJsonDataManager.h"

#import "TSSAppSetting.h"
#import "TSSAppData.h"
#import "TSSSecurity.h"

#import "SystemTss.h"
#import "EventManager.h"
#import "TSSValidationUtil.h"
#import "MultiLanguageControl.h"
#import "SmartTranslateHelper.h"

#import "NSData+Base64.h"
#import "NSDate+Ex.h"
#import "NSData+AES256.h"

#import "FollowUpAndNoteDao.h"
#import "AppointmentCommentsDao.h"
#import "AppointmentCustomerDao.h"
#import "AppointmentCustomerBean.h"

#import "EventLogBean.h"
#import "jfwBean.h"
#import "jfwDao.h"
#import "QuestionDao.h"
#import "QuestionBean.h"
#import "AgentProfileDao.h"
#import "AgentProfileBean.h"
#import "CustomerInfoDao.h"
#import "CustomerInfoBean.h"

#import "NotificationDao.h"
#import "NotificatinBean.h"
#import "NominatedCadidateDao.h"
#import "NominatedCadidateBean.h"
#import "NominationInfoDao.h"
#import "NominationInfoBean.h"
#import "NominatedPartnerDao.h"
#import "NominatedPartnerBean.h"

#import "TrackerResultBean.h"
#import "TrackerResultDao.h"
#import "TrackerRequestModel.h"
#import "TrackerResultNewFscBean.h"
#import "TrackerResultNewFscDao.h"


@implementation AnalysisJsonDataManager

#pragma mark - analysis
+(id)analysisAgentProfile:(NSDictionary *)dic
{
    DLog(@"analysisAgentProfile Server Returned Agent Profile Dict: %@", dic);
    NSMutableArray *mArr = [NSMutableArray array];
    AgentProfileBean *agent             = [[AgentProfileBean alloc]init];
    agent.agentcode                     = [dic objectForKey:@"agentCode"];
    agent.agentleadercode               = [dic objectForKey:@"managerCode"];
    [mArr addObject:agent];

    DLog(@"analysisAgentProfile final result:%@", mArr);
    return mArr;
}


+(id)analysisCustomer:(NSDictionary *)dic
{
    NSMutableArray *mArr = [NSMutableArray array];
    NSDictionary *tCustomerListDic = [dic objectForKey:@"tCustomerInfo"];
    NSArray *TCustomer= [tCustomerListDic objectForKey:@"TCustomerInfo"];
    
#if TEST_NET_RESPONSE_TIME > 0
    DLog(@"*************************AnalysisJsonDataManager-----analysisCustomer: TCustomer.count = %ld", TCustomer.count);
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
    int hasPhoteCustomerCount = 0;
#endif
    CustomerInfoBean *tCustomer = nil;
    NSString *tCreateTime = nil;
    NSNumber *num_createDate = nil;
    NSString *dobString = nil;
    NSNumber *numdob = nil;
    NSDate *tDate = nil;
    NSString *numTime = nil;
    NSNumber *number = nil;
   
    for (NSDictionary *subDic in TCustomer)
    {
        tCustomer = [[CustomerInfoDao getInstance] getBeanWithCustomerOid:[subDic objectForKey:@"oid"]];
        if ([TSSValidationUtil isNilOrNull:tCustomer]) {
            tCustomer = [[CustomerInfoBean alloc] init];

        }
        tCustomer.status = [subDic objectForKey:@"status"];
        tCustomer.customerUuid = [subDic objectForKey:@"id"];
        tCustomer.address = [subDic objectForKey:@"address"];
        tCustomer.firstname = [subDic objectForKey:@"firstName"];
        tCustomer.lastname = [subDic objectForKey:@"lastName"];
        tCustomer.age = [subDic objectForKey:@"age"];
        tCustomer.agentcode = [subDic objectForKey:@"agentCode"];
        tCustomer.branch = [subDic objectForKey:@"branch"];
        tCustomer.childrennum = [subDic objectForKey:@"childrenNo"];
        tCustomer.city = [subDic objectForKey:@"city"];
        tCustomer.companyname = [subDic objectForKey:@"companyName"];
        tCustomer.contacttype = [subDic objectForKey:@"contactType"];
        tCustomer.notes = [subDic objectForKey:@"notes"];
        tCreateTime = [subDic objectForKey:@"createDate"];
        tCustomer.createdate = [NSNumber numberWithLong:tCreateTime.longLongValue];
        tCustomer.createby = [subDic objectForKey:@"createby"];
        tCustomer.createddatetime = [subDic objectForKey:@"createddatetime"];
        num_createDate = [NSNumber numberWithLongLong:[[subDic objectForKey:@"createddatetime_Long"] longLongValue]];
        tCustomer.createddatetimelong = [num_createDate stringValue];
        tCustomer.customerType = [subDic objectForKey:@"customerType"];
        
        dobString = [subDic objectForKey:@"dob"];
        
        if (![TSSValidationUtil isNilOrEmptyString:dobString] && ![dobString isEqualToString:@"0"]) {
            numdob = [NSNumber numberWithLongLong:[dobString longLongValue]/1000];
            tDate = [NSDate convertNumberToDateNoDateFormat:numdob];
            tCustomer.dob = [tDate formatDateDefaultFormat];
        }
        
        tCustomer.email = [subDic objectForKey:@"email"];
        tCustomer.fullname = [subDic objectForKey:@"fullName"];
        tCustomer.gender = [subDic objectForKey:@"gender"];
        tCustomer.internalId = [subDic objectForKey:@"internalId"];
        tCustomer.internalRole = [subDic objectForKey:@"internalRole"];
        numTime = [subDic objectForKey:@"lastupdatedatetime_Long"];
        number = [NSNumber numberWithLongLong:[numTime longLongValue]];
        tCustomer.lastupdatedatetimelong = [number stringValue];
        tCustomer.maritalstatus = [subDic objectForKey:@"maritalStatus"];
        tCustomer.mobile = [subDic objectForKey:@"mobile"];
        tCustomer.oid = [subDic objectForKey:@"oid"];
        tCustomer.occupationcode = [subDic objectForKey:@"occupationCode"];
        tCustomer.serialVersionUID = [subDic objectForKey:@"serialVersionUID"];
        tCustomer.smoker = [subDic objectForKey:@"smoker"];
        if ([[subDic allKeys] containsObject:@"photo"]) {
            tCustomer.headerdata = [NSData dataWithBase64EncodedString:[subDic objectForKey:@"photo"]];
#if TEST_NET_RESPONSE_TIME > 0
            hasPhoteCustomerCount++;
#endif
        }
//        [tCustomer save];
        [mArr addObject:tCustomer];
    }
    [[CustomerInfoDao getInstance] saveOrUpdateArray: mArr];
#if TEST_NET_RESPONSE_TIME > 0
    DLog(@"*************************AnalysisJsonDataManager-----analysisCustomer: TCustomer.hasPhoteCustomerCount = %d", hasPhoteCustomerCount);
    NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
    DLog(@"*************************AnalysisJsonDataManager----- analysisCustomer: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
    
#endif
    return mArr;
}

+ (id) analysisCustomer: (NSDictionary *) dic forFetchFlag: (NSString *) fetchFlag
{
    NSMutableArray *mArr = [NSMutableArray array];
    NSDictionary *tCustomerListDic = [dic objectForKey:@"tCustomerInfo"];
    NSArray *TCustomer= [tCustomerListDic objectForKey:@"TCustomerInfo"];
    
#if TEST_NET_RESPONSE_TIME > 0
    DLog(@"*************************AnalysisJsonDataManager-----analysisCustomer forFetchFlag: TCustomer.count = %ld", TCustomer.count);
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
    int hasPhoteCustomerCount = 0;
#endif
    CustomerInfoBean *tCustomer = nil;
    NSString *tCreateTime = nil;
    NSNumber *num_createDate = nil;
    NSString *dobString = nil;
    NSNumber *numdob = nil;
    NSDate *tDate = nil;
    NSString *numTime = nil;
    NSNumber *number = nil;
   
    for (NSDictionary *subDic in TCustomer)
    {
        tCustomer = [[CustomerInfoDao getInstance] getBeanWithCustomerOid:[subDic objectForKey:@"oid"]];
        if ([TSSValidationUtil isNilOrNull:tCustomer]) {
            tCustomer = [[CustomerInfoBean alloc] init];
            tCustomer.status = @"1";
        }
        tCustomer.customerUuid = [subDic objectForKey:@"id"];
        tCustomer.address = [subDic objectForKey:@"address"];
        tCustomer.firstname = [subDic objectForKey:@"firstName"];
        tCustomer.lastname = [subDic objectForKey:@"lastName"];
        tCustomer.age = [subDic objectForKey:@"age"];
        tCustomer.agentcode = [subDic objectForKey:@"agentCode"];
        tCustomer.branch = [subDic objectForKey:@"branch"];
        tCustomer.childrennum = [subDic objectForKey:@"childrenNo"];
        tCustomer.city = [subDic objectForKey:@"city"];
        tCustomer.companyname = [subDic objectForKey:@"companyName"];
        tCustomer.contacttype = [subDic objectForKey:@"contactType"];
        tCustomer.notes = [subDic objectForKey:@"notes"];
        tCreateTime = [subDic objectForKey:@"createDate"];
        tCustomer.createdate = [NSNumber numberWithLong:tCreateTime.longLongValue];
        tCustomer.createby = [subDic objectForKey:@"createby"];
        tCustomer.createddatetime = [subDic objectForKey:@"createddatetime"];
        num_createDate = [NSNumber numberWithLongLong:[[subDic objectForKey:@"createddatetime_Long"] longLongValue]];
        tCustomer.createddatetimelong = [num_createDate stringValue];
        tCustomer.customerType = [subDic objectForKey:@"customerType"];
        
        dobString = [subDic objectForKey:@"dob"];
        
        if (![TSSValidationUtil isNilOrEmptyString:dobString] && ![dobString isEqualToString:@"0"]) {
            numdob = [NSNumber numberWithLongLong:[dobString longLongValue]/1000];
            tDate = [NSDate convertNumberToDateNoDateFormat:numdob];
            tCustomer.dob = [tDate formatDateDefaultFormat];
        }
        
        tCustomer.email = [subDic objectForKey:@"email"];
        tCustomer.fullname = [subDic objectForKey:@"fullName"];
        tCustomer.gender = [subDic objectForKey:@"gender"];
        tCustomer.internalId = [subDic objectForKey:@"internalId"];
        tCustomer.internalRole = [subDic objectForKey:@"internalRole"];
        numTime = [subDic objectForKey:@"lastupdatedatetime_Long"];
        number = [NSNumber numberWithLongLong:[numTime longLongValue]];
        tCustomer.lastupdatedatetimelong = [number stringValue];
        tCustomer.maritalstatus = [subDic objectForKey:@"maritalStatus"];
        tCustomer.mobile = [subDic objectForKey:@"mobile"];
        tCustomer.oid = [subDic objectForKey:@"oid"];
        tCustomer.occupationcode = [subDic objectForKey:@"occupationCode"];
        tCustomer.serialVersionUID = [subDic objectForKey:@"serialVersionUID"];
        tCustomer.smoker = [subDic objectForKey:@"smoker"];
        
        if ([TSSValidationUtil isNilOrEmptyString: fetchFlag] || [DOWNLOAD_IMAGE isEqualToString: fetchFlag]) {
            if ([[subDic allKeys] containsObject:@"photo"]) {
                tCustomer.headerdata = [NSData dataWithBase64EncodedString:[subDic objectForKey:@"photo"]];
#if TEST_NET_RESPONSE_TIME > 0
                hasPhoteCustomerCount++;
#endif
            }
        }
        //        [tCustomer save];
        [mArr addObject:tCustomer];
    }
    [[CustomerInfoDao getInstance] saveOrUpdateArray: mArr];
#if TEST_NET_RESPONSE_TIME > 0
    DLog(@"*************************AnalysisJsonDataManager-----analysisCustomer forFetchFlag: TCustomer.hasPhoteCustomerCount = %d", hasPhoteCustomerCount);
    NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
    DLog(@"*************************AnalysisJsonDataManager----- analysisCustomer forFetchFlag: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
    
#endif
    return mArr;
}

+(id)analysisNotificationViews:(NSDictionary *)dic
{
    NSMutableArray *mArr = [NSMutableArray array];
    NSArray *tArr = [dic objectForKey:@"TMessageList"];
#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
    DLog(@"*************************login test-----downLoadNotifactionAndLastUpdateTime: tArr.count = %ld", tArr.count);
#endif
    NotificatinBean *tNotification = nil;
    NSString *tStartTime = nil;
    NSString *tEndTime = nil;
    NSDictionary* extendInfo = nil;
    id obj = nil;
    NSString *treadStatus = nil;
    NSString *tcustomerName = nil;
    NSString *tformType = nil;
    for (NSDictionary *subDic in tArr)
    {
        tNotification = [[NotificatinBean alloc] init];
        tNotification.createddatetime = [subDic objectForKey:@"createddatetime"];
        tNotification.createddatetimeLong = [subDic objectForKey:@"createddatetime_Long"];
        tNotification.lastupdatedatetime = [subDic objectForKey:@"lastupdatedatetime"];
        tNotification.lastupdatedatetimeLong = [subDic objectForKey:@"lastupdatedatetime_Long"];
        tNotification.message = [subDic objectForKey:@"message"];
        
        tNotification.messageType = [subDic objectForKey:@"messageType"];
        tNotification.oid = [subDic objectForKey:@"oid"];
        tNotification.receiverCode = [subDic objectForKey:@"receiverCode"];
        tNotification.receiverName = [subDic objectForKey:@"receiverName"];
        tNotification.senderId = [subDic objectForKey:@"senderId"];
        tNotification.senderName = [subDic objectForKey:@"senderName"];
        tNotification.subject = [subDic objectForKey:@"subject"];
        tNotification.location = [subDic objectForKey:@"location"];
        tNotification.groupId = [subDic objectForKey:@"groupId"];
        tNotification.appointmentId = [subDic objectForKey:@"appointmentId"];
        tStartTime = [subDic objectForKey:@"startTime"];
        tNotification.startTime = [NSNumber numberWithLongLong:[tStartTime longLongValue]/1000];
        tEndTime = [subDic objectForKey:@"endTime"];
        if (![TSSValidationUtil isNilOrNull:tEndTime] && ![tEndTime isEqualToString:@"0"] ) {
            tNotification.endTime = [NSNumber numberWithLongLong:[tEndTime longLongValue]/1000];
        }
        extendInfo = nil;
        obj = [subDic objectForKey:@"extendInfo"];
        if([obj isKindOfClass:[NSArray class]]) {
            extendInfo = obj[0];
        } else {
           extendInfo = obj;
        }
        tNotification.groupId = [extendInfo objectForKey:@"groupId"];
        tNotification.eventId = [extendInfo objectForKey:@"oid"];
        treadStatus = [extendInfo objectForKey:@"readStatus"];
        tNotification.appointmentId = [extendInfo objectForKey:@"appointmentId"];
        if([TSSValidationUtil isNilOrNull:treadStatus]) {
            tNotification.readStatus = @"0";
        } else {
            if([treadStatus isEqualToString:@"1"] || [[treadStatus lowercaseString] isEqualToString:@"true"]) {
                tNotification.readStatus = @"1";
            } else if ([treadStatus isEqualToString:@"2"]){
                tNotification.readStatus = @"2";
            } else {
                tNotification.readStatus = @"0";
            }
        }
        tcustomerName = [extendInfo objectForKey:@"customerName"];
        tNotification.customerName = [TSSValidationUtil isNilOrNull:tcustomerName] ? @"" : tcustomerName; //
        tformType = [extendInfo objectForKey:@"formType"];
        tNotification.formType = [TSSValidationUtil isNilOrNull:tformType] ? @"" : tformType; //
        tNotification.uploadStatus = UPLOAD_STATUS_OK;
        
        if (![tNotification.readStatus isEqualToString:@"2"]) {
            [mArr addObject:tNotification];
        }
    }
#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
    DLog(@"*************************AnalysisJsonDataManager----- analysisNotificationViews: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
#endif
    return mArr;
}

+(id)analysisAppointment:(NSDictionary *)dic
{
    NSMutableArray *mArr = [NSMutableArray array];
    NSDictionary *tAppointListDic = [dic objectForKey:@"tEventList"];
    NSArray *tArr = [tAppointListDic objectForKey:@"TEvent"];
#if TEST_NET_RESPONSE_TIME > 0
    DLog(@"*************************login test-----analysisAppointment: tArr = %ld", tArr.count);
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
#endif
    int i = 0;
    NSString *tAppointmentId = nil;
    BOOL flag_calender = NO;
    FollowUpAndNoteBean *tempFollowUp = nil;
    id jsonObject = nil;
    NSArray *timeArr = nil;
    NSString *tStartTime = nil;
    NSString *tEndTime = nil;
    EKEvent *event = nil;
    
    NSString *customerName = nil;
    //save or update contacts
    NSArray *contactsLinked = nil;
    NSString *tCustomerId = nil;
    AppointmentCustomerBean *tContantAppointCustomer = nil;
    
    NSArray *agentsLinked = nil;
    NSString *internalId = nil;
    AppointmentCustomerBean *tAppointCustomer = nil;
    
    NSString *eventType = nil;
    NSString *agentName = nil;
    NSString *locationStr = nil;
    EKCalendar *calendar = nil;
    int time = 0;
    EKAlarm *alarm = nil;
    BOOL isBool = NO;
    
    NSString *groupmemberaccptedinfo = nil;
    NSData *jsonData = nil;
    NSArray *group = nil;
    NSString *contactId = nil;
    AppointmentCommentsBean *tAppointComment = nil;
    
    NSDictionary *timerDic = nil;
    NSDictionary *subContactsDic = nil;
    NSDictionary *subAgentDic = nil;
    NSDictionary *groupDic = nil;
    
    NSMutableArray *tContantAppointCustomerArray = [NSMutableArray array];
    NSMutableArray *tAppointCustomerArray = [NSMutableArray array];
    NSMutableArray *tAppointCommentArray = [NSMutableArray array];
    for (NSDictionary *subDic in tArr)
    {
        tAppointmentId = [subDic objectForKey:@"id"];
        
        flag_calender = NO;
        tempFollowUp = [[FollowUpAndNoteDao getInstance] getBeanWithAppointmentId:tAppointmentId];
        if (tempFollowUp==nil) {
            tempFollowUp = [[FollowUpAndNoteBean alloc] init];
            flag_calender = YES;
        }
        tempFollowUp.uploadStatus = UPLOAD_STATUS_OK;
        tempFollowUp.eventId = [subDic objectForKey:@"eventId"];
        tempFollowUp.appointmentId = [subDic objectForKey:@"id"];
        tempFollowUp.groupId = [subDic objectForKey:@"jfwgroupid"];
        tempFollowUp.eventType = [subDic objectForKey:@"subType"];
        tempFollowUp.eventTitleDescription = [subDic objectForKey:@"title"];
        tempFollowUp.appointmentType = [subDic objectForKey:@"type"];
        tempFollowUp.createBy = [subDic objectForKey:@"createBy"];
        tempFollowUp.createNames = [subDic objectForKey:@"createByNames"];
#if DOWNLOAD_DELETED_AND_CREATE_DATE_TIME_LONG_DATA == 1
        tempFollowUp.createDateTimeLong = [subDic objectForKey:@"createDateTime_Long"]; //此字段原来一版prod没有取出保存
#endif

        tempFollowUp.roadshowVersion = [subDic objectForKey:@"RoadshowVersion"];
        tempFollowUp.leaderAFullform = [subDic objectForKey:@"leaderAFullform"];
        
        jsonObject = [subDic objectForKey:@"reminderTimer"];
        if ([jsonObject isKindOfClass:[NSArray class]]) {
            timeArr = [subDic objectForKey:@"reminderTimer"];
            for (i = 0; i < timeArr.count; i++) {
                timerDic = [timeArr objectAtIndex: i];
                tempFollowUp.notifyTime = [timerDic objectForKey:@"timer"];
            }
        }
        
        tStartTime = [subDic objectForKey:@"startTime"];
        tempFollowUp.startTime = [NSNumber numberWithLongLong:[tStartTime longLongValue]/1000];
        tEndTime = [subDic objectForKey:@"endTime"];
        tempFollowUp.endTime =  [NSNumber numberWithLongLong:[tEndTime longLongValue]/1000];
        tempFollowUp.eventDescription =  [subDic objectForKey:@"description"];
        
        tempFollowUp.location = [subDic objectForKey:@"location"];
        tempFollowUp.responseStatus = [subDic objectForKey:@"status"];
        tempFollowUp.deleteStatus = [subDic objectForKey:@"deleteStatus"];
        
        tempFollowUp.othersDescription = [subDic objectForKey:@"OthersDescription"];
        tempFollowUp.createJFWSameCustomer = [subDic objectForKey:@"newJFWSameCustomer"];

        if ([[tempFollowUp.deleteStatus uppercaseString] isEqualToString:RESPONSE_STATUS_REMOVE]) {
            //20171214 modify event 本地保留数据，不删除
#if DOWNLOAD_DELETED_AND_CREATE_DATE_TIME_LONG_DATA == 0
            //*
             // delete relate customer
             [[AppointmentCustomerDao getInstance] delByAppointmentId:tempFollowUp.appointmentId];
             //delete relate comments
             [[AppointmentCommentsDao getInstance] delByAppointmentId:tempFollowUp.appointmentId];
             //*/
#endif
             if (![TSSValidationUtil isNilOrEmptyString:tempFollowUp.eventIdentifier]) {
                 event = [[EventManager shareInstance].store eventWithIdentifier:tempFollowUp.eventIdentifier];
                 [[EventManager shareInstance] deleteEvent:event];
             }
#if DOWNLOAD_DELETED_AND_CREATE_DATE_TIME_LONG_DATA == 0
            //*
             [tempFollowUp delete];;
             continue;
             //*/
#endif
         }
        
        tempFollowUp.calendarStyle = [subDic objectForKey:@"category"];
        tempFollowUp.lastUpdateDateTimeLong = [subDic objectForKey:@"lastUpdateDateTime_Long"];
        
        // delete
        [[AppointmentCustomerDao getInstance] delByAppointmentId:tempFollowUp.appointmentId];

        customerName = nil;
        //save or update contacts
        contactsLinked = [subDic objectForKey:@"contactsLinked"];
        for (i = 0; i < contactsLinked.count; i++)
        {
            subContactsDic = [contactsLinked objectAtIndex: i];
            tCustomerId = [subContactsDic objectForKey:@"id"];
            if (![TSSValidationUtil isNilOrEmptyString:tCustomerId]) {
                tContantAppointCustomer = [[AppointmentCustomerBean alloc] init];
                tempFollowUp.customerName = [subContactsDic objectForKey:@"fullName"];
                tContantAppointCustomer.customerType = @"1";
                tContantAppointCustomer.groupId = tempFollowUp.groupId;
                tContantAppointCustomer.appointmentId = tempFollowUp.appointmentId;
                tContantAppointCustomer.customerId = tCustomerId;
                tContantAppointCustomer.severId = [subContactsDic objectForKey:@"oid"];
                tContantAppointCustomer.customerName = [subContactsDic objectForKey:@"fullName"];
                tContantAppointCustomer.jfwRole = [subContactsDic objectForKey:@"role"];
//                [tContantAppointCustomer save];
                [tContantAppointCustomerArray addObject: tContantAppointCustomer];
                
                customerName = tContantAppointCustomer.customerName;
            }
        }
        
        //save or update agents
        agentsLinked = [subDic objectForKey:@"agentsLinked"];
        
        for (i = 0; i < agentsLinked.count; i++)
        {
            subAgentDic = [agentsLinked objectAtIndex: i];
            internalId = [subAgentDic objectForKey:@"id"];
            if (![TSSValidationUtil isNilOrEmptyString:internalId]) {
                tAppointCustomer  = [[AppointmentCustomerBean alloc] init];
                tAppointCustomer.customerType = @"0";
                tAppointCustomer.groupId = tempFollowUp.groupId;
                tAppointCustomer.appointmentId = tempFollowUp.appointmentId;
                tAppointCustomer.severId = [subAgentDic objectForKey:@"oid"];
                tAppointCustomer.customerId = internalId;
                tAppointCustomer.customerName = [subAgentDic objectForKey:@"fullName"];
                tAppointCustomer.jfwRole = [subAgentDic objectForKey:@"role"];
                if ([tAppointCustomer.jfwRole isEqualToString:Agent]) {
                    tempFollowUp.agentName = [subAgentDic objectForKey:@"fullName"];
                }
//                [tAppointCustomer save];
                [tAppointCustomerArray addObject:tAppointCustomer];
                
                //for leader create appointment to insert calendar
                //todo
                if ([tempFollowUp.appointmentType isEqualToString:JFW_APPOINTMENT_TYPE]&&[tAppointCustomer.jfwRole isEqualToString:Agent]&&[[TSSAppData getInstance].agentCode isEqualToString:tAppointCustomer.customerId]) {
                    if(flag_calender) {
                        if ([TSSValidationUtil isNilOrEmptyString:tempFollowUp.eventIdentifier]) {
                            //create event
                            event = [EKEvent eventWithEventStore:[EventManager shareInstance].store];
                            event.title = @"New Event (Joint Field Work)";

                            eventType = [[SmartTranslateHelper getInstance] getUIEventTypeByAppointmentType: tempFollowUp.appointmentType];
                            agentName = tempFollowUp.createNames;
                            if ([[TSSAppData getInstance].agentCode isEqualToString:tempFollowUp.createBy]) {
                                agentName = tAppointCustomer.customerName;
                            } else {
                                agentName = tempFollowUp.createNames;
                            }
                            locationStr = ([TSSValidationUtil isNilOrEmptyString:tempFollowUp.location] == NO) ? [NSString stringWithFormat: @"at \n%@", tempFollowUp.location] : @"";
                            event.notes = [NSString stringWithFormat: @"Joint Field Work\n%@ - %@ \nmeet %@ %@", eventType, agentName, [TSSValidationUtil convertNilToEmptyString: customerName], locationStr];

                            event.location = tempFollowUp.location;
                            calendar = [[EventManager shareInstance].store defaultCalendarForNewEvents];
                            [event setCalendar:calendar];

                            event.startDate = [NSDate convertNumberToDateNoDateFormat:tempFollowUp.startTime];
                            event.endDate = [NSDate convertNumberToDateNoDateFormat:tempFollowUp.endTime];
                            
                            time = [[NSString stringWithFormat:@"-%d",tempFollowUp.notifyTime.intValue*60] intValue];
                            
                            alarm = [EKAlarm alarmWithRelativeOffset:time];
                            [event setAlarms:@[alarm]];
                            
                            isBool = [[EventManager shareInstance] createEvent:event];
                            if (isBool == YES) {
                                tempFollowUp.eventIdentifier = event.eventIdentifier;
                            }
                        } else {
                            //to do update event
                        }
                    }
                }
            }
        }
        
        groupmemberaccptedinfo = [subDic objectForKey:@"groupmemberaccptedinfo"];
        if (groupmemberaccptedinfo.length != 0)
        {
            jsonData = [groupmemberaccptedinfo dataUsingEncoding:NSUTF8StringEncoding];
            group = [NSJSONSerialization JSONObjectWithData:jsonData options:0 error:nil];
            for (i = 0; i < group.count; i++) {
                
                groupDic = [group objectAtIndex: i];
                contactId = [groupDic objectForKey:@"contactId"];
                tAppointComment = [[AppointmentCommentsDao getInstance] getBeanWithAppointmentId:tempFollowUp.appointmentId];
                if (tAppointComment==nil) {
                    tAppointComment = [[AppointmentCommentsBean alloc] init];
                }
                
                tAppointComment.status = [groupDic objectForKey:@"acceptstatus"];
                tAppointComment.contactId = contactId;
                tAppointComment.appointmentId = tempFollowUp.appointmentId;
                tAppointComment.commentsTime = [groupDic objectForKey:@"time"];
                tAppointComment.eventId = [groupDic objectForKey:@"eventId"];
//                [tAppointComment save];
                [tAppointCommentArray addObject:tAppointComment];
            }
        }
        
//        [tempFollowUp save];
        [mArr addObject:tempFollowUp];
    }
    
    [[FollowUpAndNoteDao getInstance] saveOrUpdateArray:mArr];
    [[AppointmentCustomerDao getInstance] saveOrUpdateArray: tAppointCustomerArray];
    [[AppointmentCustomerDao getInstance] saveOrUpdateArray: tContantAppointCustomerArray];
    [[AppointmentCommentsDao getInstance] saveOrUpdateArray: tAppointCommentArray];
    
#if TEST_NET_RESPONSE_TIME > 0
    DLog(@"*************************AnalysisJsonDataManager-----analysisAppointment: tAppointCustomerArrayCount = %ld", tAppointCustomerArray.count);
    DLog(@"*************************AnalysisJsonDataManager-----analysisAppointment: tContantAppointCustomerArrayCount = %ld", tContantAppointCustomerArray.count);
    DLog(@"*************************AnalysisJsonDataManager-----analysisAppointment: tAppointCommentArray = %ld", tAppointCommentArray.count);
    NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
    DLog(@"*************************AnalysisJsonDataManager----- analysisAppointment: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
    
#endif
    
    return mArr;
}

+(id)analysisJfwViews:(NSDictionary *)dic
{
    NSMutableArray *mArr = [NSMutableArray array];
    NSArray *tArr = [dic objectForKey:@"TEventJFWList"];

#if TEST_NET_RESPONSE_TIME > 0
    DLog(@"*************************login test-----analysisJfwViews: tArr = %ld", tArr.count);

    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];

    int hasImgSignAgentCount = 0;
    int hasImgSignLeaderCount = 0;
#endif
    
    NSString *jfwGroupId = nil;
    NSString *jfwStatus = nil;
    JfwBean *tJfw = nil;
    NSString *tStartTime = nil;
    NSString *tEndTime = nil;
    NSString *tRevisedStartTime = nil;
    NSString *imgSignAgent_str = nil;
    NSString *imgSignLeader_str = nil;
    NSString *tLongLastUPTime = nil;
    NSArray *questionArr = nil;
    QuestionBean *tQuestion = nil;
    NSString *tCreateTime = nil;
    NSString *tUpdateTime = nil;
    int i = 0;
    NSDictionary *qtDic = nil;
    
    NSMutableArray *questionArray = [NSMutableArray array];
    
    for (NSDictionary *subDic in tArr)
    {
        jfwGroupId = [subDic objectForKey:@"groupId"];
        jfwStatus = [subDic objectForKey:@"status"];
        //20171215 modify 删除状态的jfw也要保存
#if DOWNLOAD_DELETED_AND_CREATE_DATE_TIME_LONG_DATA == 0
        //*
        if([jfwStatus isEqualToString:JFW_TYPE_STATUS_DELETED]) {
            [[JfwDao getInstance] deleteGroupById:jfwGroupId];
            [[QuestionDao getInstance] deleteGroupById:jfwGroupId];
            continue;
        }
         //*/
#endif
        tJfw = [[JfwDao getInstance] getBeanWithGroupId:[subDic objectForKey:@"groupId"] andFormType:[subDic objectForKey:@"type"]];
        if (tJfw==nil) {
            tJfw = [[JfwBean alloc] init];
        }
        tJfw.formTitle = [subDic objectForKey:@"title"];
        tJfw.formDescription = [subDic objectForKey:@"description"];
        tJfw.groupId = [subDic objectForKey:@"groupId"];
        tStartTime = [subDic objectForKey:@"startTime"];
        tJfw.startTime = [NSNumber numberWithLongLong:[tStartTime longLongValue]/1000];
        tRevisedStartTime = [subDic objectForKey:@"revisedStartTime"];
        if (![TSSValidationUtil isNilOrNull:tRevisedStartTime] && ![tRevisedStartTime isEqualToString:@"0"] ) {
          tJfw.revisedStartTime = [NSNumber numberWithLongLong:[tRevisedStartTime longLongValue]/1000];
        }
        tEndTime = [subDic objectForKey:@"endTime"];
        if (![TSSValidationUtil isNilOrNull:tEndTime] && ![tEndTime isEqualToString:@"0"] ) {
            tJfw.endTime = [NSNumber numberWithLongLong:[tEndTime longLongValue]/1000];
        }
        tJfw.advisorCode = [subDic objectForKey:@"advisorCode"];
        tJfw.advisorName = [subDic objectForKey:@"advisorName"];
        tJfw.assesorCode = [subDic objectForKey:@"assessorCode"];
        tJfw.assesorName = [subDic objectForKey:@"assessorName"];
        tJfw.customerName = [subDic objectForKey:@"customerName"];
        tJfw.policyNumber = [subDic objectForKey:@"policyNumber"];
        tJfw.submissionLocation = [subDic objectForKey:@"submissionLocation"];
        tJfw.deleteStatus = [subDic objectForKey:@"deleteStatus"];
        tJfw.parterDeleteStatus = [subDic objectForKey:@"parterdeleteStatus"];
        tJfw.additionalPolicyNumber = [subDic objectForKey:@"additionalPolicyNumber"];
        tJfw.purposeDescription = [subDic objectForKey:@"purposeDescription"];
        tJfw.otherActivity = [subDic objectForKey:@"otherActivity"];
                
        imgSignAgent_str = [subDic objectForKey:@"imgSignAgent"];
#if TEST_NET_RESPONSE_TIME > 0
        if (imgSignAgent_str != nil && imgSignAgent_str.length > 0) {
            hasImgSignAgentCount ++;
        }
#endif
        tJfw.imgSignAgent = [NSData dataWithBase64EncodedString:imgSignAgent_str];

        imgSignLeader_str = [subDic objectForKey:@"imgSignLeader"];
#if TEST_NET_RESPONSE_TIME > 0
        if (imgSignLeader_str != nil && imgSignLeader_str.length > 0) {
            hasImgSignLeaderCount ++;
        }
#endif
        tJfw.imgSignLeader = [NSData dataWithBase64EncodedString:imgSignLeader_str];
        tJfw.commentsByLeader = [subDic objectForKey:@"commentsByLeader"];
        tJfw.commentsByAgent = [subDic objectForKey:@"commentsByAgent"];
        tJfw.totalScore = [subDic objectForKey:@"totalScore"];
        tJfw.competent = [subDic objectForKey:@"competent"];
        tJfw.competentComments = [subDic objectForKey:@"competentComments"];
        //NSString *tCreateTime = [subDic objectForKey:@"createTime"];
       // tJfw.createdate = [NSNumber numberWithLongLong:[tCreateTime longLongValue]/1000];
       //NSString *tUpdateTime = [subDic objectForKey:@"updateTime"];
       // tJfw.updatedate = [NSNumber numberWithLongLong:[tUpdateTime longLongValue]/1000];
        tJfw.serverId = [subDic objectForKey:@"oid"];
        tJfw.jfwStatus = [subDic objectForKey:@"status"];
        
        tJfw.jfwType = [subDic objectForKey:@"type"];
        tJfw.agentLink = [subDic objectForKey:@"agentsLinked"];
        tJfw.contactLink = [subDic objectForKey:@"contactsLinked"];

        tJfw.eventType = [subDic objectForKey:@"eventType"];
        tJfw.createBy = [subDic objectForKey:@"agentCode"];
        tJfw.location = [subDic objectForKey:@"location"];
        tJfw.lastupdatedatetime = [subDic objectForKey:@"lastUpdateDateTime"];
        tLongLastUPTime = [subDic objectForKey:@"lastUpdateDateTime_Long"];
        tJfw.lastupdatedatetimelong = [NSNumber numberWithLongLong:tLongLastUPTime.longLongValue];
        
        tLongLastUPTime = [subDic objectForKey:@"FSCSubmissionTime_Long"];
        tJfw.fscSubmissionTimeLong = [NSNumber numberWithLongLong:tLongLastUPTime.longLongValue];
        tLongLastUPTime = [subDic objectForKey:@"AssessorSubmissionTime_Long"];
        tJfw.assessorSubmissionTimeLong = [NSNumber numberWithLongLong:tLongLastUPTime.longLongValue];
        
        tJfw.serverCreateTime = [subDic objectForKey:@"createDateTime_Long"];
        tJfw.freshFSCTandC = [subDic objectForKey:@"newFSCTandC"];
        
        questionArr = [subDic objectForKey:@"question"];
        if (questionArr.count > 0) {
            for (i = 0; i < questionArr.count; i++) {
                qtDic = [questionArr objectAtIndex: i];
                tQuestion = [[QuestionDao getInstance] getBeanWithIdAndTypeAndNo:tJfw.groupId andType:tJfw.jfwType andQuestionNO:[qtDic objectForKey:@"questionNo"]];
                if(tQuestion==nil) {
                    tQuestion = [[QuestionBean alloc] init];
                }
                tQuestion.groupId = tJfw.groupId;
                tQuestion.jfwId = [qtDic objectForKey:@"jfwId"];
                tQuestion.questionType = [qtDic objectForKey:@"type"];
                tQuestion.questionTitle = [qtDic objectForKey:@"title"];
                tQuestion.questionDescrption = [qtDic objectForKey:@"descrption"];
                tQuestion.questionNo = [qtDic objectForKey:@"questionNo"];
                tQuestion.answer = [qtDic objectForKey:@"answer"];
                tQuestion.remark = [qtDic objectForKey:@"remark"];
                tCreateTime = [qtDic objectForKey:@"createTime"];
                tQuestion.createdate = [NSNumber numberWithLongLong:[tCreateTime longLongValue]/1000];
                tUpdateTime = [qtDic objectForKey:@"updateTime"];
                tQuestion.updatedate = [NSNumber numberWithLongLong:[tUpdateTime longLongValue]/1000];
//                [tQuestion save];
                //[mArr addObject:tQuestion];
                
                [questionArray addObject:tQuestion];
            }
        }
        //20171215 modify 删除状态的jfw也要保存
#if DOWNLOAD_DELETED_AND_CREATE_DATE_TIME_LONG_DATA == 0
        if (![tJfw.deleteStatus isEqualToString:RESPONSE_STATUS_REMOVE]) {
#endif
//            [tJfw save];
            [mArr addObject:tJfw];
#if DOWNLOAD_DELETED_AND_CREATE_DATE_TIME_LONG_DATA == 0
        }
#endif
        
//        [mArr addObject:tJfw];
    }
    
    [[JfwDao getInstance] saveOrUpdateArray: mArr];
    [[QuestionDao getInstance] saveOrUpdateArray: questionArray];
#if TEST_NET_RESPONSE_TIME > 0
    DLog(@"*************************login test-----analysisJfwViews: hasImgSignAgentCount = %d", hasImgSignAgentCount);
    DLog(@"*************************login test-----analysisJfwViews: hasImgSignLeaderCount = %d", hasImgSignLeaderCount);
    DLog(@"*************************login test-----analysisJfwViews: questionArray = %ld", questionArray.count);
    NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
    DLog(@"*************************AnalysisJsonDataManager----- analysisJfwViews: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
    
#endif
    return mArr;
}

+(id)analysisJfwEmail:(NSDictionary *)dic
{
    NSString *sendCount = [dic objectForKey:@"sendCount"];
    NSString *sendSuccessCount = [dic objectForKey:@"sendSuccessCount"];
    NSArray *detailArr = [dic objectForKey:@"detail"];
    NSString *selfName = nil;
    NSString *otherName = nil;
    NSString *selfSendStatus = nil;
    NSString *otherSendStatus = nil;
    NSString *agentCode = nil;
    for (NSDictionary *detaiDic in detailArr) {
        agentCode = [detaiDic objectForKey:@"agentCode"];
        if ([agentCode isEqualToString:[TSSAppData getInstance].agentCode]) {
            selfSendStatus = [detaiDic objectForKey:@"sendMailSuccess"];
            selfName = [detaiDic objectForKey:@"agentName"];
        } else {
            otherSendStatus = [detaiDic objectForKey:@"sendMailSuccess"];
            otherName = [detaiDic objectForKey:@"agentName"];
        }
    }
    NSString *messageStatus = [NSString stringWithFormat:@"sendCount %@ sendSuccessCount %@ %@ %@ %@ %@",sendCount,sendSuccessCount,selfName,selfSendStatus,otherName,otherSendStatus];
    DLog(@"analysisJfwEmail : %@",messageStatus);
    return sendSuccessCount;
}

+ (id) analysisNominatedCadidates:(NSDictionary *)dic
{
    NSMutableArray *nominatedCadidateArr = [NSMutableArray array];
    NSArray *dictionaryArr = [dic objectForKey:@"NominatedCadidates"];
    if (dictionaryArr != nil && dictionaryArr.count > 0) {
        [[NominatedCadidateDao getInstance] deleteAll];
    }
#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
    DLog(@"*************************AnalysisJsonDataManager-----analysisNominatedCadidates: dictionaryArr = %ld", dictionaryArr.count);
#endif
    NominatedCadidateBean *ncBean = nil;
    for (NSMutableDictionary *nominatedCadidateDic in dictionaryArr) {
        ncBean = [[NominatedCadidateBean alloc] init];
        ncBean.nominatedCode = [nominatedCadidateDic objectForKey:@"nominatedCode"];
        ncBean.nominatedName = [nominatedCadidateDic objectForKey:@"nominatedName"];
        ncBean.nominatedAgencyCode = [nominatedCadidateDic objectForKey:@"nominatedAgencyCode"];
        ncBean.nominatedDistrictCode = [nominatedCadidateDic objectForKey:@"nominatedDistrictCode"];
//        [ncBean save];
        [nominatedCadidateArr addObject: ncBean];
    }
    [[NominatedCadidateDao getInstance] saveOrUpdateArray: nominatedCadidateArr];
#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
    DLog(@"*************************AnalysisJsonDataManager----- analysisNominatedCadidates: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
#endif
    return nominatedCadidateArr;
}

+(id)analysisNominatedHistory:(NSDictionary *)dic
{
    NSMutableArray *nominationInfoArr = [NSMutableArray array];
    NSArray *dictionaryArr = [dic objectForKey:@"NominatedHistory"];
#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
    DLog(@"*************************AnalysisJsonDataManager-----analysisNominatedHistory: dictionaryArr = %ld", dictionaryArr.count);
#endif
    NSString *nominationInfoID = nil;
    NominationInfoBean *niBean = nil;
    NSString *dateStr = nil;
    for (NSMutableDictionary *nominatedHistoryDic in dictionaryArr) {
        nominationInfoID = [nominatedHistoryDic objectForKey:@"id"];
        
        niBean = [[NominationInfoDao getInstance] getBeanWithNominationInfoID: nominationInfoID];
        if (niBean == nil) {
            niBean = [[NominationInfoBean alloc] init];
        }
        niBean.nominationInfoID = [nominatedHistoryDic objectForKey:@"id"];
        niBean.oid = [nominatedHistoryDic objectForKey:@"oid"];
        niBean.sponsorLeaderCode = [nominatedHistoryDic objectForKey:@"sponsorLeaderCode"];
        
        niBean.fscCode = [nominatedHistoryDic objectForKey:@"FSCCode"];
        niBean.fscName = [nominatedHistoryDic objectForKey:@"FSCName"];
        niBean.assessorCode = [nominatedHistoryDic objectForKey:@"assessorCode"];
        niBean.assessorName = [nominatedHistoryDic objectForKey:@"assessorName"];
        
        niBean.assessorStartDate = [NSNumber numberWithLongLong:[[nominatedHistoryDic objectForKey:@"assessorStartDate"] longLongValue]/1000];
        niBean.assessorEndDate = [NSNumber numberWithLongLong: ([[nominatedHistoryDic objectForKey:@"assessorEndDate"] longLongValue] - 999)/1000];
        dateStr = [nominatedHistoryDic objectForKey:@"assessorEndDate"];
        
        niBean.createDateTimeLong = [nominatedHistoryDic objectForKey:@"createdatetime_Long"];
        niBean.lastUpdateDateTimeLong = [nominatedHistoryDic objectForKey:@"lastupdatedatetime_Long"];
        niBean.deleteStatus = [nominatedHistoryDic objectForKey:@"status"];
        
        niBean.uploadStatus = UPLOAD_STATUS_OK;
//        [niBean save];
        [nominationInfoArr addObject: niBean];
    }
    [[NominationInfoDao getInstance] saveOrUpdateArray: nominationInfoArr];
#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
    DLog(@"*************************AnalysisJsonDataManager----- analysisNominatedHistory: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
#endif
    return nominationInfoArr;
}

+ (void) transCustomerFromDict:(NSMutableDictionary *) customerDic intoCustomerInfo: (CustomerInfoBean *) customerInfo andTempString:(NSString *) tempString andTempNumber:(NSNumber *) tempNumber
{
    customerInfo.customerUuid = [customerDic objectForKey:@"id"];
    customerInfo.address = [customerDic objectForKey:@"address"];
    customerInfo.firstname = [customerDic objectForKey:@"firstName"];
    customerInfo.lastname = [customerDic objectForKey:@"lastName"];
    customerInfo.age = [customerDic objectForKey:@"age"];
    customerInfo.agentcode = [customerDic objectForKey:@"agentCode"];
    customerInfo.branch = [customerDic objectForKey:@"branch"];
    customerInfo.childrennum = [customerDic objectForKey:@"childrenNo"];
    customerInfo.city = [customerDic objectForKey:@"city"];
    customerInfo.companyname = [customerDic objectForKey:@"companyName"];
    customerInfo.contacttype = [customerDic objectForKey:@"contactType"];
    customerInfo.notes = [customerDic objectForKey:@"notes"];
    
    tempString = [customerDic objectForKey:@"createDate"];
    customerInfo.createdate = [NSNumber numberWithLong:tempString.longLongValue];
    customerInfo.createby = [customerDic objectForKey:@"createby"];
    customerInfo.createddatetime = [customerDic objectForKey:@"createddatetime"];
    tempNumber = [NSNumber numberWithLongLong:[[customerDic objectForKey:@"createddatetime_Long"] longLongValue]];
    customerInfo.createddatetimelong = [tempNumber stringValue];
    customerInfo.customerType = [customerDic objectForKey:@"customerType"];
    
    tempString = [customerDic objectForKey:@"dob"];
    
    if (![TSSValidationUtil isNilOrEmptyString:tempString] && ![tempString isEqualToString:@"0"]) {
        tempNumber = [NSNumber numberWithLongLong:[tempString longLongValue]/1000];
        customerInfo.dob = [[NSDate convertNumberToDateNoDateFormat:tempNumber] formatDateDefaultFormat];
    }
    
    customerInfo.email = [customerDic objectForKey:@"email"];
    customerInfo.fullname = [customerDic objectForKey:@"fullName"];
    customerInfo.gender = [customerDic objectForKey:@"gender"];
    customerInfo.internalId = [customerDic objectForKey:@"internalId"];
    customerInfo.internalRole = [customerDic objectForKey:@"internalRole"];
    tempString = [customerDic objectForKey:@"lastupdatedatetime_Long"];
    tempNumber = [NSNumber numberWithLongLong:[tempString longLongValue]];
    customerInfo.lastupdatedatetimelong = [tempNumber stringValue];
    customerInfo.maritalstatus = [customerDic objectForKey:@"maritalStatus"];
    customerInfo.mobile = [customerDic objectForKey:@"mobile"];
    customerInfo.oid = [customerDic objectForKey:@"oid"];
    customerInfo.occupationcode = [customerDic objectForKey:@"occupationCode"];
    customerInfo.serialVersionUID = [customerDic objectForKey:@"serialVersionUID"];
    customerInfo.smoker = [customerDic objectForKey:@"smoker"];
    if ([[customerDic allKeys] containsObject:@"photo"]) {
        customerInfo.headerdata = [NSData dataWithBase64EncodedString:[customerDic objectForKey:@"photo"]];
    }
}

+ (id) analysisNominatedParters: (NSDictionary *) dic andCondensedFlag:(NSString *)condensedFlag
{
    NSMutableArray *nominatedParterArr = [NSMutableArray array];
    NSArray *dictionaryArr = [dic objectForKey:@"tCustomerInfo"];

#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
    DLog(@"*************************login test-----analysisNominatedParters: %@, dictionaryArr = %ld", condensedFlag,  dictionaryArr.count);
#endif
    NominatedPartnerBean *npBean = nil;
    NSString *tempString = nil;
    NSNumber *tempNumber = nil;
    for (NSMutableDictionary *parternerDic in dictionaryArr) {
        if ([condensedFlag isEqualToString: IMO_SMART_YES]) {
            npBean = [[NominatedPartnerBean alloc] init];
            npBean.partnerCode = [parternerDic objectForKey:@"agentCode"];
            npBean.partnerName = [parternerDic objectForKey:@"agentName"];
        } else if ([condensedFlag isEqualToString: CONDENSED_FLAG_FOR_DOWNLOAD_NOMINATED_PARTERS]) {
            
            npBean = [[NominatedPartnerDao getInstance] getBeanWithInternalId:[parternerDic objectForKey:@"internalId"]];
            if ([TSSValidationUtil isNilOrNull:npBean]) {
                npBean = [[NominatedPartnerBean alloc] init];
                npBean.status = @"1";
            }
            npBean.partnerCode = [parternerDic objectForKey:@"internalId"];
            npBean.partnerName = [parternerDic objectForKey:@"fullName"];
            npBean.internalId = [parternerDic objectForKey:@"internalId"];
            npBean.fullname = [parternerDic objectForKey:@"fullName"];
            npBean.customerType = IMO_SMART_NO;
            
            if ([[TSSAppData getInstance].agentJfwRole isEqualToString: Leader]) {
                npBean.internalRole = Agent;
            } else if ([[TSSAppData getInstance].agentJfwRole isEqualToString: Agent]) {
                npBean.internalRole = Leader;
            }
            [npBean save];
            [nominatedParterArr addObject: npBean];
        } else {
            npBean = [[NominatedPartnerDao getInstance] getBeanWithCustomerOid:[parternerDic objectForKey:@"oid"]];
            if ([TSSValidationUtil isNilOrNull:npBean]) {
                npBean = [[NominatedPartnerBean alloc] init];
                npBean.status = @"1";
            }
            [self transCustomerFromDict: parternerDic intoCustomerInfo: npBean andTempString: tempString andTempNumber: tempNumber];
            [npBean save];
            [nominatedParterArr addObject: npBean];
        }
    }
#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
    DLog(@"*************************AnalysisJsonDataManager----- analysisNominatedParters: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
#endif
    return nominatedParterArr;
}

+ (id) analysisTrackerSummary: (NSDictionary *) dic andRequestModel:(TrackerRequestModel *) requestModel
{
    NSMutableArray *trackerSummaryArr = [NSMutableArray array];
    NSArray *dictionaryArr = [dic objectForKey:@"FSCCodeList"];
    
    //如果没有返回结果，等同于请求失败
    if (dictionaryArr == nil || dictionaryArr.count < 1) {
        requestModel.errorMessage = MuliteLocalizedString(@"TrackerSearch_Fail_FSCCodeList_Empty");
        return nil;
    }

#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
    DLog(@"*************************login test-----analysisTrackerSummary: dictionaryArr = %ld",  dictionaryArr.count);
#endif

    NSString *agentCode = nil;
    NSMutableArray *trackerArray = nil;
    TrackerResultBean *trBean = nil;
    NSNumber *trackerNum = nil;
    NSUInteger i = 0;
    NSUInteger year = requestModel.currentYear - 1;
    NSUInteger tempCount = 0;
    for (NSMutableDictionary *trackerDic in dictionaryArr) {
        tempCount = 0;
        agentCode = [trackerDic objectForKey:@"agentCode"];
        trackerArray = [trackerDic objectForKey:@"Tracker"];
        year = requestModel.currentYear - 1;
        
        //如果没有返回tracker，或者每个agentcode对应的tracker数量不是24，都视为请求失败
        if (trackerArray == nil || trackerArray.count < 1) {
            requestModel.errorMessage = MuliteLocalizedString(@"TrackerSearch_Fail_Tracker_Empty");
            return nil;
        }
        
        for (i = 0; i < 24; i++) {
            
            trBean = [[TrackerResultBean alloc] init];
            trBean.fscCode = agentCode;
            if (i < trackerArray.count) {
                trackerNum = [trackerArray objectAtIndex: i];
            } else {
                trackerNum = [NSNumber numberWithInteger: 0];
            }
            
            trBean.year = [NSString stringWithFormat: @"%ld", year];
            trBean.month = [NSString stringWithFormat: @"%ld", tempCount + 1];
            trBean.trackerCount = trackerNum;
            
            [trackerSummaryArr addObject: trBean];
            
            tempCount ++;
            if (tempCount == 12) {
                tempCount = 0;
                year = requestModel.currentYear;
            }
        }
    }
    [[TrackerResultDao getInstance] deleteAll];
    [[TrackerResultDao getInstance] saveOrUpdateArray: trackerSummaryArr];
#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
    DLog(@"*************************AnalysisJsonDataManager----- analysisTrackerSummary: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
#endif
    return trackerSummaryArr;
}

+ (id) analysisTrackerNewFscTandC: (NSDictionary *) dic
{
    NSMutableArray *trackerResultArr = [NSMutableArray array];
    NSArray *tandcDictList = [dic objectForKey:@"TandCList"];
    
    //删除原有数据
    [[TrackerResultNewFscDao getInstance] deleteAll];

    if (tandcDictList == nil || tandcDictList.count < 1) {
        return nil;
    }
    
#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
    DLog(@"*************************login test-----analysisTrackerNewFscTandC: dictionaryArr = %ld",  tandcDictList.count);
#endif
    
    NSString *agentCode = nil;
    NSMutableArray *tandcArray = nil;
    TrackerResultNewFscBean *trBean = nil;
    NSUInteger i = 0, j = 0;
    NSDictionary *tandc = nil;
    NSArray *formsArray = nil;
    NSDictionary *categoryDict = nil;
    NSString *categoryStr = nil;
    NSString *dateLongStr = nil;

    for (NSDictionary *tandcDict in tandcDictList) {
    
        agentCode = [tandcDict objectForKey:@"agentCode"];
        tandcArray = [tandcDict objectForKey:@"TandC"];
        
        for (i = 0; i < tandcArray.count; i++) {
            tandc = [tandcArray objectAtIndex: i];
            
            trBean = [[TrackerResultNewFscBean alloc] init];
            trBean.requestAgentCode = [TSSAppData getInstance].agentCode;
            trBean.requestAgentName = [TSSAppData getInstance].agentName;
            trBean.agentCode = agentCode;
            trBean.customerName = [tandc objectForKey: @"CustomerName"];
            formsArray = [tandc objectForKey: @"Forms"];
            
            if (formsArray == nil || formsArray.count == 0) {
                continue;
            }
            for (j = 0; j < formsArray.count; j++) {
                categoryDict = [formsArray objectAtIndex: j];
                categoryStr = [categoryDict objectForKey: @"Category"];
                dateLongStr = [categoryDict objectForKey: @"Date_Long"];
                
                if ([categoryStr isEqualToString: @"Opening"]) {
                    trBean.category1 = categoryStr;
                    trBean.dateLong1 = dateLongStr;
                } else if ([categoryStr isEqualToString: @"Closing"]) {
                    trBean.category2 = categoryStr;
                    trBean.dateLong2 = dateLongStr;
                }
            }
            [trackerResultArr addObject: trBean];
        }
    }
    
    [[TrackerResultNewFscDao getInstance] saveOrUpdateArray: trackerResultArr];
#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
    DLog(@"*************************AnalysisJsonDataManager----- analysisTrackerNewFscTandC: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
#endif
    return trackerResultArr;
}

+ (id) analysisJfwDeleteStatus: (NSDictionary *) dic andCollaboratorId: (NSString *) collaboratorId
{
    NSArray *dictionaryArr = [dic objectForKey:@"JFWGroupIdList"];
    NSMutableDictionary *jfwDeleteStatusDict = [NSMutableDictionary dictionary];
    NSString *groupId = nil;
    NSString *agentCode = [TSSAppData getInstance].agentCode;
    NSString *deleteStatus = nil;
    NSString *parternerDeleteStatus = nil;
    NSString *groupIdStatus = nil;
    for (NSDictionary *tempDict in dictionaryArr) {
        groupId = [tempDict objectForKey: @"groupId"];
        deleteStatus = [tempDict objectForKey: agentCode];
        parternerDeleteStatus = [tempDict objectForKey: collaboratorId];
        if ([deleteStatus isEqualToString: RESPONSE_STATUS_REMOVE] || [parternerDeleteStatus isEqualToString: RESPONSE_STATUS_REMOVE]) {
            groupIdStatus = RESPONSE_STATUS_REMOVE;
        } else {
            groupIdStatus = RESPONSE_STATUS_PENDING;
        }
        [jfwDeleteStatusDict setObject:groupIdStatus forKey:groupId];
    }
    return jfwDeleteStatusDict;
}

+ (id) analysisCreateDateTimeForAppointment: (NSDictionary *) dic
{
    NSMutableArray *followUpAndNoteArray = [NSMutableArray array];
    NSDictionary *tEventListDict = [dic objectForKey: @"tEventList"];
    if (tEventListDict != nil) {
        NSArray *tEventDictArray = [tEventListDict objectForKey: @"TEvent"];
        
        if (tEventDictArray != nil && tEventDictArray.count > 0)
        {
            NSString *appointmentID = nil;
            NSString *eventId = nil;
            NSString *createDateTime_Long = nil;
            FollowUpAndNoteBean *tempFollowUp = nil;
            
            for (NSDictionary *tempDict in tEventDictArray) {
                appointmentID = [tempDict objectForKey: @"id"];
                eventId = [tempDict objectForKey: @"eventId"];
                createDateTime_Long = [tempDict objectForKey: @"createDateTime_Long"];
                
                tempFollowUp = [[FollowUpAndNoteDao getInstance] getBeanWithAppointmentId: appointmentID];
                if (tempFollowUp==nil) {
                    continue;
                }
                if ([tempFollowUp.eventId isEqualToString: eventId]) {
                    tempFollowUp.createDateTimeLong = createDateTime_Long;
                    [followUpAndNoteArray addObject: tempFollowUp];
                }
            }
            if (followUpAndNoteArray.count > 0) {
                [[FollowUpAndNoteDao getInstance] saveOrUpdateArray: followUpAndNoteArray];
            }
        }
    }
    return followUpAndNoteArray;
}

+ (id) analysisDefaultAcceptedRoadshowForProd1: (NSDictionary *) dic
{
//    NSMutableArray *followUpAndNoteArray = [NSMutableArray array];
    NSMutableArray *tAppointCommentArray = nil;
    NSArray *roadshowsDictArray = [dic objectForKey: @"Roadshows"];
    if (roadshowsDictArray != nil && roadshowsDictArray.count > 0) {
        NSString *eventId = nil;
        NSString *appointmentID = nil;
        NSString *groupmemberaccptedinfo = nil;
        
        int i = 0;
        NSData *jsonData = nil;
        NSArray *group = nil;
        NSDictionary *groupDic = nil;
        NSString *contactId = nil;
        
        AppointmentCommentsBean *tAppointComment = nil;
        tAppointCommentArray = [NSMutableArray array];
        
        FollowUpAndNoteBean *followUpAndNoteBean = nil;
        for (NSDictionary *tempDict in roadshowsDictArray) {
            
            eventId = [tempDict objectForKey: @"eventId"];
            appointmentID = [tempDict objectForKey: @"id"];
            
            followUpAndNoteBean = [[FollowUpAndNoteDao getInstance] getBeanWithAppointmentId:appointmentID];
            //如果沒有找到event，跳過
            if (followUpAndNoteBean == nil) {
                continue;
            }
            
            groupmemberaccptedinfo = [tempDict objectForKey:@"groupmemberaccptedinfo"];
            if (groupmemberaccptedinfo != nil && groupmemberaccptedinfo.length > 0)
            {
                jsonData = [groupmemberaccptedinfo dataUsingEncoding:NSUTF8StringEncoding];
                group = [NSJSONSerialization JSONObjectWithData:jsonData options:0 error:nil];
                for (i = 0; i < group.count; i++) {
                    groupDic = [group objectAtIndex: i];
                    contactId = [groupDic objectForKey:@"contactId"];
                    tAppointComment = [[AppointmentCommentsDao getInstance] getBeanWithAppointmentId: appointmentID];
                    if (tAppointComment == nil) {
                        tAppointComment = [[AppointmentCommentsBean alloc] init];
                    }
                    
                    tAppointComment.status = [groupDic objectForKey:@"acceptstatus"];
                    tAppointComment.contactId = contactId;
                    tAppointComment.appointmentId = appointmentID;
                    tAppointComment.commentsTime = [groupDic objectForKey:@"time"];
                    tAppointComment.eventId = eventId;

                    [tAppointCommentArray addObject:tAppointComment];
                }
            } else {
                //如果没有，说明此时服务器端对应的jfw还没有创建，安全起见并不回传groupmemberaccptedinfo接收信息，刷新界面时重新请求，直到jfw创建了为止
//                //说明这条记录是在staging上新版后，使用旧版的app创建的roadshow记录，此处应该把roadshowversion设置为1并上传服务器
//                followUpAndNoteBean.roadshowVersion = IMO_SMART_YES;
//                followUpAndNoteBean.uploadStatus = UPLOAD_STATUS_FAILED;
//                [followUpAndNoteArray addObject: followUpAndNoteBean];
            }
        }
        
        if (tAppointCommentArray != nil && tAppointCommentArray.count > 0) {
            [[AppointmentCommentsDao getInstance] saveOrUpdateArray: tAppointCommentArray];
        }
        
//        if (followUpAndNoteArray != nil && followUpAndNoteArray.count > 0) {
//            [[FollowUpAndNoteDao getInstance] saveOrUpdateArray: followUpAndNoteArray];
//        }
    }
//    return followUpAndNoteArray;
    return tAppointCommentArray;
}

#pragma mark - covertDictionary
+(NSMutableDictionary*)covertDictionaryWithEventLogBean:(EventLogBean *)eventLogBean
{
    NSMutableDictionary *resultDict = [NSMutableDictionary dictionary];
    [resultDict setValue:eventLogBean.idKey forKey:@"eventlogid"];
    [resultDict setValue:eventLogBean.agentcode forKey:@"agentcode"];
    [resultDict setValue:eventLogBean.eventtype forKey:@"event"];
    [resultDict setValue:eventLogBean.devicetype forKey:@"devicetype"];
    [resultDict setValue:eventLogBean.deviceosversion forKey:@"deviceosversion"];
    [resultDict setValue:@"" forKey:@"functiontype"];
    [resultDict setValue:@"1" forKey:@"functionId"];
    
    NSString *tCreateTime = FORMAT(@"%lld",(long long)([eventLogBean.createdate doubleValue] * 1000));
    //NSString *tCreateTime = [eventLogBean.createdate stringValue];
    [resultDict setValue:tCreateTime  forKey:@"createddatetime"];
    
    return resultDict;
}

#pragma change
+(NSMutableDictionary*)covertDictionaryWithCustomerBean:(CustomerInfoBean *)customerBean
{
    NSMutableDictionary *resultDict = [NSMutableDictionary dictionary];
    
    [resultDict setValue:customerBean.customerUuid forKey:@"id"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:customerBean.oid] forKey:@"oid"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:[TSSAppData getInstance].agentCode] forKey:@"agentCode"];
    [resultDict setValue:customerBean.fullname forKey:@"fullName"];
    [resultDict setValue:customerBean.firstname  forKey:@"firstName"];
    [resultDict setValue:customerBean.lastname  forKey:@"lastName"];
    [resultDict setValue:customerBean.gender forKey:@"gender"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:customerBean.age] forKey:@"age"];
    
    NSDate *dobDate = [NSDate convertNSStringToNSDateWithFormat:DATE_YMD withDateString:customerBean.dob];
    NSNumber *dobNum = [NSDate convertNSDateToNSNumber:dobDate];
    
    NSString *dobString = FORMAT(@"%lld",(long long)[dobNum longLongValue]*1000);
    [resultDict setValue:dobString forKey:@"dob"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:customerBean.contacttype] forKey:@"contactType"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:customerBean.customerType] forKey:@"customerType"];
    [resultDict setValue:customerBean.smoker forKey:@"smoker"];
    [resultDict setValue:customerBean.maritalstatus forKey:@"maritalStatus"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:customerBean.occupationcode] forKey:@"occupationCode"];
    [resultDict setValue:customerBean.email forKey:@"email"];
    [resultDict setValue:customerBean.mobile forKey:@"mobile"];
    [resultDict setValue:customerBean.notes forKey:@"notes"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:customerBean.companyname] forKey:@"companyName"];
    
    NSNumber *createNum = [NSDate convertNSDateToNSNumber:[NSDate date]];
    NSString *createDate = [NSString stringWithFormat:@"%lld",(long long)[createNum longLongValue]*1000];
    NSString *updateDate = [NSString stringWithFormat:@"%lld",(long long)[createNum longLongValue]*1000];
    [resultDict setValue:createDate  forKey:@"createDate"];
    [resultDict setValue:updateDate  forKey:@"updateDate"];
    [resultDict setObject:[TSSValidationUtil converStringToEmptyString:customerBean.status] forKey:@"status"];
    [resultDict setObject:[TSSValidationUtil converStringToEmptyString:customerBean.childrennum] forKey:@"childrenNo"];
    [resultDict setObject:[TSSValidationUtil converStringToEmptyString:customerBean.internalId] forKey:@"internalId"];
    if (![TSSValidationUtil isNilOrNull:customerBean.headerdata]) {
        NSString *photoString = [customerBean.headerdata base64Encoding];
        [resultDict setObject:photoString forKey:@"photo"];
    } else {
        [resultDict setObject:@"" forKey:@"photo"];
    }
    [resultDict setObject:@"" forKey:@"address"];
    
    return resultDict;
}

+(NSMutableDictionary *)covertDictionaryWithFollowUpAndNoteBean:(FollowUpAndNoteBean *)followUpBean
{
    NSMutableDictionary *mDic = [NSMutableDictionary dictionary];
    NSArray *appointCustomerArr;
    NSString *idString = followUpBean.appointmentId;
    
    appointCustomerArr = [[AppointmentCustomerDao getInstance] getBeansWithGroupId:followUpBean.groupId];
    
    NSArray *agentsLinked = [NSArray array];
    NSArray *contactsLinked = [NSArray array];
    NSString *contactId ;
    
    NSString *eventId = [TSSValidationUtil converStringToEmptyString:followUpBean.eventId];
    NSString *createBy = [TSSValidationUtil converStringToEmptyString:followUpBean.createBy];
    NSString *updateBy = [TSSValidationUtil converStringToEmptyString:followUpBean.updateBy];
    
    NSNumber *createNum = [NSDate convertNSDateToNSNumber:[NSDate date]];
    NSString *createDate = [NSString stringWithFormat:@"%lld",(long long)[createNum longLongValue]*1000];
    NSString *updateDate = [NSString stringWithFormat:@"%lld",(long long)[createNum longLongValue]*1000];
    
    NSString *partnerJfwRole = nil;
    AppointmentCommentsBean *tAppointComment = nil;
    NSArray *accArr = nil;
    for (AppointmentCustomerBean *tempAppoint in appointCustomerArr)
    {
        if([tempAppoint.customerType isEqualToString:@"0"]) {
            agentsLinked = @[@{@"id":[TSSValidationUtil converStringToEmptyString:tempAppoint.customerId],@"oid":[TSSValidationUtil converStringToEmptyString:tempAppoint.severId],@"role":[TSSValidationUtil converStringToEmptyString:tempAppoint.jfwRole],@"fullName":[TSSValidationUtil converStringToEmptyString:tempAppoint.customerName]}];
            
            contactId = tempAppoint.customerId;
            partnerJfwRole = tempAppoint.jfwRole;
        } else if ([tempAppoint.customerType isEqualToString:@"1"]) {
           contactsLinked  = @[@{@"id":[TSSValidationUtil converStringToEmptyString:tempAppoint.customerId],@"oid":[TSSValidationUtil converStringToEmptyString:tempAppoint.severId],@"role":[TSSValidationUtil converStringToEmptyString:tempAppoint.jfwRole],@"fullName":[TSSValidationUtil converStringToEmptyString:tempAppoint.customerName]}];
        }
        //todo
        //如果被邀请者是agent，说明发起邀请人是leader，leader创建的event均是默认对方接受的
        if ([tempAppoint.jfwRole isEqualToString:Agent]) {
            accArr = @[@{@"acceptstatus":@"1",@"contactId":contactId,@"remark":@"",@"time":createDate}];
            [mDic setObject:accArr forKey:@"groupmemberaccptedinfo"];
            
            tAppointComment = [[AppointmentCommentsDao getInstance] getBeanWithAppointmentId:tempAppoint.appointmentId];
            if (tAppointComment==nil) {
                tAppointComment = [[AppointmentCommentsBean alloc] init];
            }
            tAppointComment.status = @"1";
            tAppointComment.appointmentId = tempAppoint.appointmentId;
            [tAppointComment save];
        } else if ([tempAppoint.jfwRole isEqualToString: Leader]) {
            //如果是agent建立，leader接受或拒绝，leader再删除
            if ([followUpBean.deleteStatus isEqualToString: RESPONSE_STATUS_REMOVE]) {
                //如果是删除状态，也要传递groupmemberaccptedinfo
                tAppointComment = [[AppointmentCommentsDao getInstance] getBeanWithAppointmentId:tempAppoint.appointmentId];
                if (tAppointComment != nil && [followUpBean.appointmentId isEqualToString:tempAppoint.appointmentId]) {
                    
                    accArr = @[@{@"acceptstatus":tAppointComment.status,@"contactId":contactId,@"remark":@"",@"time":tAppointComment.commentsTime}];
                    [mDic setObject:accArr forKey:@"groupmemberaccptedinfo"];

                }
            }
        }
    }
    
    NSNumber *num = [NSNumber numberWithLongLong:[createDate longLongValue]];
    NSDate *date = [NSDate convertNumberToDateNoDateFormat:num];
    [date formatDateTimeDefaultFormat];
    
    NSString *category = [TSSValidationUtil converStringToEmptyString:followUpBean.calendarStyle];
    
    NSString *title = [TSSValidationUtil converStringToEmptyString:followUpBean.eventTitleDescription];
    NSString *description = [TSSValidationUtil converStringToEmptyString:followUpBean.eventDescription];
    NSDate *tDataStart = [NSDate convertNumberToDateNoDateFormat:followUpBean.startTime];
    NSString *tDataStartStr = [NSString stringWithFormat:@"%lld",(long long)([tDataStart timeIntervalSince1970]*1000)];
    NSString *startTime = tDataStartStr;
    NSDate *tDataEnd = [NSDate convertNumberToDateNoDateFormat:followUpBean.endTime];
    NSString *tDataEndStr = [NSString stringWithFormat:@"%lld",(long long)([tDataEnd timeIntervalSince1970]*1000)];
    NSString *endTime =  tDataEndStr;
    NSString *location = [TSSValidationUtil converStringToEmptyString:followUpBean.location];
    NSString *status = [TSSValidationUtil converStringToEmptyString:followUpBean.responseStatus];
    NSString *reminderEnable = @"1";
    
    NSArray *reminderTimer = @[@{@"timer":[TSSValidationUtil converStringToEmptyString:followUpBean.notifyTime]}];
    NSString *type = [TSSValidationUtil converStringToEmptyString:followUpBean.appointmentType];
    NSString *subType = [TSSValidationUtil converStringToEmptyString:followUpBean.eventType];
    NSString *tGroupId = [TSSValidationUtil converStringToEmptyString:followUpBean.groupId];
    NSString *tDeleteStatus = [TSSValidationUtil converStringToEmptyString:followUpBean.deleteStatus];
    
    NSString *othersDescription = [TSSValidationUtil converStringToEmptyString: followUpBean.othersDescription];
    NSString *newJFWSameCustomer = [TSSValidationUtil converStringToEmptyString: followUpBean.createJFWSameCustomer];

    NSString *roadshowVersion = [TSSValidationUtil converStringToEmptyString: followUpBean.roadshowVersion];
    NSString *leaderAFullform = [TSSValidationUtil converStringToEmptyString: followUpBean.leaderAFullform];

    
    //myJFWRole改成创建者的角色
    if ([createBy isEqualToString: [TSSAppData getInstance].agentCode]) {
        [mDic setObject:[TSSAppData getInstance].agentJfwRole forKey:@"myJFWRole"];
    } else {
        [mDic setObject:partnerJfwRole forKey:@"myJFWRole"];;
    }

    [mDic setObject:idString forKey:@"id"];
    [mDic setObject:eventId forKey:@"eventId"];
    [mDic setObject:createBy forKey:@"createBy"];
    [mDic setObject:tGroupId forKey:@"jfwgroupid"];
    [mDic setObject:createDate forKey:@"createDate"];
    [mDic setObject:updateBy forKey:@"updateBy"];
    [mDic setObject:updateDate forKey:@"updateDate"];
    [mDic setObject:category forKey:@"category"];
    [mDic setObject:contactsLinked forKey:@"contactsLinked"];
    [mDic setObject:agentsLinked forKey:@"agentsLinked"];
    [mDic setObject:title forKey:@"title"];
    [mDic setObject:description forKey:@"description"];
    [mDic setObject:startTime forKey:@"startTime"];
    [mDic setObject:endTime forKey:@"endTime"];
    [mDic setObject:location forKey:@"location"];
    [mDic setObject:status forKey:@"status"];
    [mDic setObject:reminderEnable forKey:@"reminderEnabled"];
    [mDic setObject:reminderTimer forKey:@"reminderTimer"];
    [mDic setObject:type forKey:@"type"];
    [mDic setObject:subType forKey:@"subType"];
    [mDic setObject:tDeleteStatus forKey:@"deleteStatus"];
    //        [mDic setObject:myJfwRole forKey:@"myJFWRole"];
    
    [mDic setObject:othersDescription forKey:@"OthersDescription"];
    [mDic setObject:newJFWSameCustomer forKey:@"newJFWSameCustomer"];
    

    [mDic setObject:roadshowVersion forKey:@"RoadshowVersion"];
    [mDic setObject:leaderAFullform forKey:@"leaderAFullform"];

    
    return mDic;
}

+(NSMutableDictionary*)covertDictionaryWithJfwBean:(JfwBean *)tJfw
{
    NSMutableDictionary *resultDict = [NSMutableDictionary dictionary];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tJfw.idKey] forKey:@"idkey"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tJfw.formTitle] forKey:@"title"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tJfw.formDescription] forKey:@"description"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tJfw.advisorName] forKey:@"advisorName"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tJfw.assesorName] forKey:@"assessorName"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tJfw.advisorCode] forKey:@"advisorCode"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tJfw.assesorCode] forKey:@"assessorCode"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tJfw.groupId] forKey:@"groupId"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tJfw.serverId] forKey:@"oid"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tJfw.jfwType] forKey:@"type"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tJfw.submissionLocation] forKey:@"submissionLocation"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tJfw.deleteStatus] forKey:@"deleteStatus"];
    NSString *tStartTime = FORMAT(@"%lld",(long long)([tJfw.startTime doubleValue] * 1000));
    [resultDict setValue:tStartTime forKey:@"startTime"];
    NSString *tReviseStartTime = FORMAT(@"%lld",(long long)([tJfw.revisedStartTime doubleValue] * 1000));
    [resultDict setValue:tReviseStartTime forKey:@"revisedStartTime"];
    //end time 与 revisedStartTime是 相同的， 当revisedStartTime为空时等于starttime
    [resultDict setValue:tReviseStartTime forKey:@"endTime"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tJfw.customerName] forKey:@"customerName"];
    NSString *tPolicyNumber = [TSSValidationUtil converStringToEmptyString:tJfw.policyNumber];
    [resultDict setValue:[tPolicyNumber uppercaseString]  forKey:@"policyNumber"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tJfw.additionalPolicyNumber] forKey:@"additionalPolicyNumber"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tJfw.location] forKey:@"location"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tJfw.purposeDescription] forKey:@"purposeDescription"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tJfw.otherActivity] forKey:@"otherActivity"];
    NSString *imgSignAgentStr = [tJfw.imgSignAgent base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:imgSignAgentStr] forKey:@"imgSignAgent"];
    NSString *imgSignLeaderStr = [tJfw.imgSignLeader base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:imgSignLeaderStr] forKey:@"imgSignLeader"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tJfw.commentsByLeader] forKey:@"commentsByLeader"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tJfw.commentsByAgent] forKey:@"commentsByAgent"];
    [resultDict setValue:tJfw.totalScore forKey:@"totalScore"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tJfw.competent] forKey:@"competent"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tJfw.competentComments] forKey:@"competentComments"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tJfw.sendNotification] forKey:@"sendNotification"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tJfw.jfwStatus] forKey:@"status"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tJfw.location] forKey:@"location"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tJfw.agentLink]  forKey:@"agentsLinked"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tJfw.contactLink]  forKey:@"contactsLinked"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tJfw.eventType]  forKey:@"eventType"];
    [resultDict setValue:tJfw.createBy forKey:@"agentCode"];
    NSNumber *createNum = [NSDate convertNSDateToNSNumber:[NSDate date]];
    NSString *tCreateTime = [NSString stringWithFormat:@"%lld",(long long)[createNum longLongValue]*1000];
    NSString *tUpdateTime = [NSString stringWithFormat:@"%lld",(long long)[createNum longLongValue]*1000];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tCreateTime]  forKey:@"createTime"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tUpdateTime]  forKey:@"updateTime"];
    
    
    if ([tJfw.assesorCode isEqualToString:[TSSAppData getInstance].agentCode]) {
        NSMutableArray *questionArr = [[QuestionDao getInstance] getBeansWithGroupIdAndType:tJfw.groupId andType:tJfw.jfwType];
        NSMutableArray *tQuestionArr = [NSMutableArray array];
        NSMutableDictionary *questionDic = nil;
        for (QuestionBean *temp in questionArr) {
            temp.oid = tJfw.serverId;
            questionDic = [AnalysisJsonDataManager covertDictionaryWithQuestionBean:temp];
            [tQuestionArr addObject:questionDic];
        }
        [resultDict setValue:tQuestionArr  forKey:@"question"];
    }
    
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tJfw.freshFSCTandC]  forKey:@"newFSCTandC"];
    return resultDict;
}

+ (NSMutableDictionary *)covertDictionaryForAppointmentCommentWithFolowUpBean:(FollowUpAndNoteBean *)followUpBean
{
    NSMutableDictionary *mDic = [NSMutableDictionary dictionary];
    AppointmentCommentsBean *appointCommentBean = [[AppointmentCommentsDao getInstance] getBeanWithAppointmentId:followUpBean.appointmentId];
    [mDic setObject:followUpBean.eventId forKey:@"eventId"];
    [mDic setObject:[TSSValidationUtil converStringToEmptyString:appointCommentBean.idKey] forKey:@"idKey"];
    [mDic setObject:appointCommentBean.status forKey:@"status"];
    //[mDic setObject:appointCommentBean.remark forKey:@"remark"];
    [mDic setObject:appointCommentBean.commentsTime forKey:@"time"];
    
    return mDic;
}

+(NSMutableDictionary*)covertDictionaryWithQuestionBean:(QuestionBean *)tQuest
{
    NSMutableDictionary *resultDict = [NSMutableDictionary dictionary];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tQuest.jfwId] forKey:@"jfwId"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tQuest.oid] forKey:@"jfwOId"];
    [resultDict setValue:tQuest.questionType forKey:@"type"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tQuest.questionTitle] forKey:@"title"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tQuest.questionDescrption] forKey:@"descrption"];
    [resultDict setValue:tQuest.questionNo forKey:@"questionNo"];
    [resultDict setValue:[TSSValidationUtil converStringToEmptyString:tQuest.answer] forKey:@"answer"];
    [resultDict setValue:tQuest.remark forKey:@"remark"];
    
    NSNumber *createNum = [NSDate convertNSDateToNSNumber:[NSDate date]];
    NSString *tCreateTime = [NSString stringWithFormat:@"%lld",(long long)[createNum longLongValue]*1000];
    NSString *tUpdateTime = [NSString stringWithFormat:@"%lld",(long long)[createNum longLongValue]*1000];
    [resultDict setValue:tCreateTime  forKey:@"createTime"];
    [resultDict setValue:tUpdateTime  forKey:@"updateTime"];
    return resultDict;
}


+ (NSMutableDictionary *)covertDictionaryWithUploadNotificationBean:(NotificatinBean *)notifyBean
{
    NSMutableDictionary *mDic = [NSMutableDictionary dictionary];
    
    [mDic setObject:notifyBean.readStatus forKey:@"readStatus"];
    [mDic setObject:notifyBean.oid forKey:@"oid"];
    
    return mDic;
}

+ (NSMutableDictionary *)covertDictionaryWithNominationInfoBean: (NominationInfoBean *) nominationInfoBean
{
    NSMutableDictionary *nominationInfoDict = [NSMutableDictionary dictionary];
    [nominationInfoDict setValue:[TSSValidationUtil converStringToEmptyString: nominationInfoBean.nominationInfoID] forKey:@"id"];
    [nominationInfoDict setValue:[TSSValidationUtil converStringToEmptyString: nominationInfoBean.oid] forKey:@"oid"];
    [nominationInfoDict setValue:[TSSValidationUtil converStringToEmptyString: nominationInfoBean.fscCode] forKey:@"FSCCode"];
    [nominationInfoDict setValue:[TSSValidationUtil converStringToEmptyString: nominationInfoBean.fscName] forKey:@"FSCName"];
    [nominationInfoDict setValue:[TSSValidationUtil converStringToEmptyString: nominationInfoBean.assessorCode] forKey:@"assessorCode"];
    [nominationInfoDict setValue:[TSSValidationUtil converStringToEmptyString: nominationInfoBean.assessorName] forKey:@"assessorName"];
    
    [nominationInfoDict setValue:[TSSValidationUtil converStringToEmptyString: FORMAT(@"%lld",(long long)([nominationInfoBean.assessorStartDate doubleValue] * 1000))] forKey:@"StartDate"];
    [nominationInfoDict setValue:[TSSValidationUtil converStringToEmptyString: FORMAT(@"%lld",(long long)([nominationInfoBean.assessorEndDate doubleValue] * 1000 + 999))] forKey:@"EndDate"];
    [nominationInfoDict setValue:[TSSValidationUtil converStringToEmptyString: nominationInfoBean.deleteStatus] forKey:@"status"];
    
    return nominationInfoDict;
}
@end
