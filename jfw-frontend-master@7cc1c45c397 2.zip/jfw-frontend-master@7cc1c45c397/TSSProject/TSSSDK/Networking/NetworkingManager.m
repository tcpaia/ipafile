//
//  NetworkingManager.m
//  TSSProject
//
//  Created by TSS on 16/2/22.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import "NetworkingManager.h"
#import "Singleton.h"
#import "TSSAppData.h"
#import "TSSAppSetting.h"

#import "NSData+AES256.h"
#import "NSData+Base64.h"
#import "NSString+Ex.h"
#import "NSDate+Ex.h"
#import "HashValue.h"

#import "TSSSecurity.h"
#import "TSSZipUtil.h"
#import "TSSValidationUtil.h"
#import "EventManager.h"
#import "AnalysisJsonDataManager.h"

#import "CustomerInfoDao.h"
#import "jfwDao.h"
#import "jfwBean.h"
#import "QuestionDao.h"
#import "FollowUpAndNoteDao.h"
#import "AppointmentCommentsDao.h"
#import "AppointmentCommentsBean.h"
#import "NotificationDao.h"
#import "NotificatinBean.h"
#import "AppointmentCustomerDao.h"
#import "AppointmentCustomerBean.h"

#import "NominatedCadidateDao.h"
#import "NominatedCadidateBean.h"
#import "NominationInfoDao.h"
#import "NominationInfoBean.h"

#import "SmartTranslateHelper.h"
#import "PDKeyChain.h"

@interface NetworkingManager()<NetworkingManagerDelegate>
{
    AFNetworkReachabilityStatus _status;
    BOOL _isNetwork;
}
@property (nonatomic, strong) AFHTTPSessionManager *manager;

@end

@implementation NetworkingManager

SYNTHESIZE_SINGLETON_FOR_CLASS(NetworkingManager)

- (AFHTTPSessionManager *)createAFHTTPSessionManager
{
    if (self.manager == nil) {
        self.manager = [AFHTTPSessionManager manager];
        //AZ - 12/31/15 - Upgrade AFNetworking to v3.0.4, add @"text/plain" for AFJSONResponseSerializer supporting, add @"application/octet-stream" for encrypted data supporting, 3.0 returns NSDictionary directly
        [self.manager.responseSerializer setAcceptableContentTypes:[NSSet setWithObjects:@"application/json", @"application/octet-stream", @"text/json", @"text/javascript", @"text/plain", @"text/html", nil]];
        //        //Set timeout period
        //        self.manager.requestSerializer.timeoutInterval = 30;
#ifdef ATS
        //SSL Pinning using cer file for server connection, need AFNetworking 3.0
        [self.manager setSecurityPolicy:[self customSecurityPolicy]];
#else
        //Disable SSL Pinning for SIT and UAT
        [self.manager.securityPolicy setAllowInvalidCertificates:YES];
#endif
    }
    return self.manager;
}

- (AFSecurityPolicy*)customSecurityPolicy
{
    NSString *cerPath = [[NSBundle mainBundle] pathForResource:[TSSAppData getInstance].sslCertFile ofType:@"cer"];
    NSData *certData = [NSData dataWithContentsOfFile:cerPath];
    AFSecurityPolicy *securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeCertificate];
    [securityPolicy setAllowInvalidCertificates:NO];
    [securityPolicy setPinnedCertificates:[NSSet setWithObjects:certData, nil]];
    return securityPolicy;
}

- (NSString *)getUrl:(BPNetworkingTask)task
{
    //NSMutableString *result = [NSMutableString stringWithString:[AppVariables getInstance].serverUrl];
    NSMutableString *result = [NSMutableString stringWithString:@""];
    switch (task) {
        case BPNetworkingTaskServerConnection:
            break;
        case BPNetworkingTaskSyncData:
            break;
        default:
            break;
    }
    return result;
}

- (void)startMonitoringNetwork
{
    
    AFNetworkReachabilityManager *manager = [AFNetworkReachabilityManager sharedManager];
    
    [manager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        switch (status)
        {
            case AFNetworkReachabilityStatusUnknown:
                _status = BPNetworkStatusUnknown;
                _isNetwork = NO;
                DLog(@"未知网络");
                break;
            case AFNetworkReachabilityStatusNotReachable:
                _status = BPNetworkStatusNotReachable;
                _isNetwork = NO;
                DLog(@"无网络");
                break;
            case AFNetworkReachabilityStatusReachableViaWWAN:
                _status = BPNetworkStatusReachableViaWWAN;
                _isNetwork = YES;
                DLog(@"手机自带网络");
                break;
            case AFNetworkReachabilityStatusReachableViaWiFi:
                _status = BPNetworkStatusReachableViaWiFi;
                _isNetwork = YES;
                DLog(@"WIFI");
                break;
        }
    }];
    [manager startMonitoring];
    
}

- (void)checkNetStatusWithBlock:(NetWorkStatus)netStatus
{
    netStatus(_status);
}

- (BOOL)currentNetworkStatus
{
    return _isNetwork;
}

- (NSURLSessionDataTask *) connectToServer
{
    __block BOOL result = NO;
    [self createAFHTTPSessionManager];
    return [self.manager POST:[self getUrl:BPNetworkingTaskServerConnection] parameters:nil progress:^(NSProgress *uploadProgress) {
        
    } success:^(NSURLSessionDataTask *operation, id responseObject) {
        NSDictionary *dic = (NSDictionary *) responseObject;
        
        result = (![TSSValidationUtil isNilOrNull:dic] && dic.count > 0);
        if (result)
            [self.delegate completeTask:BPNetworkingTaskServerConnection responseObject:dic success:YES error:nil];
        else
            [self.delegate completeTask:BPNetworkingTaskServerConnection responseObject:dic success:NO error:nil];
        
    } failure:^(NSURLSessionDataTask *operation, NSError *error) {
        result = NO;
        [self.delegate completeTask:BPNetworkingTaskServerConnection responseObject:nil success:NO error:error];
    }];
}

- (NSURLSessionDataTask *) syncData
{
    __block BOOL result = NO;
    [self createAFHTTPSessionManager];
    return [self.manager POST:[self getUrl:BPNetworkingTaskSyncData] parameters:nil progress:^(NSProgress *uploadProgress) {
        
    } success:^(NSURLSessionDataTask *operation, id responseObject) {
        NSDictionary *dic = (NSDictionary *) responseObject;
        
        result = (![TSSValidationUtil isNilOrNull:dic] && dic.count > 0);
        if (result)
            [self.delegate completeTask:BPNetworkingTaskSyncData responseObject:dic success:YES error:nil];
        else
            [self.delegate completeTask:BPNetworkingTaskSyncData responseObject:dic success:NO error:nil];
        
    } failure:^(NSURLSessionDataTask *operation, NSError *error) {
        result = NO;
        [self.delegate completeTask:BPNetworkingTaskSyncData responseObject:nil success:NO error:error];
    }];
}

//TEST NEWTWORKING
#pragma mark checkServerConnecting
- (void)checkServerConnecting:(void (^)(id response))responseBlock
{
    NSString *actionType= @"ACT_SEVER_TIMESTAMP";
    NSMutableDictionary *parameterDictionary = [NSMutableDictionary dictionary];
    [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:actionType] forKey:@"actionType"];
    [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:[TSSAppData getInstance].agentCode] forKey:@"agentCode"];
    //for China, using brach code
    NSString *requestURLString = [TSSAppSetting getInstance].serverUrl;
    [[NetworkingManager getInstance] postUploadWithURLString:requestURLString fileURL:nil parameters:parameterDictionary postData:nil timeoutInterval:SERVER_CONNECTION_TIME responseBlock:responseBlock];
}

- (void)checkAppVersion:(CallBack)callback
{
    NSString *actionType= @"ACT_CHECK_VERSION";
    NSString *agtCode = [TSSAppData getInstance].agentCode;
    NSDictionary *dict = @{
                           @"platForm":[TSSValidationUtil convertNilToEmptyString:@"ios"],
                           @"channelCode":[TSSValidationUtil convertNilToEmptyString:@""],//7050
                           @"agentCode":[TSSValidationUtil convertNilToEmptyString:agtCode],
                           @"majorVersion":[TSSAppSetting getInstance].majorVersion,
                           @"minorVersion":[TSSAppSetting getInstance].minVersion
                           };
    NSMutableDictionary *parameterDictionary = [NSMutableDictionary dictionary];
    [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:actionType] forKey:@"actionType"];
    if (dict) {
        NSString *resultJsonString = [TSSValidationUtil convertToJsonString:dict];
        NSString *encryptedJsonString = [[[resultJsonString dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKey:[TSSSecurity encryptionKey]] base64Encoding];
        [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:encryptedJsonString] forKey:@"parametersJson"];
    }
    [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:[TSSAppData getInstance].agentCode] forKey:@"agentCode"];
    //for China, using brach code
    [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:@""] forKey:@"branch"];
    
    NSString *requestURLString = [TSSAppSetting getInstance].serverUrl;

#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
#endif
    [[NetworkingManager getInstance] postUploadWithURLString:requestURLString fileURL:nil parameters:parameterDictionary postData:nil timeoutInterval:SERVER_CONNECTION_TIME responseBlock:^(id response) {
#if TEST_NET_RESPONSE_TIME > 0
        NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
        DLog(@"*************************login test-----checkAppVersion: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
#endif
        if ([response isKindOfClass:[NSError class]])
        {
            //callback(response);
        }
        else
        {
            NSDictionary *resultDic = (NSDictionary *)response;
            NSString *returnValStr = [resultDic objectForKey:@"returnVal"];
            NSString *returnValStr1 = [resultDic objectForKey:@"returnVal1"];
            NSData *nsval  = [[NSData dataWithBase64EncodedString:returnValStr] AES256DecryptWithKey:[TSSSecurity encryptionKey]];
            NSData *nsval1  = [[NSData dataWithBase64EncodedString:returnValStr1] AES256DecryptWithKey:[TSSSecurity encryptionKey]];
#if TEST_NET_RESPONSE_TIME > 0
            [TSSSecurity writeResponseData: nsval toTestFileName: @"checkAppVersion" andTimeInterval:requestEndTime];
#endif
            if(![TSSValidationUtil isNilOrNull:nsval] && nsval.length > 0) {
                resultDic = [NSJSONSerialization JSONObjectWithData:nsval options:0 error:nil];
            }
            else{
                resultDic = [NSJSONSerialization JSONObjectWithData:nsval1 options:0 error:nil];
            }
#if TEST_NET_RESPONSE_TIME > 0
            DLog(@"*************************login test-----checkAppVersion: count = %ld", resultDic.count);
#endif
            callback(resultDic);
        }
    }];
}

- (void)uploadAgentProfile:(NSDictionary*)agentDict andCallback:(CallBack)callback {
    NSString *urlStr = [TSSAppSetting getInstance].serverUrl;
    NSString *actionType = @"ACT_UPLOAD_AGENTPROFILE";
    NSString *agentCode  = [TSSAppData getInstance].agentCode;
    NSString *sencondKey = [TSSSecurity encryptionKey];
    NSString *dataFile = nil;
    NSString *branch = @"";
    NSDictionary *dic = nil;
    if([[TSSAppSetting getInstance].buildVesion isEqualToString:BUILD_VERSION_SIT_COE])
    {
        dic = @{
                @"contractcode":      [agentDict objectForKey:@"act_contractcode"],
                @"token2fa":          [agentDict objectForKey:@"act_token2fa"],
                @"contact":           [agentDict objectForKey:@"act_contact"],
                @"masterKey":         [agentDict objectForKey:@"act_masterKey"],
                @"servertimestamp":   [agentDict objectForKey:@"act_servertimestamp"],
                @"message":           [agentDict objectForKey:@"act_message"],
                @"email":             [agentDict objectForKey:@"act_email"],
                @"name":              [agentDict objectForKey:@"act_name"],
                @"gender":            [agentDict objectForKey:@"act_gender"],
                @"agencyname":        [agentDict objectForKey:@"act_agencyname"],
                @"channelcode":       [agentDict objectForKey:@"act_channelcode"],
                @"fsccode":           [agentDict objectForKey:@"act_fsccode"],
                @"license":           [agentDict objectForKey:@"act_license"],
                @"timebomb":          [agentDict objectForKey:@"act_timebomb"],
                @"nric":              [agentDict objectForKey:@"act_nric"],
                @"agencycode":        @"02108",
                @"rnfcode":           [agentDict objectForKey:@"act_rnfcode"],
                @"localPassword":     [agentDict objectForKey:@"localPassword"]
                };
    }
    else
    {
        dic = @{
                @"contractcode":      [agentDict objectForKey:@"act_contractcode"],
                @"token2fa":          [agentDict objectForKey:@"act_token2fa"],
                @"contact":           [agentDict objectForKey:@"act_contact"],
                @"masterKey":         [agentDict objectForKey:@"act_masterKey"],
                @"servertimestamp":   [agentDict objectForKey:@"act_servertimestamp"],
                @"message":           [agentDict objectForKey:@"act_message"],
                @"email":             [agentDict objectForKey:@"act_email"],
                @"name":              [agentDict objectForKey:@"act_name"],
                @"gender":            [agentDict objectForKey:@"act_gender"],
                @"agencyname":        [agentDict objectForKey:@"act_agencyname"],
                @"channelcode":       [agentDict objectForKey:@"act_channelcode"],
                @"fsccode":           [agentDict objectForKey:@"act_fsccode"],
                @"license":           [agentDict objectForKey:@"act_license"],
                @"timebomb":          [agentDict objectForKey:@"act_timebomb"],
                @"nric":              [agentDict objectForKey:@"act_nric"],
                @"agencycode":        [agentDict objectForKey:@"act_agencycode"],
                @"rnfcode":           [agentDict objectForKey:@"act_rnfcode"],
                @"localPassword":     [agentDict objectForKey:@"localPassword"]
                };
    }
    DLog(@"#uploadAgentProfile upload dic: %@", dic);
    NSString *resultJsonString = [TSSValidationUtil convertToJsonString:dic];
    
    NSString* testStrP = @"{\"a\":\"b\"}";
    NSString* testStrE = (NSString *)[[[testStrP dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKey:sencondKey] base64EncodedDataWithOptions:0];;
    DLog(@"upload agent profile test key %@ & result: %@", sencondKey, testStrE);
    
    NSString *encryptedJsonString = (NSString *)[[[resultJsonString dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKey:sencondKey] base64EncodedDataWithOptions:0];
    NSMutableDictionary *parmater = [NSMutableDictionary dictionary];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:agentCode] forKey:@"agentCode"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:actionType] forKey:@"actionType"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:encryptedJsonString] forKey:@"parametersJson"];
    [parmater setValue:dataFile forKey:@"dataFile"];
    [parmater setValue:branch forKey:@"branch"];
    [[NetworkingManager getInstance] postUploadWithURLString:urlStr fileURL:nil parameters:parmater postData:nil timeoutInterval:UPLOAD_DOWNLOAD_TIME responseBlock:^(id response) {
        if ([response isKindOfClass:[NSError class]]){
            DLog(@"%s error",__func__);
            callback(response);
        }
        else{
            NSDictionary *resultDic = (NSDictionary *)response;
            NSString *returnValStr  = [resultDic objectForKey:@"returnVal"];
            NSString *returnValStr1 = [resultDic objectForKey:@"returnVal1"];
            if (![TSSValidationUtil isNilOrEmptyString:returnValStr]) {
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:returnValStr options:0] AES256DecryptWithKey:sencondKey];
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                callback(resultDic);
            }else {
                NSData *data1 = [[[NSData alloc]initWithBase64EncodedString:returnValStr1 options:0] AES256DecryptWithKey:sencondKey];
                resultDic = [NSJSONSerialization JSONObjectWithData:data1 options:0 error:nil];
                NSString *errorMsg = [resultDic objectForKey:@"errorMsg"];
                if ([errorMsg isEqualToString:@"Password history Cached."]) {
                    callback(errorMsg);
                }else {
                    callback (UPLOAD_STATUS_FAILED);
                }
            }
        }
    } ];
}

- (void)checkAgentProfile:(CallBack)callback
{
    NSString *actionType= @"AGENT_ACTIVATION";
    NSString *agtCode = [TSSAppData getInstance].agentCode;
    NSString *encryptedPassword = [[[[TSSAppData getInstance].agentPassword dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKey:[TSSSecurity encryptionKey]] base64Encoding];
    NSDictionary *dict = @{
                           @"agentCode":[TSSValidationUtil convertNilToEmptyString:agtCode],
                           @"platform":[TSSValidationUtil convertNilToEmptyString:@"ios"],
                           @"channelCode":[TSSValidationUtil convertNilToEmptyString:@"7050"],
                           @"E2EE_RPIN":[TSSValidationUtil convertNilToEmptyString:encryptedPassword],
                           @"branch":[TSSValidationUtil convertNilToEmptyString:@"1086"],
                           @"deviceToken":[TSSValidationUtil convertNilToEmptyString:[TSSAppData getInstance].deviceToken],
                           @"deviceTokenOld":[TSSValidationUtil convertNilToEmptyString:[TSSAppData getInstance].deviceToken]
                           };
    
    NSMutableDictionary *parameterDictionary = [NSMutableDictionary dictionary];
    [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:actionType] forKey:@"actionType"];
    if (dict) {
        //DLog(@"actionType == %@, parameterObject == %@, encryptionKey = %@", actionType, dict, encryptionKey);
        NSString *resultJsonString = [TSSValidationUtil convertToJsonString:dict];
        NSString *encryptedJsonString = [[[resultJsonString dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKey:[TSSSecurity encryptionKey]] base64Encoding];
        [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:encryptedJsonString] forKey:@"parametersJson"];
    }
    [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:[TSSAppData getInstance].agentCode] forKey:@"agentCode"];
    //for China, using brach code
    [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:@""] forKey:@"branch"];
    
    NSString *requestURLString = [TSSAppSetting getInstance].serverUrl;
    
#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
#endif
    [[NetworkingManager getInstance] postUploadWithURLString:requestURLString fileURL:nil parameters:parameterDictionary postData:nil timeoutInterval:UPLOAD_DOWNLOAD_TIME responseBlock:^(id response) {
#if TEST_NET_RESPONSE_TIME > 0
        NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
        DLog(@"*************************login test-----checkAgentProfile: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
#endif
        if ([response isKindOfClass:[NSError class]])
        {
            DLog(@"error found");
            callback(response);
        }
        else
        {
            
            NSDictionary *resultDic = (NSDictionary *)response;
            NSString *returnValStr = [resultDic objectForKey:@"returnVal"];
            NSData *keyData = [[TSSAppData getInstance].agentPassword dataUsingEncoding:NSUTF8StringEncoding];
            NSData *decodedData  = [[NSData dataWithBase64EncodedString:returnValStr] AES256DecryptWithKeyData:[HashValue sha256HashWithData:keyData]];
#if TEST_NET_RESPONSE_TIME > 0
            [TSSSecurity writeResponseData: decodedData toTestFileName: @"checkAgentProfile" andTimeInterval:requestEndTime];
#endif
            resultDic = [NSJSONSerialization JSONObjectWithData:decodedData options:0 error:nil];
#if TEST_NET_RESPONSE_TIME > 0
            DLog(@"*************************login test-----checkAgentProfile: count = %ld", resultDic.count);
#endif
            DLog(@"succss: %@",resultDic.description);
            callback(resultDic);
        }
        
    }];
}

- (void)uploadAgenPhoto:(NSData *)photoData withCallback:(CallBack)callback {
    NSString *agentCode = [TSSAppData getInstance].agentCode;
    NSString *masterkey = [TSSAppData getInstance].masterKey;
    NSString *dataFile = nil;
    NSString *branch = @"";
    NSString *actionType = @"ACT_UPLOAD_AGENT_PHOTO";
    NSString *urlStr = [TSSAppSetting getInstance].serverUrl;
    
    NSDictionary *dic = @{@"clientNo":@"",@"agentCode":agentCode,@"agentPhoto":[photoData base64Encoding]};
    
    NSString *resultJsonString = [TSSValidationUtil convertToJsonString:dic];
    
    NSString *encryptedJsonString = (NSString *)[[[resultJsonString dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKey:masterkey] base64EncodedDataWithOptions:0];
    
    NSMutableDictionary *parmater = [NSMutableDictionary dictionary];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:agentCode] forKey:@"agentCode"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:actionType] forKey:@"actionType"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:encryptedJsonString] forKey:@"parametersJson"];
    [parmater setValue:dataFile forKey:@"dataFile"];
    [parmater setValue:branch forKey:@"branch"];
    
#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
#endif
    [[NetworkingManager getInstance] postUploadWithURLString:urlStr fileURL:nil parameters:parmater postData:nil timeoutInterval:UPLOAD_DOWNLOAD_TIME responseBlock:^(id response) {
#if TEST_NET_RESPONSE_TIME > 0
        NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
        DLog(@"*************************login test-----uploadAgenPhoto: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
#endif
        if ([response isKindOfClass:[NSError class]]){
            callback(UPLOAD_STATUS_FAILED);
        }
        else{
            NSDictionary *resultDic = (NSDictionary *)response;
            NSString *returnValStr = [resultDic objectForKey:@"returnVal"];
            NSString *retunrVal1 = [resultDic objectForKey:@"returnVal1"];
            if (![TSSValidationUtil isNilOrNull:retunrVal1]) {
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:retunrVal1 options:0] AES256DecryptWithKey:[TSSAppData getInstance].masterKey];
                resultDic  = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                NSString *errorMsg = [resultDic objectForKey:@"errorMsg"];
                DLog(@"error -- %@ -",errorMsg);
            }
            if ([TSSValidationUtil isNilOrEmptyString:returnValStr]){
                callback(UPLOAD_STATUS_FAILED);
            }else {
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:returnValStr options:0] AES256DecryptWithKey:[TSSAppData getInstance].masterKey];
#if TEST_NET_RESPONSE_TIME > 0
                [TSSSecurity writeResponseData: data toTestFileName: @"uploadAgenPhoto" andTimeInterval:requestEndTime];
#endif
                NSString *resultString =  [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
#if TEST_NET_RESPONSE_TIME > 0
                DLog(@"*************************login test-----uploadAgenPhoto: result = %@", resultString);
#endif
                if ([resultString isEqualToString:@"SUCCESS"]) {
                    callback(UPLOAD_STATUS_OK);
                }else {
                    callback(UPLOAD_STATUS_FAILED);
                }
                
            }
        }
    }];
}

#pragma mark event logs upload
-(void)eventLogUpload:(CallBack)callback
{
    NSMutableArray *events = [[EventLogDao getInstance] getBeansWithCount:10];
    if ([events count]==0) {
        return;
    }
    NSMutableArray *uploadEventLogArray = [NSMutableArray array];
    NSMutableDictionary *dict = nil;
    for (EventLogBean *eventLogBean in events) {
        dict = [AnalysisJsonDataManager covertDictionaryWithEventLogBean:eventLogBean];
        [uploadEventLogArray addObject:dict];
    }
    NSMutableDictionary *resultDictionary = [NSMutableDictionary dictionary];
    [resultDictionary setValue:uploadEventLogArray forKey:@"eventLog"];
    NSString *postStr = [TSSValidationUtil convertToJsonString:resultDictionary];
    postStr = [postStr replace:@"\n" replaceWith:@""];
    NSData *postData = [postStr dataUsingEncoding:NSUTF8StringEncoding];
    NSString *fileOutPath = [NSTemporaryDirectory() stringByAppendingPathComponent:FORMAT(@"%llu.zip", (long long)[[NSDate date] timeIntervalSince1970])];
    
    
    [TSSZipUtil zipFileWithPassword:nil fileName:@"eventLog" fileData:postData fileOutPath:fileOutPath];
    postData = [NSData dataWithContentsOfFile:fileOutPath];
    postData = [postData AES256EncryptWithKey:[TSSAppData getInstance].masterKey];
    //for base64
    NSString *postDataStr = [postData base64Encoding];
    postData = [postDataStr dataUsingEncoding:NSUTF8StringEncoding];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    [fileManager removeItemAtPath:fileOutPath error:NULL];
    
    NSMutableDictionary *parmater = [NSMutableDictionary dictionary];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:[TSSAppData getInstance].agentCode] forKey:@"agentCode"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:@"ACT_UPLOAD_EVENT_LOG"] forKey:@"actionType"];
    [parmater setValue:@"" forKey:@"parametersJson"];

    [parmater setValue:@"" forKey:@"branch"];
    
#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
#endif
    [[NetworkingManager getInstance] postUploadWithURLString:[TSSAppSetting getInstance].serverUrl fileURL:nil parameters:parmater postData:postData timeoutInterval:UPLOAD_DOWNLOAD_TIME responseBlock:^(id response) {
#if TEST_NET_RESPONSE_TIME > 0
        NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
        DLog(@"*************************login test-----eventLogUpload: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
#endif
        
        if ([response isKindOfClass:[NSError class]])
        {
            DLog(@"%s error",__func__);
            callback(response);
        }
        else
        {
            NSDictionary *resultDic = (NSDictionary *)response;
            NSString *returnValStr = [resultDic objectForKey:@"returnVal"];
            NSData *data = [[[NSData alloc]initWithBase64EncodedString:returnValStr options:0] AES256DecryptWithKey:[TSSAppData getInstance].masterKey];
#if TEST_NET_RESPONSE_TIME > 0
            [TSSSecurity writeResponseData: data toTestFileName: @"eventLogUpload" andTimeInterval:requestEndTime];
#endif
            resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
            NSString *msgResult = [resultDic objectForKey:@"errorMessage"];
#if TEST_NET_RESPONSE_TIME > 0
            DLog(@"*************************login test-----eventLogUpload: result = %@", msgResult);
#endif
            for (EventLogBean *eventLogBean in events) {
                [[EventLogDao getInstance] deleteWithID:eventLogBean.idKey];
            }
            callback(msgResult);
            
        }
    } ];
}

- (void)downSetUpManagerSelectStatus:(NSString *)selectStatus withSetupManagerCode:(NSString *)managerCode withCallBack:(CallBack)callback {

    NSString *actionType = @"ACT_SETUPMANAGER";
    NSString *agentCode = [TSSAppData getInstance].agentCode;
    NSString *masterkey = [TSSAppData getInstance].masterKey;
    NSString *dataFile = nil;
    NSString *branch = @"";
    NSDictionary *dic = @{@"selectStatus":selectStatus,@"setupManagerCode":managerCode};
    NSString *resultJsonString = [TSSValidationUtil convertToJsonString:dic];
    
    NSString *encryptedJsonString = (NSString *)[[[resultJsonString dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKey:masterkey] base64EncodedDataWithOptions:0];
    
    NSMutableDictionary *parmater = [NSMutableDictionary dictionary];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:agentCode] forKey:@"agentCode"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:actionType] forKey:@"actionType"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:encryptedJsonString] forKey:@"parametersJson"];
    [parmater setValue:dataFile forKey:@"dataFile"];
    [parmater setValue:branch forKey:@"branch"];
    [[NetworkingManager getInstance] postUploadWithURLString:[TSSAppSetting getInstance].serverUrl fileURL:nil parameters:parmater postData:nil timeoutInterval:UPLOAD_DOWNLOAD_TIME responseBlock:^(id response) {
        //SERVER_CONNECTION_TIME
        if ([response isKindOfClass:[NSError class]])
        {
            DLog(@"%s error",__func__);
            callback(response);
        }
        else
        {
            NSDictionary *resultDic = (NSDictionary *)response;
            NSString *returnValStr = [resultDic objectForKey:@"returnVal"];
            NSData *data = [[[NSData alloc]initWithBase64EncodedString:returnValStr options:0] AES256DecryptWithKey:masterkey];
            resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
            NSString *errorMsg = [resultDic objectForKey:@"errorMsg"];
            if (errorMsg.length != 0) {
                callback(errorMsg);
            }else {
                NSArray *resultArr = [AnalysisJsonDataManager analysisCustomer:resultDic];
                callback(resultArr);
            }
        }
    } ];
}

#pragma mark downloadCustomerLastUpdateTime
-(void)downloadCustomerLastUpdateTime:(NSString *)lastUpdateTime andRecordNo:(NSString *)recordNo andLater:(NSString*)sign andCallBack:(CallBack)callback
{
    NSString *urlStr = [TSSAppSetting getInstance].serverUrl;
    NSString *actionType = @"ACT_DOWNLOAD_CUSTOMER_BYCOUNT";
    NSString *agentCode = [TSSAppData getInstance].agentCode;
    NSString *masterkey = [TSSAppData getInstance].masterKey;
    NSString *dataFile = nil;
    NSString *branch = @"";
    NSDictionary *dic = nil;
    if (LOGIN_WITHOUT_ACTIVATION>=1) {
         dic = @{@"agentCode":agentCode,@"lastUpdateTime":@"",@"recordNo":@"0",@"operator":@">"};
    }
    else
    {
        dic = @{@"agentCode":agentCode,@"lastUpdateTime":lastUpdateTime,@"recordNo":recordNo,@"operator":sign};
    }

    
    NSString *resultJsonString = [TSSValidationUtil convertToJsonString:dic];
    
    NSString *encryptedJsonString = (NSString *)[[[resultJsonString dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKey:masterkey] base64EncodedDataWithOptions:0];
    
    NSMutableDictionary *parmater = [NSMutableDictionary dictionary];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:agentCode] forKey:@"agentCode"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:actionType] forKey:@"actionType"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:encryptedJsonString] forKey:@"parametersJson"];
    [parmater setValue:dataFile forKey:@"dataFile"];
    [parmater setValue:branch forKey:@"branch"];
    
#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
#endif
    [[NetworkingManager getInstance] postUploadWithURLString:urlStr fileURL:nil parameters:parmater postData:nil timeoutInterval:SERVER_CONNECTION_TIME responseBlock:^(id response) {
#if TEST_NET_RESPONSE_TIME > 0
        NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
        DLog(@"*************************login test-----downloadCustomerLastUpdateTime: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
#endif
        
        if ([response isKindOfClass:[NSError class]])
        {
            DLog(@"%s error",__func__);
            callback(response);
        }
        else
        {
            NSDictionary *resultDic = (NSDictionary *)response;
            NSString *returnValStr = [resultDic objectForKey:@"returnVal"];
            NSData *data = [[[NSData alloc]initWithBase64EncodedString:returnValStr options:0] AES256DecryptWithKey:masterkey];
#if TEST_NET_RESPONSE_TIME > 0
            [TSSSecurity writeResponseData:data toTestFileName: @"downloadCustomerLastUpdateTime" andTimeInterval:requestEndTime];
#endif
            resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
            NSArray *resultArr = [AnalysisJsonDataManager analysisCustomer:resultDic];
            callback(resultArr);
            
        }
    } ];
}

-(void)downloadCustomerLastUpdateTime:(NSString *)lastUpdateTime andRecordNo:(NSString *)recordNo andLater:(NSString*)sign andFetchFlag: (NSString *)fetchFlag andOids: (NSArray *)oids andCallBack:(CallBack)callback
{
    NSString *urlStr = [TSSAppSetting getInstance].serverUrl;
    NSString *actionType = @"ACT_DOWNLOAD_CUSTOMER_BYCOUNT";
    NSString *agentCode = [TSSAppData getInstance].agentCode;
    NSString *masterkey = [TSSAppData getInstance].masterKey;
    NSString *dataFile = nil;
    NSString *branch = @"";
    
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:@{@"agentCode":agentCode,@"lastUpdateTime":lastUpdateTime,@"recordNo":recordNo,@"operator":sign}];
    if ([TSSValidationUtil isNilOrEmptyString: fetchFlag] == NO) {
        [dic setObject:fetchFlag forKey:@"fetchFlag"];
        if ([fetchFlag isEqualToString:DOWNLOAD_IMAGE]) {
            [dic setObject:oids forKey:@"oids"];
        }
    }

    NSString *resultJsonString = [TSSValidationUtil convertToJsonString:dic];
    NSString *encryptedJsonString = (NSString *)[[[resultJsonString dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKey:masterkey] base64EncodedDataWithOptions:0];
    NSMutableDictionary *parmater = [NSMutableDictionary dictionary];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:agentCode] forKey:@"agentCode"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:actionType] forKey:@"actionType"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:encryptedJsonString] forKey:@"parametersJson"];
    [parmater setValue:dataFile forKey:@"dataFile"];
    [parmater setValue:branch forKey:@"branch"];
    
#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
#endif
    [[NetworkingManager getInstance] postUploadWithURLString:urlStr fileURL:nil parameters:parmater postData:nil timeoutInterval:SERVER_CONNECTION_TIME responseBlock:^(id response) {
#if TEST_NET_RESPONSE_TIME > 0
        NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
        DLog(@"*************************login test-----downloadCustomerLastUpdateTime andFetchFlag: beginTime = %f, endTime = %f, take time = %f, fetchFlag = %@", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime, fetchFlag);
#endif
        
        if ([response isKindOfClass:[NSError class]])
        {
            DLog(@"%s error",__func__);
            callback(response);
        }
        else
        {
            NSDictionary *resultDic = (NSDictionary *)response;
            NSString *returnValStr = [resultDic objectForKey:@"returnVal"];
            NSData *data = [[[NSData alloc]initWithBase64EncodedString:returnValStr options:0] AES256DecryptWithKey:masterkey];
#if TEST_NET_RESPONSE_TIME > 0
            [TSSSecurity writeResponseData:data toTestFileName: @"downloadAndFetchFlagCustomerLastUpdateTime" andTimeInterval:requestEndTime];
#endif
            resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
            NSArray *resultArr = [AnalysisJsonDataManager analysisCustomer:resultDic forFetchFlag: fetchFlag];
            callback(resultArr);
            
        }
    } ];
}

-(void)downLoadNotifactionAndLastUpdateTime:(NSString *)lastUpdateTime andRecordNo:(NSString *)recordNo andCallBack:(CallBack)callback
{
    NSString *urlStr = [TSSAppSetting getInstance].serverUrl;
    NSString *agentCode = [TSSAppData getInstance].agentCode;
    NSString *actionType = @"ACT_DOWNLOAD_NOTIFICATION_INBOX";
    NSString *masterkey = [TSSAppData getInstance].masterKey;
    NSString *dataFile = nil;
    NSString *branch = @"";
    NSDictionary *dic = @{@"agentCode":agentCode,@"lastUpdateTime":lastUpdateTime,@"recordNo":recordNo,@"operator":@">",@"orderby":@"desc"};
    NSString *resultJsonString = [TSSValidationUtil convertToJsonString:dic];
    NSString *encryptedJsonString = (NSString *)[[[resultJsonString dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKey:masterkey] base64EncodedDataWithOptions:0];
    
    NSMutableDictionary *parmater = [NSMutableDictionary dictionary];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:agentCode] forKey:@"agentCode"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:actionType] forKey:@"actionType"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:encryptedJsonString] forKey:@"parametersJson"];
    [parmater setValue:dataFile forKey:@"dataFile"];
    [parmater setValue:branch forKey:@"branch"];

#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
#endif
    [[NetworkingManager getInstance] postUploadWithURLString:urlStr fileURL:nil parameters:parmater postData:nil timeoutInterval:UPLOAD_DOWNLOAD_TIME responseBlock:^(id response) {
#if TEST_NET_RESPONSE_TIME > 0
        NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
        DLog(@"*************************login test-----downLoadNotifactionAndLastUpdateTime: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
#endif
        if ([response isKindOfClass:[NSError class]])
        {
            DLog(@"%s error",__func__);
            callback(response);
        }
        else
        {
            NSDictionary *resultDic = (NSDictionary *)response;
            NSString *returnValStr = [resultDic objectForKey:@"returnVal"];
            NSData *data = [[[NSData alloc]initWithBase64EncodedString:returnValStr options:0] AES256DecryptWithKey:masterkey];
#if TEST_NET_RESPONSE_TIME > 0
            [TSSSecurity writeResponseData: data toTestFileName: @"downLoadNotifactionAndLastUpdateTime" andTimeInterval:requestEndTime];
#endif
            resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
            NSArray *resultArr = [AnalysisJsonDataManager analysisNotificationViews:resultDic];
            
            callback(resultArr);
        }
    } ];
}

-(void)notificationUploadAndNotifyList:(NSArray *)notificationList andCallBack:(CallBack)callback
{
    NSString *agentCode = [TSSAppData getInstance].agentCode;
    NSString *masterkey = [TSSAppData getInstance].masterKey;
    NSString *dataFile = nil;
    NSString *branch = @"";
    NSString *actionType = @"ACT_UPLOAD_NOTIFICATION_STATUS";
    NSString *urlStr = [TSSAppSetting getInstance].serverUrl;
    
    if (notificationList == nil || notificationList.count == 0)
    {
        NSMutableArray *temp_eventList = [NSMutableArray array];
        NSArray *notifyArr = [[NotificationDao getInstance] getBeanWithUploadStatus:UPLOAD_STATUS_FAILED];
        if (notifyArr.count > 0)
        {
            NSMutableDictionary *mDic = nil;
            for (NotificatinBean *notifyBean in notifyArr) {
                mDic = [AnalysisJsonDataManager covertDictionaryWithUploadNotificationBean:notifyBean];
                [temp_eventList addObject:mDic];
            }
            notificationList = temp_eventList;
        }
    }
    if(notificationList.count<=0)
    {
        return;
    }
    NSDictionary *dic = @{@"statusList":notificationList};
    NSString *resultJsonString = [TSSValidationUtil convertToJsonString:dic];
    NSString *encryptedJsonString = (NSString *)[[[resultJsonString dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKey:masterkey] base64EncodedDataWithOptions:0];
    
    NSMutableDictionary *parmater = [NSMutableDictionary dictionary];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:agentCode] forKey:@"agentCode"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:actionType] forKey:@"actionType"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:encryptedJsonString] forKey:@"parametersJson"];
    [parmater setValue:dataFile forKey:@"dataFile"];
    [parmater setValue:branch forKey:@"branch"];
    
#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
#endif
    [[NetworkingManager getInstance] postUploadWithURLString:urlStr fileURL:nil parameters:parmater postData:nil timeoutInterval:UPLOAD_DOWNLOAD_TIME responseBlock:^(id response) {
#if TEST_NET_RESPONSE_TIME > 0
        NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
        DLog(@"*************************login test-----notificationUploadAndNotifyList: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
#endif
        
        if ([response isKindOfClass:[NSError class]])
        { // upload error, do nothing
            callback(UPLOAD_STATUS_FAILED);
        }
        else
        {
            NSDictionary *resultDic = (NSDictionary *)response;
            NSString *returnValStr = [resultDic objectForKey:@"returnVal"];
            NSString *retunrVal1 = [resultDic objectForKey:@"returnVal1"];
            if ([TSSValidationUtil isNilOrEmptyString:returnValStr])
            { // upload error, do nothing
                callback(UPLOAD_STATUS_FAILED);
            }
            else{
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:returnValStr options:0] AES256DecryptWithKey:masterkey];
#if TEST_NET_RESPONSE_TIME > 0
                [TSSSecurity writeResponseData: data toTestFileName: @"notificationUploadAndNotifyList" andTimeInterval:requestEndTime];
#endif
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                NSArray *statusList = [resultDic objectForKey:@"statusList"];
#if TEST_NET_RESPONSE_TIME > 0
                DLog(@"*************************login test-----notificationUploadAndNotifyList: statusList.count = %ld", statusList.count);
#endif
                NSString *toid = nil;
                NotificatinBean *temp = nil;
                for (NSDictionary *subDic in statusList){
                    toid = [subDic objectForKey:@"oid"];
                    temp = [[NotificationDao getInstance] getBeanWithoid:toid];
                    if (temp != nil) {
                        
                        if ([[temp.readStatus uppercaseString] isEqualToString:@"TRUE"] ||
                            [[temp.readStatus uppercaseString] isEqualToString:@"1"]) {
                            temp.readStatus = @"1";
                        }
                        else if ([[temp.readStatus uppercaseString] isEqualToString:@"0"]){
                            temp.readStatus = @"0";
                        }else if ([[temp.readStatus uppercaseString] isEqualToString:@"2"]){
                            temp.readStatus = @"2";
                            [[NotificationDao getInstance] deleteWithID:temp.idKey];
                        }
                        temp.uploadStatus = @"1";
                        [temp save];
                    }
                    callback(UPLOAD_STATUS_OK);
                }
            }
        }
    } ];
}


#pragma mark customers upload
-(void)uploadcustomers:(NSArray *)customers withContactHistoryList:(NSArray *)contactHistoryList withCallBack:(CallBack)callback
{
    if (customers.count == 0)
    {
        NSMutableArray *customerArr = [[CustomerInfoDao getInstance] getCustomerBeanWithUploadStatus:@"0"];
        if (customerArr.count > 0)
        {
            NSMutableArray *temp_customerArr = [NSMutableArray array];
            NSMutableDictionary *dict = nil;
            for (CustomerInfoBean *tCustomerBean in customerArr) {
                
                if (![TSSValidationUtil isNilOrEmptyString:tCustomerBean.firstname]) {
                    dict = [AnalysisJsonDataManager covertDictionaryWithCustomerBean:tCustomerBean];
                    [temp_customerArr addObject:dict];
                }
                
                
            }
            customers = temp_customerArr;
            contactHistoryList = @[];
        }
    }
    NSMutableDictionary *resultDictionary = [NSMutableDictionary dictionary];
    [resultDictionary setValue:customers forKey:@"customer"];
    [resultDictionary setValue:contactHistoryList forKey:@"contactHistoryList"];
    NSString *postStr = [TSSValidationUtil convertToJsonString:resultDictionary];
    
    postStr = [postStr replace:@"\n" replaceWith:@""];
    NSData *postData = [postStr dataUsingEncoding:NSUTF8StringEncoding];
    NSString *fileOutPath = [NSTemporaryDirectory() stringByAppendingPathComponent:FORMAT(@"%llu.zip", (long long)[[NSDate date] timeIntervalSince1970])];
    
    [TSSZipUtil zipFileWithPassword:nil fileName:@"customer" fileData:postData fileOutPath:fileOutPath];
    postData = [NSData dataWithContentsOfFile:fileOutPath];
    postData = [postData AES256EncryptWithKey:[TSSAppData getInstance].masterKey];
    
    //for base64;
    NSString *postDataStr = [postData base64Encoding];
    postData = [postDataStr dataUsingEncoding:NSUTF8StringEncoding];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    [fileManager removeItemAtPath:fileOutPath error:NULL];
    
    NSMutableDictionary *parmater = [NSMutableDictionary dictionary];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:[TSSAppData getInstance].agentCode] forKey:@"agentCode"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:@"ACT_UPLOAD_CUSTOMER"] forKey:@"actionType"];
    [parmater setValue:@"" forKey:@"parametersJson"];
    [parmater setValue:@"" forKey:@"dataFile"];
    [parmater setValue:@"" forKey:@"branch"];
    
    if (customers.count > 0)
    {
#if TEST_NET_RESPONSE_TIME > 0
        NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
#endif
        [[NetworkingManager getInstance] postUploadWithURLString:[TSSAppSetting getInstance].serverUrl fileURL:nil parameters:parmater postData:postData timeoutInterval:UPLOAD_DOWNLOAD_TIME responseBlock:^(id response) {
#if TEST_NET_RESPONSE_TIME > 0
            NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
            DLog(@"*************************login test-----uploadcustomers: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
#endif
            
            if ([response isKindOfClass:[NSError class]])
            {
                DLog(@"%s error",__func__);
                callback(response);
            }
            else
            {
                NSDictionary *resultDic = (NSDictionary *)response;
                NSString *returnValStr = [resultDic objectForKey:@"returnVal"];
                NSString *retunrVal1 = [resultDic objectForKey:@"returnVal1"];
                if ([TSSValidationUtil isNilOrEmptyString:returnValStr]) {
                    NSData *data = [[[NSData alloc]initWithBase64EncodedString:retunrVal1 options:0] AES256DecryptWithKey:[TSSAppData getInstance].masterKey];
                    resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                    DLog(@"resultDic = %@",resultDic);
                    //callback(resultDic);
                }
                else{
                    NSData *data = [[[NSData alloc]initWithBase64EncodedString:returnValStr options:0] AES256DecryptWithKey:[TSSAppData getInstance].masterKey];
#if TEST_NET_RESPONSE_TIME > 0
                    [TSSSecurity writeResponseData:data toTestFileName: @"uploadcustomers" andTimeInterval:requestEndTime];
#endif
                    resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                    NSArray *custArr = [resultDic objectForKey:@"idMapping"];
#if TEST_NET_RESPONSE_TIME > 0
                    DLog(@"*************************login test-----uploadcustomers: custArr.count = %ld", custArr.count);
#endif
                    callback(custArr);
                }
                
            }
        } ];
    }
}

/*
-(void)getGoogleMapNearbyInfomation:(NSString *)path andParameters:(NSDictionary *)parameters andCallBack:(CallBack)callback
{
    [[NetworkingManager getInstance] postUploadWithURLString:path fileURL:nil parameters:parameters postData:nil timeoutInterval:UPLOAD_DOWNLOAD_TIME responseBlock:^(id response)
     {
         if ([response isKindOfClass:[NSError class]])
         {
             DLog(@"%s error",__func__);
             callback(response);
         }
         else
         {
             NSDictionary *dic = (NSDictionary *)response;
             NSArray *resultArr = [AnalysisJsonDataManager analysisGoogleNearbyInfo:dic];
             callback(resultArr);
         }
     }];
}

-(void)getGoogleMapRouteInfomation:(NSString *)path andParameters:(NSDictionary *)parameters andCallBack:(CallBack)callback
{
    [[NetworkingManager getInstance] postUploadWithURLString:path fileURL:nil parameters:parameters postData:nil timeoutInterval:UPLOAD_DOWNLOAD_TIME responseBlock:^(id response)
     {
         if ([response isKindOfClass:[NSError class]])
         {
             DLog(@"%s error",__func__);
             callback(response);
         }
         else
         {
             NSDictionary *dic = (NSDictionary *)response;
             NSArray *resultArr = [AnalysisJsonDataManager analysisGoogleDestinationsInfo:dic];
             callback(resultArr);
         }
     }];
}

-(void)getGoogleMapGeoCodingInfomation:(NSString *)path andParameters:(NSDictionary *)parameters andCallBack:(CallBack)callback
{
    [[NetworkingManager getInstance] postUploadWithURLString:path fileURL:nil parameters:parameters postData:nil timeoutInterval:UPLOAD_DOWNLOAD_TIME responseBlock:^(id response)
     {
         if ([response isKindOfClass:[NSError class]])
         {
             DLog(@"%s error",__func__);
             callback(response);
         }
         else
         {
             NSDictionary *dic = (NSDictionary *)response;
             NSArray *resultArr = [AnalysisJsonDataManager analysisGoogleGeocodeInfo:dic];
             callback(resultArr);
         }
     }];
}

-(void)getGoogleMapDistanceInfomation:(NSString *)path andParameters:(NSDictionary *)parameters andCallBack:(CallBack)callback
{
    [[NetworkingManager getInstance] postUploadWithURLString:path fileURL:nil parameters:parameters postData:nil timeoutInterval:UPLOAD_DOWNLOAD_TIME responseBlock:^(id response)
     {
         if ([response isKindOfClass:[NSError class]])
         {
             DLog(@"%s error",__func__);
             callback(response);
         }
         else
         {
             NSDictionary *dic = (NSDictionary *)response;
             NSArray *resultArr = [AnalysisJsonDataManager analysisGoogleDistanceInfo:dic];
             callback(resultArr);
         }
     }];
}

#pragma mark notificatin jfw appointment
-(void)notificationDownload:(NSString *)lastUpdateTime andCallBack:(CallBack)callback
{
    
    NSString *agentCode = [TSSAppData getInstance].agentCode;
    NSString *masterkey = [TSSAppData getInstance].masterKey;
    NSString *dataFile = nil;
    NSString *branch = @"";
    NSString *actionType = @"ACT_DOWNLOAD_NOTIFICATION_INBOX";
    NSString *urlStr = [TSSAppSetting getInstance].serverUrl;
    
    NSDictionary *dic = @{@"agentCode":agentCode,@"lastUpdateTime":lastUpdateTime,@"recordNo":@"10",@"operator":@">",@"orderby":@"desc"};
    NSString *resultJsonString = [TSSValidationUtil convertToJsonString:dic];
    
    NSString *encryptedJsonString = (NSString *)[[[resultJsonString dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKey:masterkey] base64EncodedDataWithOptions:0];
    
    NSMutableDictionary *parmater = [NSMutableDictionary dictionary];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:agentCode] forKey:@"agentCode"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:actionType] forKey:@"actionType"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:encryptedJsonString] forKey:@"parametersJson"];
    [parmater setValue:dataFile forKey:@"dataFile"];
    [parmater setValue:branch forKey:@"branch"];
    
    
    [[NetworkingManager getInstance] postUploadWithURLString:urlStr fileURL:nil parameters:parmater postData:nil timeoutInterval:UPLOAD_DOWNLOAD_TIME responseBlock:^(id response) {
        
        if ([response isKindOfClass:[NSError class]])
        {
            DLog(@"%s error",__func__);
            callback(response);
        }
        else
        {
            NSDictionary *resultDic = (NSDictionary *)response;
            NSString *returnValStr = [resultDic objectForKey:@"returnVal"];
            NSString *retunrVal1 = [resultDic objectForKey:@"returnVal1"];
            if ([TSSValidationUtil isNilOrEmptyString:returnValStr]) {
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:retunrVal1 options:0] AES256DecryptWithKey:masterkey];
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                DLog(@"resultDic = %@",resultDic);
                //callback(resultDic);
            }
            else{
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:returnValStr options:0] AES256DecryptWithKey:masterkey];
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                NSArray *resultArr = [AnalysisJsonDataManager analysisNotificationViews:resultDic];
                callback(resultArr);
            }
            
        }
    } ];
}
*/
- (void)upLoadJfwStatusWithJfwStatus:(NSArray *)jfwStatus withCallBack:(CallBack)callback
{
    NSMutableArray *mArr = [NSMutableArray array];
    if (jfwStatus.count == 0) {
        NSArray *arr = [[AppointmentCommentsDao getInstance] getBeanWithAppointmentUploadStatus:UPLOAD_STATUS_FAILED];
        FollowUpAndNoteBean *followUpAndNoteBean = nil;
        NSDictionary *dic = nil;
        for (AppointmentCommentsBean *appointCommentBean in arr) {
            //此处包含删除状态
            followUpAndNoteBean = [[FollowUpAndNoteDao getInstance] getBeanWithAppointmentId:appointCommentBean.appointmentId];
            dic = [AnalysisJsonDataManager covertDictionaryForAppointmentCommentWithFolowUpBean:followUpAndNoteBean];
            [mArr addObject:dic];
        }
        jfwStatus = mArr;
    }
    
    if (jfwStatus.count==0) {
        return;
    }
    
    NSString *agentCode = [TSSAppData getInstance].agentCode;
    NSString *masterkey = [TSSAppData getInstance].masterKey;
    NSString *dataFile = nil;
    NSString *branch = @"";
    NSString *actionType = @"ACT_UPLOAD_JFW_STATUS";
    NSString *urlStr = [TSSAppSetting getInstance].serverUrl;
    NSDictionary *jfwStatusDic = @{@"jfwStatus":jfwStatus};
    NSString *resultJsonString = [TSSValidationUtil convertToJsonString:jfwStatusDic];
    
    NSString *encryptedJsonString = (NSString *)[[[resultJsonString dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKey:masterkey] base64EncodedDataWithOptions:0];
    
    NSMutableDictionary *parmater = [NSMutableDictionary dictionary];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:agentCode] forKey:@"agentCode"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:actionType] forKey:@"actionType"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:encryptedJsonString] forKey:@"parametersJson"];
    [parmater setValue:dataFile forKey:@"dataFile"];
    [parmater setValue:branch forKey:@"branch"];
    
    if (jfwStatus.count > 0) {
#if TEST_NET_RESPONSE_TIME > 0
        NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
#endif
        [[NetworkingManager getInstance] postUploadWithURLString:urlStr fileURL:nil parameters:parmater postData:nil timeoutInterval:UPLOAD_DOWNLOAD_TIME responseBlock:^(id response) {
#if TEST_NET_RESPONSE_TIME > 0
            NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
            DLog(@"*************************login test-----upLoadJfwStatusWithJfwStatus: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
#endif
            
            if ([response isKindOfClass:[NSError class]])
            {
                DLog(@"%s error",__func__);
                //callback(response);
            }
            else
            {
                NSDictionary *resultDic = (NSDictionary *)response;
                NSString *returnValStr = [resultDic objectForKey:@"returnVal"];
                NSString *retunrVal1 = [resultDic objectForKey:@"returnVal1"];
                if ([TSSValidationUtil isNilOrEmptyString:returnValStr]) {
                    NSData *data = [[[NSData alloc]initWithBase64EncodedString:retunrVal1 options:0] AES256DecryptWithKey:masterkey];
                    resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                    
                    //callback(resultDic);
                }
                else{
                    NSData *data = [[[NSData alloc]initWithBase64EncodedString:returnValStr options:0] AES256DecryptWithKey:masterkey];
#if TEST_NET_RESPONSE_TIME > 0
                    [TSSSecurity writeResponseData: data toTestFileName: @"upLoadJfwStatusWithJfwStatus" andTimeInterval:requestEndTime];
#endif
                    resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                    
                    NSArray *uploadStatus = [resultDic objectForKey:@"uploadStatus"];
#if TEST_NET_RESPONSE_TIME > 0
                    DLog(@"*************************login test-----upLoadJfwStatusWithJfwStatus: uploadStatus.count = %ld", uploadStatus.count);
#endif
                    callback(uploadStatus);
                }
                
            }
        } ];
    }
}

- (void)jfwUploadEmail:(NSString *)jfwOid withCallBack:(CallBack)callback {
    NSString *actionType = @"ACT_EMAIL_JFW";
    NSString *agentCode = [TSSAppData getInstance].agentCode;
    NSString *masterkey = [TSSAppData getInstance].masterKey;
    NSString *dataFile = nil;
    NSString *branch = @"";
    NSDictionary *dic = @{@"jfwOid":jfwOid};
    NSString *resultJsonString = [TSSValidationUtil convertToJsonString:dic];
    
    NSString *encryptedJsonString = (NSString *)[[[resultJsonString dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKey:masterkey] base64EncodedDataWithOptions:0];
    
    NSMutableDictionary *parmater = [NSMutableDictionary dictionary];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:agentCode] forKey:@"agentCode"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:actionType] forKey:@"actionType"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:encryptedJsonString] forKey:@"parametersJson"];
    [parmater setValue:dataFile forKey:@"dataFile"];
    [parmater setValue:branch forKey:@"branch"];
    [[NetworkingManager getInstance] postUploadWithURLString:[TSSAppSetting getInstance].serverUrl fileURL:nil parameters:parmater postData:nil timeoutInterval:UPLOAD_DOWNLOAD_TIME responseBlock:^(id response) {
        //SERVER_CONNECTION_TIME
        if ([response isKindOfClass:[NSError class]])
        {
            DLog(@"%s error",__func__);
            callback(response);
        }
        else
        {
            NSDictionary *resultDic = (NSDictionary *)response;
            NSString *returnValStr = [resultDic objectForKey:@"returnVal"];
            NSString *retunrVal1 = [resultDic objectForKey:@"returnVal1"];
            if ([TSSValidationUtil isNilOrEmptyString:returnValStr]) {
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:retunrVal1 options:0] AES256DecryptWithKey:masterkey];
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                callback(resultDic);
            }else {
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:returnValStr options:0] AES256DecryptWithKey:masterkey];
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                NSString *messageStatus = [AnalysisJsonDataManager analysisJfwEmail:resultDic];
                callback(messageStatus);
            }
            
        }
    } ];
    
}

-(void)jfwUpload:(NSArray *)aJfwArray andCallBack:(CallBack)callback
{
    if (aJfwArray.count==0) {
        callback(UPLOAD_STATUS_FAILED);
        DLog(@"delete call back failed");
        return;
    }
    NSMutableDictionary *resultDictionary = [NSMutableDictionary dictionary];
    NSMutableArray *resultArray = [NSMutableArray array];
    NSDictionary *tDic = nil;
    for (JfwBean *temp in aJfwArray) {
        tDic = [AnalysisJsonDataManager covertDictionaryWithJfwBean:temp];
        [resultArray addObject:tDic];
    }
    NSString *currentTime = FORMAT(@"%lld",(long long)([[NSDate convertNSDateToNSNumber:[NSDate date]] doubleValue] * 1000));
    [resultDictionary setValue:resultArray forKey:@"jfwForm"];
    [resultDictionary setValue:currentTime forKey:@"submissionTime"];
    
    NSString *postStr = [TSSValidationUtil convertToJsonString:resultDictionary];
    DLog(@"jfwUpload------- %@",postStr);
    NSString *encryptedJsonString = (NSString *)[[[postStr dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKey:[TSSAppData getInstance].masterKey] base64EncodedDataWithOptions:0];
    
    NSMutableDictionary *parmater = [NSMutableDictionary dictionary];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:[TSSAppData getInstance].agentCode] forKey:@"agentCode"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:@"ACT_UPLOAD_JFW_FORM"] forKey:@"actionType"];
    [parmater setValue:encryptedJsonString forKey:@"parametersJson"];
    [parmater setValue:@"" forKey:@"branch"];
    
    [[NetworkingManager getInstance] postUploadWithURLString:[TSSAppSetting getInstance].serverUrl fileURL:nil parameters:parmater postData:nil timeoutInterval:UPLOAD_DOWNLOAD_TIME responseBlock:^(id response) {
        
        if ([response isKindOfClass:[NSError class]])
        {
            DLog(@"%s error",__func__);
            for (JfwBean *temp in aJfwArray) {
                temp.uploadStatus = UPLOAD_STATUS_FAILED;
                [temp save];
            }
            callback(UPLOAD_STATUS_FAILED);
            DLog(@"delete call back failed");
        }
        else
        {
            NSDictionary *resultDic = (NSDictionary *)response;
            NSString *returnValStr = [resultDic objectForKey:@"returnVal"];
            NSString *retunrVal1 = [resultDic objectForKey:@"returnVal1"];//error
            DLog(@"retunrVal1:%@",retunrVal1);
            DLog(@"returnValStr:%@",returnValStr);
            if ([TSSValidationUtil isNilOrEmptyString:returnValStr]) {
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:retunrVal1 options:0] AES256DecryptWithKey:[TSSAppData getInstance].masterKey];
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                for (JfwBean *temp in aJfwArray) {
                    temp.uploadStatus = UPLOAD_STATUS_FAILED;
                    [temp save];
                }
                NSString *errorMsg = [resultDic objectForKey:@"errorMsg"];
                if ([errorMsg isEqualToString:@"Expired submission time."]) {
                    callback(errorMsg);
                    DLog(@"delete call back failed");
                }else {
                    callback(UPLOAD_STATUS_FAILED);
                    DLog(@"delete call back failed");
                }
            }
            else{
                DLog(@"returnValStr start decode");
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:returnValStr options:0] AES256DecryptWithKey:[TSSAppData getInstance].masterKey];
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                DLog(@"resultDic = %@",resultDic);
                NSArray *arr = [resultDic objectForKey:@"TEventJFWList"];
                JfwBean *j = nil;
                NSArray *questionArr = nil;
                int i = 0;
                NSDictionary *qtDic = nil;
                QuestionBean *tQuestion = nil;
                for (NSDictionary *subDic in arr)
                {
                    DLog(@"NSDictionary *subDic in arr start");
                    j = [[JfwDao getInstance] getBeanWithGroupId:[subDic objectForKey:@"groupId"] andFormType:[subDic objectForKey:@"type"]];
                    j.serverId = [subDic objectForKey:@"oid"];
                    j.jfwStatus = [subDic objectForKey:@"status"];
                    j.uploadStatus = UPLOAD_STATUS_OK;
                    
                    questionArr = [subDic objectForKey:@"question"];
                    if (questionArr.count > 0)
                    {
                        for (i = 0; i < questionArr.count; i++)
                        {
                            qtDic = [questionArr objectAtIndex: i];
                            tQuestion = [[QuestionDao getInstance] getBeanWithIdAndTypeAndNo:j.groupId andType:j.jfwType andQuestionNO:[qtDic objectForKey:@"questionNo"]];
                            if(tQuestion==nil)
                            {
                                continue;
                            }
                            tQuestion.oid = [qtDic objectForKey:@"oid"];
                            [tQuestion save];
                            //[mArr addObject:tQuestion];
                        }
                    }
                    //20171215 modify 删除状态的jfw也要保存
#if DOWNLOAD_DELETED_AND_CREATE_DATE_TIME_LONG_DATA == 0
                    ///*
                    if ([j.deleteStatus isEqualToString:RESPONSE_STATUS_REMOVE])
                    {
                        [[JfwDao getInstance] deleteGroupById:j.groupId];
                        [[QuestionDao getInstance] deleteGroupById:j.groupId];
                    }else
                    {
                     //*/
#endif
                        [j save];
#if DOWNLOAD_DELETED_AND_CREATE_DATE_TIME_LONG_DATA == 0
                    ///*
                     }
                     //*/
#endif
                    DLog(@"NSDictionary *subDic in arr end");
                }
                DLog(@"callback(UPLOAD_STATUS_OK");
                callback(UPLOAD_STATUS_OK);
                DLog(@"delete call back OK");
            }
        }
    } ];
}

-(void)jfwDownLoad:(NSString *)lastUpdateTime andRecordNo:(NSString *)recordNo andLater:(NSString*)sign oids:(NSMutableArray*)aOids fetchFlag:(NSString*)aFetchFlag andCallBack:(CallBack)callback
{
    NSString *agentCode = [TSSAppData getInstance].agentCode;
    NSString *masterkey = [TSSAppData getInstance].masterKey;
    NSString *dataFile = nil;
    NSString *branch = @"";
    NSString *actionType = @"ACT_DOWNLOAD_JFW_FORM";
    NSString *urlStr = [TSSAppSetting getInstance].serverUrl;
    
    NSMutableArray *tOidArray = [NSMutableArray array];
    NSMutableDictionary *tOidDict = nil;
    for (JfwBean *tOidJfw in aOids) {
        tOidDict = [NSMutableDictionary dictionary];
        [tOidDict setValue:[TSSValidationUtil converStringToEmptyString:tOidJfw.serverId] forKey:@"oid"];
        [tOidArray addObject:tOidDict];
    }
    
    NSDictionary *dic = @{@"agentCode":agentCode,@"lastUpdateTime":lastUpdateTime,@"recordNo":recordNo,@"operator":sign,@"orderby":@"desc",@"fetchFlag":aFetchFlag,@"oids":tOidArray};
    NSString *resultJsonString = [TSSValidationUtil convertToJsonString:dic];
    
    NSString *encryptedJsonString = (NSString *)[[[resultJsonString dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKey:masterkey] base64EncodedDataWithOptions:0];
    
    NSMutableDictionary *parmater = [NSMutableDictionary dictionary];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:agentCode] forKey:@"agentCode"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:actionType] forKey:@"actionType"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:encryptedJsonString] forKey:@"parametersJson"];
    [parmater setValue:dataFile forKey:@"dataFile"];
    [parmater setValue:branch forKey:@"branch"];
    

#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
#endif
    [[NetworkingManager getInstance] postUploadWithURLString:urlStr fileURL:nil parameters:parmater postData:nil timeoutInterval:UPLOAD_DOWNLOAD_MORETIME responseBlock:^(id response) {

#if TEST_NET_RESPONSE_TIME > 0
        NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
        DLog(@"*************************login test-----jfwDownLoad: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
#endif
        if ([response isKindOfClass:[NSError class]])
        {
            DLog(@"%s error",__func__);
            callback(UPLOAD_STATUS_FAILED);
        }
        else
        {
            NSDictionary *resultDic = (NSDictionary *)response;
            NSString *returnValStr = [resultDic objectForKey:@"returnVal"];
            NSString *retunrVal1 = [resultDic objectForKey:@"returnVal1"];
            if ([TSSValidationUtil isNilOrEmptyString:returnValStr]) {
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:retunrVal1 options:0] AES256DecryptWithKey:masterkey];
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                DLog(@"resultDic = %@",resultDic);
                callback(UPLOAD_STATUS_FAILED);
            }
            else{
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:returnValStr options:0] AES256DecryptWithKey:masterkey];

#if TEST_NET_RESPONSE_TIME > 0
                [TSSSecurity writeResponseData: data toTestFileName: @"jfwDownLoad" andTimeInterval:requestEndTime];
#endif
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                NSArray *resultArr = [AnalysisJsonDataManager analysisJfwViews:resultDic];
                callback(resultArr);
            }
        }
    } ];
}

-(void)commentsStatusUpload:(NSString *)appointId andStatus:(NSString*)aStatus andComments:(NSString*)aComments andCallBack:(CallBack)callback
{
    
    NSMutableDictionary *parmater = [NSMutableDictionary dictionary];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:[TSSAppData getInstance].agentCode] forKey:@"agentCode"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:@"ACT_UPLOAD_JFW_STATUS"] forKey:@"actionType"];
    [parmater setValue:appointId forKey:@"appointmentId"];
    [parmater setValue:aStatus forKey:@"status"];
    [parmater setValue:aStatus forKey:@"comments"];
    [parmater setValue:@"" forKey:@"commentsTime"];
    [parmater setValue:@"" forKey:@"branch"];
    
    [[NetworkingManager getInstance] postUploadWithURLString:[TSSAppSetting getInstance].serverUrl fileURL:nil parameters:parmater postData:nil timeoutInterval:UPLOAD_DOWNLOAD_TIME responseBlock:^(id response) {
        
        if ([response isKindOfClass:[NSError class]])
        {
            DLog(@"%s error",__func__);
            callback(response);
        }
        else
        {
            NSDictionary *resultDic = (NSDictionary *)response;
            NSString *returnValStr = [resultDic objectForKey:@"returnVal"];
            NSData *data = [[[NSData alloc]initWithBase64EncodedString:returnValStr options:0] AES256DecryptWithKey:[TSSAppData getInstance].masterKey];
            resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
            NSString *msgResult = [resultDic objectForKey:@"errorMessage"];
            callback(msgResult);
        }
    } ];
}

-(void)appointmentUploadAndEventList:(NSArray *)eventList andCallBack:(CallBack)callback
{
    NSString *agentCode = [TSSAppData getInstance].agentCode;
    NSString *masterkey = [TSSAppData getInstance].masterKey;
    NSString *dataFile = nil;
    NSString *branch = @"";
    NSString *actionType = @"ACT_UPLOAD_CALENDAR_EVENTS";
    NSString *urlStr = [TSSAppSetting getInstance].serverUrl;
    
    if (eventList.count == 0)
    {
        NSMutableArray *temp_eventList = [NSMutableArray array];
        //此处包含删除状态
        NSArray *followUpArr = [[FollowUpAndNoteDao getInstance] getBeanWithUploadStatus:UPLOAD_STATUS_FAILED];
        if (followUpArr.count > 0)
        {
            NSMutableDictionary *mDic = nil;
            for (FollowUpAndNoteBean *followupBean in followUpArr) {
                mDic = [AnalysisJsonDataManager covertDictionaryWithFollowUpAndNoteBean:followupBean];
                [temp_eventList addObject:mDic];
            }
            eventList = temp_eventList;
        }
    }
    if(eventList.count==0)
    {
        return;
    }
    NSDictionary *dic = @{@"agentId":[TSSAppData getInstance].agentCode,@"eventList":eventList};
    NSString *resultJsonString = [TSSValidationUtil convertToJsonString:dic];
    
    NSString *encryptedJsonString = (NSString *)[[[resultJsonString dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKey:masterkey] base64EncodedDataWithOptions:0];
    
    NSMutableDictionary *parmater = [NSMutableDictionary dictionary];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:agentCode] forKey:@"agentCode"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:actionType] forKey:@"actionType"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:encryptedJsonString] forKey:@"parametersJson"];
    [parmater setValue:dataFile forKey:@"dataFile"];
    [parmater setValue:branch forKey:@"branch"];
    
    if (eventList.count > 0) {
#if TEST_NET_RESPONSE_TIME > 0
        NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
#endif
        [[NetworkingManager getInstance] postUploadWithURLString:urlStr fileURL:nil parameters:parmater postData:nil timeoutInterval:UPLOAD_DOWNLOAD_TIME responseBlock:^(id response) {
#if TEST_NET_RESPONSE_TIME > 0
            NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
            DLog(@"*************************login test-----appointmentUploadAndEventList: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
#endif
            if ([response isKindOfClass:[NSError class]])
            {
                DLog(@"%s error",__func__);
                //set fail
                NSString *tId = nil;
                FollowUpAndNoteBean *temp = nil;
                for (NSDictionary *subDic in eventList) {
                    tId = [subDic objectForKey:@"id"];
                    temp = [[FollowUpAndNoteDao getInstance] getBeanWithAppointmentId:tId];
                    temp.uploadStatus = UPLOAD_STATUS_FAILED;
                    [temp save];
                }
                callback(UPLOAD_STATUS_FAILED);
            }
            else
            {
                NSDictionary *resultDic = (NSDictionary *)response;
                NSString *returnValStr = [resultDic objectForKey:@"returnVal"];
                NSString *retunrVal1 = [resultDic objectForKey:@"returnVal1"];
                if ([TSSValidationUtil isNilOrEmptyString:returnValStr]) {
                    NSData *data = [[[NSData alloc]initWithBase64EncodedString:retunrVal1 options:0] AES256DecryptWithKey:masterkey];
                    resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                    DLog(@"resultDic = %@",resultDic);
                    NSString *tId = nil;
                    FollowUpAndNoteBean *temp = nil;
                    for (NSDictionary *subDic in eventList) {
                        
                        tId = [subDic objectForKey:@"id"];
                        temp = [[FollowUpAndNoteDao getInstance] getBeanWithAppointmentId:tId];
                        temp.uploadStatus = UPLOAD_STATUS_FAILED;
                        [temp save];
                    }
                    callback(UPLOAD_STATUS_FAILED);
                }
                else
                {
                   
                    NSData *data = [[[NSData alloc]initWithBase64EncodedString:returnValStr options:0] AES256DecryptWithKey:masterkey];
#if TEST_NET_RESPONSE_TIME > 0
                    [TSSSecurity writeResponseData: data toTestFileName: @"appointmentUploadAndEventList" andTimeInterval:requestEndTime];
#endif
                    resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                    NSArray *eventList = [resultDic objectForKey:@"eventList"];
#if TEST_NET_RESPONSE_TIME > 0
                    DLog(@"*************************login test-----appointmentUploadAndEventList: eventList = %ld", eventList.count);
#endif
                    NSString *tId = nil;
                    FollowUpAndNoteBean *temp = nil;
                    EKEvent *event = nil;
                    for (NSDictionary *subDic in eventList)
                    {
                        
                        //Same followUp
                        tId = [subDic objectForKey:@"id"];
                        temp = [[FollowUpAndNoteDao getInstance] getBeanWithAppointmentId:tId];
                        if (temp!=nil)
                        {
                            if ([temp.deleteStatus isEqualToString:RESPONSE_STATUS_REMOVE])
                            {
                                //20171214 modify 删除event的时候，不删除数据
#if DOWNLOAD_DELETED_AND_CREATE_DATE_TIME_LONG_DATA == 0
                                ///*
                                // delete relate customer
                                [[AppointmentCustomerDao getInstance] delByAppointmentId:temp.appointmentId];
                                //delete relate comments
                                [[AppointmentCommentsDao getInstance] delByAppointmentId:temp.appointmentId];
                                //*/
#endif
                                if (![TSSValidationUtil isNilOrEmptyString:temp.eventIdentifier]) {
                                    event = [[EventManager shareInstance].store eventWithIdentifier:temp.eventIdentifier];
                                    [[EventManager shareInstance] deleteEvent:event];
                                }
#if DOWNLOAD_DELETED_AND_CREATE_DATE_TIME_LONG_DATA == 0
                                [temp delete];
#endif
#if DOWNLOAD_DELETED_AND_CREATE_DATE_TIME_LONG_DATA == 1
                                //20171214 modify 删除event的时候，不删除数据
                                temp.eventIdentifier = nil;
                                temp.uploadStatus = UPLOAD_STATUS_OK;
                                [temp save];
#endif
                            }
                            else
                            {
                                temp.eventId = [subDic objectForKey:@"eventId"];
                                temp.uploadStatus = UPLOAD_STATUS_OK;
                                [temp save];
                            }
                        }
                    }
                    callback(UPLOAD_STATUS_OK);
                }
            }
        } ];
    }
}

-(void)appointmentEventDownload:(NSString *)lastUpdateTime andRecordNo:(NSString *)recordNo andCallBack:(CallBack)callback
{
    NSString *agentCode = [TSSAppData getInstance].agentCode;
    NSString *masterkey = [TSSAppData getInstance].masterKey;
    NSString *dataFile = nil;
    NSString *branch = @"";
    NSString *actionType = @"ACT_DOWNLOAD_CALENDAR_EVENTS";
    NSString *urlStr = [TSSAppSetting getInstance].serverUrl;
    
    NSDictionary *dic = @{@"agentCode":agentCode,@"lastUpdateTime":lastUpdateTime,@"recordNo":recordNo,@"operator":@">",@"orderby":@"asc"};
    NSString *resultJsonString = [TSSValidationUtil convertToJsonString:dic];
    
    NSString *encryptedJsonString = (NSString *)[[[resultJsonString dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKey:masterkey] base64EncodedDataWithOptions:0];
    
    NSMutableDictionary *parmater = [NSMutableDictionary dictionary];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:agentCode] forKey:@"agentCode"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:actionType] forKey:@"actionType"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:encryptedJsonString] forKey:@"parametersJson"];
    [parmater setValue:dataFile forKey:@"dataFile"];
    [parmater setValue:branch forKey:@"branch"];
    
#if TEST_NET_RESPONSE_TIME > 0
    DLog(@"actionType = %@, plain parametersJson = %@", actionType, resultJsonString);
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
#endif
    [[NetworkingManager getInstance] postUploadWithURLString:urlStr fileURL:nil parameters:parmater postData:nil timeoutInterval:UPLOAD_DOWNLOAD_TIME responseBlock:^(id response) {
        
#if TEST_NET_RESPONSE_TIME > 0
        NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
        DLog(@"*************************appointmentEventDownload beginTime = %f, endTime = %f, take time = %f, lastUpdateTime = %@", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime, lastUpdateTime);
#endif
        if ([response isKindOfClass:[NSError class]])
        {
            DLog(@"%s error",__func__);
            callback(response);
        }
        else
        {
            NSDictionary *resultDic = (NSDictionary *)response;
            NSString *returnValStr = [resultDic objectForKey:@"returnVal"];
            NSString *retunrVal1 = [resultDic objectForKey:@"returnVal1"];
            //error
            if ([TSSValidationUtil isNilOrEmptyString:returnValStr]) {
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:retunrVal1 options:0] AES256DecryptWithKey:masterkey];
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                callback(resultDic);
            }
            else{
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:returnValStr options:0] AES256DecryptWithKey:masterkey];
#if TEST_NET_RESPONSE_TIME > 0
                [TSSSecurity writeResponseData: data toTestFileName: @"appointmentEventDownload" andTimeInterval:requestEndTime];
#endif
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
#if TEST_NET_RESPONSE_TIME > 0
                NSArray *resultArr = [AnalysisJsonDataManager analysisAppointment:resultDic];
#else
                NSArray *resultArr = [AnalysisJsonDataManager analysisAppointment:resultDic];
#endif
                
#if TEST_NET_RESPONSE_TIME > 0
                NSArray *tFollowArray = [[FollowUpAndNoteDao getInstance] getBeansWithCount:1];
                FollowUpAndNoteBean *tNewBean = nil;
                if (tFollowArray.count>0) {
                    tNewBean = [tFollowArray firstObject];
                }

                NSString *tLastTimeLong = [TSSValidationUtil converStringToEmptyString:tNewBean.lastUpdateDateTimeLong];
                DLog(@"*************************appointmentEventDownload: beginTime = %f, endTime = %f, after down load appointment, lastUpdateTime = %@", requestBeginTime, requestEndTime, tLastTimeLong);
#endif
                callback(resultArr);
            }
        }
    } ];
}

- (void)postUploadWithURLString:(NSString *)URLString fileURL:(NSURL *)fileURL parameters:(id)parameters postData:(NSData *)postData timeoutInterval:(NSTimeInterval)timeoutInterval responseBlock:(void (^)(id response))responseBlock {

    [self createAFHTTPSessionManager];
    
    self.manager.requestSerializer.timeoutInterval = timeoutInterval;
#if TEST_NET_RESPONSE_TIME > 0
    DLog(@"start request with parameters = %@", parameters);
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSinceReferenceDate];
#endif
    [self.manager POST:URLString parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
            if (fileURL) {
                [formData appendPartWithFileURL:fileURL name:@"uploadFile" error:NULL];
            }
            if (postData) {
                DLog(@"upload postData length == %lu", (unsigned long)[postData length]);
                [formData appendPartWithFormData:postData name:@"dataFile"];
            }
        }  progress:nil success:^(NSURLSessionDataTask *operation, id responseObject) {
#if TEST_NET_RESPONSE_TIME > 0
            NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSinceReferenceDate];
            DLog(@"parameters = %@, cost time = %f", parameters, requestEndTime - requestBeginTime);
#endif
               if (responseBlock) {
                   responseBlock(responseObject);
               }
           } failure:^(NSURLSessionDataTask *operation, NSError *error) {
#if TEST_NET_RESPONSE_TIME > 0
               NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSinceReferenceDate];
               DLog(@"parameters = %@, cost time = %f, error = %@", parameters, requestEndTime - requestBeginTime, error);
#endif
               if (responseBlock) {
                   responseBlock(error);
               }
           }];
}

- (void) downLoadNominatedCadidatesForCallBack: (CallBack)callback
{
    NSString *actionType= @"ACT_DOWNLOAD_NOMINATED_CANDIDATE";
    NSString *masterkey = [TSSAppData getInstance].masterKey;
    
    NSDictionary *dic = @{@"agentCode":[TSSAppData getInstance].agentCode};
    NSString *resultJsonString = [TSSValidationUtil convertToJsonString:dic];
    NSString *encryptedJsonString = (NSString *)[[[resultJsonString dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKey:masterkey] base64EncodedDataWithOptions:0];
    NSString *agentType = [[SmartTranslateHelper getInstance] getAgentTypeForNomination];
    
    NSMutableDictionary *parameterDictionary = [NSMutableDictionary dictionary];
    
    [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:actionType] forKey:@"actionType"];
    [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:[TSSAppData getInstance].agentCode] forKey:@"agentCode"];
    [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:agentType] forKey:@"agentType"];

    [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:encryptedJsonString] forKey:@"parametersJson"];
    //for China, using brach code
    [parameterDictionary setValue:@"" forKey:@"dataFile"];
    [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:@""] forKey:@"branch"];
    
    NSString *requestURLString = [TSSAppSetting getInstance].serverUrl;
#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
#endif
    [[NetworkingManager getInstance] postUploadWithURLString:requestURLString fileURL:nil parameters:parameterDictionary postData:nil timeoutInterval:UPLOAD_DOWNLOAD_TIME responseBlock:^(id response) {
#if TEST_NET_RESPONSE_TIME > 0
        NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
        DLog(@"*************************login test-----downLoadNominatedCadidates: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
#endif

        if ([response isKindOfClass:[NSError class]])
        {
            DLog(@"error found");
            callback(response);
        }
        else
        {
            NSDictionary *resultDic = (NSDictionary *)response;
            NSString *returnValStr = [resultDic objectForKey:@"returnVal"];
            NSString *retunrVal1 = [resultDic objectForKey:@"returnVal1"];
            if ([TSSValidationUtil isNilOrEmptyString:returnValStr]) {
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:retunrVal1 options:0] AES256DecryptWithKey:masterkey];
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                DLog(@"downLoadNominatedCadidatesForCallBack failed returnVal1: %@",resultDic.description);
                callback(resultDic);
            }else {
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:returnValStr options:0] AES256DecryptWithKey:masterkey];
#if TEST_NET_RESPONSE_TIME > 0
                [TSSSecurity writeResponseData: data toTestFileName: @"downLoadNominatedCadidates" andTimeInterval:requestEndTime];
#endif
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                DLog(@"downLoadNominatedCadidatesForCallBack succss: %@",resultDic.description);
                NSMutableArray *resultArray = [AnalysisJsonDataManager analysisNominatedCadidates:resultDic];
                callback(resultArray);
            }
        }
    }];
}

- (void) downLoadNominatedHistory:(NSString *)lastUpdateTime andRecordNo:(NSString *)recordNo andLater:(NSString*)sign andCallBack: (CallBack)callback
{
    NSString *urlStr = [TSSAppSetting getInstance].serverUrl;
    NSString *agentCode = [TSSAppData getInstance].agentCode;
    
    NSString *actionType = @"ACT_DOWNLOAD_NOMINATE_HISTORY";
    NSString *masterkey = [TSSAppData getInstance].masterKey;

    NSString *agentType = [[SmartTranslateHelper getInstance] getAgentTypeForNomination];
    NSDictionary *dic = @{@"agentCode":agentCode,@"agentType":[TSSValidationUtil convertNilToEmptyString:agentType],  @"lastUpdateTime":lastUpdateTime, @"recordNo":recordNo, @"operator":@">", @"orderby":@"desc"};

    NSString *resultJsonString = [TSSValidationUtil convertToJsonString:dic];
    NSString *encryptedJsonString = (NSString *)[[[resultJsonString dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKey:masterkey] base64EncodedDataWithOptions:0];
    
    NSMutableDictionary *parmater = [NSMutableDictionary dictionary];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:agentCode] forKey:@"agentCode"];
    
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:actionType] forKey:@"actionType"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:encryptedJsonString] forKey:@"parametersJson"];
    [parmater setValue:nil forKey:@"dataFile"];
    [parmater setValue:@"" forKey:@"branch"];
    
#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
#endif
    [[NetworkingManager getInstance] postUploadWithURLString:urlStr fileURL:nil parameters:parmater postData:nil timeoutInterval:UPLOAD_DOWNLOAD_TIME responseBlock:^(id response) {
       
#if TEST_NET_RESPONSE_TIME > 0
        NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
        DLog(@"*************************login test-----downLoadNominatedHistory: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
#endif
        
        if ([response isKindOfClass:[NSError class]])
        {
            DLog(@"%s error",__func__);
            callback(response);
        }
        else
        {
            NSDictionary *resultDic = (NSDictionary *)response;
            NSString *returnValStr = [resultDic objectForKey:@"returnVal"];
            NSString *retunrVal1 = [resultDic objectForKey:@"returnVal1"];
            if ([TSSValidationUtil isNilOrEmptyString:returnValStr]) {
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:retunrVal1 options:0] AES256DecryptWithKey:masterkey];
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                DLog(@"downLoadNominatedHistory failed returnVal1: %@",resultDic.description);
                callback(resultDic);
            }else {
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:returnValStr options:0] AES256DecryptWithKey:masterkey];
#if TEST_NET_RESPONSE_TIME > 0
                [TSSSecurity writeResponseData: data toTestFileName: @"downLoadNominatedHistory" andTimeInterval:requestEndTime];
#endif
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                DLog(@"downLoadNominatedHistory succss: %@",resultDic.description);
                NSMutableArray *resultArray = [AnalysisJsonDataManager analysisNominatedHistory: resultDic];
                callback(resultArray);
            }
        }
    } ];
}

- (void) downLoadNominatedPartersByCondensedFlag:(NSString *)condensedFlag andCallBack: (CallBack)callback
{
    NSString *masterkey = [TSSAppData getInstance].masterKey;
    NSString *actionType= @"ACT_DOWNLOAD_NOMINATED_PARTER";
    NSString *agentType = [[SmartTranslateHelper getInstance] getAgentTypeForNomination];
    
    NSMutableDictionary *parameterDictionary = [NSMutableDictionary dictionary];
    [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:actionType] forKey:@"actionType"];
    [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:[TSSAppData getInstance].agentCode] forKey:@"agentCode"];
    [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:agentType] forKey:@"agentType"];
    
    NSDictionary *dic = @{@"agentCode":[TSSAppData getInstance].agentCode, @"agentType" : agentType, @"condensed": condensedFlag};
    NSString *resultJsonString = [TSSValidationUtil convertToJsonString:dic];
    NSString *encryptedJsonString = (NSString *)[[[resultJsonString dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKey:masterkey] base64EncodedDataWithOptions:0];
    [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:encryptedJsonString] forKey:@"parametersJson"];
    //for China, using brach code
    [parameterDictionary setValue:@"" forKey:@"dataFile"];
    [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:@""] forKey:@"branch"];
    
    NSString *requestURLString = [TSSAppSetting getInstance].serverUrl;
#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
#endif
    [[NetworkingManager getInstance] postUploadWithURLString:requestURLString fileURL:nil parameters:parameterDictionary postData:nil timeoutInterval:UPLOAD_DOWNLOAD_TIME responseBlock:^(id response) {
#if TEST_NET_RESPONSE_TIME > 0
        NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
        DLog(@"*************************login test-----downLoadNominatedParterByCondensedFlag: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
#endif
        
        if ([response isKindOfClass:[NSError class]])
        {
            DLog(@"error found");
            callback(response);
        } else {
            NSDictionary *resultDic = (NSDictionary *)response;
            NSString *returnValStr = [resultDic objectForKey:@"returnVal"];
            NSString *retunrVal1 = [resultDic objectForKey:@"returnVal1"];
            if ([TSSValidationUtil isNilOrEmptyString:returnValStr]) {
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:retunrVal1 options:0] AES256DecryptWithKey:masterkey];
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                DLog(@"downLoadNominatedParterByCondensedFlag failed returnVal1: %@",resultDic.description);
                callback(resultDic);
            }else {
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:returnValStr options:0] AES256DecryptWithKey:masterkey];
#if TEST_NET_RESPONSE_TIME > 0
                [TSSSecurity writeResponseData: data toTestFileName: @"downLoadNominatedParterByCondensedFlag" andTimeInterval:requestEndTime];
#endif
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                DLog(@"downLoadNominatedParterByCondensedFlag succss: %@",resultDic.description);
                NSMutableArray *resultArray = [AnalysisJsonDataManager analysisNominatedParters:resultDic andCondensedFlag: condensedFlag];
                callback(resultArray);
            }
        }
    }];
}

- (void) downLoadTrackerSummaryByRequestModel:(TrackerRequestModel *) requestModel andCallBack: (CallBack)callback
{
    NSString *masterkey = [TSSAppData getInstance].masterKey;
    NSString *actionType= @"ACT_DOWNLOAD_TRACKER_SUMMARY";
    NSString *agentType = [[SmartTranslateHelper getInstance] getAgentTypeForNomination];
    
    NSMutableDictionary *parameterDictionary = [NSMutableDictionary dictionary];
    [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:actionType] forKey:@"actionType"];
    [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:[TSSAppData getInstance].agentCode] forKey:@"agentCode"];
    
    NSDictionary *dic = @{@"agentType":[TSSValidationUtil convertNilToEmptyString:agentType], @"LeaderCode":requestModel.leaderCode, @"FSCCodeList" : requestModel.fscCodeList, @"TimeSpan": requestModel.timeSpan};
    NSString *resultJsonString = [TSSValidationUtil convertToJsonString:dic];
    NSString *encryptedJsonString = (NSString *)[[[resultJsonString dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKey:masterkey] base64EncodedDataWithOptions:0];
    [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:encryptedJsonString] forKey:@"parametersJson"];
    //for China, using brach code
    [parameterDictionary setValue:@"" forKey:@"dataFile"];
    [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:@""] forKey:@"branch"];
    
    NSString *requestURLString = [TSSAppSetting getInstance].serverUrl;
#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
#endif
    [[NetworkingManager getInstance] postUploadWithURLString:requestURLString fileURL:nil parameters:parameterDictionary postData:nil timeoutInterval:UPLOAD_DOWNLOAD_TIME responseBlock:^(id response) {
#if TEST_NET_RESPONSE_TIME > 0
        NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
        DLog(@"************************* test-----downLoadTrackerSummaryByRequestModel: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
#endif
        
        if ([response isKindOfClass:[NSError class]])
        {
            DLog(@"error found");
            callback(UPLOAD_STATUS_FAILED);
        } else {
            NSDictionary *resultDic = (NSDictionary *)response;
            NSString *returnValStr = [resultDic objectForKey:@"returnVal"];
            NSString *retunrVal1 = [resultDic objectForKey:@"returnVal1"];
            if ([TSSValidationUtil isNilOrEmptyString:returnValStr]) {
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:retunrVal1 options:0] AES256DecryptWithKey:masterkey];
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                DLog(@"downLoadTrackerSummaryByRequestModel failed returnVal1: %@",resultDic.description);
                callback(UPLOAD_STATUS_FAILED);
            }else {
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:returnValStr options:0] AES256DecryptWithKey:masterkey];
#if TEST_NET_RESPONSE_TIME > 0
                [TSSSecurity writeResponseData: data toTestFileName: @"downLoadTrackerSummaryByRequestModel" andTimeInterval:requestEndTime];
#endif
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                DLog(@"downLoadTrackerSummaryByRequestModel succss: %@",resultDic.description);
                NSMutableArray *resultArray = [AnalysisJsonDataManager analysisTrackerSummary:resultDic andRequestModel:requestModel];
                //如果没有返回结果，或者返回结果不是24列，则返回空
                if (resultArray == nil) {
                    if ([TSSValidationUtil isNilOrEmptyString: requestModel.errorMessage]) {
                        callback(UPLOAD_STATUS_FAILED);
                    } else {
                        callback(requestModel.errorMessage);
                    }
                } else {
                    callback(UPLOAD_STATUS_OK);
                }
            }
        }
    }];
}

- (void) downLoadTrackerNewFscByRequestModel:(TrackerNewFscRequestModel *) requestModel andCallBack: (CallBack)callback
{
    
    NSString *masterkey = [TSSAppData getInstance].masterKey;
    NSString *actionType= @"ACT_DOWNLOAD_NEWFSCTANDC_SUMMARY";
    
    NSMutableDictionary *parameterDictionary = [NSMutableDictionary dictionary];
    [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:actionType] forKey:@"actionType"];
    [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:[TSSAppData getInstance].agentCode] forKey:@"agentCode"];
    
    NSDictionary *dic = @{@"agentCode": requestModel.agentCode, @"agentType": requestModel.agentType, @"TandCList" : requestModel.tandcList};
    NSString *resultJsonString = [TSSValidationUtil convertToJsonString:dic];
    NSString *encryptedJsonString = (NSString *)[[[resultJsonString dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKey:masterkey] base64EncodedDataWithOptions:0];
    [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:encryptedJsonString] forKey:@"parametersJson"];
    //for China, using brach code
    [parameterDictionary setValue:@"" forKey:@"dataFile"];
    [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:@""] forKey:@"branch"];
    
    NSString *requestURLString = [TSSAppSetting getInstance].serverUrl;
#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
#endif
    [[NetworkingManager getInstance] postUploadWithURLString:requestURLString fileURL:nil parameters:parameterDictionary postData:nil timeoutInterval:UPLOAD_DOWNLOAD_TIME responseBlock:^(id response) {
#if TEST_NET_RESPONSE_TIME > 0
        NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
        DLog(@"************************* test-----downLoadTrackerNewFscByRequestModel: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
#endif
        
        if ([response isKindOfClass:[NSError class]])
        {
            callback(UPLOAD_STATUS_FAILED);
        } else {
            NSDictionary *resultDic = (NSDictionary *)response;
            NSString *returnValStr = [resultDic objectForKey:@"returnVal"];
            NSString *retunrVal1 = [resultDic objectForKey:@"returnVal1"];
            if ([TSSValidationUtil isNilOrEmptyString:returnValStr]) {
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:retunrVal1 options:0] AES256DecryptWithKey:masterkey];
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                DLog(@"downLoadTrackerNewFscByRequestModel failed returnVal1: %@",resultDic.description);
                callback(UPLOAD_STATUS_FAILED);
            }else {
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:returnValStr options:0] AES256DecryptWithKey:masterkey];
#if TEST_NET_RESPONSE_TIME > 0
                [TSSSecurity writeResponseData: data toTestFileName: @"downLoadTrackerSummaryByRequestModel" andTimeInterval:requestEndTime];
#endif
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                DLog(@"downLoadTrackerNewFscByRequestModel succss: %@",resultDic.description);
                [AnalysisJsonDataManager analysisTrackerNewFscTandC:resultDic];
            
                callback(UPLOAD_STATUS_OK);
            }
        }
    }];
}

- (void) nominateAssessorUpload:(NSArray *)nominateAssessorList andCallBack:(CallBack)callback
{
    if (nominateAssessorList == nil || nominateAssessorList.count == 0) {
        callback(UPLOAD_STATUS_FAILED);
        DLog(@"nominateAssessorUpload------- faild: nominateAssessorList.count = 0");
        return;
    }
    NSMutableDictionary *resultDictionary = [NSMutableDictionary dictionary];
    NSMutableArray *mominateInfoDictArray = [NSMutableArray array];
    NSDictionary *tempDict = nil;
    for (NominationInfoBean *niBean in nominateAssessorList) {
        tempDict = [AnalysisJsonDataManager covertDictionaryWithNominationInfoBean:niBean];
        [mominateInfoDictArray addObject:tempDict];
    }
    
    NSString *agentType = [[SmartTranslateHelper getInstance] getAgentTypeForNomination];
    [resultDictionary setValue:agentType forKey:@"agentType"];
    [resultDictionary setValue:mominateInfoDictArray forKey:@"NominatedList"];
    
    NSString *postStr = [TSSValidationUtil convertToJsonString:resultDictionary];
    DLog(@"nominateAssessorUpload------- %@",postStr);
    NSString *encryptedJsonString = (NSString *)[[[postStr dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKey:[TSSAppData getInstance].masterKey] base64EncodedDataWithOptions:0];
    
    NSMutableDictionary *parmater = [NSMutableDictionary dictionary];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:[TSSAppData getInstance].agentCode] forKey:@"agentCode"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:@"ACT_UPLOAD_NOMINATED_ASSESSOR"] forKey:@"actionType"];
    [parmater setValue:encryptedJsonString forKey:@"parametersJson"];
    [parmater setValue:@"" forKey:@"dataFile"];
    [parmater setValue:@"" forKey:@"branch"];
    
    [[NetworkingManager getInstance] postUploadWithURLString:[TSSAppSetting getInstance].serverUrl fileURL:nil parameters:parmater postData:nil timeoutInterval:UPLOAD_DOWNLOAD_TIME responseBlock:^(id response) {
        
        if ([response isKindOfClass:[NSError class]]) {
            DLog(@"%s error",__func__);
            for (NominationInfoBean *tempBean in nominateAssessorList) {
                tempBean.uploadStatus = UPLOAD_STATUS_FAILED;
                [tempBean save];
            }
            callback(UPLOAD_STATUS_FAILED);
            DLog(@"nominateAssessorUpload call back failed");
        } else {
            NSDictionary *resultDic = (NSDictionary *)response;
            NSString *returnValStr = [resultDic objectForKey:@"returnVal"];
            NSString *retunrVal1 = [resultDic objectForKey:@"returnVal1"];//error
            DLog(@"retunrVal1:%@",retunrVal1);
            DLog(@"returnValStr:%@",returnValStr);
            if ([TSSValidationUtil isNilOrEmptyString:returnValStr]) {
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:retunrVal1 options:0] AES256DecryptWithKey:[TSSAppData getInstance].masterKey];
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                NominationInfoBean *niBean = nil;
                for (NominationInfoBean *tempBean in nominateAssessorList) {
                    niBean = [[NominationInfoDao getInstance] getBeanWithNominationInfoID: tempBean.nominationInfoID ];
                    niBean.uploadStatus = UPLOAD_STATUS_FAILED;
                    [niBean save];
                }
                NSString *errorMsg = [resultDic objectForKey:@"errorMsg"];
                if ([errorMsg isEqualToString:@"Expired submission time."]) {
                    callback(errorMsg);
                    DLog(@"nominateAssessorUpload call back failed");
                } else {
                    callback(UPLOAD_STATUS_FAILED);
                    DLog(@"nominateAssessorUpload call back failed");
                }
            } else {
                DLog(@"returnValStr start decode");
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:returnValStr options:0] AES256DecryptWithKey:[TSSAppData getInstance].masterKey];
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                DLog(@"resultDic = %@",resultDic);
                NSArray *arr = [resultDic objectForKey:@"NominatedList"];
                
                NominationInfoBean *niBean = nil;
                for (NSDictionary *subDic in arr) {
                    niBean = [[NominationInfoDao getInstance] getBeanWithNominationInfoID: [subDic objectForKey:@"id"]];
                    if (niBean != nil) {
                        niBean.oid = [subDic objectForKey:@"oid"];
                        niBean.uploadStatus = UPLOAD_STATUS_OK;
                        [niBean save];
                    }
                }
                DLog(@"nominateAssessorUpload callback(UPLOAD_STATUS_OK");
                callback(UPLOAD_STATUS_OK);
                DLog(@"nominateAssessorUpload call back OK");
            }
        }
    } ];
}

-(void) downLoadJFWDeleteStatusByGroupIDs : (NSArray *) groupIdDicArray andCollaboratorId:(NSString *) collaboratorId andCallBack:(CallBack)callback
{
    NSString *actionType= @"ACT_DOWNLOAD_JFW_DELETED_STATUS";
    NSString *masterkey = [TSSAppData getInstance].masterKey;
    
    NSDictionary *dic = @{@"JFWGroupIdList": groupIdDicArray};
    NSString *resultJsonString = [TSSValidationUtil convertToJsonString:dic];
    NSString *encryptedJsonString = (NSString *)[[[resultJsonString dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKey:masterkey] base64EncodedDataWithOptions:0];
    NSString *agentType = [[SmartTranslateHelper getInstance] getAgentTypeForNomination];
    
    NSMutableDictionary *parameterDictionary = [NSMutableDictionary dictionary];
    
    [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:actionType] forKey:@"actionType"];
    [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:[TSSAppData getInstance].agentCode] forKey:@"agentCode"];
    [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:agentType] forKey:@"agentType"];
    
    [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:encryptedJsonString] forKey:@"parametersJson"];
    //for China, using brach code
    [parameterDictionary setValue:@"" forKey:@"dataFile"];
    [parameterDictionary setValue:[TSSValidationUtil convertNilToEmptyString:@""] forKey:@"branch"];
    
    NSString *requestURLString = [TSSAppSetting getInstance].serverUrl;
#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
#endif
    [[NetworkingManager getInstance] postUploadWithURLString:requestURLString fileURL:nil parameters:parameterDictionary postData:nil timeoutInterval:UPLOAD_DOWNLOAD_TIME responseBlock:^(id response) {
#if TEST_NET_RESPONSE_TIME > 0
        NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
        DLog(@"*************************login test-----downLoadJFWDeleteStatusByGroupIDs: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
#endif
        
        if ([response isKindOfClass:[NSError class]])
        {
            DLog(@"error found");
            callback(UPLOAD_STATUS_FAILED);
        }
        else
        {
            NSDictionary *resultDic = (NSDictionary *)response;
            NSString *returnValStr = [resultDic objectForKey:@"returnVal"];
            NSString *retunrVal1 = [resultDic objectForKey:@"returnVal1"];
            if ([TSSValidationUtil isNilOrEmptyString:returnValStr]) {
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:retunrVal1 options:0] AES256DecryptWithKey:masterkey];
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                DLog(@"downLoadJFWDeleteStatusByGroupIDs failed returnVal1: %@",resultDic.description);
                callback(UPLOAD_STATUS_FAILED);
            }else {
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:returnValStr options:0] AES256DecryptWithKey:masterkey];
#if TEST_NET_RESPONSE_TIME > 0
                [TSSSecurity writeResponseData: data toTestFileName: @"downLoadJFWDeleteStatusByGroupIDs" andTimeInterval:requestEndTime];
#endif
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                DLog(@"downLoadJFWDeleteStatusByGroupIDs succss: %@",resultDic.description);
                NSDictionary *jfwDeleteStatusDict = [AnalysisJsonDataManager analysisJfwDeleteStatus: resultDic andCollaboratorId: collaboratorId];
                callback(jfwDeleteStatusDict);
            }
        }
    }];
}

-(void) downloadDeletedAppointmentEvent:(NSString *)lastUpdateTime andCallBack:(CallBack)callback
{
    NSString *agentCode = [TSSAppData getInstance].agentCode;
    NSString *masterkey = [TSSAppData getInstance].masterKey;
    NSString *dataFile = nil;
    NSString *branch = @"";
    NSString *actionType = @"T_ACT_DOWNLOAD_DELETED_CALENDAR_EVENTS";
    NSString *urlStr = [TSSAppSetting getInstance].serverUrl;
    NSDictionary *dic = @{@"agentCode":agentCode,@"lastUpdateDateTime_Long":lastUpdateTime};
    NSString *resultJsonString = [TSSValidationUtil convertToJsonString:dic];
    
    NSString *encryptedJsonString = (NSString *)[[[resultJsonString dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKey:masterkey] base64EncodedDataWithOptions:0];
    
    NSMutableDictionary *parmater = [NSMutableDictionary dictionary];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:agentCode] forKey:@"agentCode"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:actionType] forKey:@"actionType"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:encryptedJsonString] forKey:@"parametersJson"];
    [parmater setValue:dataFile forKey:@"dataFile"];
    [parmater setValue:branch forKey:@"branch"];
    
#if TEST_NET_RESPONSE_TIME > 0
    DLog(@"actionType = %@, plain parametersJson = %@", actionType, resultJsonString);
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
#endif
    [[NetworkingManager getInstance] postUploadWithURLString:urlStr fileURL:nil parameters:parmater postData:nil timeoutInterval:UPLOAD_DOWNLOAD_TIME responseBlock:^(id response) {
        
#if TEST_NET_RESPONSE_TIME > 0
        NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
        DLog(@"*************************downloadDeletedAppointmentEvent beginTime = %f, endTime = %f, take time = %f, lastUpdateTime = %@", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime, lastUpdateTime);
#endif
        if ([response isKindOfClass:[NSError class]])
        {
            DLog(@"%s error",__func__);
            callback(response);
        }
        else
        {
            NSDictionary *resultDic = (NSDictionary *)response;
            NSString *returnValStr = [resultDic objectForKey:@"returnVal"];
            NSString *retunrVal1 = [resultDic objectForKey:@"returnVal1"];
            //error
            if ([TSSValidationUtil isNilOrEmptyString:returnValStr]) {
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:retunrVal1 options:0] AES256DecryptWithKey:masterkey];
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                callback(resultDic);
            }
            else{
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:returnValStr options:0] AES256DecryptWithKey:masterkey];
#if TEST_NET_RESPONSE_TIME > 0
                [TSSSecurity writeResponseData: data toTestFileName: @"downloadDeletedAppointmentEvent" andTimeInterval:requestEndTime];
#endif
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
#if TEST_NET_RESPONSE_TIME > 0
                NSArray *resultArr = [AnalysisJsonDataManager analysisAppointment:resultDic];
#else
                NSArray *resultArr = [AnalysisJsonDataManager analysisAppointment:resultDic];
                //成功后设置标示，下次不再下载数据
                NSString *firstDownLoadDeteletedFollowupKey = [NSString stringWithFormat: @"%@%@", [TSSAppData getInstance].agentCode, FIRST_DOWNLOAD_DELETE_FOLLOWUP];
                NSString *enfirstDownLoadDeteletedFollowupKey =  [TSSSecurity sha256:firstDownLoadDeteletedFollowupKey];
                [PDKeyChain keyChainSaveKey:enfirstDownLoadDeteletedFollowupKey withkeyChainValue:FIRST_DOWNLOAD_DELETE_DONE];

#endif
                
#if TEST_NET_RESPONSE_TIME > 0
                NSArray *tFollowArray = [[FollowUpAndNoteDao getInstance] getBeansWithCount:1];
                FollowUpAndNoteBean *tNewBean = nil;
                if (tFollowArray.count>0) {
                    tNewBean = [tFollowArray firstObject];
                }
                
                NSString *tLastTimeLong = [TSSValidationUtil converStringToEmptyString:tNewBean.lastUpdateDateTimeLong];
                DLog(@"*************************downloadDeletedAppointmentEvent: beginTime = %f, endTime = %f, after down load appointment, lastUpdateTime = %@", requestBeginTime, requestEndTime, tLastTimeLong);
#endif
                callback(resultArr);
            }
            
        }
    } ];
}


-(void) downloadDeletedJFW:(NSString *)lastUpdateTime andCallBack:(CallBack)callback
{
    NSString *agentCode = [TSSAppData getInstance].agentCode;
    NSString *masterkey = [TSSAppData getInstance].masterKey;
    NSString *dataFile = nil;
    NSString *branch = @"";
    NSString *actionType = @"T_ACT_DOWNLOAD_DELETED_JFW_FORM";
    NSString *urlStr = [TSSAppSetting getInstance].serverUrl;

    
    NSDictionary *dic = @{@"agentCode":agentCode,@"lastUpdateDateTime_Long":lastUpdateTime};
    NSString *resultJsonString = [TSSValidationUtil convertToJsonString:dic];
    
    NSString *encryptedJsonString = (NSString *)[[[resultJsonString dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKey:masterkey] base64EncodedDataWithOptions:0];
    
    NSMutableDictionary *parmater = [NSMutableDictionary dictionary];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:agentCode] forKey:@"agentCode"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:actionType] forKey:@"actionType"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:encryptedJsonString] forKey:@"parametersJson"];
    [parmater setValue:dataFile forKey:@"dataFile"];
    [parmater setValue:branch forKey:@"branch"];
    
    
#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
#endif
    [[NetworkingManager getInstance] postUploadWithURLString:urlStr fileURL:nil parameters:parmater postData:nil timeoutInterval:UPLOAD_DOWNLOAD_MORETIME responseBlock:^(id response) {
        
#if TEST_NET_RESPONSE_TIME > 0
        NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
        DLog(@"*************************login test-----downloadDeletedJFW: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
#endif
        if ([response isKindOfClass:[NSError class]])
        {
            DLog(@"%s error",__func__);
            callback(UPLOAD_STATUS_FAILED);
        }
        else
        {
            NSDictionary *resultDic = (NSDictionary *)response;
            NSString *returnValStr = [resultDic objectForKey:@"returnVal"];
            NSString *retunrVal1 = [resultDic objectForKey:@"returnVal1"];
            if ([TSSValidationUtil isNilOrEmptyString:returnValStr]) {
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:retunrVal1 options:0] AES256DecryptWithKey:masterkey];
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                DLog(@"resultDic = %@",resultDic);
                callback(UPLOAD_STATUS_FAILED);
            }
            else{
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:returnValStr options:0] AES256DecryptWithKey:masterkey];
                
#if TEST_NET_RESPONSE_TIME > 0
                [TSSSecurity writeResponseData: data toTestFileName: @"downloadDeletedJFW" andTimeInterval:requestEndTime];
#endif
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                NSArray *resultArr = [AnalysisJsonDataManager analysisJfwViews:resultDic];
                
                //成功后设置标示，下次不再下载数据
                NSString *firstDownLoadDeteletedJFWKey = [NSString stringWithFormat: @"%@%@", [TSSAppData getInstance].agentCode, FIRST_DOWNLOAD_DELETE_JFW];
                NSString *enfirstDownLoadDeteletedJFWKey =  [TSSSecurity sha256:firstDownLoadDeteletedJFWKey];
                [PDKeyChain keyChainSaveKey:enfirstDownLoadDeteletedJFWKey withkeyChainValue:FIRST_DOWNLOAD_DELETE_DONE];
                callback(resultArr);            }
            
        }
    } ];
}

-(void) downloadCreateDateTimeForAppointmentEvent:(NSString *)lastUpdateTime andCallBack:(CallBack)callback
{
    NSString *agentCode = [TSSAppData getInstance].agentCode;
    NSString *masterkey = [TSSAppData getInstance].masterKey;
    NSString *dataFile = nil;
    NSString *branch = @"";
    NSString *actionType = @"T_ACT_DOWNLOAD_CALENDAR_EVENTS_SECTION";
    NSString *urlStr = [TSSAppSetting getInstance].serverUrl;
    
    NSDictionary *subDic = @{@"item" : @"createDateTime_Long"};
    NSDictionary *dic = @{@"agentCode": agentCode, @"section": [NSMutableArray arrayWithObject:subDic],@"lastUpdateDateTime_Long": lastUpdateTime};
    NSString *resultJsonString = [TSSValidationUtil convertToJsonString:dic];
    
    NSString *encryptedJsonString = (NSString *)[[[resultJsonString dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKey:masterkey] base64EncodedDataWithOptions:0];
    
    NSMutableDictionary *parmater = [NSMutableDictionary dictionary];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:agentCode] forKey:@"agentCode"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:actionType] forKey:@"actionType"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:encryptedJsonString] forKey:@"parametersJson"];
    [parmater setValue:dataFile forKey:@"dataFile"];
    [parmater setValue:branch forKey:@"branch"];
    
    
#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
#endif
    [[NetworkingManager getInstance] postUploadWithURLString:urlStr fileURL:nil parameters:parmater postData:nil timeoutInterval:UPLOAD_DOWNLOAD_MORETIME responseBlock:^(id response) {
        
#if TEST_NET_RESPONSE_TIME > 0
        NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
        DLog(@"*************************login test-----downloadDeletedJFW: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
#endif
        if ([response isKindOfClass:[NSError class]])
        {
            DLog(@"%s error",__func__);
            callback(UPLOAD_STATUS_FAILED);
        }
        else
        {
            NSDictionary *resultDic = (NSDictionary *)response;
            NSString *returnValStr = [resultDic objectForKey:@"returnVal"];
            NSString *retunrVal1 = [resultDic objectForKey:@"returnVal1"];
            if ([TSSValidationUtil isNilOrEmptyString:returnValStr]) {
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:retunrVal1 options:0] AES256DecryptWithKey:masterkey];
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                DLog(@"resultDic = %@",resultDic);
                callback(UPLOAD_STATUS_FAILED);
            }
            else{
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:returnValStr options:0] AES256DecryptWithKey:masterkey];
                
#if TEST_NET_RESPONSE_TIME > 0
                [TSSSecurity writeResponseData: data toTestFileName: @"downloadDeletedJFW" andTimeInterval:requestEndTime];
#endif
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                NSArray *resultArr = [AnalysisJsonDataManager analysisCreateDateTimeForAppointment: resultDic];
                //成功后设置标示，下次不再下载数据
                //NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
                NSString *firstDownLoadCreateDateTimeLongFollowupKey = [NSString stringWithFormat: @"%@%@", [TSSAppData getInstance].agentCode, FIRST_DOWNLOAD_CREATE_DATE_TIME_LONG_FOLLOWUP];
                NSString *enfirstDownLoadCreateDateTimeLongFollowupKey =  [TSSSecurity sha256:firstDownLoadCreateDateTimeLongFollowupKey];
                [PDKeyChain keyChainSaveKey:enfirstDownLoadCreateDateTimeLongFollowupKey withkeyChainValue:FIRST_DOWNLOAD_DELETE_DONE];
                callback(resultArr);
            }
            
        }
    } ];
}

- (void) updateDefaultAcceptedRoadshowForProd1: (NSArray *)acceptedRoadshowList andCallBack:(CallBack)callback
{
    NSString *agentCode = [TSSAppData getInstance].agentCode;
    NSString *masterkey = [TSSAppData getInstance].masterKey;
    NSString *dataFile = nil;
    NSString *branch = @"";
    NSString *actionType = @"T_ACT_UPDATE_ACCEPTEDROADSHOW_ACCPTED";
    NSString *urlStr = [TSSAppSetting getInstance].serverUrl;
    
    NSDictionary *dic = @{@"agentCode": agentCode, @"Roadshows": acceptedRoadshowList};
    NSString *resultJsonString = [TSSValidationUtil convertToJsonString:dic];
    
    NSString *encryptedJsonString = (NSString *)[[[resultJsonString dataUsingEncoding:NSUTF8StringEncoding] AES256EncryptWithKey:masterkey] base64EncodedDataWithOptions:0];
    
    NSMutableDictionary *parmater = [NSMutableDictionary dictionary];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:agentCode] forKey:@"agentCode"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:actionType] forKey:@"actionType"];
    [parmater setValue:[TSSValidationUtil convertNilToEmptyString:encryptedJsonString] forKey:@"parametersJson"];
    [parmater setValue:dataFile forKey:@"dataFile"];
    [parmater setValue:branch forKey:@"branch"];
    
    
#if TEST_NET_RESPONSE_TIME > 0
    NSTimeInterval requestBeginTime = [[NSDate date] timeIntervalSince1970];
#endif
    [[NetworkingManager getInstance] postUploadWithURLString:urlStr fileURL:nil parameters:parmater postData:nil timeoutInterval:UPLOAD_DOWNLOAD_MORETIME responseBlock:^(id response) {
        
#if TEST_NET_RESPONSE_TIME > 0
        NSTimeInterval requestEndTime = [[NSDate date] timeIntervalSince1970];
        DLog(@"*************************login test-----updateDefaultAcceptedRoadshowForProd1: beginTime = %f, endTime = %f, take time = %f", requestBeginTime, requestEndTime, requestEndTime - requestBeginTime);
#endif
        if ([response isKindOfClass:[NSError class]])
        {
            DLog(@"%s error",__func__);
            callback(UPLOAD_STATUS_FAILED);
        }
        else
        {
            NSDictionary *resultDic = (NSDictionary *)response;
            NSString *returnValStr = [resultDic objectForKey:@"returnVal"];
            NSString *retunrVal1 = [resultDic objectForKey:@"returnVal1"];
            if ([TSSValidationUtil isNilOrEmptyString:returnValStr]) {
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:retunrVal1 options:0] AES256DecryptWithKey:masterkey];
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                DLog(@"resultDic = %@",resultDic);
                callback(UPLOAD_STATUS_FAILED);
            } else {
                NSData *data = [[[NSData alloc]initWithBase64EncodedString:returnValStr options:0] AES256DecryptWithKey:masterkey];
                
#if TEST_NET_RESPONSE_TIME > 0
                [TSSSecurity writeResponseData: data toTestFileName: @"updateDefaultAcceptedRoadshowForProd1" andTimeInterval:requestEndTime];
#endif
                resultDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                
                DLog(@"*************************login test-----updateDefaultAcceptedRoadshowForProd1: resultDic = %@", resultDic);
                NSArray *resultArr = [AnalysisJsonDataManager analysisDefaultAcceptedRoadshowForProd1: resultDic];

                callback(resultArr);
            }
        }
    } ];
}

@end
