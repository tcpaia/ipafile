//
//  AnalysisJsonDataManager.h
//  TSSProject
//
//  Created by 于磊 on 16/5/27.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FollowUpAndNoteBean.h"
#import "AppointmentCommentsBean.h"
#import "AppointmentCustomerBean.h"
#import "NotificatinBean.h"

@class EventLogBean;
@class CustomerInfoBean;
@class LeadsInfoBean;
@class QuestionBean;
@class JfwBean;
@class NominationInfoBean;
@class TrackerRequestModel;

@interface AnalysisJsonDataManager : NSObject

+ (id) analysisAgentProfile: (NSDictionary *) dic;
+ (id) analysisCustomer: (NSDictionary *) dic;
+ (id) analysisCustomer: (NSDictionary *) dic forFetchFlag: (NSString *) fetchFlag;
/*
+ (id) analysisGoogleNearbyInfo: (NSDictionary *) dic;
+ (id) analysisGoogleDestinationsInfo: (NSDictionary *) dic;
+ (id) analysisGoogleGeocodeInfo: (NSDictionary *) dic;
+ (id) analysisGoogleDistanceInfo: (NSDictionary *) dic;
 */
+ (id) analysisNotificationViews: (NSDictionary *) dic;
+ (id) analysisJfwViews: (NSDictionary *) dic;
+ (id) analysisAppointment: (NSDictionary *) dic;

+ (id) analysisJfwEmail: (NSDictionary *) dic;
+ (id) analysisNominatedCadidates: (NSDictionary *) dic;
+ (id) analysisNominatedHistory: (NSDictionary *) dic;
+ (id) analysisNominatedParters: (NSDictionary *) dic andCondensedFlag:(NSString *)condensedFlag;
+ (id) analysisTrackerSummary: (NSDictionary *) dic andRequestModel:(TrackerRequestModel *) requestModel;
+ (id) analysisTrackerNewFscTandC: (NSDictionary *) dic;
+ (id) analysisJfwDeleteStatus: (NSDictionary *) dic andCollaboratorId: (NSString *) collaboratorId;
+ (id) analysisCreateDateTimeForAppointment: (NSDictionary *) dic;
+ (id) analysisDefaultAcceptedRoadshowForProd1: (NSDictionary *) dic;

+ (NSMutableDictionary *) covertDictionaryWithEventLogBean: (EventLogBean *) eventLogBean;
+ (NSMutableDictionary *) covertDictionaryWithCustomerBean: (CustomerInfoBean *) customerBean;
+ (NSMutableDictionary *) covertDictionaryWithFollowUpAndNoteBean: (FollowUpAndNoteBean *) followUpBean;
+ (NSMutableDictionary *) covertDictionaryWithQuestionBean: (QuestionBean *) tQuest;
+ (NSMutableDictionary *) covertDictionaryWithJfwBean: (JfwBean *) tJfw;
+ (NSMutableDictionary *) covertDictionaryForAppointmentCommentWithFolowUpBean: (FollowUpAndNoteBean *) followUpBean;

+ (NSMutableDictionary *) covertDictionaryWithUploadNotificationBean: (NotificatinBean *) notifyBean;

+ (NSMutableDictionary *) covertDictionaryWithNominationInfoBean: (NominationInfoBean *) nominationInfoBean;
@end
