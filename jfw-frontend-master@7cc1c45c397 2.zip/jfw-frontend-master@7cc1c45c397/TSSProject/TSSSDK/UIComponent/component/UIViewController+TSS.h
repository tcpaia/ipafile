//
//  UIViewController+TSS.h
//  TSSActionDemo
//
//  Created by yijin on 12/16/15.
//  Copyright (c) 2015 yijin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIResponder+TSS.h"
@interface UIViewController (TSS)
-(void) forwardWithStoryboardName:(NSString *) storyboard andPageName:(NSString *) pageName isShowBackButton:(BOOL) hiddenBack;
-(BOOL) doValidation;
@end
