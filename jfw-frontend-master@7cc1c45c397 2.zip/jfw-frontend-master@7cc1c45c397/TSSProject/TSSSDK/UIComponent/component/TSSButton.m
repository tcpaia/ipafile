//
//  TSSButton.m
//  TSSActionDemo
//
//  Created by yijin on 12/16/15.
//  Copyright (c) 2015 yijin. All rights reserved.
//

#import "TSSButton.h"
#import "UIResponder+TSS.h"
@implementation TSSButton
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
        [self callAcation:self.onClick andUserInfo:nil sender:self];
}
//- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event;
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
//    [self callAcation:self.onClick andUserInfo:nil sender:self];
}
@end
