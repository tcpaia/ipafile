//
//  UIResponder+TSS.m
//  TSSActionDemo
//
//  Created by yijin on 12/16/15.
//  Copyright (c) 2015 yijin. All rights reserved.
//

#import "UIResponder+TSS.h"
@implementation UIResponder (TSS)

-(void) callAcation:(NSString *)action andUserInfo:(NSDictionary *)info sender:(id) sender{
    if ([self isNotEmptyFunc:action]) {
        [[self nextResponder] callAcation:action andUserInfo:info sender:sender];
    }
}

-(BOOL) isNotEmptyFunc:(NSString *) func{
    NSString *temp = [func stringByReplacingOccurrencesOfString:@" " withString:@""];
    if (temp == nil || [temp.lowercaseString isEqualToString:@"null"] || temp.length==0) {
        return NO;
    }
    return YES;
}
@end
