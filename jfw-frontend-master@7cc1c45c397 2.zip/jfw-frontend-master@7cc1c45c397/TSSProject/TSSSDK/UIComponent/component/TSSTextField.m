//
//  TSSTextField.m
//  TSSActionDemo
//
//  Created by yijin on 12/16/15.
//  Copyright (c) 2015 yijin. All rights reserved.
//

#import "TSSTextField.h"
#import "UIResponder+TSS.h"
@implementation TSSTextField
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    if (self.delegate == nil) {
        self.delegate = self;
    }
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    return YES;
}
- (void)textFieldDidBeginEditing:(UITextField *)textField{
}
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField{
    return YES;
}
- (void)textFieldDidEndEditing:(UITextField *)textField{
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [dic setObject:textField.text forKey:@"text"];
    [self callAcation:self.didEndEditing andUserInfo:dic sender:textField];
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    return YES;
}
- (BOOL)textFieldShouldClear:(UITextField *)textField{
    return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    return YES;
}
@end
