//
//  UIViewController+TSS.m
//  TSSActionDemo
//
//  Created by yijin on 12/16/15.
//  Copyright (c) 2015 yijin. All rights reserved.
//

#import "UIViewController+TSS.h"
#import "UIResponder+TSS.h"
#import "TSSFileLog.h"

#ifdef PAGE
#import "TSSPageContainer.h"
#endif

@implementation UIViewController (TSS)

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
-(void) callAcation:(NSString *)action andUserInfo:(NSDictionary *)info sender:(id) sender
{
    @try {
        [self performSelector:NSSelectorFromString(action) withObject:info];
    }
    @catch (NSException *exception) {
        [[TSSFileLog getInstance] logException:exception];
    }
}
#pragma clang diagnostic pop

-(void) forwardWithStoryboardName:(NSString *) storyboard andPageName:(NSString *) pageName isShowBackButton:(BOOL) hiddenBack{
    if ([self isKindOfClass:[UIViewController class]]) {
        if (![self doValidation]) {
            return;
        }
        UIStoryboard *secondStoryboard = [UIStoryboard storyboardWithName:storyboard bundle:nil];
        UIViewController *homepage = [secondStoryboard instantiateViewControllerWithIdentifier:pageName];
        homepage.navigationItem.hidesBackButton = hiddenBack;
        DLog(@"=======>%@",self.navigationController);
        [self.view addSubview:homepage.view];

    }else{
        
    }
}
-(BOOL) doValidation{

    return YES;
}
@end
