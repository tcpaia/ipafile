//
//  TSSPageInfo.m
//  TSSActionDemo
//
//  Created by yijin on 12/17/15.
//  Copyright © 2015 yijin. All rights reserved.
//

#import "TSSPageInfo.h"
#define key1 @"storyboard"
#define key2 @"pageName"
#define key3 @"bussinessID"
#define key4 @"hiddenBack"

@implementation TSSPageInfo
-(id) initWithInfo:(NSMutableDictionary *) vDic{
    self = [super init];
    if (self) {
        dic = vDic;
    }
    return self;
}
-(NSString *) storyboard
{
    return [dic objectForKey:key1];
}

-(NSString *) pageName
{
    return [dic objectForKey:key2];
}

-(NSString *) bussinessID
{
    return [dic objectForKey:key3];
}
-(BOOL) hiddenBack
{
    return [dic objectForKey:key4];
}
@end
