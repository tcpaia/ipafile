//
//  UIResponder+TSS.h
//  TSSActionDemo
//
//  Created by yijin on 12/16/15.
//  Copyright (c) 2015 yijin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIResponder (TSS)
-(void) callAcation:(NSString *)action andUserInfo:(NSDictionary *)info sender:(id) sender;
-(BOOL) isNotEmptyFunc:(NSString *) func;
@end
