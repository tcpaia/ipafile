//
//  TSSButton.h
//  TSSActionDemo
//
//  Created by yijin on 12/16/15.
//  Copyright (c) 2015 yijin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TSSButton : UIButton
@property (nonatomic,strong) IBInspectable NSString* onClick;
@end
