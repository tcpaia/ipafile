//
//  TSSPageInfo.h
//  TSSActionDemo
//
//  Created by yijin on 12/17/15.
//  Copyright © 2015 yijin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TSSPageInfo : NSObject{
    @private
    NSMutableDictionary *dic;
}
@property (nonatomic,readonly) NSString *storyboard;
@property (nonatomic,readonly) NSString *pageName;
@property (nonatomic,readonly) NSString *bussinessID;
@property (nonatomic,readonly) BOOL hiddenBack;


-(id) initWithInfo:(NSMutableDictionary *) vDic;
@end
