//
//  TSSTextField.h
//  TSSActionDemo
//
//  Created by yijin on 12/16/15.
//  Copyright (c) 2015 yijin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TSSTextField : UITextField <UITextFieldDelegate>
@property (nonatomic,strong) IBInspectable NSString* didEndEditing;
@property (nonatomic,strong) IBInspectable NSString* comName;
@end
