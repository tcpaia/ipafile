//
//  TSSFactoryComponent.h
//  TSSProject
//
//  Created by TSS on 15/12/15.
//  Copyright © 2015年 AIA. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MBProgressHUD.h"

enum SIAlertViewType {
    SIErrorType,         //error
    SIInfomationType,    //information
    SIOptionsType,       //Options
    SINoTitleType        //No title
};

//typedef void (^MYBlock)(NSData *imgData);
@interface TSSFactoryComponent : NSObject<MBProgressHUDDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIActionSheetDelegate>

@property (nonatomic , retain) MBProgressHUD *progressHUD;
@property (nonatomic, copy) void (^MYBlock)(NSData *imgData);

+ (TSSFactoryComponent *) getInstance;

- (UIBarButtonItem *) createUIBarButtonItemWithTitle:(NSString *)title style:(UIBarButtonItemStyle)style target:(id)target action:(SEL)action color:(UIColor*)color;

- (void) showProgressWithLoading;

- (void) showProgressWithLabel:(NSString *)label detail:(NSString *)detail;

- (void) hideProgressMessage:(BOOL)animated;

- (void)showDialog:(UIViewController *)rootView popView:(UIViewController *)popView;

-(void)showDialog:(UIViewController *)rootVc andMessage:(NSString *)message;

- (void)showDialog:(UIViewController *)rootVc andMessage:(NSString *)message andCamera:(NSString *)cameraMessage andPhoto:(NSString *)photoMessage;
@end
