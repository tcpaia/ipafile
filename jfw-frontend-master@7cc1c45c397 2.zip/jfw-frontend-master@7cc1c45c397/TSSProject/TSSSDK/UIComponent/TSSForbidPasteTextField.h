//
//  TSSForbidPasteTextField.h
//  demo
//
//  Created by Lei on 31/05/2017.
//  Copyright © 2017 yulei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TSSForbidPasteTextField : UITextField

@end
