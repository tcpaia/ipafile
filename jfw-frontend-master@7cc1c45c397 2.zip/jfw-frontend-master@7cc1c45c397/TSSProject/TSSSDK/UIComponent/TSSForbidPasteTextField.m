//
//  TSSForbidPasteTextField.m
//  demo
//
//  Created by Lei on 31/05/2017.
//  Copyright © 2017 yulei. All rights reserved.
//

#import "TSSForbidPasteTextField.h"

@implementation TSSForbidPasteTextField

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code
 }
 */

-(BOOL)canPerformAction:(SEL)action withSender:(id)sender{
    
    if(action ==@selector(paste:))//Forbid Paste
        
        return NO;
    
    if(action ==@selector(select:))// Forbid select
        
        return NO;
    
    if(action ==@selector(selectAll:))// Forbid full select
        
        return NO;
    
    return[super canPerformAction:action withSender:sender];
    
}

@end
