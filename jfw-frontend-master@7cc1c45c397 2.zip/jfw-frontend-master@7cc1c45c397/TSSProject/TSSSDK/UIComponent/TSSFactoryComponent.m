//
//  TSSFactoryComponent.m
//  TSSProject
//
//  Created by TSS on 15/12/15.
//  Copyright © 2015年 AIA. All rights reserved.
//

#import "TSSFactoryComponent.h"
#import "Singleton.h"
#import "SystemTss.h"
#import "TSSValidationUtil.h"

#define UIBARBUTTONITEM_TEXT_ATTRIBUTES     [NSDictionary dictionaryWithObjectsAndKeys:UI_COLOR_BLACK, NSForegroundColorAttributeName, [UIFont fontWithName:DEFAULT_FONT size:INPUT_FONT_SIZE], NSFontAttributeName, nil]

@implementation TSSFactoryComponent

SYNTHESIZE_SINGLETON_FOR_CLASS(TSSFactoryComponent)

- (UIBarButtonItem *) createUIBarButtonItemWithTitle:(NSString *)title style:(UIBarButtonItemStyle)style target:(id)target action:(SEL)action color:(UIColor*)color
{
    UIBarButtonItem *buttonItem = [[UIBarButtonItem alloc] initWithTitle:title style:style target:target action:action];
    [buttonItem setTintColor:color];
    [buttonItem setTitleTextAttributes:UIBARBUTTONITEM_TEXT_ATTRIBUTES forState:UIControlStateNormal];
    return buttonItem;
}

- (void) showProgressWithLoading
{
//    NSString *text = [[[NSUserDefaults standardUserDefaults] objectForKey:@"dic"] objectForKey:@"Loading"];
    [self showProgressWithLabel:TRANSLATE(@"Loading") detail:nil];
}

- (void) showProgressWithLabel:(NSString *)label detail:(NSString *)detail
{
//    /*******update - ios9 - begin*******/
//    if (SYSTEM_VERSION_LESS_THAN(@"8.0")){
//        UIWindow *window = [[[UIApplication sharedApplication] windows] objectAtIndex:0];
//        self.progressHUD = [[MBProgressHUD alloc] initWithWindow:window];
//        [window addSubview:self.progressHUD];
//    }else{
//        if (self.progressHUD.superview !=nil) return;
//        UIView *view = [[UIApplication sharedApplication].windows lastObject];
//        self.progressHUD = [MBProgressHUD showHUDAddedTo:view animated:YES];
//    }
//    /*******update - ios9 - end*******/
    UIWindow *window = [[[UIApplication sharedApplication] windows] objectAtIndex:0];
    self.progressHUD = [[MBProgressHUD alloc] initWithWindow:window];
    [window addSubview:self.progressHUD];
    
    self.progressHUD.mode = MBProgressHUDModeIndeterminate;
    self.progressHUD.delegate = self;
    self.progressHUD.labelText = label;
    self.progressHUD.detailsLabelText = detail;
    [self.progressHUD show:NO];
}

- (void) hideProgressMessage:(BOOL)animated
{
    if (self.progressHUD==nil) {
        return;
    }
    if (self.progressHUD.superview ==nil) return;
    //    NSLog(@"hideProgressMessage %@", self.progressHUD.superview);
    [self.progressHUD hide:animated];
}

-(void)showDialog:(UIViewController *)rootVc andMessage:(NSString *)message
{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Information" message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) { }];
    [alert addAction:cancelAction];
    [rootVc presentViewController:alert animated:YES completion:nil];
}

- (void)showDialog:(UIViewController *)rootVc andMessage:(NSString *)message andCamera:(NSString *)cameraMessage andPhoto:(NSString *)photoMessage
{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil message:message preferredStyle:UIAlertControllerStyleActionSheet];
    UIAlertAction *cameraAction = [UIAlertAction actionWithTitle:cameraMessage style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action)
                             
                             {
                                 if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera]) {
                                     UIImagePickerController *ipc = [[UIImagePickerController alloc]init];
                                     ipc.delegate = self;
                                     ipc.allowsEditing = YES;
                                     [ipc setSourceType:UIImagePickerControllerSourceTypeCamera];
                                     [rootVc presentViewController:ipc animated:YES completion:nil];
                                 }
                                 
                             }];
    UIAlertAction *photoAction = [UIAlertAction actionWithTitle:photoMessage style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action)
                            {
                                
                                UIImagePickerController *ipc = [[UIImagePickerController alloc]init];
                                ipc.delegate = self;
                                ipc.allowsEditing = YES;
                                [ipc setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
                                [rootVc presentViewController:ipc animated:YES completion:nil];
                                
                            }];
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
        
    }];
    [alert addAction:cameraAction];
    [alert addAction:photoAction];
    [alert addAction:cancel];
    [rootVc presentViewController:alert animated:YES completion:nil];
}

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *image = [info objectForKey:UIImagePickerControllerEditedImage];
    UIImage *newImage = [self imageWithImage:image scaledToSize:CGSizeMake(300, 300)];
    NSString *imgStr = [[info objectForKey:UIImagePickerControllerReferenceURL]description];
    NSData *imgData;
    if ([[imgStr uppercaseString] hasSuffix:@"JPG"])
    {
        imgData = UIImageJPEGRepresentation(newImage, 1);
    }
    else
    {
        imgData = UIImagePNGRepresentation(newImage);
    }
    self.MYBlock(imgData);

    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (UIImage *)imageWithImage:(UIImage*)image
               scaledToSize:(CGSize)newSize;
{
    UIGraphicsBeginImageContext(newSize);
    [image drawInRect:CGRectMake(0,0,newSize.width,newSize.height)];
    UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
    
}

- (void)showDialog:(UIViewController *)rootView popView:(UIViewController *)popView
{
    UINavigationController *dialog = [[UINavigationController alloc] initWithRootViewController:popView];
    dialog.modalPresentationStyle = UIModalPresentationFullScreen;
    [rootView presentViewController:dialog animated:YES completion:nil];
}




@end
