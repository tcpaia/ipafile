//
//  TSSMenuController.m
//  TSSProject
//
//  Created by TSS on 16/1/14.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import "TSSMenuController.h"

#import "SystemTss.h"
#import "TSSFactoryComponent.h"
#import "TSSAppData.h"
#import "TSSValidationUtil.h"
#import "TSSAppSetting.h"

#import "MenuBaseTableViewCell.h"
#import "MenuHeadTableViewCell.h"
#import "MultiLanguageControl.h"

#import "AgentProfileDao.h"
#import "AgentProfileBean.h"

#import "CustomerViewController.h"
#import "FollowUpAndNoteViewController.h"
#import "NotificationViewController.h"
#import "JFWViewController.h"
#import "SetUpViewController.h"
#import "SetUpNominateViewController.h"
#import "SettingsViewController.h"
#import "TrackerViewController.h"

//#import "NetworkingManager.h"
//#import "TrackerUIHelper.h"
//#import "TrackerRequestModel.h"
//#import "CustomerInfoDao.h"

static NSString * const kICSColorsViewControllerCellReuseId = @"kICSColorsViewControllerCellReuseId";

@interface TSSMenuController ()

@property(nonatomic, strong) NSMutableArray *titleArr;
@property(nonatomic, strong) NSMutableArray *defaultImgArr;
@property (nonatomic, strong) NSMutableArray *viewCs;
@end

@implementation TSSMenuController

- (id)init
{
    self = [super initWithStyle:UITableViewStyleGrouped];
    if (self) {
        
    }
    return self;
}

#pragma mark - Managing the view

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self createTableView];
    [self createDataSource];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshAgentPhoto) name:kNotificationChangeAgentPhotoBySettings object:nil];
}

-(void)createTableView
{
    AgentProfileBean *tAgent = [[AgentProfileDao getInstance] getBeanWithCode:[TSSAppData getInstance].agentCode];
    _iAgentLevelCode = tAgent.agentlevelcode;
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:kICSColorsViewControllerCellReuseId];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.backgroundColor = UI_COLOR_MENU_SUB_BACKCOLOR;
    [self.tableView registerNib:UFNib(@"MenuBaseTableViewCell") forCellReuseIdentifier:kMenuBaseCellReuseId];
    MenuHeadTableViewCell *headCell = [[[NSBundle mainBundle] loadNibNamed:@"MenuHeadTableViewCell" owner:self options:nil] lastObject];
    headCell.frame = CGRectMake(0, 0, SCREEN_WEIGHT, [MenuHeadTableViewCell defaultHeight]);
    headCell.VC = self;
    headCell.delegate = self;
    [self.tableView setTableHeaderView:headCell];
    
    if ([TSSValidationUtil isNilOrEmptyString:tAgent.agentname]) {
        headCell.nameLabel.text = @"WELCOME!";
    } else {
        headCell.nameLabel.text = tAgent.agentname;
    }
    if ([TSSValidationUtil isNilOrEmptyString:tAgent.agentphoto]) {
        headCell.headImgView.image = [UIImage imageNamed:@"Agent"];
    } else {
        NSData *imgData = [[NSData alloc]initWithBase64EncodedString:tAgent.agentphoto options:NSDataBase64Encoding64CharacterLineLength];
        headCell.headImgView.image = [UIImage imageWithData:imgData];
    }
}

-(void)createDataSource
{
    self.titleArr = [NSMutableArray array];
    self.defaultImgArr = [NSMutableArray array];
    self.viewCs = [NSMutableArray array];
    
    FollowUpAndNoteViewController *followUpVc = [[FollowUpAndNoteViewController alloc]initWithNibName:@"BaseViewController" bundle:nil];
    JFWViewController *jfwVC = [[JFWViewController alloc]initWithNibName:@"BaseViewController" bundle:nil];;
    CustomerViewController *customerVc = [[CustomerViewController alloc]initWithNibName:@"BaseViewController" bundle:nil];
    TrackerViewController *trackerVc = [[TrackerViewController alloc]initWithNibName:@"BaseViewController" bundle:nil];
    SetUpViewController *setupVc = [[SetUpViewController alloc]initWithNibName:@"BaseViewController" bundle:nil];
    SetUpNominateViewController *setupNominateVc = [[SetUpNominateViewController alloc]initWithNibName:@"BaseViewController" bundle:nil];
    SettingsViewController *settingsVc = [[SettingsViewController alloc]initWithNibName:@"BaseViewController" bundle:nil];
    UIAlertController *alertview=[UIAlertController alertControllerWithTitle:@"Message" message:@"Do you wish to logout?" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancel=[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
    }];
    UIAlertAction *defult = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        exit(0);
    }];
    [alertview addAction:cancel];
    [alertview addAction:defult];
    
    
    
    if ([[TSSAppSetting getInstance].follow_up_sw isEqualToString:@"1"])
    {
        [self.titleArr addObject:MuliteLocalizedString(@"M_Appointment")];
        [self.defaultImgArr addObject:@"Appointment"];
        followUpVc.titleTXT = MuliteLocalizedString(@"M_Appointment");
        [self.viewCs addObject:followUpVc];
    }
    
    if ([[TSSAppSetting getInstance].jfw_sw isEqualToString:@"1"])
    {
        [self.titleArr addObject:MuliteLocalizedString(@"M_Joint_Field_Work")];
        [self.defaultImgArr addObject:@"JOINT FIELD WORK"];
        jfwVC.titleTXT = MuliteLocalizedString(@"M_Joint_Field_Work");
        [self.viewCs addObject:jfwVC];
    }
    if ([[TSSAppSetting getInstance].customer_sw isEqualToString:@"1"])
    {
        [self.titleArr addObject:MuliteLocalizedString(@"M_Contact")];
        [self.defaultImgArr addObject:@"contact"];
        customerVc.titleTXT = MuliteLocalizedString(@"M_Contact");
        [self.viewCs addObject:customerVc];
    }
    if ([[TSSAppSetting getInstance].setting_sw isEqualToString:@"1"])
    {
        [self.titleArr addObject:MuliteLocalizedString(@"M_Setup")];
        [self.defaultImgArr addObject:@"Setup"];
        setupVc.titleTXT = MuliteLocalizedString(@"M_Setup");
        [self.viewCs addObject:setupVc];
    }
    
    if ([[TSSAppSetting getInstance].nomination_sw isEqualToString:@"1"])
    {
        [self.titleArr addObject:MuliteLocalizedString(@"M_Nomination")];
        [self.defaultImgArr addObject:@"nomination_menu"];
        setupNominateVc.titleTXT = MuliteLocalizedString(@"M_Nomination");
        [self.viewCs addObject: setupNominateVc];
    }
    
    if ([[TSSAppSetting getInstance].traker_sw isEqualToString:@"1"])
    {
        [self.titleArr addObject:MuliteLocalizedString(@"M_Tracker")];
        [self.defaultImgArr addObject:@"notes_menu"];
        trackerVc.titleTXT = MuliteLocalizedString(@"M_Tracker");
        [self.viewCs addObject: trackerVc];
    }
    
    if ([[TSSAppSetting getInstance].settings_sw isEqualToString:@"1"])
    {
        [self.titleArr addObject:MuliteLocalizedString(@"M_Settings")];
        [self.defaultImgArr addObject:@"Setup"];
        settingsVc.titleTXT = MuliteLocalizedString(@"M_Settings");
        [self.viewCs addObject: settingsVc];
    }
    
    if ([[TSSAppSetting getInstance].logout isEqualToString:@"1"])
    {
        [self.titleArr addObject:MuliteLocalizedString(@"M_Logout")];
        [self.defaultImgArr addObject:@"logout"];
        [self.viewCs addObject:alertview];
    }
    
    [self.tableView reloadData];
}

#pragma mark - Configuring the view’s layout behavior

- (UIStatusBarStyle)preferredStatusBarStyle
{
    // Even if this view controller hides the status bar, implementing this method is still needed to match the center view controller's
    // status bar style to avoid a flicker when the drawer is dragged and then left to open.
    return UIStatusBarStyleLightContent;
}

- (BOOL)prefersStatusBarHidden
{
    return YES;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return [MenuBaseTableViewCell defaultHeight];
}
#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.titleArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MenuBaseTableViewCell *cell = (MenuBaseTableViewCell *)[tableView dequeueReusableCellWithIdentifier:kMenuBaseCellReuseId];
    cell.tTitle.text = [self.titleArr objectAtIndex:indexPath.row];
    cell.vImage.image = [UIImage imageNamed:[self.defaultImgArr objectAtIndex:indexPath.row]];
    return cell;
}

#pragma mark - Table view delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([self.viewCs[indexPath.row] isKindOfClass:[BaseViewController class] ])
    {
        BaseViewController *viewC = self.viewCs[indexPath.row];
        /*
        if ([viewC isKindOfClass:[TrackerViewController class]]) {
            //如果是tracker，请求服务器
            [self clickMenuForTracker: viewC];
            return;
        }
         */
        //viewC.isUploadViewC = YES;
       [self.drawer replaceCenterViewControllerWithViewController:viewC];
    }
    else
    {
        UIAlertController *alertview = self.viewCs[indexPath.row];
        [self presentViewController:alertview animated:YES completion:nil];
    }
}

#pragma mark - ICSDrawerControllerPresenting

- (void)drawerControllerWillOpen:(ICSDrawerController *)drawerController
{
    self.view.userInteractionEnabled = NO;
    [self.tableView reloadData];
}

- (void)drawerControllerDidOpen:(ICSDrawerController *)drawerController
{
    self.view.userInteractionEnabled = YES;
}

- (void)drawerControllerWillClose:(ICSDrawerController *)drawerController
{
    self.view.userInteractionEnabled = NO;
}

- (void)drawerControllerDidClose:(ICSDrawerController *)drawerController
{
    self.view.userInteractionEnabled = YES;
}

- (void) refreshAgentPhoto
{
    MenuHeadTableViewCell *headCell = (MenuHeadTableViewCell *) self.tableView.tableHeaderView;
    AgentProfileBean *tAgent = [[AgentProfileDao getInstance] getBeanWithCode:[TSSAppData getInstance].agentCode];
    if ([TSSValidationUtil isNilOrEmptyString:tAgent.agentphoto]) {
        headCell.headImgView.image = [UIImage imageNamed:@"Agent"];
    } else {
        NSData *imgData = [[NSData alloc]initWithBase64EncodedString:tAgent.agentphoto options:NSDataBase64Encoding64CharacterLineLength];
        headCell.headImgView.image = [UIImage imageWithData:imgData];
    }
}

/*
#pragma mark - clickTracker
- (BOOL) checkBeforeSearchTracker
{
    //如果customer一条都不存在，则提示先下载customer
    NSString *agentJfwRole = [TSSAppData getInstance].agentJfwRole;
    if ([agentJfwRole isEqualToString: Leader]) {
        NSUInteger allCustomerCount = [[CustomerInfoDao getInstance] selectAllCountForBeansOrderByDESC];
        if (allCustomerCount < 1) {
            [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"TrackerSearchDownLoadCustomerFirst")];
            return NO;
        }
        NSUInteger fscCustomerCount = [[CustomerInfoDao getInstance] selectCountForBeansNoWithRoleType: [TSSAppData getInstance].agentJfwRole];
        if (fscCustomerCount < 1) {
            [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"TrackerSearchNoFSC")];
            return NO;
        }
    } else {
        NSUInteger agentProfileCount = [[AgentProfileDao getInstance] selectCountForBeanWithCode: [TSSAppData getInstance].agentCode];
        if (agentProfileCount < 1) {
            [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"TrackerSearchDownLoadAgentProfileFirst")];
            return NO;
        }
    }
    return YES;
}

- (void)clickMenuForTracker: (BaseViewController *) viewC
{
    if ([self checkBeforeSearchTracker] == NO) {
        return;
    }
    
    [[TSSFactoryComponent getInstance] showProgressWithLoading];
    [[NetworkingManager getInstance] checkServerConnecting:^(id response) {
        if ([response isKindOfClass:[NSError class]]) {
            [[TSSFactoryComponent getInstance] hideProgressMessage:YES];
            [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"J_CheckInternet")];
            return;
        } else {
            //组装参数，网络请求,如果正确，跳转到界面，如果不正确，出现提示信息
            TrackerRequestModel *requestModel = [[TrackerUIHelper getInstance] buildRequestModel];
            [[NetworkingManager getInstance] downLoadTrackerSummaryByRequestModel:requestModel andCallBack:^(id obj) {
                [[TSSFactoryComponent getInstance] hideProgressMessage:YES];
                NSString *resultMessage = (NSString *)obj;
                if ([resultMessage isEqualToString:UPLOAD_STATUS_OK]) {
                    [self.drawer replaceCenterViewControllerWithViewController:viewC];
                } else if ([resultMessage isEqualToString:UPLOAD_STATUS_FAILED]) {
                    [[TSSFactoryComponent getInstance] showDialog:self andMessage:MuliteLocalizedString(@"TrackerSearch_Fail")];
                } else {
                    [[TSSFactoryComponent getInstance] showDialog:self andMessage:resultMessage];
                }
            }];
        }
    }];
}
 */

@end
