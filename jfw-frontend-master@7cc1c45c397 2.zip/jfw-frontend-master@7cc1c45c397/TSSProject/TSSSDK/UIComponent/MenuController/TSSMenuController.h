//
//  TSSMenuController.h
//  TSSProject
//
//  Created by TSS on 16/1/14.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ICSDrawerController.h"
#import "UIViewController+TSS.h"

typedef NS_ENUM(NSUInteger, TSSPaneViewControllerType) {
    TSSPaneViewControllerTypeNewsfeed,
    TSSPaneViewControllerTypeDashboard,
    TSSPaneViewControllerTypeNotification,
    TSSPaneViewControllerTypeCustomer,
    TSSPaneViewControllerTypeQuickQuote,
    TSSPaneViewControllerTypeLeads,
    TSSPaneViewControllerTypeFollow,
    TSSPaneViewControllerTypeAppointment,
    TSSPaneViewControllerTypeMapCustomer,
    TSSPaneViewControllerTypeGoogleMapCustomer,
    TSSPaneViewControllerTypeSetUp,
    TSSPaneViewControllerTypeCount
};

@interface TSSMenuController : UITableViewController<ICSDrawerControllerChild, ICSDrawerControllerPresenting>

@property(nonatomic, weak) ICSDrawerController *drawer;
@property (nonatomic, assign) int paneViewControllerType;
@property(nonatomic,retain)NSString *iAgentLevelCode;


@end
