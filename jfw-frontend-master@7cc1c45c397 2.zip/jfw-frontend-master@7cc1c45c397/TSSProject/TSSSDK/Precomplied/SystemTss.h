//
//  SystemTss.h
//  Wrapper
//
//  Created by TSS on 15/12/22.
//  Copyright © 2015年 EL-Apple. All rights reserved.
//

#ifndef SystemImo_h
#define SystemImo_h


#define SHAREDINSTANCE_DECLARATION(classname) \
\
+ (classname *)sharedInstance; \
\

#define SHAREDINSTANCE_IMPLEMENTATION(classname) \
\
+ (classname *)sharedInstance \
{\
static classname *sharedInstance;\
static dispatch_once_t once;\
dispatch_once(&once, ^{\
sharedInstance = [[classname alloc] init];\
});\
return sharedInstance;\
}\
\



#define FORMAT(format, ...) [NSString stringWithFormat:(format), ##__VA_ARGS__]

#define SYSTEM_VERSION_LESS_THAN(v)                 ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)

#define IOS_VERSION_8_OR_LATER IOS_VERSION_OR_LATER(8.0)

#define SCREEN_HEIGHT [[UIScreen mainScreen] bounds].size.height
#define SCREEN_WEIGHT [[UIScreen mainScreen] bounds].size.width

#define AutoSizeScaleY  SCREEN_HEIGHT/480
#define AutoSizeScaleX SCREEN_WEIGHT/320

#define TopViewHigh (20+44)

#define Localizable @"Localizable"

//Multiple languages
#define TRANSLATE(key_) [[[NSUserDefaults standardUserDefaults] objectForKey:@"dic"] objectForKey:key_]
#define UFStoryboard(name) [UIStoryboard storyboardWithName:name bundle:nil]

#define UFNib(name) [UINib nibWithNibName:name bundle:nil]

//table names
#define	TEST_BEAN_TABLE				@"TestTable"


#define AppLanguage @"appLanguage"
#define CustomLocalizedString(key, comment) \
[[NSBundle bundleWithPath:[[NSBundle mainBundle] pathForResource:[NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults] objectForKey:@"appLanguage"]] ofType:@"lproj"]] localizedStringForKey:(key) value:@"" table:nil]

#define MuliteLocalizedString(key) [[MultiLanguageControl bundle] localizedStringForKey:(key) value:nil table:Localizable]


// ---------FOR COLOR --------
#define UIColorMakeRGBA(nRed, nGreen, nBlue, nAlpha) [UIColor colorWithRed:(nRed)/255.0f green:(nGreen)/255.0f blue:(nBlue)/255.0f alpha:nAlpha]

#define UI_COLOR_WHITE [UIColor whiteColor]
#define UI_COLOR_BLACK [UIColor blackColor]

#define UI_COLOR_SMART_YELLOW UIColorMakeRGBA(250, 249, 243, 1)
#define UI_COLOR_SMART_LIGHT_GRAY UIColorMakeRGBA(232,230,231,1)
#define UI_COLOR_SMART_CELL_RED UIColorMakeRGBA(173, 5, 75, 1)
#define UI_COLOR_SMART_BLUE UIColorMakeRGBA(57, 190, 238, 1)
#define UI_COLOR_SMART_TEXTFONT_COLOR UIColorMakeRGBA(111, 110, 104, 1)
#define UI_COLOR_SMART_BG_COLOR UIColorMakeRGBA(250, 249, 243, 1)

//MENU COLOR
#define UI_COLOR_MENU_HEADER_BACKCOLOR UIColorMakeRGBA(41, 40, 37, 1)
#define UI_COLOR_MENU_SUB_BACKCOLOR UIColorMakeRGBA(48,47,44,1)
#define UI_COLOR_MENU_HEADERTITLE_COLOR UIColorMakeRGBA(216, 216, 216, 1)
#define UI_COLOR_MENU_SUBTITLE_COLOR UIColorMakeRGBA(187, 187, 187, 1)

//LOGIN COLOR
#define UI_COLOR_SMART_RED UIColorMakeRGBA(211, 17, 69, 1)//#D31145 100%
#define UI_COLOR_LANGUAGE_BLUE UIColorMakeRGBA(34,168,218,1)//#22A8DA 100%
#define UI_COLOR_SMART_Segment_Selected_Color UIColorMakeRGBA(89, 108, 128, 1)//#596C80 100%
#define UI_COLOR_SMART_TOUCH_ID UIColorMakeRGBA(205, 211, 217, 1)//CDD3D9
#define UI_COLOR_VERSION_TITLE_COLOR UIColorMakeRGBA(199, 199, 205, 1)
//HOME COLOR
#define UI_COLOR_HOME_HEADER_HELLO UIColorMakeRGBA(54, 62, 63, 1)//#363E3F 100%
#define UI_COLOR_HOME_HEADER_COLOR UIColorMakeRGBA(85, 67, 68, 1)//#554344 100%
//Contact
//-------- FOR  NavController Title  FONT -----------
#define NavTitleFont [UIFont fontWithName:@"Avenir-Black" size:16]

//JFW COLOR
#define UI_COLOR_JFW_HEAER_YELLOW UIColorMakeRGBA(250, 249, 243, 1)//#FAF9F3 100%
#define UI_COLOR_JFW_INDEXBUTTON_SELECT_BLUE UIColorMakeRGBA(34, 168, 218, 1)//#22A8DA 100%
#define UI_COLOR_JFW_INDEXBUTTON_BORDER_COLOR UIColorMakeRGBA(219, 218, 212, 1) //#DBDAD4 100%
#define UI_COLOR_JFW_NAME_TITLE UIColorMakeRGBA(85, 67, 68, 1)
#define UI_COLOR_JFW_CALENDAR_TITLE UIColorMakeRGBA(89, 108, 128, 1)
#define kCalendarBasicColor UIColorMakeRGBA(211, 17, 69, 1)

//Appointment Color
#define BOTTOM_LINE_COLOR UIColorMakeRGBA(219, 218, 212, 1)
//-------- FOR  DashBoardController MyAgent  FONT -----------
#define DashBoardMyAgentFont [UIFont fontWithName:@"Menlo-Bold" size:17]

#define AIAFont_14 [UIFont fontWithName:@"AIAEverestBeta-CondensedMedium" size:14]
#define AIAFont_15 [UIFont fontWithName:@"AIAEverestBeta-CondensedMedium" size:15]
#define AIABold_14 [UIFont fontWithName:@"Helvetica-Bold" size:14]

#define Smart_Arail_16 [UIFont fontWithName:@"Arail" size:16]
#define Smart_Black [UIColor blackColor]
#define Smart_AIASans_14 [UIFont fontWithName:@"AIA Sans Condensed 07" size:14]

//------- FOR Default FONT ----------

#define DefaultFont  @"Helvetica Neue"

#define DEFAULT_FONT @"DIN Regular"
#define DEFAULT_BOLD_FONT @"din-bold"
#define DEFAULT_BLACK_FONT @"DIN Medium"
#define DEFAULT_ITALIC_FONT         @"DIN-RegularItalicAlt"
#define DEFAULT_BOLD_ITALIC_FONT    @"DIN-BoldItalicAlt"
#define DEFAULT_LIGHT_FONT          @"DINPro-Light"
#define DEFAULT_FONT_SIZE 19
#define TITLE_FONT_SIZE 44
#define INPUT_FONT_SIZE             16
#define SELECTION_FONT_SIZE         12
#define TAB_TITLE_FONT_SIZE         14


#define AIA_Everest_Normal @"AIA Everest"
#define AIASans_Condensed_Header @"AIASansCondensed07-Medium"

#define DEFAULT_UIFONT [UIFont fontWithName:DEFAULT_FONT size:DEFAULT_FONT_SIZE]
#define BLACK_UIFONT [UIFont fontWithName:DEFAULT_BLACK_FONT size:DEFAULT_FONT_SIZE]
#define TITLE_UIFONT [UIFont fontWithName:DEFAULT_BOLD_FONT size:TITLE_FONT_SIZE]


//------- FOR Login timebomb ----------
#define TIME_BOMB_STATUS_VALID 0
#define TIME_BOMB_STATUS_LICENSE_EXPIRED 1
#define TIME_BOMB_STATUS_DESTRUCT_DATA 2
#define TIME_BOMB_STATUS_UNLIMITED_USAGE 3

#define NOTIFICATION_CLOSE @"close_view"

#define SEPARATE_VIEW_HEIGH 50

#define DOCUMENT_PATH @"document_path"
#define RESOURCE_PATH @"resource_path"
#define APP_GROUP_PATH @"group_path"

//touch id define
#define TOUCHID_AGENT @"agentCode"
#define TOUCHID_PASS @"agentPass"
#define TOUCHID_AGENT_ENCRTION @"agentCode_ENCRTION"
#define TOUCHID_PASS_ENCRTION @"agentPass_ENCRTION"
#define TOUCHID_SWITCH @"touchid"
#define TOUCHID_UNABLE @"unable"

#define TOUCHID_LOGIN_AGENT @"agentCodeForTouchID"
#define TOUCHID_LOGIN_PASS @"agentPassForTouchID"
#define TOUCHID_LOGIN_AGENT_ENCRTION @"agentCodeForTouchID_ENCRTION"
#define TOUCHID_LOGIN_PASS_ENCRTION @"agentPassForTouchID_ENCRTION"
#define TOUCHID_LOGIN_SWITCH @"loginForTouchID"
#define TOUCHID_LOGIN_SWITCH_ON @"on"
#define TOUCHID_LOGIN_SWITCH_OFF @"off"
#define TOUCHID_LOGIN_DEVICE @"Device_TouchID"
#define TOUCHID_LOGIN_DEVICE_UNSUPPORTED @"Unsupported"
#define TOUCHID_LOGIN_DEVICE_SUPPORTED @"Supported"
//#define TOUCHID_LOGIN_UNABLE @"unable"

#define LOCAL_PASS_WORD_COUNT 8
#define LOCAL_PASS_WORD_KEY @"localPassWordFor"

//network connection time
#define SERVER_CONNECTION_TIME 600
#define UPLOAD_DOWNLOAD_TIME 600
#define UPLOAD_DOWNLOAD_MORETIME 600

#define ACTIVATION_TYPE_NEW_USER 0
#define ACTIVATION_TYPE_FORGET_PASSWORD 1

//Notification Name
#define kNotificationRefreshLeads @"NotificationRefreshLeads"


//------- For Follow UP Notifaction ---
#define kNotificationRefreshFollowUpAndNote @"NotificationRefreshFollowUpAndNote"

#define kAlertRefreshFollowUpAndNote @"AlertRefreshFollowUpAndNote"

#define kNotificationAddFollowUpAndNote @"NotificationAddFollowUpAndNote"

// ------ For AppointmentViewController loadData Notifaction ---
#define kNotificationRefreshAppointment @"NotificationRefreshAppointment"

// ------ For AppointmentViewController removeData  Notifaction ---
#define kNotificationRemoveAppointment @"NotificationRemoveAppointment"

#define kNotificationRefreshJFWFooterData @"NotifiRefreshJFWFooterData"

#define kNotificationRefreshJFWCloseData @"NotifiRefreshJFWCloseData"

#define kNotificationRefreshJFWTopData @"NotifiRefreshJFWTopData"

#define kNotificationPopUpJfwForm @"NotifiPopUpJfwForm"

#define kNotificationChangeAgentPhotoBySettings @"NotificationChangeAgentPhotoBySettings"

#define kNotificationChangeAgentPhotoByMenu @"NotificationChangeAgentPhotoByMenu"

#define kFollowUp @"Follow Up"
#define kNote @"Notes"
#define kApponment @"Appointment"
#define kRoadshow @"Roadshow"
#define kDoorKnock @"Door Knock"
#define kStreetProspecting @"Street Prospecting"
#define kOthers @"Others"

#define Leader @"leader"
#define Agent  @"agent"
#define Others @"Others"

#define Singapore @"Singapore"

//For Customer
#define Male        @"M"
#define Female      @"F"
#define Smoker      @"0"
#define NonSmoker  @"1"
#define Married     @"M"
#define Single      @"S"

//For Canlendar 
#define Five @"5 mins"
#define Ten @"10 mins"
#define Fifteen @"15 mins"
#define Thirty @"30 mins"
#define OneHour @"1 hour"
#define TwoHours @"2 hours"
#define OneDay @"1 day"
#define TwoDays @"2 days"
#define OneWeek @"1 week"


// -----Google Key --
//#define GoogleKey @"AIzaSyA3HzBAI26iuAypmWN9ylLQDD9pBZiP4Ds"
#define GoogleKey @"AIzaSyCdSIInKrBjj6Ha6R2MuYSKRB9DIyvfK60"
//AIzaSyCre9ch5hmT_hg1OnARDl6Njkh4UBPcsXI

//-- For Language --
#define ChangeLanguage @"changeLanguage"

//appointment init status
#define RESPONSE_STATUS_PENDING @"P"
//appointment remove
#define RESPONSE_STATUS_REMOVE @"R"

#define NOMINATION_STATUS_PENDING @"Pending"
#define NOMINATION_STATUS_REMOVE @"Deleted"
#define NOMINATION_STATUS_HIDE @"Hide"

#define UPLOAD_STATUS_FAILED @"0"
#define UPLOAD_STATUS_OK @"1"

//home
#define HOME_TODAY @"Today"
#define HOME_7DAYS @"7Days"
#define HOME_30DAYS @"30Days"

//appointment event type
#define JFW_APPOINTMENT_TYPE @"A"
#define JFW_ROADSHOW_TYPE @"R"
#define JFW_DOORKNOCK_TYPE @"D"
#define JFW_STREETPROSPECTING_TYPE @"S"
#define JFW_OTHERS_TYPE @"O"

#define JFW_FSCContact_TYPE @"1"
#define JFW_FSCContactNO_TYPE @"0"


#define APPOINTMENT_EVENT_TITLE @"Appointment"
#define ROADSHOW_EVENT_TITLE @"Roadshow"
#define DOORKNOCK_EVENT_TITLE @"Door Knock"
#define STREETPROSPECTING_EVENT_TITLE @"Street Prospecting"
#define OTHERS_EVENT_TITLE @"Others"
#define JFW_EVENT_TITLE @"JFW"

#define BUILD_VERSION_PRO_SGP @"PRO_SGP"
#define BUILD_VERSION_UAT_SGP @"UAT_SGP"
#define BUILD_VERSION_SIT_SGP @"SIT_SGP"
#define BUILD_VERSION_SIT_COE @"SIT_COE"
#define BUILD_VERSION_DEMO @"DEMO_GROUP"

#define LOGIN_WITHOUT_ACTIVATION    0   //此参数为1时，为免activation的方式登陆。配合TSSAppSetting的代码，表示sit免激活登陆。正式发布的uat和prod，此参数为0
#define TEST_NET_RESPONSE_TIME      0   //此参数为1时，打印日志，测试与服务器请求数据的时间。正式发布的uat和prod，此参数为0

#define NOTIFICATION_MESSAGE_TYPE_APPOINTMENT           @"appointment"
#define NOTIFICATION_MESSAGE_TYPE_JFW                   @"jfw"
#define NOTIFICATION_MESSAGE_TYPE_DOORKNOCK             @"doorknock"
#define NOTIFICATION_MESSAGE_TYPE_STREETPROSPECTING     @"streetprospecting"
#define NOTIFICATION_MESSAGE_TYPE_OTHERS                @"others"

//download jfw have image or text
#define DOWNLOAD_TEXT @"text"
#define DOWNLOAD_IMAGE @"image"

#define IMO_SMART_YES @"1"
#define IMO_SMART_NO @"0"

#define IMO_SMART_YES_STR   @"YES"
#define IMO_SMART_NO_STR    @"NO"

#define CONDENSED_FLAG_FOR_DOWNLOAD_NOMINATED_PARTERS @"2"

#define NOMINATE_AGENT_TYPE_LEADER @"Leader"
#define NOMINATE_AGENT_TYPE_FSC  @"FSC"
#define TRACKER_NEW_FSC_AGENT_TYPE_AGENT    @"Agent"

#define FIRST_LOGIN_STATUS                              @"_login_status"                                //用户首次登陆的记录，例如36249_login_status，作为key值存放在userdefault里面
#define FIRST_LOGIN_STATUS_FIRST_ACTIVATION_SUCCESS     @"first_activationSuccess"                      //用户第一次activation成功
#define FIRST_LOGIN_STATUS_FIRST_LOGIN_SUCCESS          @"first_loginSuccess"                           //用户第一次登陆成功
#define FIRST_LOGIN_STATUS_SECOND_LOGIN_SUCCESS         @"second_loginSuccess"                          //用户第一次登陆成功后，再次登陆，则设置为此标示，表示已经多次登陆

//过渡代码
#define FIRST_DOWNLOAD_DELETE_FOLLOWUP                  @"_first_download_deleted_followup"             //下载已经删除的Followup
#define FIRST_DOWNLOAD_DELETE_JFW                       @"_first_download_deleted_jfw"                  //下载已经删除的JFW
#define FIRST_DOWNLOAD_CREATE_DATE_TIME_LONG_FOLLOWUP   @"_first_download_createdatetime_long_followup" //下载FollowUpAndNote的createdatetime_long
#define FIRST_DOWNLOAD_DELETE_DONE                      @"Done"                                         //已下载
#define FIRST_DOWNLOAD_DELETE_NO_NEED                   @"NoNeed"                                       //不需要下载（如果用新版代码activation的download包含删除和createdatetime_long信息，不需要执行过渡代码）

#define DOWNLOAD_DELETED_AND_CREATE_DATE_TIME_LONG_DATA 1   //为0时不保存删除数据和FollowUpAndNote的创建时间，为1时保存所有数据。正式发布的uat和prod，此参数为1
#define UPLOAD_ACCEPTED_ROAD_SHOW_FOR_VERSION1          1   //为1时，查询所有旧版的roadshow，调用接口修改服务器端数据，以达到增加接受roadshow的appointmentcomments数据，为0时无操作。最终正式发布的uat和prod，此参数为1

#define UPLOAD_ACCEPTED_ROAD_SHOW_FOR_VERSION1_REQUEST_PER_COUNT  100.0                                 //更新旧版roadshow时，避免一次请求数据量过大，每次100条

#endif /* SystemImo_h */
