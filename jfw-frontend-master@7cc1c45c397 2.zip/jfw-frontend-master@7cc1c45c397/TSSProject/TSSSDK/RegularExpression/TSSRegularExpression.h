//
//  TSSRegularExpression.h
//  TSSActionDemo
//
//  Created by yijin on 12/21/15.
//  Copyright (c) 2015 yijin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TSSRegularExpression : NSObject

+(BOOL)evaluateWithObject:(NSString *) obj andRegex:(NSString *) regex;

@end
