//
//  TSSRegularExpression.m
//  TSSActionDemo
//
//  Created by yijin on 12/21/15.
//  Copyright (c) 2015 yijin. All rights reserved.
//

#import "TSSRegularExpression.h"

@implementation TSSRegularExpression
+(BOOL)evaluateWithObject:(NSString *) obj andRegex:(NSString *) regex{
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    return [predicate evaluateWithObject:obj];
}

@end
