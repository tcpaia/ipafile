//
//  TSSRegularExpressionHandler.h
//  TSSActionDemo
//
//  Created by yijin on 12/21/15.
//  Copyright (c) 2015 yijin. All rights reserved.
//

#import "TSSRegularExpression.h"
#ifndef TSSActionDemo_TSSRegularExpressionHandler_h
#define TSSActionDemo_TSSRegularExpressionHandler_h

#define REX_EMAIL @"\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*"


#define isEmail(obj)[TSSRegularExpression evaluateWithObject:obj andRegex:REX_EMAIL]\

#endif
