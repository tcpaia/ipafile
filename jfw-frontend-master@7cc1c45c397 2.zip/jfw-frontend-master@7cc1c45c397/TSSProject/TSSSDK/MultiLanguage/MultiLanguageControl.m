//
//  TSSInternationalControl.m
//  TSSProject
//
//  Created by 于磊 on 16/4/6.
//  Copyright © 2016年 AIA. All rights reserved.
//

#import "MultiLanguageControl.h"

#define UserLanguage @"userLanguage"
#define ReType @"lproj"
#define AppleLanguages @"AppleLanguages"
#define KLANGUAGE_EN @"en"
#define KLANGUAGE_CN @"cn"

@implementation MultiLanguageControl

static NSBundle *bundle = nil;

+(NSBundle *)bundle
{
    return bundle;
}

+(void)initUserLanguage
{
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    
    NSString *language = [ud valueForKey:UserLanguage];
    
    if ([language isEqualToString:KLANGUAGE_EN]) {
        language = @"en";
    } else if ([language isEqualToString:KLANGUAGE_CN]) {
        language = @"zh-Hans";
    } else {
        language = @"en";
    }
    NSString *path = [[NSBundle mainBundle] pathForResource:language ofType:ReType];
    bundle = [NSBundle bundleWithPath:path];
}

+(NSString *)userLanguage
{
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    NSString *language = [ud valueForKey:UserLanguage];
    return language;
}

+(void)setUserLanguage:(NSString *)language
{
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    NSString *path = [[NSBundle mainBundle] pathForResource:language ofType:ReType];
    bundle = [NSBundle bundleWithPath:path];
    [ud setValue:language forKey:UserLanguage];
    [ud synchronize];
}

@end
