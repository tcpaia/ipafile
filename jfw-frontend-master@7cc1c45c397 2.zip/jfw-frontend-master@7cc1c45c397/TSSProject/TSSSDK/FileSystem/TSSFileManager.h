//
//  TSSFileManager.h
//  TSSFileSystemDemo
//
//  Created by yijin on 12/10/15.
//  Copyright (c) 2015 yijin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TSSFileManager : NSObject{
    @private
    NSString *orginarPath;
    NSString *fileName;
}
+(instancetype) defaultFileManager;
-(void) createFileWithPath:(NSString *) path andData:(NSData *) data isDirectory:(BOOL) isDirectory error:(NSError **) error;
-(BOOL) isFileExistsAtPath:(NSString *) path;
-(BOOL) removeItemAtPath:(NSString *) path error:(NSError **) error;
-(BOOL) copyItemAtPath:(NSString *) path toPath:(NSString *) toPath   error:(NSError **) error;
-(NSData *) readFileWith:(NSString *) path;

- (BOOL)fileExits:(NSString *)fileName;


+ (NSString *)applicationResourceDirectory;
+ (NSString *)applicationDocumentsDirectory;
+ (NSString *)applicationTemporaryDirectory;

+ (NSString *)createTmpFileNameWithExtension:(NSString *)ext;

+ (BOOL)deleteFile:(NSString *)filePath;
+ (NSString *)deleteFileIfExists:(NSString *)fileName;
+ (BOOL)fileExits:(NSString *)fileName;
+ (BOOL)copyFile:(NSString *)fromFile toFile:(NSString *)toFile;
+ (BOOL)createFolder:(NSString *)folder;
+ (NSDate *)getLastModifiedDate:(NSString *)path;
+ (NSDate *)getCreationDate:(NSString *)path;
+ (long long int)getFileSize:(NSString *)path;

/**
 * Read a file from start
 *filePath the file to read
 *length the length to read from start
 */
+ (NSString *)readContentOfFile:(NSString *)filePath length:(int)length encoding:(NSStringEncoding)encoding;


@end
