//
//  TSSFileManager.m
//  TSSFileSystemDemo
//
//  Created by yijin on 12/10/15.
//  Copyright (c) 2015 yijin. All rights reserved.
//

#import "TSSFileManager.h"
#import "HashValue.h"
#import "NSData+AES256.h"
#include <sys/xattr.h>
#import "SystemTss.h"
#import "NSString+Ex.h"

#define IDENTIFIER @"AIA Information Technology(Beijing) Co.,Ltd."
#define INDEX 44
#define KEYENCODE NSUTF32LittleEndianStringEncoding
#define MAIN_DOMAIN [NSString stringWithFormat:@"%@/.tss", [NSHomeDirectory() stringByAppendingPathComponent:@"Library"]]

#pragma mark -
#pragma mark TSSFileManager(private)
@interface TSSFileManager(private)
-(void) createFileWithPath:(NSString *)path andData:(NSData *)data;
-(void) createDirectory:(NSString *) path;
-(NSData *) encryptionFile:(NSData *) data andKey:(NSString *) key;
-(NSString *) tssApplicationFolder;
-(NSString *) encryptionPath:(NSString *) path;
-(NSString *) encryption:(NSString *) doc andIndex:(int) index;
@end


@implementation TSSFileManager
+(instancetype) defaultFileManager
{
    static TSSFileManager *fileManager = nil;
    static dispatch_once_t onceToken = 0;
    dispatch_once(&onceToken, ^{
        fileManager = [[TSSFileManager alloc] init]; });
    return fileManager;
}

#pragma mark -
#pragma mark Public Method
-(void) createFileWithPath:(NSString *) path andData:(NSData *) data isDirectory:(BOOL) isDirectory error:(NSError **) error{
    orginarPath = path;
    NSString *virtualPath = [NSString stringWithFormat:@"%@/%@",MAIN_DOMAIN,[self encryptionPath:path isDirectory:isDirectory]];
    if (isDirectory) {
        [self createDirectory:virtualPath error:error];
    }else{
        [self createDirectory:virtualPath error:error];
        [self createFileWithPath:[NSString stringWithFormat:@"%@%@",virtualPath,fileName] andData:[self encryptionFile:data andKey:fileName]];
    }

    DLog(@"createFileWithPath:%@",virtualPath);
}

-(BOOL) isFileExistsAtPath:(NSString *) path
{
    NSString *enPath = [NSString stringWithFormat:@"%@/%@",MAIN_DOMAIN,[self encryptionPath:path isDirectory:NO]];
    return [[NSFileManager defaultManager] fileExistsAtPath:enPath];
}




-(BOOL) removeItemAtPath:(NSString *) path error:(NSError **) error
{
    return [[NSFileManager defaultManager] removeItemAtPath:path error:error];
}

-(BOOL) copyItemAtPath:(NSString *) path toPath:(NSString *) toPath   error:(NSError **) error
{
    NSString *org_Path = [NSString stringWithFormat:@"%@/%@",MAIN_DOMAIN,[self encryptionFullPath:path]];
    NSString *to_Path = [NSString stringWithFormat:@"%@/%@",MAIN_DOMAIN,[self encryptionFullPath:toPath]];
    return [[NSFileManager defaultManager] copyItemAtPath:org_Path toPath:to_Path error:error];
}

-(NSData *) readFileWith:(NSString *) path
{
    NSString *virtualPath = [NSString stringWithFormat:@"%@/%@",MAIN_DOMAIN,[self encryptionPath:path isDirectory:NO]];
    NSString *filePath = [NSString stringWithFormat:@"%@%@",virtualPath,fileName];
    NSData *file = [NSData dataWithContentsOfFile:filePath];
    return [self decryptionFile:file andKey:fileName];;
}

#pragma mark -
#pragma mark Private Method

-(void) createFileWithPath:(NSString *)path andData:(NSData *)data{
    if (![[NSFileManager defaultManager] fileExistsAtPath:path]) {
        [[NSFileManager defaultManager]  createFileAtPath:path contents:data attributes: [NSDictionary dictionaryWithObject:NSFileProtectionComplete forKey: NSFileProtectionKey]];
    }
}

-(void) createDirectory:(NSString *) path error:(NSError **) error{
    if (![[NSFileManager defaultManager] fileExistsAtPath:path]) {
        [[NSFileManager defaultManager] createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:error];
    }
}

-(NSData *) encryptionFile:(NSData *) data andKey:(NSString *) key{
    
    NSData *hashkeyData = [self encryptionKey:key andIndex:key.length];
    
    return  [data AES256EncryptWithKeyData:hashkeyData];
}


-(NSData *) decryptionFile:(NSData *) data andKey:(NSString *) key{
    
    NSData *hashkeyData = [self encryptionKey:key andIndex:key.length];
    
    return  [data AES256DecryptWithKeyData:hashkeyData];
}


-(NSString *) tssApplicationFolder{
    [self createDirectory:MAIN_DOMAIN];
    return MAIN_DOMAIN;
}

-(NSString *) encryptionFullPath:(NSString *) path {
    NSArray *pathArray = [path componentsSeparatedByString:@"/"];
    NSMutableString *encPath = [NSMutableString string];
    int index = pathArray.count + 1;
    for (NSString *value in pathArray) {
        if ([value isEqualToString:pathArray.lastObject]) {
            [encPath appendFormat:@"%@",[self encryption:value andIndex:index]];
        }else{
            [encPath appendFormat:@"%@/",[self encryption:value andIndex:index]];
        }
        index = index*13%INDEX;
    }
    return encPath;
}

-(NSString *) encryptionPath:(NSString *) path isDirectory:(BOOL) isDirectory{
    NSArray *pathArray = [path componentsSeparatedByString:@"/"];
    NSMutableString *encPath = [NSMutableString string];
    int index = pathArray.count + 1;
    for (NSString *value in pathArray) {
        if ([value isEqualToString:pathArray.lastObject]) {
            if (isDirectory) {
                [encPath appendFormat:@"%@",[self encryption:value andIndex:index]];
            }else{
                fileName = [self encryption:value andIndex:index];
            }
        }else{
            [encPath appendFormat:@"%@/",[self encryption:value andIndex:index]];
        }
        index = index*13%INDEX;
    }
    return encPath;
}


-(NSData *) encryptionKey:(NSString *) doc andIndex:(int) index{
    NSString *key1 = [NSString stringWithFormat:@"%@%@%@",[IDENTIFIER substringFromIndex:index%INDEX].uppercaseString,doc,[IDENTIFIER substringToIndex:index%INDEX].lowercaseString];
    
    NSString *key2 = [NSString stringWithFormat:@"%@%@%@",[IDENTIFIER substringToIndex:index%INDEX].uppercaseString,[IDENTIFIER substringToIndex:index%INDEX].lowercaseString,doc.capitalizedString];
    
    NSString *format = [NSString stringWithFormat:@"%@_%@_%@",doc,key2.uppercaseString,key1.lowercaseString];
    return [HashValue sha256HashWithString:format];

}

-(NSString *) encryption:(NSString *) doc andIndex:(int) index{
    NSData *hashkeyData = [self encryptionKey:doc andIndex:index];
    
    NSData *enData = [[doc dataUsingEncoding:KEYENCODE] AES256EncryptWithKeyData:hashkeyData];
    
    NSString *enPath = [[enData base64EncodedStringWithOptions:0] stringByReplacingOccurrencesOfString:@"/" withString:@""];
    
    return enPath;
}

- (BOOL)fileExits:(NSString *)aFileName {
    NSFileManager *fileManager = [NSFileManager defaultManager];
    return [fileManager fileExistsAtPath:aFileName];
}

+ (NSString *)createTmpFileNameWithExtension:(NSString *)ext {
    return [[TSSFileManager applicationTemporaryDirectory] stringByAppendingPathComponent:FORMAT(@"%f.%@", [[NSDate date] timeIntervalSince1970],ext)];
}

+ (BOOL)deleteFile:(NSString *)filePath {
    NSFileManager *fileManager = [NSFileManager defaultManager];
    return [fileManager removeItemAtPath:filePath error:NULL];
}

+ (BOOL)fileExits:(NSString *)fileName {
    NSFileManager *fileManager = [NSFileManager defaultManager];
    return [fileManager fileExistsAtPath:fileName];
}

+ (BOOL)copyFile:(NSString *)fromFile toFile:(NSString *)toFile {
    DLog(@"copy file from %@ to %@", fromFile, toFile);
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    NSError *error;
    BOOL success = [fileManager copyItemAtPath:fromFile toPath:toFile error:&error];
    if (!success)
    {
        DLog(@"copyFile: %@", [error localizedDescription]);
        //		[TFUIUtil showMessage:@"Error" message:[error localizedDescription]];
        //		NSAssert1(0, @"Failed to copy file with message '%@'.", [error localizedDescription]);
    }
    return success;
}

+ (BOOL)createFolder:(NSString *)folder {
    if (folder == nil || [folder length] == 0) {
        return NO;
    }
    folder = [folder replace:@"\\" replaceWith:@"/"];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if ([fileManager fileExistsAtPath:folder]) {
        return YES;
    }
    NSError *error;
    BOOL success = [fileManager createDirectoryAtPath:folder withIntermediateDirectories:YES attributes:nil error:&error];

    if (!success) {
        DLog(@"createFolder: %@", [error localizedDescription]);
    }
    
    return success;
}

+ (NSDate *)getLastModifiedDate:(NSString *)path {
    NSFileManager *fm = [NSFileManager defaultManager];
    NSDictionary *attrs = [fm attributesOfItemAtPath:path error:nil];
    if (attrs != nil) {
        return (NSDate*)[attrs objectForKey: NSFileModificationDate];
    } else {
        return nil;
    }
}

+ (NSDate *)getCreationDate:(NSString *)path {
    NSFileManager *fm = [NSFileManager defaultManager];
    NSDictionary *attrs = [fm attributesOfItemAtPath:path error:nil];
    if (attrs != nil)  {
        return (NSDate*)[attrs objectForKey: NSFileCreationDate];
    } else {
        return nil;
    }
}

+ (long long int) getFileSize:(NSString *)path {
    NSFileManager *fm = [NSFileManager defaultManager];
    NSDictionary *attrs = [fm attributesOfItemAtPath:path error:nil];
    if (attrs != nil)  {
        return [(NSNumber*)[attrs objectForKey: NSFileSize] longLongValue];
    } else {
        return 0;
    }
}

- (BOOL)addSkipBackupAttributeToItemAtURL:(NSURL *)URL {
    const char* filePath = [[URL path] fileSystemRepresentation];
    const char* attrName = "com.apple.MobileBackup";
    u_int8_t attrValue = 1;
    int result = setxattr(filePath, attrName, &attrValue, sizeof(attrValue), 0, 0);
    return result == 0;
}

+ (NSString *)applicationResourceDirectory {
    NSString *documentPath = [[NSBundle mainBundle] resourcePath];
    return documentPath;
}

+ (NSString *)applicationDocumentsDirectory  {
    return [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
}

+ (NSString *)deleteFileIfExists:(NSString *)fileName {

    NSString *originalFile = [[TSSFileManager applicationTemporaryDirectory] stringByAppendingPathComponent:fileName];
    if ([TSSFileManager fileExits:originalFile]) {
        [TSSFileManager deleteFile:originalFile];
    }
    return originalFile;
}

+ (NSString *)applicationTemporaryDirectory {
    return NSTemporaryDirectory();
}

+ (NSString *)readContentOfFile:(NSString *)filePath length:(int)length encoding:(NSStringEncoding)encoding {
    NSFileManager *filemgr = [NSFileManager defaultManager];
    if ([filemgr fileExistsAtPath:filePath] == NO) {
        return nil;
    }
    NSData *databuffer;
    NSFileHandle *file;
    file = [NSFileHandle fileHandleForReadingAtPath:filePath];
    if (file == nil) {
        return nil;
    }
    databuffer = [file readDataOfLength:length];
    [file closeFile];
    NSString *aStr = [[NSString alloc] initWithData:databuffer encoding:encoding];
    return aStr;
}


@end
