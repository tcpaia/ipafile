//
//  NominationHelper.h
//  TSSProject
//
//  Created by WFF on 2018/2/28.
//  Copyright © 2018 AIA. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NominationHelper : NSObject

+ (NominationHelper *) getInstance;

- (BOOL) isNominatedFscByCode: (NSString *) fscCode;
@end
