//
//  NominationHelper.m
//  TSSProject
//
//  Created by WFF on 2018/2/28.
//  Copyright © 2018 AIA. All rights reserved.
//

#import "NominationHelper.h"
#import "Singleton.h"
#import "CustomerInfoDao.h"

@implementation NominationHelper

SYNTHESIZE_SINGLETON_FOR_CLASS(NominationHelper);

- (BOOL) isNominatedFscByCode: (NSString *) fscCode
{
    NSUInteger fscCustomerCount = [[CustomerInfoDao getInstance] selectCountWithCustometType: IMO_SMART_NO andInternalID: fscCode];
    if (fscCustomerCount < 1) {
        return YES;
    }
    return NO;
}
@end
