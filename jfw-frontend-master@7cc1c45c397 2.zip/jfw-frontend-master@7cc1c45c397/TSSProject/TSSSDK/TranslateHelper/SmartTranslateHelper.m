//
//  SmartTranslateHelper.m
//  TSSProject
//
//  Created by WFF on 25/09/2017.
//  Copyright © 2017 AIA. All rights reserved.
//

#import "SmartTranslateHelper.h"
#import "Singleton.h"
#import "SystemTss.h"
#import "MultiLanguageControl.h"
#import "TSSAppData.h"

@implementation SmartTranslateHelper

SYNTHESIZE_SINGLETON_FOR_CLASS(SmartTranslateHelper);

- (id) init
{
    if (self = [super init]) {
        [self initDictionaries];
    }
    return self;
}

- (void) initDictionaries
{
    //key : UIEventType ,value : EventType
    self.eventTypeForUIEventTypeDict = [NSMutableDictionary dictionaryWithObjectsAndKeys:APPOINTMENT_EVENT_TITLE, kApponment, ROADSHOW_EVENT_TITLE, kRoadshow, DOORKNOCK_EVENT_TITLE, kDoorKnock, STREETPROSPECTING_EVENT_TITLE, kStreetProspecting, OTHERS_EVENT_TITLE, kOthers, nil];

    //key : UIEventType ,value : AppointmentType
    self.appointmentTypeForUIEventTypeDict = [NSMutableDictionary dictionaryWithObjectsAndKeys:JFW_APPOINTMENT_TYPE, kApponment, JFW_ROADSHOW_TYPE, kRoadshow, JFW_DOORKNOCK_TYPE, kDoorKnock, JFW_STREETPROSPECTING_TYPE, kStreetProspecting, JFW_OTHERS_TYPE, kOthers, nil];
    
    //key : AppointmentType ,value : UIAppointmentType
    self.uiAppointmentTypeForAppointmentType = [NSMutableDictionary dictionaryWithObjectsAndKeys:kApponment, JFW_APPOINTMENT_TYPE, kRoadshow, JFW_ROADSHOW_TYPE, kDoorKnock, JFW_DOORKNOCK_TYPE, kStreetProspecting, JFW_STREETPROSPECTING_TYPE, kOthers, JFW_OTHERS_TYPE, nil];
    
    //key : AppointmentType ,value : UIEventType
    self.uiEventTypeForAppointmentTypeDict = [NSMutableDictionary dictionaryWithObjectsAndKeys:kApponment, JFW_APPOINTMENT_TYPE, kRoadshow, JFW_ROADSHOW_TYPE, kDoorKnock, JFW_DOORKNOCK_TYPE, kStreetProspecting, JFW_STREETPROSPECTING_TYPE, kOthers, JFW_OTHERS_TYPE, nil];
    
    self.appointmentTypeArray = [NSArray arrayWithObjects:JFW_APPOINTMENT_TYPE, JFW_ROADSHOW_TYPE, JFW_DOORKNOCK_TYPE, JFW_STREETPROSPECTING_TYPE, JFW_OTHERS_TYPE, nil];
    
}

- (NSString *) getEventTypeByUIEventType: (NSString *) uiEventType
{
    return [self.eventTypeForUIEventTypeDict objectForKey: uiEventType];
}

- (NSString *) getAppointmentTypeByUIEventType: (NSString *) uiEventType
{
    return [self.appointmentTypeForUIEventTypeDict objectForKey: uiEventType];
}

- (NSString *) getUIAppointmentTypeByAppointmentType: (NSString *) appointmentType
{
    if ([self.appointmentTypeArray containsObject: appointmentType]) {
        return [self.uiAppointmentTypeForAppointmentType objectForKey: appointmentType];
    }
    return MuliteLocalizedString(@"Select");
}

- (NSString *) getUIEventTypeByAppointmentType: (NSString *) appointmentType
{
    if ([self isLegalAppointmentType:appointmentType]) {
        return [self.uiEventTypeForAppointmentTypeDict objectForKey:appointmentType];
    }
    return @"";
}

- (BOOL) isLegalAppointmentType: (NSString *) appointmentType
{
    return [self.appointmentTypeArray containsObject: appointmentType];
}

- (NSString *) getAgentTypeForNomination
{
    if ([[TSSAppData getInstance].agentJfwRole isEqualToString:Leader]) {
        return NOMINATE_AGENT_TYPE_LEADER;
    }
    return NOMINATE_AGENT_TYPE_FSC;
}

- (NSString *) getAgentTypeForTrackerNewFsc
{
    if ([[TSSAppData getInstance].agentJfwRole isEqualToString:Leader]) {
        return NOMINATE_AGENT_TYPE_LEADER;
    }
    return TRACKER_NEW_FSC_AGENT_TYPE_AGENT;
}


@end
