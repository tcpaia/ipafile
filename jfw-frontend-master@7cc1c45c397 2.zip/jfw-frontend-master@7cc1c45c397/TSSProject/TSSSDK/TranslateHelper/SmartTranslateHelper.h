//
//  SmartTranslateHelper.h
//  TSSProject
//
//  Created by WFF on 25/09/2017.
//  Copyright © 2017 AIA. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SmartTranslateHelper : NSObject

@property (nonatomic, retain) NSMutableDictionary *eventTypeForUIEventTypeDict;
@property (nonatomic, retain) NSMutableDictionary *appointmentTypeForUIEventTypeDict;
@property (nonatomic, retain) NSMutableDictionary *uiAppointmentTypeForAppointmentType;
@property (nonatomic, retain) NSMutableDictionary *uiEventTypeForAppointmentTypeDict;

@property (nonatomic, retain) NSArray *appointmentTypeArray;

+ (SmartTranslateHelper *) getInstance;

- (NSString *) getEventTypeByUIEventType: (NSString *) uiEventType;

- (NSString *) getAppointmentTypeByUIEventType: (NSString *) uiEventType;

- (NSString *) getUIAppointmentTypeByAppointmentType: (NSString *) appointmentType;

- (NSString *) getUIEventTypeByAppointmentType: (NSString *) appointmentType;

- (BOOL) isLegalAppointmentType: (NSString *) appointmentType;

- (NSString *) getAgentTypeForNomination;

- (NSString *) getAgentTypeForTrackerNewFsc;

@end
