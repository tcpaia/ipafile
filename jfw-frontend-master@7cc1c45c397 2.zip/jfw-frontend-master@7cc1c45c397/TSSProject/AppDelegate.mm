//
//  AppDelegate.m
//  TSSProject
//
//  Created by TSS on 15/12/1.
//  Copyright © 2015年 AIA. All rights reserved.
//

#import "AppDelegate.h"
#import "TSSMenuController.h"
#import "ICSDrawerController.h"
#import "TSSAppData.h"
#import "SystemTss.h"
#import "LoginViewController.h"
#import "SmartLoginViewController.h"
#import "TSSValidationUtil.h"
#import "TSSAppSetting.h"
#import "TSSFactoryComponent.h"
#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import "NotificatinBean.h"
#import "NotificationDao.h"
#import "CustomerViewController.h"
#import "TSSSecurity.h"
#import "TSSAppDataBase.h"
//#import "SetUpViewController.h"
#import "Availability.h"
#import "NetworkingManager.h"
#import <UserNotifications/UserNotifications.h>
#import "FollowUpAndNoteViewController.h"
//#import "JFWViewController.h"
#import "TSSValidationUtil.h"
#import "EventManager.h"
#import "MultiLanguageControl.h"
#import "YBBackgroundShadeView.h"

#define KTouchItemPublicPosition @"touch1"
#define KTouchItemDashboard @"touch2"
#define KTouchItemCustomer @"touch3"
#define KTouchItemAppointment @"touch4"


@interface AppDelegate ()
{
    //GMSPlacesClient *placesClient;
    
}
@property (nonatomic) int suspendTimeStartFrom;
@property (nonatomic) BOOL didEnterBackGround;
@property (nonatomic,strong)CLLocationManager *locationManager;



@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    [[NetworkingManager getInstance] startMonitoringNetwork];
    [MultiLanguageControl initUserLanguage];
    UIUserNotificationSettings *notiSettings = [UIUserNotificationSettings settingsForTypes:(UIUserNotificationTypeNone | UIUserNotificationTypeBadge | UIUserNotificationTypeSound | UIUserNotificationTypeAlert) categories:nil];
    [[UIApplication sharedApplication] registerUserNotificationSettings:notiSettings];
    [[UIApplication sharedApplication] registerForRemoteNotifications];
    
    application.applicationIconBadgeNumber = 0;
    
    [EventManager shareInstance];
//#ifdef __IPHONE_9_0
//    [self init3DTouchActionShow:YES];
//#endif
    
//    if([TSSSecurity jailbroken]) {
//        //        [[TSSFactoryComponent getInstance] showAlertViewByType:SIInfomationType message:@"Smart can not run on jailbroken device" handler:^(SIAlertView *alertView) {
//        //            exit(0);
//        //        } otherHandler:nil];
//        UIAlertView *tAlert = [[UIAlertView alloc] initWithTitle:@"Information" message:@"Smart can not run on jailbroken device" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
//        [tAlert show];
//        return NO;
//    }
    
    //[[TSSAppDataBase getInstance] initLanguageDb];
    
    //[GMSServices provideAPIKey:GoogleKey];
    //BOOL FLAG = [GMSPlacesClient provideAPIKey:GoogleKey];
    
    //placesClient = [[GMSPlacesClient alloc] init];
    self.locationManager = [[CLLocationManager alloc]init];
    [self.locationManager requestWhenInUseAuthorization];
   // [self.locationManager requestAlwaysAuthorization];
    CLGeocoder *geocoder = [[CLGeocoder alloc] init];
    [geocoder reverseGeocodeLocation:_locationManager.location completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
        if (!error) {
            CLPlacemark *placeMark = [placemarks firstObject];
            [TSSAppData getInstance].address = placeMark.name;
        }
    }];
    
    
//    [self getAddressFromLocation:self.locationManager.location completionHandler:^(NSMutableDictionary *d) {
//        NSLog(@"address informations : %@", d);
//        //NSLog(@"formatted address : %@", [placemark.addressDictionary valueForKey:@"FormattedAddressLines"]);
//        NSLog(@"Street : %@", [d valueForKey:@"Street"]);
//        NSLog(@"ZIP code : %@", [d valueForKey:@"ZIP"]);
//        NSLog(@"City : %@", [d valueForKey:@"City"]);
//        if (![TSSValidationUtil isNilOrEmptyString:[d valueForKey:@"Street"]] ) {
//            [TSSAppData getInstance].address = [d valueForKey:@"Street"];
//        }
//        
//        // etc.
//    } failureHandler:^(NSError *error) {
//        NSLog(@"Error : %@", error);
//    }];
    

    //[self redirectNSlogToDocumentFolder];
    return YES;
}

- (void)userNotificationCenter:(UNUserNotificationCenter *)center willPresentNotification:(UNNotification *)notification withCompletionHandler:(void (^)(UNNotificationPresentationOptions))completionHandler
{
    NSDictionary *userInfo = notification.request.content.userInfo;
    
    DLog(@"willPresentNotification == %@",userInfo);
    //可以设置当收到通知后, 有哪些效果呈现(声音/提醒/数字角标)
    completionHandler(UNNotificationPresentationOptionBadge | UNNotificationPresentationOptionSound | UNNotificationPresentationOptionAlert);
}

- (void)userNotificationCenter:(UNUserNotificationCenter *)center didReceiveNotificationResponse:(UNNotificationResponse *)response withCompletionHandler:(void(^)())completionHandler
{
    NSDictionary *userInfo = response.notification.request.content.userInfo;
    DLog(@"didReceiveNotificationResponse == %@",userInfo);
    completionHandler();
}

//如果是以前的旧框架, 此方法 前台/后台/退出/静默推送都可以处理
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler
{
    //[self downLoadNotifications];
    //    //当APP在前台运行时
    //    if( [UIApplication sharedApplication].applicationState == UIApplicationStateActive)
    //    {
    //        [self jumpViewController:userInfo];
    //    }
    //当APP在后台运行时，当有通知栏消息时，点击它，就会执行下面的方法跳转到相应的页面
//    if ([UIApplication sharedApplication].applicationState == UIApplicationStateInactive)
//    {
//        [self jumpViewController:userInfo];
//    }
    DLog(@"didReceiveRemoteNotification.userInfo == %@",userInfo);
    
    completionHandler(UIBackgroundFetchResultNewData);
}

- (void)downLoadNotifications
{
    NSArray *datas = [[NotificationDao getInstance] getBeansWithCount:1];
    NotificatinBean *temp;
    if (datas.count > 0){
        temp = [datas firstObject];
    }
    NSString *lastUpdateTimelong = [TSSValidationUtil converStringToEmptyString:temp.lastupdatedatetimeLong];
    [[NetworkingManager getInstance] downLoadNotifactionAndLastUpdateTime:lastUpdateTimelong andRecordNo:@"0" andCallBack:^(id obj) {
        if (![obj isKindOfClass:[NSError class]]) {
            NSArray *arr = (NSArray *)obj;
            if (arr.count > 0){
                for (NotificatinBean *notiBean in arr){
                    NotificatinBean *find = [[NotificationDao getInstance] getBeanWithoid:notiBean.oid];
                    if(find != nil){
                        find.readStatus = notiBean.readStatus;
                        find.uploadStatus = UPLOAD_STATUS_OK;
                        [find save];
                    }
                    else{
                        [notiBean save];
                    }
                }
                [[NSNotificationCenter defaultCenter] postNotificationName:kAlertRefreshFollowUpAndNote object:nil];
            }
        }
    }];
}

- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
    DLog(@"deviceToken == %@",deviceToken);
    NSString *dt = [[deviceToken description] stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"<>"]];
    dt = [dt stringByReplacingOccurrencesOfString:@" " withString:@""];
    //NSLog(@"APN trimmed device token: %@", dt);
    //    if ([AppVariable getInstance].ShouldLogDeviceToken) {
    //        TFSLogInfo(@"deviceToken == %@,APN trimmed device token: %@", deviceToken, dt)
    //    }
    if (![TSSValidationUtil isNilOrEmptyString:dt]) {
        [TSSAppData getInstance].deviceToken = [NSString stringWithFormat:@"%@", dt];
    } else {
        [TSSAppData getInstance].deviceToken = @"";
    }
    
}

- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error {
    DLog(@"error == %@",error);
    //    if ([AppVariable getInstance].ShouldLogDeviceToken) {
    //        TFSLogError(@"didFailToRegisterForRemoteNotificationsWithError error = %@",error);
    //    }
}

- (void)getAddressFromLocation:(CLLocation *)location completionHandler:(void (^)(NSMutableDictionary *placemark))completionHandler failureHandler:(void (^)(NSError *error))failureHandler
{
//    NSMutableDictionary *d = [NSMutableDictionary dictionary];
    CLGeocoder *geocoder = [[CLGeocoder alloc]init];
    [geocoder reverseGeocodeLocation:location completionHandler:^(NSArray *placemarks, NSError *error) {
        if (failureHandler && (error || placemarks.count == 0)) {
            failureHandler(error);
        } else {
            CLPlacemark *placemark = [placemarks objectAtIndex:0];
            if(completionHandler) {
                completionHandler(placemark.addressDictionary);
            }
        }
    }];
}
//
//- (void)jumpViewController:(NSDictionary*)notifactionInfo
//{
//    if ([[notifactionInfo objectForKey:@"PNSTYPE"] isEqualToString:@"appointment"])
//    {
//        FollowUpAndNoteViewController *followUp = [[FollowUpAndNoteViewController alloc]initWithNibName:@"BaseViewController" bundle:nil];
//        followUp.titleTXT = kApponment;
//        //followUp.isUploadViewC = YES;
//        [[TSSAppData getInstance].drawer replaceCenterViewControllerWithViewController:followUp];
//    }
//    else if ([[notifactionInfo objectForKey:@"PNSTYPE"] isEqualToString:@"jfw"]){
//        JFWViewController *jfwViewC = [[JFWViewController alloc]initWithNibName:@"BaseViewController" bundle:nil];
//        [jfwViewC.navigationController popToRootViewControllerAnimated:YES];
//        jfwViewC.titleTXT = @"JFW";
//        [[TSSAppData getInstance].drawer replaceCenterViewControllerWithViewController:jfwViewC];
//    }
//}



- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    exit(0);
}
- (void)applicationWillResignActive:(UIApplication *)application {
    [[YBBackgroundShadeView defaultShadeView] appearShade];
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
    pasteboard.string = @"";
    [pasteboard setItems:@[]];
    self.didEnterBackGround = YES;
    self.suspendTimeStartFrom = [[NSDate date] timeIntervalSince1970];
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    [[TSSAppDataBase getInstance] initLanguageDb];
    [[YBBackgroundShadeView defaultShadeView] disAppearShade];
}



- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    [[YBBackgroundShadeView defaultShadeView] disAppearShade];
    [self calculateInativeTime];
    
}

- (void)calculateInativeTime
{
    int now = [[NSDate date] timeIntervalSince1970];
    
    DLog(@"applicationDidBecomeActive %d %d-%d=%d", self.didEnterBackGround, self.suspendTimeStartFrom, now, now-self.suspendTimeStartFrom);
    
    if(self.didEnterBackGround && (now - self.suspendTimeStartFrom > ([TSSAppSetting getInstance].timeoutMinute) * 60))
    {
        [self showTimeoutAlert];
    }
    //reset the flag
    self.didEnterBackGround = NO;
}

- (void)showTimeoutAlert {
    NSString *alert_str = FORMAT(@"App has been inactive for %d minutes and will auto logout.", [TSSAppSetting getInstance].timeoutMinute);
    
    //        [[TSSFactoryComponent getInstance] showAlertViewByType:SIInfomationType message:alert_str handler:^(SIAlertView *alertView) {
    //            exit(0);
    //        } otherHandler:nil];
    UIAlertView *tAlert = [[UIAlertView alloc] initWithTitle:@"Information" message:alert_str delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
    [tAlert show];
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}
- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation {
    BOOL handled = [[FBSDKApplicationDelegate sharedInstance] application:application
                                                                  openURL:url
                                                        sourceApplication:sourceApplication
                                                               annotation:annotation
                    ];
    // Add any custom logic here.
    return handled;
}


/**
 *  手动添加3D touch功能
 */

- (void)onGetNetworkState:(int)iError
{
    if (0 == iError) {
        DLog(@"联网成功");
    }
    else{
        DLog(@"onGetNetworkState %d",iError);
    }
    
}

- (void)onGetPermissionState:(int)iError
{
    if (0 == iError) {
        DLog(@"授权成功");
    }
    else {
        DLog(@"onGetPermissionState %d",iError);
    }
}

// 将NSlog打印信息保存到Document目录下的文件中
- (void)redirectNSlogToDocumentFolder
{
    //document文件夹
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentDirectory = [paths objectAtIndex:0];
    //
    NSString *foldPath = [documentDirectory stringByAppendingFormat:@"/appLog"];
    
    //文件保护等级
    NSDictionary *attribute = [NSDictionary dictionaryWithObject:NSFileProtectionNone
                                                          forKey:NSFileProtectionKey];
    [[NSFileManager defaultManager] createDirectoryAtPath:foldPath withIntermediateDirectories:YES attributes:attribute error:nil];
    
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setLocale:[[NSLocale alloc] initWithLocaleIdentifier:@"zh_CN"]];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"]; //每次启动后都保存一个新的日志文件中
    NSString *dateStr = [formatter stringFromDate:[NSDate date]];
    NSString *logFilePath = [foldPath stringByAppendingFormat:@"/%@.log",dateStr];
    
    [self checkFlieProtection:logFilePath];
    // 将log输入到文件
    freopen([logFilePath cStringUsingEncoding:NSASCIIStringEncoding], "a+", stdout);
    freopen([logFilePath cStringUsingEncoding:NSASCIIStringEncoding], "a+", stderr);
}

- (void)checkFlieProtection:(NSString *)path {
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSString *pathSqlite = path;
    NSDictionary *attributeSql = [fileManager attributesOfItemAtPath:pathSqlite error:nil];
    if ([[attributeSql objectForKey:NSFileProtectionKey] isEqualToString:NSFileProtectionComplete]) {
        NSDictionary *attribute = [NSDictionary dictionaryWithObject:NSFileProtectionCompleteUntilFirstUserAuthentication
                                                              forKey:NSFileProtectionKey];
        [fileManager setAttributes:attribute ofItemAtPath:pathSqlite error:nil];
        DLog(@"改变文件权限 %@ : %@",path,attribute);
    }
}

- (BOOL)application:(UIApplication *)application shouldAllowExtensionPointIdentifier:(NSString *)extensionPointIdentifier
{
    return NO;
}

@end
